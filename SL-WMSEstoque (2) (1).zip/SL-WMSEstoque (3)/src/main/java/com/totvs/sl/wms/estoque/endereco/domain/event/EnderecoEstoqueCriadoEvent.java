package com.totvs.sl.wms.estoque.endereco.domain.event;

import java.math.BigDecimal;

import com.totvs.sl.wms.estoque.endereco.domain.model.Endereco;
import com.totvs.sl.wms.estoque.endereco.domain.model.EnderecoId;
import com.totvs.sl.wms.estoque.unidade.domain.model.UnidadeId;
import com.totvs.sl.wms.estoque.util.amqp.SubjectDomainEvent;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data(staticConstructor = "of")
@EqualsAndHashCode(callSuper = false)
public final class EnderecoEstoqueCriadoEvent extends SubjectDomainEvent implements SubjectEndereco {

	private final EnderecoId id;
	private final UnidadeId unidadeId;
	private final EnderecoEstoqueCriadoEventCapacidade capacidade;

	@Data(staticConstructor = "of")
	public static final class EnderecoEstoqueCriadoEventCapacidade {
		private final Integer unitizador;
		private final BigDecimal peso;
		private final EnderecoEstoqueCriadoEventDimensao dimensao;
	}

	@Data(staticConstructor = "of")
	public static final class EnderecoEstoqueCriadoEventDimensao {
		private final BigDecimal altura;
		private final BigDecimal largura;
		private final BigDecimal comprimento;
	}

	public static EnderecoEstoqueCriadoEvent from(Endereco endereco) {

		var capacidade = endereco.getCapacidade();

		EnderecoEstoqueCriadoEventCapacidade eventCapacidade = null;

		if (capacidade.isPresent()) {

			var unitizador = capacidade.get().getUnitizador().orElse(null);
			var peso = capacidade.get().getPeso().orElse(null);

			EnderecoEstoqueCriadoEventDimensao dimensao = null;

			if (capacidade.get().getDimensao().isPresent()) {
				dimensao = EnderecoEstoqueCriadoEventDimensao.of(capacidade.get()
																		   .getDimensao()
																		   .orElseThrow()
																		   .getAltura(),
																 capacidade.get()
																		   .getDimensao()
																		   .orElseThrow()
																		   .getLargura(),
																 capacidade.get()
																		   .getDimensao()
																		   .orElseThrow()
																		   .getComprimento());
			}

			eventCapacidade = EnderecoEstoqueCriadoEventCapacidade.of(unitizador, peso, dimensao);

		}

		return EnderecoEstoqueCriadoEvent.of(endereco.getId(), endereco.getUnidadeId(), eventCapacidade);
	}
}
