package com.totvs.sl.wms.estoque.estoque.domain.event;

import java.math.BigDecimal;
import java.util.List;

import com.totvs.sl.wms.estoque.estoque.domain.model.Estoque;
import com.totvs.sl.wms.estoque.estoque.domain.model.EstoqueId;
import com.totvs.sl.wms.estoque.movimentoestoque.domain.model.MovimentoEstoque;
import com.totvs.sl.wms.estoque.unidade.domain.model.UnidadeId;
import com.totvs.sl.wms.estoque.util.amqp.TransactionalEvent;

import lombok.Builder;
import lombok.Data;
import lombok.Getter;
import lombok.ToString;

@Getter
@ToString
public final class EstoqueBloqueadoSaidaEfetuadaEvent extends TransactionalEvent implements SubjectSaidaEstoque {

	private final UnidadeId unidadeId;
	private final EstoqueSaida estoque;

	@Data
	@Builder
	public static final class EstoqueSaida {
		private final EstoqueId id;
		private final BigDecimal quantidadeSaida;
		private final BigDecimal saldo;
		private final BigDecimal saldoReservado;
		private final BigDecimal saldoDisponivel;
		private final BigDecimal quantidadeBloqueadaMovimentacaoNaoReservada;
		private final BigDecimal quantidadeBloqueadaMovimentacaoReservada;
		private final BigDecimal quantidadeBloqueadaMovimentacaoTotal;
		private final List<EstoqueAtributoSaldoEvent> atributosSaldo;
	}

	@Builder
	private EstoqueBloqueadoSaidaEfetuadaEvent(String generatedBy,
											   String transactionId,
											   UnidadeId unidadeId,
											   EstoqueSaida estoque) {
		super(generatedBy, transactionId);
		this.unidadeId = unidadeId;
		this.estoque = estoque;
	}

	public static EstoqueBloqueadoSaidaEfetuadaEvent from(Estoque estoque, MovimentoEstoque movimentoEstoque) {
		return EstoqueBloqueadoSaidaEfetuadaEvent.builder()
												 .unidadeId(estoque.getUnidadeId())
												 .transactionId(movimentoEstoque.getOrigem().getId().toString())
												 .generatedBy(movimentoEstoque.getOrigem().getOrigem())
												 .estoque(EstoqueSaida.builder()
																	  .id(estoque.getId())
																	  .quantidadeSaida(movimentoEstoque.getQuantidade())
																	  .saldo(estoque.getSaldo())
																	  .saldoReservado(estoque.getQuantidadeReservada())
																	  .saldoDisponivel(estoque.getSaldoDisponivel())
																	  .quantidadeBloqueadaMovimentacaoNaoReservada(estoque.getQuantidadeBloqueadaParaMovimentacaoEstoqueNaoReservada())
																	  .quantidadeBloqueadaMovimentacaoReservada(estoque.getQuantidadeBloqueadaParaMovimentacaoEstoqueReservada())
																	  .quantidadeBloqueadaMovimentacaoTotal(estoque.getQuantidadeBloqueadaParaMovimentacaoEstoqueTotal())
																	  .atributosSaldo(EstoqueAtributoSaldoEvent.from(estoque.getAtributosSaldo()))
																	  .build())
												 .build();

	}
}
