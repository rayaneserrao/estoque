package com.totvs.sl.wms.estoque.endereco.domain.event;

import java.math.BigDecimal;

import com.totvs.sl.wms.estoque.endereco.domain.model.Endereco;
import com.totvs.sl.wms.estoque.endereco.domain.model.EnderecoId;
import com.totvs.sl.wms.estoque.util.amqp.SubjectConfiguracao;
import com.totvs.sl.wms.estoque.util.amqp.SubjectDomainEvent;

import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
@Builder
public final class EnderecoOcupacaoPrevistaAtualizadaEvent extends SubjectDomainEvent implements SubjectConfiguracao {

	private final EnderecoId id;
	private final Integer unitizador;
	private final BigDecimal peso;
	private final BigDecimal cubagem;

	public static EnderecoOcupacaoPrevistaAtualizadaEvent from(Endereco endereco) {

		return EnderecoOcupacaoPrevistaAtualizadaEvent.builder()
													  .id(endereco.getId())
													  .unitizador(endereco.getOcupacaoPrevista().getUnitizador())
													  .peso(endereco.getOcupacaoPrevista().getPeso())
													  .cubagem(endereco.getOcupacaoPrevista().getCubagem())
													  .build();
	}

}
