package com.totvs.sl.wms.estoque.estoque.amqp.cmd.validator;

import java.util.Objects;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import org.springframework.util.CollectionUtils;

import com.totvs.sl.wms.estoque.estoque.amqp.cmd.EfetuarTransferenciaEnderecoEstoqueCmd;

public class AtributosOpcionaisTransferenciaEstoqueValidator implements
		ConstraintValidator<ValidarAtributosOpcionaisTransferenciaEstoque, EfetuarTransferenciaEnderecoEstoqueCmd> {

	public static final String BLOQUEIO_CONFLITA_COM_RESERVAS = "{EfetuarTransferenciaEnderecoEstoqueCmd.bloqueioMovimentacaoEstoqueId.conflitaComReservas}";
	public static final String BLOQUEIO_CONFLITA_COM_QUANTIDADE = "{EfetuarTransferenciaEnderecoEstoqueCmd.bloqueioMovimentacaoEstoqueId.conflitaComQuantidade}";
	public static final String RESERVAS_CONFLITAM_COM_QUANTIDADE = "{EfetuarTransferenciaEnderecoEstoqueCmd.reservasDefinitivas.conflitaComQuantidade}";

	@Override
	public boolean isValid(EfetuarTransferenciaEnderecoEstoqueCmd object, ConstraintValidatorContext context) {
		var hasViolation = false;

		context.disableDefaultConstraintViolation();
		if (Objects.nonNull(object.getBloqueioMovimentacaoEstoqueId())) {
			if (!CollectionUtils.isEmpty(object.getReservasDefinitivas())) {
				hasViolation = true;
				context.buildConstraintViolationWithTemplate(BLOQUEIO_CONFLITA_COM_RESERVAS).addConstraintViolation();
			}
			if (object.getQuantidade() != null) {
				hasViolation = true;
				context.buildConstraintViolationWithTemplate(BLOQUEIO_CONFLITA_COM_QUANTIDADE).addConstraintViolation();
			}
		} else {
			if (!CollectionUtils.isEmpty(object.getReservasDefinitivas()) && object.getQuantidade() != null) {
				hasViolation = true;
				context.buildConstraintViolationWithTemplate(RESERVAS_CONFLITAM_COM_QUANTIDADE)
					   .addConstraintViolation();
			}
		}
		return !hasViolation;
	}

}
