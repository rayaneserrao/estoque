package com.totvs.sl.wms.estoque.estoque.amqp.cmd;

import java.util.Objects;

import javax.validation.constraints.NotNull;

import com.totvs.sl.wms.estoque.bloqueiomovimentacaounitizador.domain.model.BloqueioMovimentacaoUnitizadorId;
import com.totvs.sl.wms.estoque.endereco.domain.model.EnderecoId;
import com.totvs.sl.wms.estoque.estoque.domain.event.SubjectMovimentacaoEstoque;
import com.totvs.sl.wms.estoque.movimentovertical.domain.model.MovimentoVertical;
import com.totvs.sl.wms.estoque.unidade.domain.model.UnidadeId;
import com.totvs.sl.wms.estoque.unitizador.domain.model.UnitizadorId;
import com.totvs.sl.wms.estoque.util.amqp.EstoqueOutput;
import com.totvs.sl.wms.estoque.util.amqp.TransactionalCmd;

import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = true)
public final class EfetuarTransferenciaEnderecoUnitizadorEstoqueCmd extends TransactionalCmd
		implements SubjectMovimentacaoEstoque, EstoqueOutput {

	public static final String NAME = "EfetuarTransferenciaEnderecoUnitizadorEstoqueCmd";
	public static final String CONDITIONAL_EXPRESSION = "headers['type']=='" + NAME + "'";
	public static final String GENERATED_BY_MOVIMENTO_VERTICAL = "MOVIMENTO_VERTICAL";

	@NotNull(message = "{EfetuarTransferenciaEnderecoUnitizadorEstoqueCmd.unidadeId.NotNull}")
	private final UnidadeId unidadeId;

	@NotNull(message = "{EfetuarTransferenciaEnderecoUnitizadorEstoqueCmd.unitizadorId.NotNull}")
	private final UnitizadorId unitizadorId;

	@NotNull(message = "{EfetuarTransferenciaEnderecoUnitizadorEstoqueCmd.enderecoId.NotNull}")
	private final EnderecoId enderecoId;

	private final BloqueioMovimentacaoUnitizadorId bloqueioMovimentacaoUnitizadorId;

	private final String chaveAcesso;

	@Builder
	private EfetuarTransferenciaEnderecoUnitizadorEstoqueCmd(String generatedBy,
															 String transactionId,
															 UnidadeId unidadeId,
															 UnitizadorId unitizadorId,
															 EnderecoId enderecoId,
															 BloqueioMovimentacaoUnitizadorId bloqueioMovimentacaoUnitizadorId,
															 String chaveAcesso) {
		super(generatedBy, transactionId);
		this.unidadeId = unidadeId;
		this.unitizadorId = unitizadorId;
		this.enderecoId = enderecoId;
		this.bloqueioMovimentacaoUnitizadorId = bloqueioMovimentacaoUnitizadorId;
		this.chaveAcesso = chaveAcesso;
	}

	public static EfetuarTransferenciaEnderecoUnitizadorEstoqueCmd from(MovimentoVertical movimentoVertical,
																		String chaveAcesso) {
		return EfetuarTransferenciaEnderecoUnitizadorEstoqueCmd.builder()
															   .generatedBy(GENERATED_BY_MOVIMENTO_VERTICAL)
															   .transactionId(Objects.toString(movimentoVertical.getId()))
															   .unidadeId(movimentoVertical.getUnidadeId())
															   .unitizadorId(movimentoVertical.getUnitizadorId())
															   .enderecoId(movimentoVertical.getEnderecoIdDestino()
																							.get())
															   .bloqueioMovimentacaoUnitizadorId(null)
															   .chaveAcesso(chaveAcesso)
															   .build();
	}

}
