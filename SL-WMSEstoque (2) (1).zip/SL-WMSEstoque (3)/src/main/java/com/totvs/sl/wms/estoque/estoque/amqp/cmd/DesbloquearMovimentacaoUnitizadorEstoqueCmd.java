package com.totvs.sl.wms.estoque.estoque.amqp.cmd;

import javax.validation.constraints.NotNull;

import com.totvs.sl.wms.estoque.bloqueiomovimentacaounitizador.domain.model.BloqueioMovimentacaoUnitizadorId;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor(staticName = "of")
@NoArgsConstructor(access = AccessLevel.PRIVATE, force = true)
public final class DesbloquearMovimentacaoUnitizadorEstoqueCmd {

	public static final String NAME = "DesbloquearMovimentacaoUnitizadorEstoqueCmd";
	public static final String CONDITIONAL_EXPRESSION = "headers['type']=='" + NAME + "'";

	@NotNull(message = "{DesbloquearMovimentacaoUnitizadorEstoqueCmd.bloqueioMovimentacaoUnitizadorId.NotNull}")
	private final BloqueioMovimentacaoUnitizadorId bloqueioMovimentacaoUnitizadorId;
}
