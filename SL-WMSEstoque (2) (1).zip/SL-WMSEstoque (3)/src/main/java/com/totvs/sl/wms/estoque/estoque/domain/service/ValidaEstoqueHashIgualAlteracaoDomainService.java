package com.totvs.sl.wms.estoque.estoque.domain.service;

import java.util.List;
import java.util.Objects;

import org.springframework.stereotype.Component;

import com.totvs.sl.wms.estoque.caracteristicavalor.domain.model.CaracteristicaValor;
import com.totvs.sl.wms.estoque.estoque.domain.model.Estoque;
import com.totvs.sl.wms.estoque.estoque.domain.model.EstoqueHash;
import com.totvs.sl.wms.estoque.estoque.exception.WMSEstoqueSemInformacaoAlteradaException;

import lombok.AllArgsConstructor;

@Component
@AllArgsConstructor
public class ValidaEstoqueHashIgualAlteracaoDomainService {

	public void validar(Estoque estoque, EstoqueHash estoqueHash) {
		if (estoque.getHash().equals(estoqueHash.getHash())) {
			throw new WMSEstoqueSemInformacaoAlteradaException(estoque.getUnidadeId().toString(),
															   estoque.getProdutoId().toString(),
															   estoque.getSkuId().toString(),
															   Objects.toString(estoque.getUnitizadorId(), null),
															   estoque.getTipoEstoqueId().toString(),
															   estoque.getEnderecoId().toString(),
															   estoque.getSituacaoCorrente().toString(),
															   estoque.getAvariado().toString(),
															   this.montarCaracteristicas(estoque.getCaracteristicas()));
		}
	}

	private String montarCaracteristicas(List<CaracteristicaValor<?>> caracteristicas) {

		var strBuilder = new StringBuilder();

		caracteristicas.forEach(caracteristica -> {
			var strCaracteristica = caracteristica.getCaracteristicaConfiguracaoId().toString() + " Valor: "
					+ caracteristica.getValor().toString() + " | ";
			strBuilder.append(strCaracteristica);
		});

		return strBuilder.toString();
	}
}
