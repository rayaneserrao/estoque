package com.totvs.sl.wms.estoque.endereco.amqp.event;

import java.util.List;

import com.totvs.sl.wms.estoque.endereco.domain.model.EnderecoId;
import com.totvs.sl.wms.estoque.estoque.domain.event.SubjectBloqueioEstoque;
import com.totvs.sl.wms.estoque.util.amqp.RejectedEvent;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data(staticConstructor = "of")
@EqualsAndHashCode(callSuper = false)
public final class BloquearEntradaEstoqueEnderecoRejeitadoEvent extends RejectedEvent
		implements SubjectBloqueioEstoque {

	public static final String NAME = "BloquearEntradaEstoqueEnderecoRejeitadoEvent";

	public static final String CONDITIONAL_EXPRESSION = "headers['type']=='" + NAME + "'";

	private final EnderecoId enderecoId;
	private final List<Inconsistencia> inconsistencias;

	@Data(staticConstructor = "of")
	public static final class Inconsistencia {
		private final String id;
		private final String mensagem;
		private final String detalhe;
	}
}
