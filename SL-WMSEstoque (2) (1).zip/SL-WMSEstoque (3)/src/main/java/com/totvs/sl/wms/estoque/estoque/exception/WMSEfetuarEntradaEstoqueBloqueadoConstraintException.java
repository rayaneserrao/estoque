package com.totvs.sl.wms.estoque.estoque.exception;

import java.util.Set;

import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;

import com.totvs.tjf.api.context.stereotype.error.ApiBadRequest;

@ApiBadRequest("WMSEfetuarEntradaEstoqueBloqueadoConstraintException")
public class WMSEfetuarEntradaEstoqueBloqueadoConstraintException extends ConstraintViolationException {

	private static final long serialVersionUID = 2741347982195889111L;

	public WMSEfetuarEntradaEstoqueBloqueadoConstraintException(Set<? extends ConstraintViolation<?>> constraintViolations) {
		super(constraintViolations);
	}
}
