package com.totvs.sl.wms.estoque.estoque.api;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

import java.util.List;
import java.util.Optional;

import javax.annotation.security.RolesAllowed;

import org.springframework.http.ResponseEntity;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.totvs.sl.wms.estoque.atributoestoquevalor.api.dto.AtributoEstoqueValorDTO;
import com.totvs.sl.wms.estoque.caracteristicavalor.api.dto.CaracteristicaValorDTO;
import com.totvs.sl.wms.estoque.estoque.api.dto.AdicionarSeloEstoqueDTO;
import com.totvs.sl.wms.estoque.estoque.api.dto.AlterarEstoqueAtributoDTO;
import com.totvs.sl.wms.estoque.estoque.api.dto.AlterarEstoqueAvariadoDTO;
import com.totvs.sl.wms.estoque.estoque.api.dto.AlterarEstoqueCaracteristicaDTO;
import com.totvs.sl.wms.estoque.estoque.api.dto.AlterarEstoqueSKUDTO;
import com.totvs.sl.wms.estoque.estoque.api.dto.AlterarEstoqueSituacaoDTO;
import com.totvs.sl.wms.estoque.estoque.api.dto.AlterarEstoqueTipoEstoqueDTO;
import com.totvs.sl.wms.estoque.estoque.api.dto.DividirFundirDTO;
import com.totvs.sl.wms.estoque.estoque.api.dto.EfetuarBaixaEstoqueDTO;
import com.totvs.sl.wms.estoque.estoque.api.dto.EntradaEstoqueLiberadoDTO;
import com.totvs.sl.wms.estoque.estoque.api.dto.RemoverSeloEstoqueDTO;
import com.totvs.sl.wms.estoque.estoque.api.dto.ReunitizarDTO;
import com.totvs.sl.wms.estoque.estoque.api.dto.TransferirEnderecoEstoqueDTO;
import com.totvs.sl.wms.estoque.estoque.api.dto.TransferirEnderecoReservaDTO;
import com.totvs.sl.wms.estoque.estoque.api.dto.TransferirEnderecoUnitizadorDTO;
import com.totvs.sl.wms.estoque.estoque.api.result.TransferirEnderecoUnitizadorResult;
import com.totvs.sl.wms.estoque.estoque.application.EstoqueAdicionarRemoverSeloApplicationService;
import com.totvs.sl.wms.estoque.estoque.application.EstoqueAlterarApplicationService;
import com.totvs.sl.wms.estoque.estoque.application.EstoqueDividirFundirApplicationService;
import com.totvs.sl.wms.estoque.estoque.application.EstoqueEfetuarEntradaApplicationService;
import com.totvs.sl.wms.estoque.estoque.application.EstoqueEfetuarSaidaApplicationService;
import com.totvs.sl.wms.estoque.estoque.application.EstoqueReunitizarApplicationService;
import com.totvs.sl.wms.estoque.estoque.application.EstoqueTransferirApplicationService;
import com.totvs.sl.wms.estoque.estoque.application.command.AdicionarSeloEstoqueCommand;
import com.totvs.sl.wms.estoque.estoque.application.command.AlterarEstoqueAtributoCommand;
import com.totvs.sl.wms.estoque.estoque.application.command.AlterarEstoqueAvariadoCommand;
import com.totvs.sl.wms.estoque.estoque.application.command.AlterarEstoqueCaracteristicaCommand;
import com.totvs.sl.wms.estoque.estoque.application.command.AlterarEstoqueSKUCommand;
import com.totvs.sl.wms.estoque.estoque.application.command.AlterarEstoqueSituacaoCommand;
import com.totvs.sl.wms.estoque.estoque.application.command.AlterarEstoqueTipoEstoqueCommand;
import com.totvs.sl.wms.estoque.estoque.application.command.EfetuarDivisaoFusaoEstoqueCommand;
import com.totvs.sl.wms.estoque.estoque.application.command.EfetuarEntradaEstoqueLiberadoCommand;
import com.totvs.sl.wms.estoque.estoque.application.command.EfetuarReunitizacaoEstoqueCommand;
import com.totvs.sl.wms.estoque.estoque.application.command.EfetuarSaidaEstoqueCommand;
import com.totvs.sl.wms.estoque.estoque.application.command.EfetuarTransferenciaEnderecoEstoqueCommand;
import com.totvs.sl.wms.estoque.estoque.application.command.EfetuarTransferenciaEnderecoReservaEstoqueCommand;
import com.totvs.sl.wms.estoque.estoque.application.command.EfetuarTransferenciaEnderecoUnitizadorEstoqueCommand;
import com.totvs.sl.wms.estoque.estoque.application.command.RemoverSeloEstoqueCommand;
import com.totvs.sl.wms.estoque.estoque.domain.model.EstoqueId;
import com.totvs.sl.wms.estoque.estoque.domain.model.SeloEstoque;
import com.totvs.sl.wms.estoque.estoque.domain.model.SituacaoEstoqueValor;
import com.totvs.sl.wms.estoque.estoque.exception.WMSAdicionarSeloEstoqueConstraintException;
import com.totvs.sl.wms.estoque.estoque.exception.WMSAlteracaoEstoqueAtributoConstraintException;
import com.totvs.sl.wms.estoque.estoque.exception.WMSAlteracaoEstoqueAvariadoConstraintException;
import com.totvs.sl.wms.estoque.estoque.exception.WMSAlteracaoEstoqueCaracteristicaConstraintException;
import com.totvs.sl.wms.estoque.estoque.exception.WMSAlteracaoEstoqueSKUConstraintException;
import com.totvs.sl.wms.estoque.estoque.exception.WMSAlteracaoEstoqueSituacaoConstraintException;
import com.totvs.sl.wms.estoque.estoque.exception.WMSAlteracaoEstoqueTipoEstoqueConstraintException;
import com.totvs.sl.wms.estoque.estoque.exception.WMSEfetuarBaixaEstoqueConstraintException;
import com.totvs.sl.wms.estoque.estoque.exception.WMSEfetuarDivisaoFusaoEstoqueConstraintException;
import com.totvs.sl.wms.estoque.estoque.exception.WMSEfetuarEntradaEstoqueLiberadoConstraintException;
import com.totvs.sl.wms.estoque.estoque.exception.WMSEfetuarTransferenciaEnderecoEstoqueConstraintException;
import com.totvs.sl.wms.estoque.estoque.exception.WMSEfetuarTransferenciaEnderecoEstoqueReservadoConstraintException;
import com.totvs.sl.wms.estoque.estoque.exception.WMSRemoverSeloEstoqueConstraintException;
import com.totvs.sl.wms.estoque.estoque.exception.WMSReunitizacaoConstraintException;
import com.totvs.sl.wms.estoque.estoque.exception.WMSTransferirEnderecoUnitizadorException;
import com.totvs.sl.wms.estoque.origem.domain.model.Origem;
import com.totvs.sl.wms.estoque.origem.domain.model.OrigemId;
import com.totvs.sl.wms.estoque.selo.api.dto.SeloEstoqueDTO;
import com.totvs.sl.wms.estoque.usuario.domain.model.UsuarioPerfil;
import com.totvs.sl.wms.estoque.util.Constants;
import com.totvs.tjf.api.context.stereotype.ApiGuideline;
import com.totvs.tjf.core.validation.ValidatorService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import lombok.AllArgsConstructor;

@RestController
@AllArgsConstructor
@RequestMapping(path = EstoqueController.PATH, produces = APPLICATION_JSON_VALUE, consumes = APPLICATION_JSON_VALUE)
@ApiGuideline(ApiGuideline.ApiGuidelineVersion.V2)
public class EstoqueController {

	public static final String PATH = "/api/v1/estoques";

	private final EstoqueTransferirApplicationService estoqueTransferirService;
	private final EstoqueReunitizarApplicationService estoqueReunitizarService;
	private final EstoqueAlterarApplicationService estoqueAlterarService;
	private final EstoqueDividirFundirApplicationService estoqueDividirFundirService;
	private final EstoqueEfetuarEntradaApplicationService estoqueEntradaService;
	private final EstoqueEfetuarSaidaApplicationService estoqueSaidaService;
	private final EstoqueAdicionarRemoverSeloApplicationService estoqueAdicionarRemoverSeloService;
	private final ValidatorService validatorService;

	@Operation(description = "Transferir endereço por unitizador.", method = "POST")
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "Unitizador transferido com sucesso."),
			@ApiResponse(responseCode = "400", description = "O unitizador não pôde ser transferido.") })
	@PostMapping("/transferirEnderecoUnitizador")
	public ResponseEntity<List<TransferirEnderecoUnitizadorResult>> transferirEnderecoUnitizador(@RequestBody TransferirEnderecoUnitizadorDTO dto) {

		validatorService.validate(dto).ifPresent(violations -> {
			throw new WMSTransferirEnderecoUnitizadorException(violations);
		});

		var origem = Origem.of(OrigemId.from(dto.getUnitizadorId().toString()), "TransferenciaEnderecoUnitizador");
		var cmd = EfetuarTransferenciaEnderecoUnitizadorEstoqueCommand.builder()
																	  .unidadeId(dto.getUnidadeId())
																	  .unitizadorId(dto.getUnitizadorId())
																	  .enderecoId(dto.getEnderecoIdDestino())
																	  .origem(origem)
																	  .build();

		var estoquesSaidaEntrada = estoqueTransferirService.handle(cmd);
		var body = TransferirEnderecoUnitizadorResult.from(estoquesSaidaEntrada);

		return ResponseEntity.ok(body);
	}

	@Operation(description = "Realizar reunitização.", method = "POST")
	@ApiResponses(value = { @ApiResponse(responseCode = "204", description = "Reunitização realizada com sucesso."),
			@ApiResponse(responseCode = "400", description = "A reunitização não pôde ser realizada.") })
	@PostMapping("/reunitizar")
	public ResponseEntity<Void> reunitizar(@RequestBody ReunitizarDTO dto) {

		validatorService.validate(dto).ifPresent(violations -> {
			throw new WMSReunitizacaoConstraintException(violations);
		});

		var cmd = EfetuarReunitizacaoEstoqueCommand.builder()
												   .unidadeId(dto.getUnidadeId())
												   .estoqueId(dto.obterEstoqueId())
												   .destino(EfetuarReunitizacaoEstoqueCommand.Destino.builder()
																									 .enderecoId(dto.getDestino()
																													.getEnderecoId())
																									 .skuId(dto.getDestino()
																											   .getSkuId())
																									 .tipoEstoqueId(dto.getDestino()
																													   .getTipoEstoqueId())
																									 .unitizadorId(dto.getDestino()
																													  .getUnitizadorId())
																									 .quantidadeSku(dto.getDestino()
																													   .getQuantidadeSku())
																									 .avariado(dto.getDestino()
																												  .getAvariado())
																									 .build())
												   .atributos(AtributoEstoqueValorDTO.toAtributoEstoqueValor(dto.getAtributos()))
												   .build();

		estoqueReunitizarService.handle(cmd);

		return ResponseEntity.noContent().build();
	}

	@Operation(description = "Realizar alteração de SKU no estoque", method = "POST")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "204", description = "Alteração de SKU no estoque realizada com sucesso."),
			@ApiResponse(responseCode = "400", description = "A alteração de SKU no estoque não pôde ser realizada.") })
	@PostMapping(path = "/{id}/alterarSku")
	public ResponseEntity<Void> alterarSku(@PathVariable EstoqueId id, @RequestBody AlterarEstoqueSKUDTO dto) {

		validatorService.validate(dto).ifPresent(violations -> {
			throw new WMSAlteracaoEstoqueSKUConstraintException(violations);
		});

		var cmd = AlterarEstoqueSKUCommand.builder().id(id).skuId(dto.getSkuId()).build();

		var estoqueId = estoqueAlterarService.handle(cmd);

		var uri = ServletUriComponentsBuilder.fromCurrentRequest().path("/").path(estoqueId.toString()).build().toUri();

		return ResponseEntity.created(uri).build();
	}

	@Operation(description = "Realizar alteração de tipo de estoque no saldo de estoque", method = "POST")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "204", description = "Alteração de tipo de estoque no saldo de estoque realizada com sucesso."),
			@ApiResponse(responseCode = "400", description = "A alteração de tipo de estoque no saldo de estoque não pôde ser realizada.") })
	@PostMapping(path = "/{id}/alterarTipoEstoque")
	public ResponseEntity<Void> alterarTipoEstoque(@PathVariable EstoqueId id,
												   @RequestBody AlterarEstoqueTipoEstoqueDTO dto) {

		validatorService.validate(dto).ifPresent(violations -> {
			throw new WMSAlteracaoEstoqueTipoEstoqueConstraintException(violations);
		});

		var cmd = AlterarEstoqueTipoEstoqueCommand.of(id, dto.getTipoEstoqueId());

		var estoqueId = estoqueAlterarService.handle(cmd);

		var uri = ServletUriComponentsBuilder.fromCurrentRequest().path("/").path(estoqueId.toString()).build().toUri();

		return ResponseEntity.created(uri).build();
	}

	@Operation(description = "Realizar alteração de uma característica no saldo de estoque", method = "POST")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "204", description = "Alteração de uma característica no saldo de estoque realizada com sucesso."),
			@ApiResponse(responseCode = "400", description = "A alteração de uma característica no saldo de estoque não pôde ser realizada.") })
	@PostMapping(path = "/{id}/alterarCaracteristica")
	public ResponseEntity<Void> alterarCaracteristica(@PathVariable EstoqueId id,
													  @RequestBody AlterarEstoqueCaracteristicaDTO dto) {

		validatorService.validate(dto).ifPresent(violations -> {
			throw new WMSAlteracaoEstoqueCaracteristicaConstraintException(violations);
		});

		var cmd = AlterarEstoqueCaracteristicaCommand.of(id, dto.getCaracteristicaConfiguracaoId(), dto.getValor());

		var estoqueId = estoqueAlterarService.handle(cmd);

		var uri = ServletUriComponentsBuilder.fromCurrentRequest().path("/").path(estoqueId.toString()).build().toUri();

		return ResponseEntity.created(uri).build();
	}

	@Operation(description = "Realizar alteração do indicador de avaria do estoque", method = "POST")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "204", description = "Alteração do indicador de avaria do estoque realizada com sucesso."),
			@ApiResponse(responseCode = "400", description = "A alteração do indicador de avaria do estoque não pôde ser realizada.") })
	@PostMapping(path = "/{id}/alterarAvariado")
	public ResponseEntity<Void> alterarAvariado(@PathVariable EstoqueId id,
												@RequestBody AlterarEstoqueAvariadoDTO dto) {

		validatorService.validate(dto).ifPresent(violations -> {
			throw new WMSAlteracaoEstoqueAvariadoConstraintException(violations);
		});

		var cmd = AlterarEstoqueAvariadoCommand.of(id, dto.getAvariado());

		var estoqueId = estoqueAlterarService.handle(cmd);

		var uri = ServletUriComponentsBuilder.fromCurrentRequest().path("/").path(estoqueId.toString()).build().toUri();

		return ResponseEntity.created(uri).build();
	}

	@Operation(description = "Realizar alteração da situação do estoque", method = "POST")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "204", description = "Alteração da situação do estoque realizada com sucesso."),
			@ApiResponse(responseCode = "400", description = "A alteração da situação do estoque não pôde ser realizada.") })
	@PostMapping(path = "/{id}/alterarSituacao")
	public ResponseEntity<Void> alterarSituacao(@PathVariable EstoqueId id,
												@RequestBody AlterarEstoqueSituacaoDTO dto) {

		validatorService.validate(dto).ifPresent(violations -> {
			throw new WMSAlteracaoEstoqueSituacaoConstraintException(violations);
		});
		var cmd = AlterarEstoqueSituacaoCommand.of(id, SituacaoEstoqueValor.valueOf(dto.getSituacao()));

		var estoqueId = estoqueAlterarService.handle(cmd);

		var uri = ServletUriComponentsBuilder.fromCurrentRequest().path("/").path(estoqueId.toString()).build().toUri();

		return ResponseEntity.created(uri).build();
	}

	@Operation(description = "Realizar alteração do Atributo do estoque", method = "POST")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "204", description = "Alteração da atributo do estoque realizada com sucesso."),
			@ApiResponse(responseCode = "400", description = "A alteração do atributo do estoque não pôde ser realizada.") })
	@PostMapping(path = "/{id}/alterarAtributo")
	public ResponseEntity<Void> alterarAtributo(@PathVariable EstoqueId id,
												@RequestBody AlterarEstoqueAtributoDTO dto) {

		validatorService.validate(dto).ifPresent(violations -> {
			throw new WMSAlteracaoEstoqueAtributoConstraintException(violations);
		});

		var cmd = AlterarEstoqueAtributoCommand.builder()
											   .id(id)
											   .estoqueAtributoSaldoId(dto.getEstoqueAtributoSaldoId())
											   .atributoEstoqueId(dto.getAtributoEstoqueId())
											   .valorAtual(dto.getValorAtual())
											   .novoValor(dto.getNovoValor())
											   .build();

		var estoqueId = estoqueAlterarService.handle(cmd);

		var uri = ServletUriComponentsBuilder.fromCurrentRequest().path("/").path(estoqueId.toString()).build().toUri();

		return ResponseEntity.created(uri).build();
	}

	@Operation(description = "Realizar transferência de endereço do saldo associado a uma reserva de estoque", method = "POST")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "Transferência de endereço associado a uma reserva de estoque realizada com sucesso."),
			@ApiResponse(responseCode = "404", description = "Reserva de estoque não foi encontrada.") })
	@PostMapping(path = "/transferirEnderecoReserva")
	public ResponseEntity<Void> transferirEnderecoReserva(@RequestBody TransferirEnderecoReservaDTO dto) {

		validatorService.validate(dto).ifPresent(violations -> {
			throw new WMSEfetuarTransferenciaEnderecoEstoqueReservadoConstraintException(violations);
		});

		Origem origem;
		if (dto.getOrigem() != null && dto.getOrigem().getId() != null) {
			origem = Origem.of(OrigemId.from(dto.getOrigem().getId()), dto.getOrigem().getDescricao());
		} else {
			origem = Origem.of(OrigemId.from(dto.getReservaDefinitivaEstoqueId().toString()),
							   "TransferenciaEnderecoReserva");
		}

		var cmd = EfetuarTransferenciaEnderecoReservaEstoqueCommand.builder()
																   .unidadeId(dto.getUnidadeId())
																   .reservaDefinitivaEstoqueId(dto.getReservaDefinitivaEstoqueId())
																   .enderecoId(dto.getEnderecoId())
																   .origem(origem)
																   .atributos(AtributoEstoqueValorDTO.toAtributoEstoqueValor(dto.getAtributos()))
																   .build();
		estoqueTransferirService.handle(cmd);

		return ResponseEntity.ok().build();
	}

	@Operation(description = "Realizar a divisão/fusão de estoque", method = "POST")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "204", description = "Divisão/Fusão de estoque realizada com sucesso."),
			@ApiResponse(responseCode = "400", description = "Divisão/Fusão de estoque não pôde ser realizada.") })
	@PostMapping(path = "/dividirFundir")
	public ResponseEntity<Void> dividirFundir(@RequestBody DividirFundirDTO dto) {

		validatorService.validate(dto).ifPresent(violations -> {
			throw new WMSEfetuarDivisaoFusaoEstoqueConstraintException(violations);
		});

		var cmd = EfetuarDivisaoFusaoEstoqueCommand.of(dto.getEstoqueSaida().getId(),
													   dto.getEstoqueSaida().getQuantidade(),
													   dto.getEstoqueEntrada().getUnitizadorId(),
													   dto.getEstoqueEntrada().getEnderecoId(),
													   AtributoEstoqueValorDTO.toAtributoEstoqueValor(dto.getAtributos()),
													   Optional.empty());

		estoqueDividirFundirService.handle(cmd);

		return ResponseEntity.noContent().build();
	}

	@RolesAllowed({ UsuarioPerfil.Perfil.OPERADOR_WMS_SENIOR })
	@Operation(description = "Efetuar entrada de estoque liberado", method = "POST")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "204", description = "Entrada de estoque liberado realizada com sucesso."),
			@ApiResponse(responseCode = "400", description = "A entrada de estoque liberado não pôde ser realizada.") })
	@PostMapping(path = "/efetuarEntradaLiberado")
	public ResponseEntity<Void> efetuarEntradaLiberado(@RequestBody EntradaEstoqueLiberadoDTO dto) {

		validatorService.validate(dto).ifPresent(violations -> {
			throw new WMSEfetuarEntradaEstoqueLiberadoConstraintException(violations);
		});

		var origem = Origem.of(OrigemId.generate(), Constants.ORIGEM_ENTRADA_SIMPLIFICADA);

		var cmd = EfetuarEntradaEstoqueLiberadoCommand.builder()
													  .unidadeId(dto.getUnidadeId())
													  .origem(origem)
													  .produtoId(dto.getProdutoId())
													  .skuId(dto.getSkuId())
													  .unitizadorId(dto.getUnitizadorId())
													  .tipoEstoqueId(dto.getTipoEstoqueId())
													  .enderecoId(dto.getEnderecoId())
													  .avariado(dto.getAvariado())
													  .quantidade(dto.getQuantidade())
													  .caracteristicasOld(CaracteristicaValorDTO.fromOld(dto.getCaracteristicas()))
													  .caracteristicas(CaracteristicaValorDTO.from(dto.getCaracteristicas()))
													  .selos(SeloEstoqueDTO.from(dto.getSelos()))
													  .atributos(AtributoEstoqueValorDTO.toAtributoEstoqueValor(dto.getAtributos()))
													  .build();

		estoqueEntradaService.handle(cmd);

		return ResponseEntity.ok().build();

	}

	@RolesAllowed({ UsuarioPerfil.Perfil.OPERADOR_WMS_SENIOR })
	@Operation(description = "Efetuar baixa de estoque", method = "POST")
	@ApiResponses(value = { @ApiResponse(responseCode = "204", description = "Baixa de estoque realizada com sucesso."),
			@ApiResponse(responseCode = "400", description = "Baixa de estoque não pôde ser realizada.") })
	@PostMapping(path = "/efetuarBaixaEstoque")
	public ResponseEntity<Void> efetuarBaixaEstoque(@RequestBody EfetuarBaixaEstoqueDTO dto) {

		validatorService.validate(dto).ifPresent(violations -> {
			throw new WMSEfetuarBaixaEstoqueConstraintException(violations);
		});

		var cmd = EfetuarSaidaEstoqueCommand.of(dto.getEstoqueId(),
												dto.getQuantidade(),
												AtributoEstoqueValorDTO.toAtributoEstoqueValor(dto.getAtributos()));

		estoqueSaidaService.handle(cmd);

		return ResponseEntity.noContent().build();
	}

	@Operation(description = "Realizar a inclusão de um selo de estoque", method = "POST")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "204", description = "Inclusão de selo no estoque realizada com sucesso."),
			@ApiResponse(responseCode = "400", description = "Inclusão de selo no estoque não pôde ser realizada.") })
	@PostMapping(path = "/{id}/adicionarSelo")
	public ResponseEntity<Void> adicionarSelo(@PathVariable EstoqueId id, @RequestBody AdicionarSeloEstoqueDTO dto) {

		validatorService.validate(dto).ifPresent(violations -> {
			throw new WMSAdicionarSeloEstoqueConstraintException(violations);
		});

		var cmd = AdicionarSeloEstoqueCommand.of(id, SeloEstoque.of(dto.getChave(), dto.getValor()));

		estoqueAdicionarRemoverSeloService.handle(cmd);

		return ResponseEntity.noContent().build();
	}

	@RolesAllowed({ UsuarioPerfil.Perfil.PLANEJADOR_WMS_SENIOR })
	@Operation(description = "Realizar a remoção de um selo de estoque", method = "POST")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "204", description = "Remoção de selo no estoque realizada com sucesso."),
			@ApiResponse(responseCode = "400", description = "Remoção de selo no estoque não pôde ser realizada.") })
	@PostMapping(path = "/{id}/removerSelo")
	public ResponseEntity<Void> removerSelo(@PathVariable EstoqueId id, @RequestBody RemoverSeloEstoqueDTO dto) {

		validatorService.validate(dto).ifPresent(violations -> {
			throw new WMSRemoverSeloEstoqueConstraintException(violations);
		});

		var cmd = RemoverSeloEstoqueCommand.of(id, SeloEstoque.of(dto.getChave(), dto.getValor()));

		estoqueAdicionarRemoverSeloService.handle(cmd);

		return ResponseEntity.noContent().build();
	}

	@Operation(description = "Realizar transferência de endereço do Estoque", method = "POST")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "204", description = "A transferência de endereço do Estoque realizada com sucesso."),
			@ApiResponse(responseCode = "400", description = "A transferência de endereço do Estoque não pôde ser realizada.") })
	@PostMapping(path = "/transferirEnderecoEstoque")
	public ResponseEntity<Void> transferirEnderecoEstoque(@RequestBody TransferirEnderecoEstoqueDTO dto) {

		validatorService.validate(dto).ifPresent(violations -> {
			throw new WMSEfetuarTransferenciaEnderecoEstoqueConstraintException(violations);
		});

		var origem = Origem.of(OrigemId.generate(),
							   StringUtils.hasText(dto.getOrigem()) ? dto.getOrigem()
									   : Constants.ORIGEM_TRANSFERENCIA_ENDERECO_ESTOQUE_MANUAL);

		var cmd = EfetuarTransferenciaEnderecoEstoqueCommand.builder()
															.unidadeId(dto.getUnidadeId())
															.unitizadorId(dto.getUnitizadorIdDestino())
															.enderecoId(dto.getEnderecoIdDestino())
															.estoqueId(dto.getEstoqueIdOrigem())
															.origem(origem)
															.quantidade(dto.getQuantidade())
															.atributos(AtributoEstoqueValorDTO.toAtributoEstoqueValor(dto.getAtributos()))
															.build();

		estoqueTransferirService.handle(cmd);

		return ResponseEntity.ok().build();
	}

}
