package com.totvs.sl.wms.estoque.endereco.amqp.event;

import com.totvs.sl.wms.estoque.endereco.domain.event.SubjectEndereco;
import com.totvs.sl.wms.estoque.endereco.domain.model.EnderecoId;
import com.totvs.sl.wms.estoque.util.amqp.RejectedEvent;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data(staticConstructor = "of")
@EqualsAndHashCode(callSuper = false)
public final class AlteracaoCapacidadeEnderecoRejeitadaEvent extends RejectedEvent implements SubjectEndereco {

	private final EnderecoId enderecoId;
	private final Inconsistencia inconsistencia;

	@Data(staticConstructor = "of")
	public static final class Inconsistencia {
		private final String id;
		private final String mensagem;
		private final String detalhe;
	}
}
