package com.totvs.sl.wms.estoque.estoque.application;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import com.totvs.sl.wms.estoque.config.amqp.WMSPublisher;
import com.totvs.sl.wms.estoque.endereco.domain.model.Endereco;
import com.totvs.sl.wms.estoque.endereco.domain.model.EnderecoDomainRepository;
import com.totvs.sl.wms.estoque.estoque.application.command.EfetuarSaidaEstoqueBloqueadoCommand;
import com.totvs.sl.wms.estoque.estoque.application.command.EfetuarSaidaEstoqueCommand;
import com.totvs.sl.wms.estoque.estoque.application.command.EfetuarSaidaEstoqueLiberadoCommand;
import com.totvs.sl.wms.estoque.estoque.application.command.EfetuarSaidaLoteEstoqueBloqueadoCommand;
import com.totvs.sl.wms.estoque.estoque.application.command.EfetuarSaidaLoteEstoqueLiberadoCommand;
import com.totvs.sl.wms.estoque.estoque.domain.event.EstoqueBloqueadoSaidaLoteEfetuadaEvent;
import com.totvs.sl.wms.estoque.estoque.domain.event.EstoqueLiberadoSaidaLoteEfetuadaEvent;
import com.totvs.sl.wms.estoque.estoque.domain.model.Estoque;
import com.totvs.sl.wms.estoque.estoque.domain.model.EstoqueAtributoSaldo;
import com.totvs.sl.wms.estoque.estoque.domain.model.EstoqueDomainRepository;
import com.totvs.sl.wms.estoque.estoque.domain.model.EstoqueId;
import com.totvs.sl.wms.estoque.estoque.domain.model.SituacaoEstoqueValor;
import com.totvs.sl.wms.estoque.estoque.domain.service.AtualizaSaldoEstoqueSaidaDomainService;
import com.totvs.sl.wms.estoque.movimentoestoque.domain.model.MovimentoEstoque;
import com.totvs.sl.wms.estoque.movimentoestoque.domain.model.MovimentoEstoqueDomainRepository;
import com.totvs.sl.wms.estoque.origem.domain.model.Origem;
import com.totvs.sl.wms.estoque.origem.domain.model.OrigemId;
import com.totvs.sl.wms.estoque.produto.domain.model.ProdutoDomainRepository;
import com.totvs.sl.wms.estoque.sku.domain.model.SKUDomainRepository;
import com.totvs.sl.wms.estoque.unidade.domain.model.UnidadeId;
import com.totvs.sl.wms.estoque.util.Constants;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;

@Service
@Transactional
@AllArgsConstructor
public class EstoqueEfetuarSaidaApplicationService {

	private final MovimentoEstoqueDomainRepository movimentoEstoqueRepository;
	private final EstoqueDomainRepository estoqueRepository;
	private final ProdutoDomainRepository produtoRepository;
	private final SKUDomainRepository skuRepository;
	private final EnderecoDomainRepository enderecoRepository;
	private final AtualizaSaldoEstoqueSaidaDomainService atualizaSaldoSaidaService;
	private final WMSPublisher publisher;

	@Getter
	@AllArgsConstructor(staticName = "of")
	public static final class EstoqueSaidaMovimento {
		private Estoque estoque;
		private MovimentoEstoque movimento;
	}

	@Getter
	@Builder
	public static final class EstoquesSaidaMovimentoLista {
		private List<EstoqueSaida> estoquesSaida;
		private List<MovimentoEstoque> movimentosSaida;
	}

	public void handle(final EfetuarSaidaEstoqueLiberadoCommand cmd) {

		var estoqueMovimento = this.efetuarSaidaEstoqueLiberado(cmd.getUnidadeId(),
																cmd.getEstoqueId(),
																cmd.getQuantidade(),
																cmd.getOrigem(),
																!CollectionUtils.isEmpty(cmd.getAtributos())
																		? List.of(EstoqueAtributoSaldo.of(cmd.getAtributos(),
																										  cmd.getQuantidade()))
																		: new ArrayList<>());

		estoqueMovimento.getMovimento().getEvents().forEach(publisher::dispatch);
		estoqueMovimento.getEstoque().getEvents().forEach(publisher::dispatch);

	}

	public void handle(final EfetuarSaidaLoteEstoqueLiberadoCommand cmd) {

		var listaEstoqueMovimento = this.efetuarSaidaEstoqueLiberado(cmd.getUnidadeId(),
																	 cmd.getEstoques(),
																	 cmd.getOrigem());

		listaEstoqueMovimento.getMovimentosSaida()
							 .forEach(movimento -> movimento.getEvents().forEach(publisher::dispatch));

		publisher.dispatch(EstoqueLiberadoSaidaLoteEfetuadaEvent.from(listaEstoqueMovimento));

	}

	public void handle(final EfetuarSaidaEstoqueBloqueadoCommand cmd) {

		var estoqueMovimento = this.efetuarSaidaEstoqueBloqueado(cmd.getUnidadeId(),
																 cmd.getEstoqueId(),
																 cmd.getQuantidade(),
																 cmd.getOrigem(),
																 cmd.getChaveAcesso(),
																 !CollectionUtils.isEmpty(cmd.getAtributos())
																		 ? List.of(EstoqueAtributoSaldo.of(cmd.getAtributos(),
																										   cmd.getQuantidade()))
																		 : new ArrayList<>());

		estoqueMovimento.getMovimento().getEvents().forEach(publisher::dispatch);
		estoqueMovimento.getEstoque().getEvents().forEach(publisher::dispatch);

	}

	public void handle(final EfetuarSaidaEstoqueCommand cmd) {

		var estoque = estoqueRepository.findWithLockByIdOrThrowNotFound(cmd.getEstoqueId());
		var origem = Origem.of(OrigemId.generate(), Constants.ORIGEM_SAIDA_SIMPLIFICADA);

		if (estoque.getSituacaoCorrente() == SituacaoEstoqueValor.LIBERADO) {
			handle(EfetuarSaidaEstoqueLiberadoCommand.builder()
													 .unidadeId(estoque.getUnidadeId())
													 .origem(origem)
													 .estoqueId(cmd.getEstoqueId())
													 .quantidade(cmd.getQuantidade())
													 .atributos(cmd.getAtributos())
													 .build());
		} else if (estoque.getSituacaoCorrente() == SituacaoEstoqueValor.BLOQUEADO) {
			handle(EfetuarSaidaEstoqueBloqueadoCommand.builder()
													  .unidadeId(estoque.getUnidadeId())
													  .origem(origem)
													  .estoqueId(cmd.getEstoqueId())
													  .quantidade(cmd.getQuantidade())
													  .atributos(cmd.getAtributos())
													  .build());
		}

	}

	public void handle(final EfetuarSaidaLoteEstoqueBloqueadoCommand cmd) {

		var listaEstoqueMovimento = this.efetuarSaidaEstoqueBloqueado(cmd.getUnidadeId(),
																	  cmd.getEstoques(),
																	  cmd.getOrigem());

		listaEstoqueMovimento.getMovimentosSaida()
							 .forEach(movimento -> movimento.getEvents().forEach(publisher::dispatch));

		publisher.dispatch(EstoqueBloqueadoSaidaLoteEfetuadaEvent.from(listaEstoqueMovimento));

	}

	private EstoqueSaidaMovimento efetuarSaidaEstoqueLiberado(UnidadeId unidadeId,
															  EstoqueId estoqueId,
															  BigDecimal quantidade,
															  Origem origem,
															  List<EstoqueAtributoSaldo> atributosSaldo) {

		var estoque = estoqueRepository.findWithLockByIdAndUnidadeIdOrThrowNotFound(estoqueId, unidadeId);

		var endereco = enderecoRepository.findByIdOrThrowNotFound(estoque.getEnderecoId());

		var produto = produtoRepository.findByIdOrThrowNotFound(estoque.getProdutoId());

		var sku = skuRepository.findByIdAndProdutoIdThrowNotFound(estoque.getSkuId(), estoque.getProdutoId());

		var movimentoEstoque = estoque.efetuarSaidaLiberado(produto,
															sku,
															quantidade,
															origem,
															endereco,
															this.determinarAlteraOcupacaoEndereco(endereco),
															atributosSaldo);

		atualizaSaldoSaidaService.atualizar(estoque);

		movimentoEstoqueRepository.insert(movimentoEstoque);

		return EstoqueSaidaMovimento.of(estoque, movimentoEstoque);

	}

	private EstoquesSaidaMovimentoLista efetuarSaidaEstoqueLiberado(UnidadeId unidadeId,
																	List<EfetuarSaidaLoteEstoqueLiberadoCommand.EstoqueSaida> estoques,
																	Origem origem) {

		var estoquesMovimentos = new ArrayList<MovimentoEstoque>();
		var estoquesSaida = new ArrayList<EstoqueSaida>();

		estoques.forEach(estoque -> {

			var estoqueMovimento = this.efetuarSaidaEstoqueLiberado(unidadeId,
																	estoque.getId(),
																	estoque.getQuantidade(),
																	origem,
																	!CollectionUtils.isEmpty(estoque.getAtributos())
																			? List.of(EstoqueAtributoSaldo.of(estoque.getAtributos(),
																											  estoque.getQuantidade()))
																			: new ArrayList<>());

			estoquesMovimentos.add(estoqueMovimento.getMovimento());
			removerEstoqueComSaldoDesatualizado(estoquesSaida, estoqueMovimento.getEstoque());
			estoquesSaida.add(EstoqueSaida.from(estoqueMovimento.getEstoque()));
		});

		return new EstoquesSaidaMovimentoLista(estoquesSaida, estoquesMovimentos);
	}

	private EstoqueSaidaMovimento efetuarSaidaEstoqueBloqueado(UnidadeId unidadeId,
															   EstoqueId estoqueId,
															   BigDecimal quantidade,
															   Origem origem,
															   String chaveAcesso,
															   List<EstoqueAtributoSaldo> atributosSaldo) {

		var estoque = estoqueRepository.findWithLockByIdAndUnidadeIdOrThrowNotFound(estoqueId, unidadeId);

		var endereco = enderecoRepository.findByIdOrThrowNotFound(estoque.getEnderecoId());

		var produto = produtoRepository.findByIdOrThrowNotFound(estoque.getProdutoId());

		var sku = skuRepository.findByIdAndProdutoIdThrowNotFound(estoque.getSkuId(), estoque.getProdutoId());

		MovimentoEstoque movimentoEstoque = estoque.efetuarSaidaBloqueado(produto,
																		  sku,
																		  quantidade,
																		  origem,
																		  chaveAcesso,
																		  endereco,
																		  this.determinarAlteraOcupacaoEndereco(endereco),
																		  atributosSaldo);

		atualizaSaldoSaidaService.atualizar(estoque);

		movimentoEstoqueRepository.insert(movimentoEstoque);

		return EstoqueSaidaMovimento.of(estoque, movimentoEstoque);

	}

	private EstoquesSaidaMovimentoLista efetuarSaidaEstoqueBloqueado(UnidadeId unidadeId,
																	 List<EfetuarSaidaLoteEstoqueBloqueadoCommand.EstoqueSaida> estoques,
																	 Origem origem) {

		var estoquesMovimentos = new ArrayList<MovimentoEstoque>();
		var estoquesSaida = new ArrayList<EstoqueSaida>();

		estoques.forEach(estoque -> {

			var estoqueMovimento = this.efetuarSaidaEstoqueBloqueado(unidadeId,
																	 estoque.getId(),
																	 estoque.getQuantidade(),
																	 origem,
																	 estoque.getChaveAcesso(),
																	 !CollectionUtils.isEmpty(estoque.getAtributos())
																			 ? List.of(EstoqueAtributoSaldo.of(estoque.getAtributos(),
																											   estoque.getQuantidade()))
																			 : new ArrayList<>());

			estoquesMovimentos.add(estoqueMovimento.getMovimento());
			removerEstoqueComSaldoDesatualizado(estoquesSaida, estoqueMovimento.getEstoque());
			estoquesSaida.add(EstoqueSaida.from(estoqueMovimento.getEstoque()));
		});

		return new EstoquesSaidaMovimentoLista(estoquesSaida, estoquesMovimentos);
	}

	private void removerEstoqueComSaldoDesatualizado(List<EstoqueSaida> estoquesSaida, Estoque estoque) {

		estoquesSaida.removeIf(estoqueDesatualizada -> estoqueDesatualizada.getEstoqueId().equals(estoque.getId()));
	}

	private boolean determinarAlteraOcupacaoEndereco(Endereco endereco) {
		return !endereco.isDoca() && !endereco.isStage();
	}
}
