package com.totvs.sl.wms.estoque.caracteristicaconfiguracao.domain.model;

import java.math.BigDecimal;
import java.time.LocalDate;

import com.totvs.sl.wms.estoque.caracteristicavalor.domain.model.CaracteristicaValor;
import com.totvs.sl.wms.estoque.caracteristicavalor.domain.model.CaracteristicaValorData;
import com.totvs.sl.wms.estoque.caracteristicavalor.domain.model.CaracteristicaValorFaixa;
import com.totvs.sl.wms.estoque.caracteristicavalor.domain.model.CaracteristicaValorFaixaData;
import com.totvs.sl.wms.estoque.caracteristicavalor.domain.model.CaracteristicaValorFaixaNumero;
import com.totvs.sl.wms.estoque.caracteristicavalor.domain.model.CaracteristicaValorFaixaTexto;
import com.totvs.sl.wms.estoque.caracteristicavalor.domain.model.CaracteristicaValorNumero;
import com.totvs.sl.wms.estoque.caracteristicavalor.domain.model.CaracteristicaValorTexto;
import com.totvs.sl.wms.estoque.util.ConversionUtils;

public enum FormatoCaracteristicaValor {
	TEXTO {
		@Override
		public CaracteristicaValor<String> getInstance(CaracteristicaConfiguracaoId id, Object valor) {
			return CaracteristicaValorTexto.builder()
										   .caracteristicaConfiguracaoId(id)
										   .valor(String.valueOf(valor))
										   .build();
		}

		@Override
		public CaracteristicaValorFaixa<?> getInstance(CaracteristicaConfiguracaoId id,
													   String valorInicial,
													   String valorFinal) {
			return CaracteristicaValorFaixaTexto.builder()
												.caracteristicaConfiguracaoId(id)
												.valorInicial(valorInicial)
												.valorFinal(valorFinal)
												.build();
		}
	},
	NUMERO {
		@Override
		public CaracteristicaValor<BigDecimal> getInstance(CaracteristicaConfiguracaoId id, Object valor) {
			return CaracteristicaValorNumero.builder()
											.caracteristicaConfiguracaoId(id)
											.valor(ConversionUtils.toBigDecimal(valor))
											.build();

		}

		@Override
		public CaracteristicaValorFaixa<?> getInstance(CaracteristicaConfiguracaoId id,
													   String valorInicial,
													   String valorFinal) {
			return CaracteristicaValorFaixaNumero.builder()
												 .caracteristicaConfiguracaoId(id)
												 .valorInicial(ConversionUtils.toBigDecimal(valorInicial))
												 .valorFinal(ConversionUtils.toBigDecimal(valorFinal))
												 .build();
		}
	},
	DATA {
		@Override
		public CaracteristicaValor<LocalDate> getInstance(CaracteristicaConfiguracaoId id, Object valor) {
			return CaracteristicaValorData.builder()
										  .caracteristicaConfiguracaoId(id)
										  .valor(ConversionUtils.toLocalDate(valor))
										  .build();
		}

		@Override
		public CaracteristicaValorFaixa<?> getInstance(CaracteristicaConfiguracaoId id,
													   String valorInicial,
													   String valorFinal) {
			return CaracteristicaValorFaixaData.builder()
											   .caracteristicaConfiguracaoId(id)
											   .valorInicial(ConversionUtils.toLocalDate(valorInicial))
											   .valorFinal(ConversionUtils.toLocalDate(valorFinal))
											   .build();
		}
	};

	public abstract CaracteristicaValor<?> getInstance(CaracteristicaConfiguracaoId id, Object valor); // NOSONAR

	public abstract CaracteristicaValorFaixa<?> getInstance(CaracteristicaConfiguracaoId id, // NOSONAR
															String valorIncicial,
															String valorFinal);

}
