package com.totvs.sl.wms.estoque.estoque.api.dto;

import javax.validation.constraints.NotBlank;

import com.totvs.sl.wms.estoque.estoque.domain.model.SituacaoEstoqueValor;
import com.totvs.tjf.core.validation.ValueOfEnum;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

@AllArgsConstructor(staticName = "of")
@NoArgsConstructor(force = true)
@Getter
@Schema(description = "Informações para alteração da situação do estoque")
public final class AlterarEstoqueSituacaoDTO {

	@NotBlank(message = "{AlterarEstoqueSituacaoDTO.situacao.NotBlank}")
	@Schema(description = "Situação do estoque")
	@ValueOfEnum(enumClass = SituacaoEstoqueValor.class, message = "{AlterarEstoqueSituacaoDTO.situacao.ValueOfENum}")
	private final String situacao;
}
