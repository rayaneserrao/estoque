package com.totvs.sl.wms.estoque.endereco.amqp.cmd;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import com.totvs.sl.wms.estoque.endereco.domain.model.EnderecoId;

import lombok.Data;

@Data(staticConstructor = "of")
public final class BloquearEntradaEstoqueEnderecoCmd {

	public static final String NAME = "BloquearEntradaEstoqueEnderecoCmd";

	public static final String CONDITIONAL_EXPRESSION = "headers['type']=='" + NAME + "'";

	@NotNull(message = "{BloquearEntradaEstoqueEnderecoCmd.id.NotNull}")
	private final EnderecoId id;

	@NotBlank(message = "{BloquearEntradaEstoqueEnderecoCmd.chaveAcesso.NotBlank}")
	private final String chaveAcesso;
}
