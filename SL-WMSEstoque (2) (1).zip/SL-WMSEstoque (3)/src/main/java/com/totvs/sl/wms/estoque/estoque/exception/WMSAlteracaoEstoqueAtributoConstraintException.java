package com.totvs.sl.wms.estoque.estoque.exception;

import java.util.Set;
import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;
import com.totvs.tjf.api.context.stereotype.error.ApiBadRequest;

@ApiBadRequest
public class WMSAlteracaoEstoqueAtributoConstraintException extends ConstraintViolationException {

	private static final long serialVersionUID = -5918528093370640963L;

	public WMSAlteracaoEstoqueAtributoConstraintException(Set<? extends ConstraintViolation<?>> constraintViolations) {
		super(constraintViolations);
	}

}
