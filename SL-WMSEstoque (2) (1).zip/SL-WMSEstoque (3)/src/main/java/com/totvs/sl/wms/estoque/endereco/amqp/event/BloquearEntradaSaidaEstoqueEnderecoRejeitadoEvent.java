package com.totvs.sl.wms.estoque.endereco.amqp.event;

import java.util.List;

import com.totvs.sl.wms.estoque.endereco.domain.model.EnderecoId;
import com.totvs.sl.wms.estoque.estoque.domain.event.SubjectBloqueioEstoque;
import com.totvs.sl.wms.estoque.util.amqp.RejectedEvent;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public final class BloquearEntradaSaidaEstoqueEnderecoRejeitadoEvent extends RejectedEvent
		implements SubjectBloqueioEstoque {

	private EnderecoId enderecoId;
	private List<Inconsistencia> inconsistencias;

	@Data(staticConstructor = "of")
	public static final class Inconsistencia {
		private final String id;
		private final String mensagem;
		private final String detalhe;
	}
}
