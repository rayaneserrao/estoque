package com.totvs.sl.wms.estoque.atributoestoque.api;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

import javax.annotation.security.RolesAllowed;

import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.totvs.sl.wms.estoque.atributoestoque.application.AtributoEstoqueExcluirApplicationService;
import com.totvs.sl.wms.estoque.atributoestoque.application.command.ExcluirAtributoEstoqueCommand;
import com.totvs.sl.wms.estoque.atributoestoque.domain.model.AtributoEstoqueId;
import com.totvs.sl.wms.estoque.usuario.domain.model.UsuarioPerfil;
import com.totvs.tjf.api.context.stereotype.ApiGuideline;
import com.totvs.tjf.api.context.stereotype.ApiGuideline.ApiGuidelineVersion;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.AllArgsConstructor;

@Tag(name = "atributo-estoque")

@AllArgsConstructor
@RestController
@ApiGuideline(ApiGuidelineVersion.V2)
@RequestMapping(path = AtributoEstoqueExcluirController.PATH, produces = APPLICATION_JSON_VALUE, consumes = APPLICATION_JSON_VALUE)
@RolesAllowed({ UsuarioPerfil.Perfil.PLANEJADOR_WMS, UsuarioPerfil.Perfil.PLANEJADOR_WMS_SENIOR })
public class AtributoEstoqueExcluirController {

	public static final String PATH = "/api/v1/atributosEstoque"; // NOSONAR

	private final AtributoEstoqueExcluirApplicationService service;

	@Operation(description = "Excluir um atributo de estoque.", method = "POST")
	@ApiResponses(value = { @ApiResponse(responseCode = "204", description = "Atributo estoque excluído com sucesso."),
			@ApiResponse(responseCode = "400", description = "O atributo estoque não pôde ser excluído pois possui alguma informação inválida."),
			@ApiResponse(responseCode = "404", description = "O atributo estoque não foi encontrado."), })
	@PostMapping(path = "/{id}/excluir", consumes = MediaType.ALL_VALUE)
	public ResponseEntity<Void> excluir(@PathVariable AtributoEstoqueId id) {

		var cmd = ExcluirAtributoEstoqueCommand.of(id);

		service.handle(cmd);

		return ResponseEntity.noContent().build();
	}

}
