package com.totvs.sl.wms.estoque.caracteristicaconfiguracao.application;

import javax.transaction.Transactional;

import org.springframework.stereotype.Service;

import com.totvs.sl.wms.estoque.caracteristicaconfiguracao.application.command.DesmarcarUtilizacaoCaracteristicaConfiguracaoCommand;
import com.totvs.sl.wms.estoque.caracteristicaconfiguracao.domain.model.CaracteristicaConfiguracaoDomainRepository;
import com.totvs.sl.wms.estoque.config.amqp.WMSPublisher;

import lombok.AllArgsConstructor;

@Service
@Transactional
@AllArgsConstructor
public class CaracteristicaConfiguracaoDesmarcarUtilizacaoApplicationService {

	private CaracteristicaConfiguracaoDomainRepository repository;
	private WMSPublisher publisher;

	public void handle(DesmarcarUtilizacaoCaracteristicaConfiguracaoCommand cmd) {

		var caracteristicaConfiguracao = repository.findByIdOrThrowNotFound(cmd.getId());

		caracteristicaConfiguracao.desmarcarUtilizado(cmd.getFuncionalidade());

		repository.update(caracteristicaConfiguracao);

		caracteristicaConfiguracao.getEvents().forEach(publisher::dispatch);
	}

}
