package com.totvs.sl.wms.estoque.caracteristicaconfiguracao.exception;

import com.totvs.tjf.api.context.stereotype.error.ApiBadRequest;

@ApiBadRequest
public class WMSCaracteristicaConfiguracaoNaoPermiteExcluirOrigemPadraoException extends RuntimeException {

	private static final long serialVersionUID = 1L;

}
