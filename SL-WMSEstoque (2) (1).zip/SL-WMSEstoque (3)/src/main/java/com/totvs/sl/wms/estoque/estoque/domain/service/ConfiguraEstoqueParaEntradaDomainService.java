package com.totvs.sl.wms.estoque.estoque.domain.service;

import java.math.BigDecimal;
import java.time.ZonedDateTime;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.totvs.sl.wms.estoque.bloqueiomovimentacaounitizador.domain.model.BloqueioMovimentacaoUnitizadorId;
import com.totvs.sl.wms.estoque.estoque.domain.model.Estoque;
import com.totvs.sl.wms.estoque.estoque.domain.model.EstoqueDomainRepository;
import com.totvs.sl.wms.estoque.estoque.domain.model.EstoqueHash;
import com.totvs.sl.wms.estoque.estoque.domain.model.EstoqueId;
import com.totvs.sl.wms.estoque.estoque.domain.model.SeloEstoque;
import com.totvs.sl.wms.estoque.estoque.domain.model.SituacaoEstoque;
import com.totvs.sl.wms.estoque.estoque.domain.model.SituacaoEstoqueBloqueado;
import com.totvs.sl.wms.estoque.estoque.exception.WMSBloqueioMovimentacaoUnitizadorIdDiferentesParaConfigurarEstoqueException;
import com.totvs.sl.wms.estoque.produto.domain.model.Produto;
import com.totvs.sl.wms.estoque.rastreio.domain.model.RastreioId;
import com.totvs.sl.wms.estoque.sku.domain.model.SKU;

import lombok.AllArgsConstructor;

@Service
@AllArgsConstructor
public class ConfiguraEstoqueParaEntradaDomainService {

	private final EstoqueDomainRepository estoqueRepository;

	public Estoque configurar(Produto produto,
							  SKU sku,
							  SituacaoEstoque situacaoEstoque,
							  EstoqueHash estoqueHash,
							  BloqueioMovimentacaoUnitizadorId bloqueioMovimentacaoUnitizadorId,
							  RastreioId rastreioId,
							  List<SeloEstoque> selos,
							  ZonedDateTime dataHoraEntrada) {

		Optional<Estoque> estoqueOptional = estoqueRepository.findWithLockByHash(estoqueHash.getHash());

		if (estoqueOptional.isPresent()) {
			Estoque estoque = estoqueOptional.get();

			if (!Objects.equals(bloqueioMovimentacaoUnitizadorId,
								estoque.getBloqueioMovimentacaoUnitizadorId().orElse(null)))
				throw new WMSBloqueioMovimentacaoUnitizadorIdDiferentesParaConfigurarEstoqueException();

			estoque.getSituacoes().add(situacaoEstoque);

			if (selos != null)
				selos.stream()
					 .filter(selo -> estoque.getSelos().stream().noneMatch(seloEstoque -> seloEstoque.equals(selo)))
					 .forEach(estoque::adicionarSelo);

			estoque.removeEvents();

			return estoque;
		} else {
			var estoque = Estoque.builder()
								 .id(EstoqueId.generate())
								 .produto(produto)
								 .sku(sku)
								 .saldo(BigDecimal.ZERO)
								 .estoqueHash(estoqueHash)
								 .rastreioId(rastreioId)
								 .selos(selos)
								 .dataHoraEntrada(dataHoraEntrada)
								 .build();

			if (Objects.nonNull(bloqueioMovimentacaoUnitizadorId)) {
				if (situacaoEstoque instanceof SituacaoEstoqueBloqueado situacaoEstoqueBloqueado)
					estoque.bloquearMovimentacaoUnitizador(bloqueioMovimentacaoUnitizadorId,
														   situacaoEstoqueBloqueado.getChaveAcesso());
				else
					estoque.bloquearMovimentacaoUnitizador(bloqueioMovimentacaoUnitizadorId);
			}

			return estoque;
		}
	}

	public Estoque configurar(Produto produto,
							  SKU sku,
							  SituacaoEstoque situacaoEstoque,
							  EstoqueHash estoqueHash,
							  RastreioId rastreioId,
							  List<SeloEstoque> selos,
							  ZonedDateTime dataHoraEntrada) {
		return configurar(produto, sku, situacaoEstoque, estoqueHash, null, rastreioId, selos, dataHoraEntrada);
	}

	public RastreioId definirRastreio(BigDecimal quantidade, Estoque estoqueSaida) {
		return quantidade.compareTo(estoqueSaida.getSaldo()) == 0 ? estoqueSaida.getRastreioId() : null;
	}
}
