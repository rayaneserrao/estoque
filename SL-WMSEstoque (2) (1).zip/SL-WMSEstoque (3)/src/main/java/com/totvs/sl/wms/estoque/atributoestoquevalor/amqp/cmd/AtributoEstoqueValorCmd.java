package com.totvs.sl.wms.estoque.atributoestoquevalor.amqp.cmd;

import java.util.Collections;
import java.util.List;
import java.util.TreeSet;
import java.util.stream.Collectors;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.springframework.util.CollectionUtils;

import com.totvs.sl.wms.estoque.atributoestoque.domain.model.AtributoEstoqueId;
import com.totvs.sl.wms.estoque.atributoestoque.domain.model.ControleQuantidadeAtributoEstoqueValor;
import com.totvs.sl.wms.estoque.atributoestoque.domain.model.FormatoAtributoEstoqueValor;
import com.totvs.sl.wms.estoque.atributoestoquevalor.domain.model.AtributoEstoqueValor;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public final class AtributoEstoqueValorCmd {

	@NotNull(message = "{AtributoEstoqueValorCmd.id.NotNull}")
	private final AtributoEstoqueId id;

	@NotNull(message = "{AtributoEstoqueValorCmd.formato.NotNull}")
	private final FormatoAtributoEstoqueValor formato;

	@NotNull(message = "{AtributoEstoqueValorCmd.controleQuantidade.NotNull}")
	private final ControleQuantidadeAtributoEstoqueValor controleQuantidade;

	@NotNull(message = "{AtributoEstoqueValorCmd.valores.NotNull}")
	@Size(min = 1, message = "{AtributoEstoqueValorCmd.valores.Size}")
	private final TreeSet<String> valores;

	public static List<AtributoEstoqueValor<?>> toAtributoEstoqueValor(List<AtributoEstoqueValorCmd> atributos) {

		if (CollectionUtils.isEmpty(atributos))
			return Collections.emptyList();

		return atributos.stream()
						.map(atributo -> atributo.getFormato()
												 .getInstance(atributo.getId(),
															  atributo.getValores(),
															  atributo.getControleQuantidade()))
						.collect(Collectors.toList());
	}
}
