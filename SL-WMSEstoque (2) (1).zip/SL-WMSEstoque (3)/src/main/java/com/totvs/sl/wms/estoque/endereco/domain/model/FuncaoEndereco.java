package com.totvs.sl.wms.estoque.endereco.domain.model;

public enum FuncaoEndereco {
	ARMAZENAGEM, DOCA, STAGE, PICKING, PRODUCAO, INTERMEDIARIO;

	public boolean isPicking() {
		return PICKING.equals(this);
	}

	public boolean isDoca() {
		return DOCA.equals(this);
	}

	public boolean isStage() {
		return STAGE.equals(this);
	}
}