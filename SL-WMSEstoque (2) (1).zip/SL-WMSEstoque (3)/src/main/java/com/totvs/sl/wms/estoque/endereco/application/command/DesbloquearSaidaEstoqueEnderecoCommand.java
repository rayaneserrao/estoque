package com.totvs.sl.wms.estoque.endereco.application.command;

import com.totvs.sl.wms.estoque.endereco.domain.model.EnderecoId;

import io.micrometer.core.lang.NonNull;
import lombok.Data;

@Data(staticConstructor = "of")
public final class DesbloquearSaidaEstoqueEnderecoCommand {

	@NonNull
	private final EnderecoId id;

	@NonNull
	private final String chaveAcesso;
}
