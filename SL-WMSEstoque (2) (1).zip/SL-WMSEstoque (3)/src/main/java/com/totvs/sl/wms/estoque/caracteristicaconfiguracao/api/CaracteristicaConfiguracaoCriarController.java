package com.totvs.sl.wms.estoque.caracteristicaconfiguracao.api;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

import javax.annotation.security.RolesAllowed;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.totvs.sl.wms.estoque.caracteristicaconfiguracao.api.dto.CriarCaracteristicaConfiguracaoDTO;
import com.totvs.sl.wms.estoque.caracteristicaconfiguracao.application.CaracteristicaConfiguracaoCriarApplicationService;
import com.totvs.sl.wms.estoque.caracteristicaconfiguracao.application.command.CriarCaracteristicaConfiguracaoCommand;
import com.totvs.sl.wms.estoque.caracteristicaconfiguracao.domain.model.CaracteristicaConfiguracaoId;
import com.totvs.sl.wms.estoque.caracteristicaconfiguracao.domain.model.CaracteristicaConfiguracaoOrigem;
import com.totvs.sl.wms.estoque.caracteristicaconfiguracao.domain.model.FormatoCaracteristicaValor;
import com.totvs.sl.wms.estoque.caracteristicaconfiguracao.exception.WMSCaracteristicaConfiguracaoConstraintException;
import com.totvs.sl.wms.estoque.usuario.domain.model.UsuarioPerfil;
import com.totvs.tjf.api.context.stereotype.ApiGuideline;
import com.totvs.tjf.api.context.stereotype.ApiGuideline.ApiGuidelineVersion;
import com.totvs.tjf.core.validation.ValidatorService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.AllArgsConstructor;

@Tag(name = "caracteristica-configuracao")

@AllArgsConstructor
@RestController
@RequestMapping(path = CaracteristicaConfiguracaoCriarController.PATH, produces = APPLICATION_JSON_VALUE, consumes = APPLICATION_JSON_VALUE)
@ApiGuideline(ApiGuidelineVersion.V2)
@RolesAllowed({ UsuarioPerfil.Perfil.PLANEJADOR_WMS, UsuarioPerfil.Perfil.PLANEJADOR_WMS_SENIOR })
public class CaracteristicaConfiguracaoCriarController {

	public static final String PATH = "/api/v1/caracteristicasConfiguracao";

	private final CaracteristicaConfiguracaoCriarApplicationService criarService;

	private final ValidatorService validator;

	@Operation(description = "Cadastrar uma nova característica de estoque.", method = "POST")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "201", description = "Característica de estoque cadastrada com sucesso."),
			@ApiResponse(responseCode = "400", description = "A característica de estoque não pôde ser cadastrada pois possui alguma informação inválida.") })
	@PostMapping
	public ResponseEntity<Void> criar(@RequestBody CriarCaracteristicaConfiguracaoDTO dto) {

		validator.validate(dto).ifPresent(violations -> {
			throw new WMSCaracteristicaConfiguracaoConstraintException(violations);
		});

		var cmd = CriarCaracteristicaConfiguracaoCommand.of(dto.getDescricao(),
															FormatoCaracteristicaValor.valueOf(dto.getFormato()),
															CaracteristicaConfiguracaoOrigem.INCLUSAO_MANUAL);

		CaracteristicaConfiguracaoId id = criarService.handle(cmd);

		return ResponseEntity.created(ServletUriComponentsBuilder.fromCurrentRequest()
																 .path("/")
																 .path(id.toString())
																 .build()
																 .toUri())
							 .build();
	}
}
