package com.totvs.sl.wms.estoque.caracteristicaconfiguracao.domain.model;

import java.util.UUID;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.totvs.tjf.core.common.domain.DomainObjectId;

public final class CaracteristicaConfiguracaoId extends DomainObjectId<UUID>
		implements Comparable<CaracteristicaConfiguracaoId> {

	private static final long serialVersionUID = -3898869524371813005L;

	protected CaracteristicaConfiguracaoId(UUID id) {
		super(id);
	}

	public static CaracteristicaConfiguracaoId generate() {
		return new CaracteristicaConfiguracaoId(UUID.randomUUID());
	}

	@JsonCreator
	public static CaracteristicaConfiguracaoId from(String uuid) {
		return uuid == null ? null : new CaracteristicaConfiguracaoId(UUID.fromString(uuid));
	}

	public int compareTo(CaracteristicaConfiguracaoId o) {// NOSONAR
		return this.getId().compareTo(o.getId());
	}
}
