package com.totvs.sl.wms.estoque.endereco.exception;

import java.util.Set;

import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;

import com.totvs.tjf.api.context.stereotype.error.ApiBadRequest;

@ApiBadRequest
public class WMSEnderecoConstraintException extends ConstraintViolationException {

	private static final long serialVersionUID = 1721199201291818274L;

	public WMSEnderecoConstraintException(Set<? extends ConstraintViolation<?>> constraintViolations) {
		super(constraintViolations);
	}
}