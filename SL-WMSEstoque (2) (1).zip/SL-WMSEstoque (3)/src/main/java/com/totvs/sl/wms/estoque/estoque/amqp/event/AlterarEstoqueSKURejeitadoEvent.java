package com.totvs.sl.wms.estoque.estoque.amqp.event;

import java.util.Collection;

import com.totvs.sl.wms.estoque.estoque.domain.model.EstoqueId;
import com.totvs.sl.wms.estoque.sku.domain.model.SKUId;
import com.totvs.sl.wms.estoque.util.amqp.RejectedEvent;
import com.totvs.sl.wms.estoque.util.amqp.SubjectConfiguracao;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data(staticConstructor = "of")
@EqualsAndHashCode(callSuper = false)
public final class AlterarEstoqueSKURejeitadoEvent extends RejectedEvent implements SubjectConfiguracao {

	public static final String NAME = "AlterarEstoqueSKURejeitadoEvent";

	public static final String CONDITIONAL_EXPRESSION = "headers['type']=='" + NAME + "'";

	private final EstoqueId estoqueId;

	private final SKUId skuId;

	private final Collection<Inconsistencia> inconsistencias;

	@Data(staticConstructor = "of")
	public static final class Inconsistencia {
		private final String id;
		private final String mensagem;
		private final String detalhe;
	}

}
