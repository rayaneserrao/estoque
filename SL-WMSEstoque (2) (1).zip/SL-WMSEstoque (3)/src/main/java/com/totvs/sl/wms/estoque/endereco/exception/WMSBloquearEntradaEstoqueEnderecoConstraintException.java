package com.totvs.sl.wms.estoque.endereco.exception;

import java.util.Set;

import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;

import com.totvs.tjf.api.context.stereotype.error.ApiBadRequest;

@ApiBadRequest("WMSGenericConstraintViolationException")
public class WMSBloquearEntradaEstoqueEnderecoConstraintException extends ConstraintViolationException {

	private static final long serialVersionUID = -1893164626868775893L;

	public WMSBloquearEntradaEstoqueEnderecoConstraintException(Set<? extends ConstraintViolation<?>> constraintViolations) {
		super(constraintViolations);
	}

}
