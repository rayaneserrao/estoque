package com.totvs.sl.wms.estoque.atributoestoque.application;

import javax.transaction.Transactional;

import org.springframework.stereotype.Service;

import com.totvs.sl.wms.estoque.atributoestoque.application.command.DesmarcarUtilizacaoAtributoEstoqueCommand;
import com.totvs.sl.wms.estoque.atributoestoque.domain.model.AtributoEstoqueDomainRepository;

import lombok.AllArgsConstructor;

@Service
@Transactional
@AllArgsConstructor
public class AtributoEstoqueDesmarcarUtilizacaoApplicationService {

	private AtributoEstoqueDomainRepository repository;

	public void handle(DesmarcarUtilizacaoAtributoEstoqueCommand cmd) {

		var atributoEstoque = repository.findByIdOrThrowNotFound(cmd.getId());

		atributoEstoque.desmarcarUtilizado(cmd.getFuncionalidade());

		repository.update(atributoEstoque);
	}

}
