package com.totvs.sl.wms.estoque.estoque.application.command;

import com.totvs.sl.wms.estoque.caracteristicaconfiguracao.domain.model.CaracteristicaConfiguracaoId;
import com.totvs.sl.wms.estoque.estoque.domain.model.EstoqueId;

import lombok.Data;

@Data(staticConstructor = "of")
public final class AlterarEstoqueCaracteristicaCommand {
	private final EstoqueId id;
	private final CaracteristicaConfiguracaoId caracteristicaConfiguracaoId;
	private final String valor;
}
