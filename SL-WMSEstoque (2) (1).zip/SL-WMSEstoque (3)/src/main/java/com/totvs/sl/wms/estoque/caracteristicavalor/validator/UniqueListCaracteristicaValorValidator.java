package com.totvs.sl.wms.estoque.caracteristicavalor.validator;

import java.util.List;
import java.util.stream.Collectors;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import org.springframework.util.CollectionUtils;

import com.totvs.sl.wms.estoque.caracteristicavalor.domain.model.CaracteristicaValor;

public class UniqueListCaracteristicaValorValidator
        implements ConstraintValidator<UniqueListCaracteristicaValor, List<CaracteristicaValor<?>>> {

	@Override
	public boolean isValid(List<CaracteristicaValor<?>> list, ConstraintValidatorContext context) {
		if (CollectionUtils.isEmpty(list))
			return true;
		var set = list.stream().map(CaracteristicaValor::getCaracteristicaConfiguracaoId).collect(Collectors.toSet());
		return set.size() == list.size();
	}
}