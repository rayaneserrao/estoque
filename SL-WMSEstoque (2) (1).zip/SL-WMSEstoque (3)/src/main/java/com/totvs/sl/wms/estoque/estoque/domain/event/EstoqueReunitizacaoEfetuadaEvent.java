package com.totvs.sl.wms.estoque.estoque.domain.event;

import java.math.BigDecimal;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.util.CollectionUtils;

import com.totvs.sl.wms.estoque.caracteristicaconfiguracao.domain.model.CaracteristicaConfiguracaoId;
import com.totvs.sl.wms.estoque.caracteristicaconfiguracao.domain.model.FormatoCaracteristicaValor;
import com.totvs.sl.wms.estoque.caracteristicavalor.domain.model.CaracteristicaValor;
import com.totvs.sl.wms.estoque.endereco.domain.model.EnderecoId;
import com.totvs.sl.wms.estoque.estoque.application.EstoqueSaida;
import com.totvs.sl.wms.estoque.estoque.domain.model.Estoque;
import com.totvs.sl.wms.estoque.estoque.domain.model.EstoqueId;
import com.totvs.sl.wms.estoque.estoque.domain.model.SituacaoEstoque;
import com.totvs.sl.wms.estoque.estoque.domain.model.SituacaoEstoqueLiberado;
import com.totvs.sl.wms.estoque.estoque.domain.model.SituacaoEstoqueValor;
import com.totvs.sl.wms.estoque.produto.domain.model.ProdutoId;
import com.totvs.sl.wms.estoque.rastreio.domain.model.RastreioId;
import com.totvs.sl.wms.estoque.sku.domain.model.SKUId;
import com.totvs.sl.wms.estoque.tipoestoque.domain.model.TipoEstoqueId;
import com.totvs.sl.wms.estoque.unidade.domain.model.UnidadeId;
import com.totvs.sl.wms.estoque.unitizador.domain.model.UnitizadorId;
import com.totvs.sl.wms.estoque.util.amqp.SubjectConfiguracao;
import com.totvs.sl.wms.estoque.util.amqp.SubjectDomainEvent;

import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
@Builder
public final class EstoqueReunitizacaoEfetuadaEvent extends SubjectDomainEvent implements SubjectConfiguracao {

	private final UnidadeId unidadeId;
	private final ProdutoId produtoId;
	private final SKUId skuId;
	private final UnitizadorId unitizadorId;
	private final TipoEstoqueId tipoEstoqueId;
	private final EnderecoId enderecoId;
	private final Boolean avariado;

	private final List<EstoqueReunitizacaoSaida> estoquesSaida;
	private final List<EstoqueReunitizacaoEntrada> estoquesEntrada;

	@Data(staticConstructor = "of")
	public static final class EstoqueOrigem {
		private final String id;
		private final String origem;
	}

	@Data
	@Builder
	public static final class EstoqueReunitizacaoSaida {
		private final EstoqueId id;
		private final BigDecimal saldo;
		private final BigDecimal saldoReservado;
		private final BigDecimal saldoDisponivel;
		private final BigDecimal quantidadeBloqueadaMovimentacaoNaoReservada;
		private final BigDecimal quantidadeBloqueadaMovimentacaoReservada;
		private final BigDecimal quantidadeBloqueadaMovimentacaoTotal;
		private final List<EstoqueAtributoSaldoEvent> atributosSaldo;
	}

	@Data
	@Builder
	public static final class EstoqueReunitizacaoEntrada {
		private final EstoqueId id;
		private final RastreioId rastreioId;
		private final Set<SituacaoEstoqueEntrada> situacoes;
		private final List<CaracteristicaEstoqueEntrada> caracteristicas;
		private final List<EstoqueAtributoSaldoEvent> atributosSaldo;
		private final BigDecimal saldo;
		private final BigDecimal saldoReservado;
		private final BigDecimal saldoDisponivel;
		private final BigDecimal quantidadeBloqueadaMovimentacaoNaoReservada;
		private final BigDecimal quantidadeBloqueadaMovimentacaoReservada;
		private final BigDecimal quantidadeBloqueadaMovimentacaoTotal;
		private final List<SeloEstoqueEvent> selos;
		private final ZonedDateTime dataHoraEntrada;
	}

	@Data
	@Builder
	public static final class SituacaoEstoqueEntrada {
		private final SituacaoEstoqueValor situacao;
		private final ZonedDateTime quando;
		private final String chaveAcesso;
		private final String motivo;
	}

	@Data(staticConstructor = "of")
	public static final class CaracteristicaEstoqueEntrada {
		private final CaracteristicaConfiguracaoId caracteristicaConfiguracaoId;
		private final FormatoCaracteristicaValor formato;
		private final String valor;
	}

	@Data(staticConstructor = "of")
	public static final class SeloEstoqueEvent {
		private final String chave;
		private final String valor;
	}

	public static EstoqueReunitizacaoEfetuadaEvent from(Collection<Estoque> estoquesEntrada,
														Collection<EstoqueSaida> estoquesSaida) {
		Estoque estoqueRef = estoquesEntrada.iterator().next();

		return EstoqueReunitizacaoEfetuadaEvent.builder()
											   .avariado(estoqueRef.getAvariado())
											   .enderecoId(estoqueRef.getEnderecoId())
											   .produtoId(estoqueRef.getProdutoId())
											   .skuId(estoqueRef.getSkuId())
											   .tipoEstoqueId(estoqueRef.getTipoEstoqueId())
											   .unidadeId(estoqueRef.getUnidadeId())
											   .unitizadorId(estoqueRef.getUnitizadorId())
											   .estoquesSaida(estoquesSaida.stream()
																		   .map(estoqueSaidaValor -> EstoqueReunitizacaoSaida.builder()
																															 .id(estoqueSaidaValor.getEstoqueId())
																															 .saldo(estoqueSaidaValor.getSaldo())
																															 .saldoReservado(estoqueSaidaValor.getSaldoReservado())
																															 .saldoDisponivel(estoqueSaidaValor.getSaldoDisponivel())
																															 .quantidadeBloqueadaMovimentacaoNaoReservada(estoqueSaidaValor.getQuantidadeBloqueadaMovimentacaoNaoReservada())
																															 .quantidadeBloqueadaMovimentacaoReservada(estoqueSaidaValor.getQuantidadeBloqueadaMovimentacaoReservada())
																															 .quantidadeBloqueadaMovimentacaoTotal(estoqueSaidaValor.getQuantidadeBloqueadaMovimentacaoTotal())
																															 .atributosSaldo(EstoqueAtributoSaldoEvent.from(estoqueSaidaValor.getAtributosSaldo()))
																															 .build())
																		   .collect(Collectors.toList()))
											   .estoquesEntrada(estoquesEntrada.stream()
																			   .map(estoqueEntradaValor -> EstoqueReunitizacaoEntrada.builder()
																																	 .id(estoqueEntradaValor.getId())
																																	 .caracteristicas(montarCaracteristicasEstoqueDestino(estoqueEntradaValor.getCaracteristicas()))
																																	 .atributosSaldo(EstoqueAtributoSaldoEvent.from(estoqueEntradaValor.getAtributosSaldo()))
																																	 .situacoes(montarSituacoesEstoqueDestino(estoqueEntradaValor.getSituacoes()))
																																	 .rastreioId(estoqueEntradaValor.getRastreioId())
																																	 .saldo(estoqueEntradaValor.getSaldo())
																																	 .saldoReservado(estoqueEntradaValor.getQuantidadeReservada())
																																	 .saldoDisponivel(estoqueEntradaValor.getSaldoDisponivel())
																																	 .quantidadeBloqueadaMovimentacaoNaoReservada(estoqueEntradaValor.getQuantidadeBloqueadaParaMovimentacaoEstoqueNaoReservada())
																																	 .quantidadeBloqueadaMovimentacaoReservada(estoqueEntradaValor.getQuantidadeBloqueadaParaMovimentacaoEstoqueReservada())
																																	 .quantidadeBloqueadaMovimentacaoTotal(estoqueEntradaValor.getQuantidadeBloqueadaParaMovimentacaoEstoqueTotal())
																																	 .selos(estoqueEntradaValor.getSelos()
																																							   .stream()
																																							   .map(selo -> SeloEstoqueEvent.of(selo.getChave(),
																																																selo.getValor()))
																																							   .collect(Collectors.toList()))
																																	 .dataHoraEntrada(estoqueEntradaValor.getDataHoraEntrada())
																																	 .build())
																			   .collect(Collectors.toList()))
											   .build();
	}

	private static Set<SituacaoEstoqueEntrada> montarSituacoesEstoqueDestino(Set<SituacaoEstoque> situacoes) {
		return situacoes.stream().map(EstoqueReunitizacaoEfetuadaEvent::criar).collect(Collectors.toSet());
	}

	private static SituacaoEstoqueEntrada criar(SituacaoEstoque situacao) {
		var situacaoLiberado = (SituacaoEstoqueLiberado) situacao;

		return SituacaoEstoqueEntrada.builder()
									 .situacao(SituacaoEstoqueValor.LIBERADO)
									 .quando(situacaoLiberado.getQuando())
									 .build();
	}

	private static List<CaracteristicaEstoqueEntrada> montarCaracteristicasEstoqueDestino(List<CaracteristicaValor<?>> caracteristicas) {
		if (CollectionUtils.isEmpty(caracteristicas)) {
			return new ArrayList<>();
		}
		return caracteristicas.stream()
							  .map(caracteristica -> CaracteristicaEstoqueEntrada.of(caracteristica.getCaracteristicaConfiguracaoId(),
																					 caracteristica.getFormato(),
																					 caracteristica.getValor()
																								   .toString()))
							  .collect(Collectors.toList());
	}
}
