package com.totvs.sl.wms.estoque.estoque.exception;

import java.util.Set;

import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;

import com.totvs.tjf.api.context.stereotype.error.ApiBadRequest;

@ApiBadRequest("WMSEfetuarEntradaEstoqueLiberadoConstraintException")
public class WMSEfetuarEntradaEstoqueLiberadoConstraintException extends ConstraintViolationException {

	private static final long serialVersionUID = 4641742797135557763L;

	public WMSEfetuarEntradaEstoqueLiberadoConstraintException(Set<? extends ConstraintViolation<?>> constraintViolations) {
		super(constraintViolations);
	}
}
