package com.totvs.sl.wms.estoque.endereco.amqp;

import org.springframework.cloud.stream.annotation.EnableBinding;
import org.springframework.cloud.stream.annotation.StreamListener;

import com.totvs.sl.wms.estoque.config.amqp.WMSChannel;
import com.totvs.sl.wms.estoque.endereco.amqp.event.EnderecoTransformadoFuncaoArmazenagemEvent;
import com.totvs.sl.wms.estoque.endereco.amqp.event.EnderecoTransformadoFuncaoPickingEvent;
import com.totvs.sl.wms.estoque.endereco.application.EnderecoApplicationService;
import com.totvs.sl.wms.estoque.endereco.application.command.AlterarFuncaoEnderecoCommand;
import com.totvs.sl.wms.estoque.endereco.application.command.AtualizarOcupacaoEnderecoCommand;
import com.totvs.sl.wms.estoque.endereco.application.command.AtualizarOcupacaoEnderecoSKUCommand;
import com.totvs.sl.wms.estoque.endereco.domain.model.FuncaoEndereco;
import com.totvs.sl.wms.estoque.movimentoestoque.domain.event.MovimentoEstoqueCriadoEvent;
import com.totvs.sl.wms.estoque.sku.domain.event.SKUAlteradoEvent;
import com.totvs.sl.wms.estoque.util.amqp.AMQPUtil;
import com.totvs.tjf.messaging.context.TOTVSMessage;

import lombok.AllArgsConstructor;

@AllArgsConstructor
@EnableBinding(value = { WMSChannel.WMSEnderecoEventsInput.class, WMSChannel.WMSEstoqueEventsInput.class })
public class EnderecoEventsSubscriber {

	private EnderecoApplicationService service;

	@StreamListener(target = WMSChannel.WMS_ENDERECO_EVENTS_IN, condition = EnderecoTransformadoFuncaoArmazenagemEvent.CONDITIONAL_EXPRESSION)
	public void enderecoTransformadoFuncaoArmazenagemEvent(final TOTVSMessage<EnderecoTransformadoFuncaoArmazenagemEvent> message) {

		AMQPUtil.gerarLog(this.getClass(), message, EnderecoTransformadoFuncaoArmazenagemEvent.CONDITIONAL_EXPRESSION);

		var event = message.getContent();

		var cmd = AlterarFuncaoEnderecoCommand.of(event.getId(), FuncaoEndereco.ARMAZENAGEM);

		service.handle(cmd);

	}

	@StreamListener(target = WMSChannel.WMS_ENDERECO_EVENTS_IN, condition = EnderecoTransformadoFuncaoPickingEvent.CONDITIONAL_EXPRESSION)
	public void enderecoTransformadoFuncaoPickingEvent(final TOTVSMessage<EnderecoTransformadoFuncaoPickingEvent> message) {

		AMQPUtil.gerarLog(this.getClass(), message, EnderecoTransformadoFuncaoPickingEvent.CONDITIONAL_EXPRESSION);

		var event = message.getContent();

		var cmd = AlterarFuncaoEnderecoCommand.of(event.getId(), FuncaoEndereco.PICKING);

		service.handle(cmd);

	}

	@StreamListener(target = WMSChannel.WMS_ESTOQUE_EVENTS_IN, condition = MovimentoEstoqueCriadoEvent.CONDITIONAL_EXPRESSION)
	public void movimentoEstoqueCriadoEvent(final TOTVSMessage<MovimentoEstoqueCriadoEvent> message) {

		var event = message.getContent();

		if (event.isAlteraOcupacaoEndereco()) {
			AMQPUtil.gerarLog(this.getClass(), message, MovimentoEstoqueCriadoEvent.CONDITIONAL_EXPRESSION);

			service.handle(AtualizarOcupacaoEnderecoCommand.builder()
														   .id(event.getEnderecoId())
														   .skuId(event.getSkuId())
														   .quantidade(event.getQuantidade())
														   .tipoMovimento(event.getTipo())
														   .build());
		}
	}

	@StreamListener(target = WMSChannel.WMS_ESTOQUE_EVENTS_IN, condition = SKUAlteradoEvent.CONDITIONAL_EXPRESSION)
	public void skuAlteradoEvent(final TOTVSMessage<SKUAlteradoEvent> message) {

		AMQPUtil.gerarLog(this.getClass(), message, SKUAlteradoEvent.CONDITIONAL_EXPRESSION);

		var event = message.getContent();

		service.handle(AtualizarOcupacaoEnderecoSKUCommand.of(event.getId()));

	}

}
