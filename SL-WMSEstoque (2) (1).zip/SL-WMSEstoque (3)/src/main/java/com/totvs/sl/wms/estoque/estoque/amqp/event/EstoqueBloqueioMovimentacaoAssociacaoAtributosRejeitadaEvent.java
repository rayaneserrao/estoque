package com.totvs.sl.wms.estoque.estoque.amqp.event;

import com.totvs.sl.wms.estoque.bloqueiomovimentacaoestoque.domain.model.BloqueioMovimentacaoEstoqueId;
import com.totvs.sl.wms.estoque.estoque.domain.event.SubjectBloqueioEstoque;
import com.totvs.sl.wms.estoque.estoque.domain.model.EstoqueId;
import com.totvs.sl.wms.estoque.util.amqp.RejectedEvent;
import com.totvs.tjf.api.context.response.ApiErrorResponse;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data(staticConstructor = "of")
@EqualsAndHashCode(callSuper = false)
public final class EstoqueBloqueioMovimentacaoAssociacaoAtributosRejeitadaEvent extends RejectedEvent
		implements SubjectBloqueioEstoque {

	private final EstoqueId estoqueId;
	private final BloqueioMovimentacaoEstoqueId bloqueioMovimentacaoEstoqueId;
	private final ApiErrorResponse inconsistencia;

}
