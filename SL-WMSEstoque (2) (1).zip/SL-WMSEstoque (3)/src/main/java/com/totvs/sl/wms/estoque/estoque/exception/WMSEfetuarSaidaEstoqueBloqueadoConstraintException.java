package com.totvs.sl.wms.estoque.estoque.exception;

import com.totvs.tjf.api.context.stereotype.error.ApiBadRequest;

import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;
import java.util.Set;

@ApiBadRequest("WMSEfetuarSaidaEstoqueBloqueadoConstraintException")
public class WMSEfetuarSaidaEstoqueBloqueadoConstraintException extends ConstraintViolationException {

	private static final long serialVersionUID = -408488342320176422L;

	public WMSEfetuarSaidaEstoqueBloqueadoConstraintException(Set<? extends ConstraintViolation<?>> constraintViolations) {
		super(constraintViolations);
	}
}
