package com.totvs.sl.wms.estoque.caracteristicaconfiguracao.application;

import javax.transaction.Transactional;

import org.springframework.stereotype.Service;

import com.totvs.sl.wms.estoque.caracteristicaconfiguracao.application.command.ExcluirCaracteristicaConfiguracaoCommand;
import com.totvs.sl.wms.estoque.caracteristicaconfiguracao.domain.model.CaracteristicaConfiguracaoDomainRepository;
import com.totvs.sl.wms.estoque.config.amqp.WMSPublisher;

import lombok.AllArgsConstructor;

@Service
@Transactional
@AllArgsConstructor
public class CaracteristicaConfiguracaoExcluirApplicationService {

	private CaracteristicaConfiguracaoDomainRepository repository;
	private WMSPublisher publisher;

	public void handle(ExcluirCaracteristicaConfiguracaoCommand cmd) {

		var caracteristicaConfiguracao = repository.findByIdOrThrowNotFound(cmd.getId());

		caracteristicaConfiguracao.excluir();

		repository.delete(cmd.getId());

		caracteristicaConfiguracao.getEvents().forEach(publisher::dispatch);
	}
}
