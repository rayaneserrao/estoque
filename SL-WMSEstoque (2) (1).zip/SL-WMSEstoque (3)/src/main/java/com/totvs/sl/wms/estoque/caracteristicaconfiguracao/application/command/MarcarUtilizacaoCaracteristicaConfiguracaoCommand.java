package com.totvs.sl.wms.estoque.caracteristicaconfiguracao.application.command;

import com.totvs.sl.wms.estoque.caracteristicaconfiguracao.domain.model.CaracteristicaConfiguracaoId;

import lombok.Data;

@Data(staticConstructor = "of")
public final class MarcarUtilizacaoCaracteristicaConfiguracaoCommand {

	private final CaracteristicaConfiguracaoId id;
	private final String funcionalidade;
}
