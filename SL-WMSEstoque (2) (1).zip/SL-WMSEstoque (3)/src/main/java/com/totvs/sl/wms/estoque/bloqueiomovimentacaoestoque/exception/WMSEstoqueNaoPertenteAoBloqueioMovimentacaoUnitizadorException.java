package com.totvs.sl.wms.estoque.bloqueiomovimentacaoestoque.exception;

import com.totvs.tjf.api.context.stereotype.error.ApiBadRequest;

@ApiBadRequest
public class WMSEstoqueNaoPertenteAoBloqueioMovimentacaoUnitizadorException extends RuntimeException {
	
	private static final long serialVersionUID = 7139151445862758947L;

}
