package com.totvs.sl.wms.estoque.endereco.application.command;

import com.totvs.sl.wms.estoque.endereco.domain.model.EnderecoId;
import com.totvs.sl.wms.estoque.origem.domain.model.Origem;

import lombok.Data;
import lombok.NonNull;

@Data(staticConstructor = "of")
public final class BloquearEntradaEstoqueEnderecoCommand {

	@NonNull
	private final EnderecoId id;

	@NonNull
	private final Origem origem;

	@NonNull
	private final String chaveAcesso;
}
