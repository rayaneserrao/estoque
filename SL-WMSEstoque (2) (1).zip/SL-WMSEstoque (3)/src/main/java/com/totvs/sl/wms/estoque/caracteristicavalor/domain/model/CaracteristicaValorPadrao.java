package com.totvs.sl.wms.estoque.caracteristicavalor.domain.model;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
@Getter
public enum CaracteristicaValorPadrao {

	CARACTERISTICA_TEXTO("Alterar"), CARACTERISTICA_NUMERO("999999"), CARACTERISTICA_DATA("1900-01-01");

	private final String valor;

}
