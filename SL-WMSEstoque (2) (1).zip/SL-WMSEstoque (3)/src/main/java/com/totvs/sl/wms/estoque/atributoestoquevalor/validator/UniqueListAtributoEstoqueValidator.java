package com.totvs.sl.wms.estoque.atributoestoquevalor.validator;

import java.util.List;
import java.util.stream.Collectors;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import org.springframework.util.CollectionUtils;

import com.totvs.sl.wms.estoque.atributoestoquevalor.domain.model.AtributoEstoqueValor;

public class UniqueListAtributoEstoqueValidator
		implements ConstraintValidator<UniqueListAtributoEstoqueValor, List<AtributoEstoqueValor<?>>> {

	@Override
	public boolean isValid(List<AtributoEstoqueValor<?>> list, ConstraintValidatorContext context) {
		if (CollectionUtils.isEmpty(list))
			return true;
		var set = list.stream().map(AtributoEstoqueValor::getId).collect(Collectors.toSet());
		return set.size() == list.size();
	}
}