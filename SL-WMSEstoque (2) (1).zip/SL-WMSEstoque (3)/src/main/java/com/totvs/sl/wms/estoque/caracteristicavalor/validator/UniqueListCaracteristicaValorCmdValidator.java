package com.totvs.sl.wms.estoque.caracteristicavalor.validator;

import java.util.List;
import java.util.stream.Collectors;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import org.springframework.util.CollectionUtils;

import com.totvs.sl.wms.estoque.caracteristicavalor.amqp.cmd.CaracteristicaValorCmd;

public class UniqueListCaracteristicaValorCmdValidator
		implements ConstraintValidator<UniqueListCaracteristicaCmdValor, List<CaracteristicaValorCmd>> {

	@Override
	public boolean isValid(List<CaracteristicaValorCmd> list, ConstraintValidatorContext context) {
		if (CollectionUtils.isEmpty(list))
			return true;
		var set = list.stream()
					  .map(CaracteristicaValorCmd::getCaracteristicaConfiguracaoId)
					  .collect(Collectors.toSet());
		return set.size() == list.size();
	}
}