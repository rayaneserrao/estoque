package com.totvs.sl.wms.estoque.bloqueiomovimentacaounitizador.exception;

import com.totvs.tjf.api.context.stereotype.error.ApiBadRequest;

@ApiBadRequest
public class WMSBloqueioMovimentacaoUnitizadorNaoEncontradoException extends RuntimeException {

	private static final long serialVersionUID = 3644714114784327351L;

}
