package com.totvs.sl.wms.estoque.categoriaproduto.exception;

import com.totvs.tjf.api.context.stereotype.error.ApiBadRequest;

@ApiBadRequest
public class WMSCategoriaProdutoNaoEncontradaException extends RuntimeException {
	private static final long serialVersionUID = 1784902210447397123L;
}
