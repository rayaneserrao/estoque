package com.totvs.sl.wms.estoque.bloqueiomovimentacaoestoque.domain.model;

import java.util.UUID;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.totvs.tjf.core.common.domain.DomainObjectId;

public final class BloqueioMovimentacaoEstoqueId extends DomainObjectId<UUID> {

	private static final long serialVersionUID = 2272204830778589029L;

	protected BloqueioMovimentacaoEstoqueId(UUID id) {
		super(id);
	}

	public static BloqueioMovimentacaoEstoqueId generate() {
        return new BloqueioMovimentacaoEstoqueId(UUID.randomUUID());
    }
    
	@JsonCreator
    public static BloqueioMovimentacaoEstoqueId from(String uuid) {
        return uuid == null ? null : new BloqueioMovimentacaoEstoqueId(UUID.fromString(uuid));
    }
}