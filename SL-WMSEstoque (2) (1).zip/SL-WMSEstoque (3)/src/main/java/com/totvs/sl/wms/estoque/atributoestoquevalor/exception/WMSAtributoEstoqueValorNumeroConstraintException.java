package com.totvs.sl.wms.estoque.atributoestoquevalor.exception;

import java.util.Set;

import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;

import com.totvs.tjf.api.context.stereotype.error.ApiBadRequest;

@ApiBadRequest("WMSGenericConstraintViolationException")
public class WMSAtributoEstoqueValorNumeroConstraintException extends ConstraintViolationException {

	private static final long serialVersionUID = 1L;

	public WMSAtributoEstoqueValorNumeroConstraintException(Set<? extends ConstraintViolation<?>> constraintViolations) {
		super(constraintViolations);
	}

}
