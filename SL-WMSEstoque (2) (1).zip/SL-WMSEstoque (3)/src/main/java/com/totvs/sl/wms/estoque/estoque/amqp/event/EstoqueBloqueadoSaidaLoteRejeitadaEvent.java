package com.totvs.sl.wms.estoque.estoque.amqp.event;

import java.util.List;

import com.totvs.sl.wms.estoque.estoque.domain.event.SubjectSaidaEstoque;
import com.totvs.sl.wms.estoque.unidade.domain.model.UnidadeId;
import com.totvs.sl.wms.estoque.util.amqp.TransactionalEvent;

import lombok.Builder;
import lombok.Data;
import lombok.Getter;
import lombok.ToString;

@Getter
@ToString
public final class EstoqueBloqueadoSaidaLoteRejeitadaEvent extends TransactionalEvent implements SubjectSaidaEstoque {

	private final UnidadeId unidadeId;
	private final List<Inconsistencia> inconsistencias;

	@Data(staticConstructor = "of")
	public static final class Inconsistencia {
		private final String id;
		private final String mensagem;
		private final String detalhe;
	}

	@Builder
	private EstoqueBloqueadoSaidaLoteRejeitadaEvent(String generatedBy,
													String transactionId,
													UnidadeId unidadeId,
													List<Inconsistencia> inconsistencias) {
		super(generatedBy, transactionId);
		this.unidadeId = unidadeId;
		this.inconsistencias = inconsistencias;
	}
}
