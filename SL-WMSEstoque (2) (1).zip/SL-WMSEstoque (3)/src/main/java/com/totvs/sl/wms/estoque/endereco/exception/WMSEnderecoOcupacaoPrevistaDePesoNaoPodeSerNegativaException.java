package com.totvs.sl.wms.estoque.endereco.exception;

import java.math.BigDecimal;

import com.totvs.tjf.api.context.stereotype.ApiErrorParameter;
import com.totvs.tjf.api.context.stereotype.error.ApiBadRequest;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
@ApiBadRequest
public class WMSEnderecoOcupacaoPrevistaDePesoNaoPodeSerNegativaException extends RuntimeException {

	private static final long serialVersionUID = 8272500902352698012L;

	@ApiErrorParameter
	private final BigDecimal peso;

	@ApiErrorParameter
	private final BigDecimal novaOcupacaoPrevistaPeso;
	
}
