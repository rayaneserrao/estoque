package com.totvs.sl.wms.estoque.caracteristicavalor.domain.model;

import static com.totvs.tjf.autoconfigure.ValidationUtils.validateIntegrity;

import java.math.BigDecimal;
import java.util.Comparator;

import javax.validation.constraints.Digits;
import javax.validation.constraints.NotNull;

import com.totvs.sl.wms.estoque.caracteristicaconfiguracao.domain.model.CaracteristicaConfiguracaoId;
import com.totvs.sl.wms.estoque.caracteristicaconfiguracao.domain.model.FormatoCaracteristicaValor;
import com.totvs.sl.wms.estoque.caracteristicavalor.exception.WMSCaracteristicaValorFaixaInicialMaiorQueFinalException;
import com.totvs.sl.wms.estoque.caracteristicavalor.exception.WMSCaracteristicaValorFaixaNumeroConstraintException;
import com.totvs.sl.wms.estoque.caracteristicavalor.validator.ValidCaracteristicaValorInicialFinal;

import lombok.AccessLevel;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Getter
@EqualsAndHashCode
@NoArgsConstructor(access = AccessLevel.PRIVATE)
@ValidCaracteristicaValorInicialFinal(message = "{CaracteristicaValorFaixaNumero.valorInicialOuValorFinal.NotNull}")
public class CaracteristicaValorFaixaNumero implements CaracteristicaValorFaixa<BigDecimal> {

	@NotNull(message = "{CaracteristicaValorFaixaNumero.caracteristicaConfiguracaoId.NotNull}")
	private CaracteristicaConfiguracaoId caracteristicaConfiguracaoId;

	@Digits(fraction = 4, integer = 11, message = "{CaracteristicaValorFaixaNumero.valorInicial.Digits}")
	private BigDecimal valorInicial;

	@Digits(fraction = 4, integer = 11, message = "{CaracteristicaValorFaixaNumero.valorFinal.Digits}")
	private BigDecimal valorFinal;

	@Builder
	private CaracteristicaValorFaixaNumero(CaracteristicaConfiguracaoId caracteristicaConfiguracaoId,
										   BigDecimal valorInicial,
										   BigDecimal valorFinal) {

		this.caracteristicaConfiguracaoId = caracteristicaConfiguracaoId;
		this.valorInicial = valorInicial;
		this.valorFinal = valorFinal;

		validateIntegrity(this).ifPresent(violations -> {
			throw new WMSCaracteristicaValorFaixaNumeroConstraintException(violations);
		});

		validarValorInicialMaiorQueValorFinal();
	}

	private void validarValorInicialMaiorQueValorFinal() {

		if (this.valorInicial == null || this.valorFinal == null)
			return;

		if (this.valorInicial.compareTo(this.valorFinal) > 0)
			throw new WMSCaracteristicaValorFaixaInicialMaiorQueFinalException();
	}

	@Override
	public FormatoCaracteristicaValor getFormato() {
		return FormatoCaracteristicaValor.NUMERO;
	}

	@Override
	public int compareTo(CaracteristicaValorFaixa<BigDecimal> caracteristica) {
		return caracteristica instanceof CaracteristicaValorFaixaNumero caracteristicaValorFaixaNumero
				? Comparator.comparing(CaracteristicaValorFaixaNumero::getCaracteristicaConfiguracaoId)
							.thenComparing(CaracteristicaValorFaixaNumero::getValorInicial,
										   Comparator.nullsFirst(BigDecimal::compareTo))
							.thenComparing(CaracteristicaValorFaixaNumero::getValorFinal,
										   Comparator.nullsFirst(BigDecimal::compareTo))
							.compare(this, caracteristicaValorFaixaNumero)
				: this.getCaracteristicaConfiguracaoId().compareTo(caracteristica.getCaracteristicaConfiguracaoId());
	}
}
