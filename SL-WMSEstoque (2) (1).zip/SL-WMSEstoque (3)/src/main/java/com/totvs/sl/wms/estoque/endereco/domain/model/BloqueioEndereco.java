package com.totvs.sl.wms.estoque.endereco.domain.model;

import static com.totvs.tjf.autoconfigure.ValidationUtils.validateIntegrity;

import javax.validation.constraints.NotNull;

import com.totvs.sl.wms.estoque.endereco.exception.WMSBloqueioEnderecoConstraintException;
import com.totvs.sl.wms.estoque.origem.domain.model.Origem;

import lombok.AccessLevel;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor(access = AccessLevel.PRIVATE, force = true)
public final class BloqueioEndereco {

	@NotNull(message = "{BloqueioEndereco.origem.NotNull}")
	private final Origem origem;

	private final TipoBloqueioEndereco tipo;

	@NotNull(message = "{BloqueioEndereco.chaveAcesso.NotNull}")
	private final String chaveAcesso;

	private BloqueioEndereco(Origem origem, TipoBloqueioEndereco tipo, String chaveAcesso) {

		this.origem = origem;
		this.tipo = tipo;
		this.chaveAcesso = chaveAcesso;

		validateIntegrity(this).ifPresent(violations -> {
			throw new WMSBloqueioEnderecoConstraintException(violations);
		});
	}

	public static BloqueioEndereco novoBloqueioEntradaEstoque(Origem origem, String chaveAcesso) {
		return new BloqueioEndereco(origem, TipoBloqueioEndereco.ENTRADA, chaveAcesso);
	}

	public static BloqueioEndereco novoBloqueioSaidaEstoque(Origem origem, String chaveAcesso) {
		return new BloqueioEndereco(origem, TipoBloqueioEndereco.SAIDA, chaveAcesso);
	}

	public static BloqueioEndereco novoBloqueioEntradaSaidaEstoque(Origem origem, String chaveAcesso) {
		return new BloqueioEndereco(origem, TipoBloqueioEndereco.ENTRADA_SAIDA, chaveAcesso);
	}
}
