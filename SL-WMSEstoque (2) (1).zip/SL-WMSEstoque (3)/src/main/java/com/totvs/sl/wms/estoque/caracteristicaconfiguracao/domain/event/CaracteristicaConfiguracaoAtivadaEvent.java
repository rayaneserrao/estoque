package com.totvs.sl.wms.estoque.caracteristicaconfiguracao.domain.event;

import com.totvs.sl.wms.estoque.caracteristicaconfiguracao.domain.model.CaracteristicaConfiguracao;
import com.totvs.sl.wms.estoque.caracteristicaconfiguracao.domain.model.CaracteristicaConfiguracaoId;
import com.totvs.sl.wms.estoque.util.amqp.SubjectConfiguracao;
import com.totvs.sl.wms.estoque.util.amqp.SubjectDomainEvent;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data(staticConstructor = "of")
@EqualsAndHashCode(callSuper = false)
public final class CaracteristicaConfiguracaoAtivadaEvent extends SubjectDomainEvent implements SubjectConfiguracao {

	private final CaracteristicaConfiguracaoId id;

	public static CaracteristicaConfiguracaoAtivadaEvent from(CaracteristicaConfiguracao caracteristicaConfiguracao) {
		return CaracteristicaConfiguracaoAtivadaEvent.of(caracteristicaConfiguracao.getId());
	}
}
