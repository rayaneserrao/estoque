package com.totvs.sl.wms.estoque.categoriaproduto.exception;

import com.totvs.tjf.api.context.stereotype.ApiErrorParameter;
import com.totvs.tjf.api.context.stereotype.error.ApiBadRequest;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
@ApiBadRequest
public class WMSDescricaoCategoriaJaExistenteException extends RuntimeException {
	
	private static final long serialVersionUID = 3477642877372076964L;
	
	@ApiErrorParameter
	private final String descricao;

}