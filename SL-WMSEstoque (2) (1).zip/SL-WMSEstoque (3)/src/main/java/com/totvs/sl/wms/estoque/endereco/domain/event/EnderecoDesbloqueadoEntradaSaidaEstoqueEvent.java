package com.totvs.sl.wms.estoque.endereco.domain.event;

import com.totvs.sl.wms.estoque.endereco.domain.model.Endereco;
import com.totvs.sl.wms.estoque.endereco.domain.model.EnderecoId;
import com.totvs.sl.wms.estoque.endereco.domain.model.TipoBloqueioEndereco;
import com.totvs.sl.wms.estoque.util.amqp.SubjectDomainEvent;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.ToString;

@Getter
@ToString
@AllArgsConstructor(access = AccessLevel.PRIVATE)
public final class EnderecoDesbloqueadoEntradaSaidaEstoqueEvent extends SubjectDomainEvent
		implements SubjectBloqueioEndereco {

	private final EnderecoId id;
	private final TipoBloqueioEndereco tipoDesbloqueioEfetuado;
	private final TipoBloqueioEndereco tipoBloqueioAtual;
	private final int estoquesDesbloqueados;

	public static EnderecoDesbloqueadoEntradaSaidaEstoqueEvent from(Endereco endereco, int estoquesDesbloqueados) {

		return new EnderecoDesbloqueadoEntradaSaidaEstoqueEvent(endereco.getId(),
																TipoBloqueioEndereco.ENTRADA_SAIDA,
																null,
																estoquesDesbloqueados);
	}
}
