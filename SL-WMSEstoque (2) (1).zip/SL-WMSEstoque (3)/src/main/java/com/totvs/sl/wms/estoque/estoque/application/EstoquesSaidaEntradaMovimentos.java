package com.totvs.sl.wms.estoque.estoque.application;

import java.util.List;

import com.totvs.sl.wms.estoque.estoque.domain.model.Estoque;
import com.totvs.sl.wms.estoque.movimentoestoque.domain.model.MovimentoEstoque;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor(staticName = "of")
public final class EstoquesSaidaEntradaMovimentos {

	private EstoqueSaidaEntrada estoques;
	private MovimentoEstoque movimentoSaida;
	private MovimentoEstoque movimentoEntrada;

	public void removerEstoqueComSaldoDesatualizado(List<Estoque> estoquesEntrada) {
		estoquesEntrada.removeIf(estoqueEntradaDesatualizada -> estoqueEntradaDesatualizada.getId()
																						   .toString()
																						   .equals(this.getEstoques()
																									   .getEstoqueEntrada()
																									   .getId()
																									   .toString()));
	}
}
