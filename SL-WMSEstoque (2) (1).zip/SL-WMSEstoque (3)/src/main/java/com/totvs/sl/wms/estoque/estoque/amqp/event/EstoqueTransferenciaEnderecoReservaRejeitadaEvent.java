package com.totvs.sl.wms.estoque.estoque.amqp.event;

import com.totvs.sl.wms.estoque.estoque.domain.event.SubjectMovimentacaoEstoque;
import com.totvs.sl.wms.estoque.reservadefinitivaestoque.domain.model.ReservaDefinitivaEstoqueId;
import com.totvs.sl.wms.estoque.util.amqp.RejectedEvent;

import com.totvs.tjf.api.context.response.ApiErrorResponse;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data(staticConstructor = "of")
@EqualsAndHashCode(callSuper = false)
public final class EstoqueTransferenciaEnderecoReservaRejeitadaEvent extends RejectedEvent
		implements SubjectMovimentacaoEstoque {

	private final ReservaDefinitivaEstoqueId reservaDefinitivaEstoqueId;
	private final ApiErrorResponse inconsistencia;
}
