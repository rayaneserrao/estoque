package com.totvs.sl.wms.estoque.estoque.domain.model;

import static com.totvs.sl.wms.estoque.util.Constants.QUANTIDADE_MAXIMA_DECIMAIS;
import static com.totvs.sl.wms.estoque.util.Constants.QUANTIDADE_MAXIMA_INTEIROS;
import static com.totvs.tjf.autoconfigure.ValidationUtils.validateIntegrity;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.TreeSet;
import java.util.stream.Collectors;

import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.Digits;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.springframework.util.CollectionUtils;

import com.totvs.sl.wms.estoque.atributoestoquevalor.domain.model.AtributoEstoqueValor;
import com.totvs.sl.wms.estoque.atributoestoquevalor.validator.UniqueListAtributoEstoqueValor;
import com.totvs.sl.wms.estoque.estoque.exception.WMSEstoqueAtributoConstraintException;
import com.totvs.sl.wms.estoque.estoque.exception.WMSEstoqueAtributoControleQuantidadeSerialQuantidadeDivergenteException;
import com.totvs.sl.wms.estoque.estoque.exception.WMSEstoqueAtributoQuantidadeSubtrairDeveSerMenorQueAtualException;
import com.totvs.sl.wms.estoque.estoque.exception.WMSEstoqueAtributoValorSomarNaoEncontradoException;
import com.totvs.sl.wms.estoque.estoque.exception.WMSEstoqueAtributoValorSubtrairNaoEncontradoException;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Getter
@NoArgsConstructor(access = AccessLevel.PRIVATE)
public final class EstoqueAtributoSaldo implements Comparable<EstoqueAtributoSaldo> {

	private EstoqueAtributoSaldoId id;

	@UniqueListAtributoEstoqueValor(message = "{EstoqueAtributoSaldo.atributos.UniqueListAtributoEstoqueValor}")
	@Size(min = 1, message = "{EstoqueAtributoSaldo.atributos.Size}")
	private List<AtributoEstoqueValor<?>> atributos = new ArrayList<>();

	@NotNull(message = "{EstoqueAtributoSaldo.saldo.NotNull}")
	@DecimalMin(value = "0.0000", message = "{EstoqueAtributoSaldo.saldo.DecimalMin}")
	@Digits(fraction = QUANTIDADE_MAXIMA_DECIMAIS, integer = QUANTIDADE_MAXIMA_INTEIROS, message = "{EstoqueAtributoSaldo.saldo.Digits}")
	private BigDecimal saldo;

	private EstoqueAtributoSaldo(EstoqueAtributoSaldoId id, List<AtributoEstoqueValor<?>> atributos, BigDecimal saldo) {

		this.id = id;
		this.saldo = saldo;

		if (!CollectionUtils.isEmpty(atributos))
			this.atributos.addAll(atributos);

		validateIntegrity(this).ifPresent(violations -> {
			throw new WMSEstoqueAtributoConstraintException(violations);
		});

		this.validarAtributosSeriais(this.atributos, this.saldo);

	}

	public static EstoqueAtributoSaldo of(List<AtributoEstoqueValor<?>> atributos, BigDecimal saldo) {
		return new EstoqueAtributoSaldo(EstoqueAtributoSaldoId.generate(), atributos, saldo);
	}

	public EstoqueAtributoSaldo somandoQuantidade(List<AtributoEstoqueValor<?>> atributosSomar, BigDecimal quantidade) {

		List<AtributoEstoqueValor<?>> atributosAtualizada = new ArrayList<>();

		if (!CollectionUtils.isEmpty(atributosSomar))

			this.atributos.forEach(atributo -> {

				var atributoSomar = atributosSomar.stream()
												  .filter(valor -> valor.getId().equals(atributo.getId()))
												  .findAny()
												  .orElseThrow(WMSEstoqueAtributoValorSomarNaoEncontradoException::new);

				atributoSomar.getValores().forEach(valor -> {
					if (!atributo.getValores().contains(valor))
						atributo.adicionarValorSerial(valor);
				});

				atributosAtualizada.add(atributo);

			});

		return EstoqueAtributoSaldo.of(atributosAtualizada, this.saldo.add(quantidade));
	}

	public EstoqueAtributoSaldo dividindoQuantidade(BigDecimal quantidade) {

		if (quantidade.compareTo(this.saldo) >= 0)
			throw new WMSEstoqueAtributoQuantidadeSubtrairDeveSerMenorQueAtualException(this.saldo, quantidade);

		List<AtributoEstoqueValor<?>> atributosRetorno = this.atributos.stream().map(atr -> {
			var valores = !atr.getControleQuantidade().isSerial() ? atr.getValores()
					: new TreeSet<>(atr.getValores().stream().toList().subList(0, quantidade.intValue()));

			return atr.getFormato().getInstance(atr.getId(), valores, atr.getControleQuantidade());

		}).collect(Collectors.toCollection(ArrayList::new));
		return EstoqueAtributoSaldo.of(atributosRetorno, quantidade);
	}

	public EstoqueAtributoSaldo subtraindoQuantidade(List<AtributoEstoqueValor<?>> atributosSubtrair,
													 BigDecimal quantidade) {

		if (quantidade.compareTo(this.saldo) >= 0)
			throw new WMSEstoqueAtributoQuantidadeSubtrairDeveSerMenorQueAtualException(this.saldo, quantidade);

		List<AtributoEstoqueValor<?>> atributosAtualizada = new ArrayList<>();

		this.atributos.forEach(atributo -> {

			var atributoSubtrair = atributosSubtrair.stream()
													.filter(valor -> valor.getId().equals(atributo.getId()))
													.findAny()
													.orElseThrow(WMSEstoqueAtributoValorSubtrairNaoEncontradoException::new);

			atributoSubtrair.getValores().forEach(valor -> {
				if (atributo.getControleQuantidade().isSerial() && atributo.getValores().contains(valor))
					atributo.removerValorSerial(valor);
			});

			atributosAtualizada.add(atributo);

		});

		return EstoqueAtributoSaldo.of(atributosAtualizada, this.saldo.subtract(quantidade));
	}

	private void validarAtributosSeriais(List<AtributoEstoqueValor<?>> atributos, BigDecimal quantidade) {

		if (Objects.nonNull(atributos))
			atributos.stream().filter(atributo -> atributo.getControleQuantidade().isSerial()).forEach(atributo -> {
				var seriais = BigDecimal.valueOf(atributo.getValores().size());
				if (seriais.compareTo(quantidade) != 0)
					throw new WMSEstoqueAtributoControleQuantidadeSerialQuantidadeDivergenteException(quantidade,
																									  seriais);
			});
	}

	@Override
	public int hashCode() {
		return this.toString().hashCode();
	}

	@Override
	public boolean equals(Object obj) {

		// Um EstoqueAtributo é considerado igual a outro quando possuem os mesmos
		// AtributoEstoqueValor do tipo VARIAVEL (os que são SERIAL não são considerados
		// na comparação).

		if (this == obj)
			return true;

		if (obj == null)
			return false;

		if (this.getClass() != obj.getClass())
			return false;

		var other = (EstoqueAtributoSaldo) obj;

		var atributosVariaveis = this.getAtributos()
									 .stream()
									 .filter(thisValue -> thisValue.getControleQuantidade().isVariavel())
									 .collect(Collectors.toCollection(TreeSet::new));

		var atributosVariaveisOther = other.getAtributos()
										   .stream()
										   .filter(thisValue -> thisValue.getControleQuantidade().isVariavel())
										   .collect(Collectors.toCollection(TreeSet::new));

		return Objects.equals(atributosVariaveis, atributosVariaveisOther);
	}

	@Override
	public String toString() {

		var sb = new StringBuilder();

		sb.append(this.id);
		sb.append("\r\n");

		this.atributos.stream().forEach(atributo -> {
			sb.append(atributo.withValoresToString());
			sb.append("\r\n");
		});

		return sb.toString();
	}

	@Override
	public int compareTo(EstoqueAtributoSaldo estoqueAtributo) {
		return this.equals(estoqueAtributo) ? 0 : -1;
	}
}
