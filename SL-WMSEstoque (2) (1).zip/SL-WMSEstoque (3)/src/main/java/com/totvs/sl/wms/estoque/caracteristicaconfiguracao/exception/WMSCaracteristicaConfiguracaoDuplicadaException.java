package com.totvs.sl.wms.estoque.caracteristicaconfiguracao.exception;

import com.totvs.tjf.api.context.stereotype.ApiErrorParameter;
import com.totvs.tjf.api.context.stereotype.error.ApiBadRequest;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
@ApiBadRequest("WMSCaracteristicaConfiguracaoDuplicadaException")
public class WMSCaracteristicaConfiguracaoDuplicadaException extends RuntimeException {

	private static final long serialVersionUID = 1246852890084431530L;
	
	@ApiErrorParameter
	private final String descricao;
}
