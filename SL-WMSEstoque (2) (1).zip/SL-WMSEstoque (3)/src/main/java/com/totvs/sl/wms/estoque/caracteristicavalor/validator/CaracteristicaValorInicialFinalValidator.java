package com.totvs.sl.wms.estoque.caracteristicavalor.validator;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import com.totvs.sl.wms.estoque.caracteristicavalor.domain.model.CaracteristicaValorFaixa;

public class CaracteristicaValorInicialFinalValidator
		implements ConstraintValidator<ValidCaracteristicaValorInicialFinal, CaracteristicaValorFaixa<?>> {

	@Override
	public boolean isValid(CaracteristicaValorFaixa<?> object, ConstraintValidatorContext context) {
		return object.getValorInicial() != null || object.getValorFinal() != null;
	}
}