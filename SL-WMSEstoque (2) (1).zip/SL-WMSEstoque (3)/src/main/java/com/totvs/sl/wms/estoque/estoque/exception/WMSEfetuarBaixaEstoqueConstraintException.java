package com.totvs.sl.wms.estoque.estoque.exception;

import java.util.Set;

import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;

import com.totvs.tjf.api.context.stereotype.error.ApiBadRequest;

@ApiBadRequest
public class WMSEfetuarBaixaEstoqueConstraintException extends ConstraintViolationException {

	private static final long serialVersionUID = -2914978375795463184L;

	public WMSEfetuarBaixaEstoqueConstraintException(Set<? extends ConstraintViolation<?>> constraintViolations) {
		super(constraintViolations);
	}

}
