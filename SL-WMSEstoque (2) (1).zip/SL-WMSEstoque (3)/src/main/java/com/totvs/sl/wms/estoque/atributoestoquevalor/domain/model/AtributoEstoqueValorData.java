package com.totvs.sl.wms.estoque.atributoestoquevalor.domain.model;

import static com.totvs.tjf.autoconfigure.ValidationUtils.validateIntegrity;

import java.time.LocalDate;
import java.util.Comparator;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.TreeSet;

import javax.validation.constraints.NotNull;

import com.totvs.sl.wms.estoque.atributoestoque.domain.model.AtributoEstoqueId;
import com.totvs.sl.wms.estoque.atributoestoque.domain.model.ControleQuantidadeAtributoEstoqueValor;
import com.totvs.sl.wms.estoque.atributoestoque.domain.model.FormatoAtributoEstoqueValor;
import com.totvs.sl.wms.estoque.atributoestoquevalor.exception.WMSAtributoEstoqueValorDataConstraintException;
import com.totvs.sl.wms.estoque.atributoestoquevalor.exception.WMSAtributoEstoqueValorDataDeveTerControleQuantidadeVariavelException;
import com.totvs.sl.wms.estoque.util.ConversionUtils;

import lombok.AccessLevel;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Getter
@ToString
@EqualsAndHashCode
@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class AtributoEstoqueValorData implements AtributoEstoqueValor<LocalDate> {

	@NotNull(message = "{AtributoEstoqueValorData.id.NotNull}")
	private AtributoEstoqueId id;

	@NotNull(message = "{AtributoEstoqueValorData.valor.NotNull}")
	private TreeSet<LocalDate> valores;

	@NotNull(message = "{AtributoEstoqueValorData.controleQuantidade.NotNull}")
	private ControleQuantidadeAtributoEstoqueValor controleQuantidade;

	@Builder
	private AtributoEstoqueValorData(AtributoEstoqueId id,
									 LocalDate valor,
									 ControleQuantidadeAtributoEstoqueValor controleQuantidade) {

		this.id = id;
		this.controleQuantidade = controleQuantidade;

		if (Objects.nonNull(valor))
			this.valores = new TreeSet<>(List.of(valor));

		validateIntegrity(this).ifPresent(violations -> {
			throw new WMSAtributoEstoqueValorDataConstraintException(violations);
		});

		if (!controleQuantidade.equals(ControleQuantidadeAtributoEstoqueValor.VARIAVEL))
			throw new WMSAtributoEstoqueValorDataDeveTerControleQuantidadeVariavelException();

	}

	@Override
	public FormatoAtributoEstoqueValor getFormato() {
		return FormatoAtributoEstoqueValor.DATA;
	}

	@Override
	public void atualizarValorVariavel(Object valor) {
		this.valores = new TreeSet<>(Set.of(ConversionUtils.toLocalDate(valor)));
	}

	@Override
	public int compareTo(AtributoEstoqueValor<LocalDate> atributo) {

		if (atributo instanceof AtributoEstoqueValorData atributoData) {
			return Comparator.comparing(AtributoEstoqueValorData::getId)
							 .thenComparing(AtributoEstoqueValorData::getValores,
											(a, b) -> a.first().compareTo(b.first()))
							 .compare(this, atributoData);
		} else {
			return this.id.compareTo(atributo.getId());
		}
	}
}
