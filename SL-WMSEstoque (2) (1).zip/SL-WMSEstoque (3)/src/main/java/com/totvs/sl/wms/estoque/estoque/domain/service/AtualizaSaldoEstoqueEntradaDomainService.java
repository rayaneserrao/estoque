package com.totvs.sl.wms.estoque.estoque.domain.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.totvs.sl.wms.estoque.caracteristicavalor.domain.model.CaracteristicaValor;
import com.totvs.sl.wms.estoque.estoque.domain.model.Estoque;
import com.totvs.sl.wms.estoque.estoque.domain.model.EstoqueDomainRepository;
import com.totvs.sl.wms.estoque.estoque.exception.WMSExisteEstoqueComMesmoHashException;

import lombok.AllArgsConstructor;

@Service
@AllArgsConstructor
public class AtualizaSaldoEstoqueEntradaDomainService {

	private static final String ESTOQUE_HASH_IDX = "estoque_hash_idx";

	private final EstoqueDomainRepository estoqueRepository;

	public void atualizar(Estoque estoque) {
		if (estoqueRepository.exists(estoque.getId())) {
			estoqueRepository.update(estoque);
		} else {
			this.inserirEstoque(estoque);
		}
	}

	private void inserirEstoque(Estoque estoque) {
		try {
			estoqueRepository.insert(estoque);
		} catch (Exception excecao) {
			var cause = excecao.getCause();
			if (cause != null && cause.getMessage().contains(ESTOQUE_HASH_IDX)) {
				throw new WMSExisteEstoqueComMesmoHashException(estoque.getUnidadeId().toString(),
																estoque.getProdutoId().toString(),
																estoque.getSkuId().toString(),
																estoque.getUnitizadorId() == null ? ""
																		: estoque.getUnitizadorId().toString(),
																estoque.getTipoEstoqueId().toString(),
																estoque.getEnderecoId().toString(),
																estoque.getSituacoes().iterator().next().toString(),
																estoque.getAvariado().toString(),
																montarDescricaoComIdCaracteristicas(estoque.getCaracteristicas()));
			}
			throw excecao;
		}

	}

	private String montarDescricaoComIdCaracteristicas(List<CaracteristicaValor<?>> valores) {
		if (!CollectionUtils.isEmpty(valores)) {
			return valores.stream()
						  .map(c -> c.getCaracteristicaConfiguracaoId().toString())
						  .collect(Collectors.joining(","));
		}
		return "";
	}
}
