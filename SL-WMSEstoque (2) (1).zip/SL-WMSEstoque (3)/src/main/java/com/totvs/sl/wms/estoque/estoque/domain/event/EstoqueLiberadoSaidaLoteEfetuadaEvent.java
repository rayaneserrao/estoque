package com.totvs.sl.wms.estoque.estoque.domain.event;

import java.math.BigDecimal;
import java.util.List;
import java.util.stream.Collectors;

import com.totvs.sl.wms.estoque.estoque.application.EstoqueEfetuarSaidaApplicationService.EstoquesSaidaMovimentoLista;
import com.totvs.sl.wms.estoque.estoque.domain.model.EstoqueId;
import com.totvs.sl.wms.estoque.unidade.domain.model.UnidadeId;
import com.totvs.sl.wms.estoque.util.amqp.SubjectDomainEvent;

import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data(staticConstructor = "of")
@EqualsAndHashCode(callSuper = false)
public final class EstoqueLiberadoSaidaLoteEfetuadaEvent extends SubjectDomainEvent
		implements SubjectEntradaEstoqueLoteEvent {

	private final UnidadeId unidadeId;
	private final OrigemSaidaLote origem;
	private final List<EstoqueSaida> estoques;

	@Data(staticConstructor = "of")
	public static final class OrigemSaidaLote {
		private final String origem;
		private final String origemId;
	}

	@Data
	@Builder
	public static final class EstoqueSaida {
		private final EstoqueId id;
		private final BigDecimal saldo;
		private final BigDecimal saldoReservado;
		private final BigDecimal saldoDisponivel;
		private final BigDecimal quantidadeBloqueadaMovimentacaoNaoReservada;
		private final BigDecimal quantidadeBloqueadaMovimentacaoReservada;
		private final BigDecimal quantidadeBloqueadaMovimentacaoTotal;
		private final List<EstoqueAtributoSaldoEvent> atributosSaldo;
	}

	public static EstoqueLiberadoSaidaLoteEfetuadaEvent from(EstoquesSaidaMovimentoLista listaEstoqueMovimento) {

		var estoquesSaida = listaEstoqueMovimento.getEstoquesSaida()
												 .stream()
												 .map(estoqueSaida -> EstoqueSaida.builder()
																				  .id(estoqueSaida.getEstoqueId())
																				  .saldo(estoqueSaida.getSaldo())
																				  .saldoReservado(estoqueSaida.getSaldoReservado())
																				  .saldoDisponivel(estoqueSaida.getSaldoDisponivel())
																				  .quantidadeBloqueadaMovimentacaoNaoReservada(estoqueSaida.getQuantidadeBloqueadaMovimentacaoNaoReservada())
																				  .quantidadeBloqueadaMovimentacaoReservada(estoqueSaida.getQuantidadeBloqueadaMovimentacaoReservada())
																				  .quantidadeBloqueadaMovimentacaoTotal(estoqueSaida.getQuantidadeBloqueadaMovimentacaoTotal())
																				  .atributosSaldo(EstoqueAtributoSaldoEvent.from(estoqueSaida.getAtributosSaldo()))
																				  .build())
												 .collect(Collectors.toList());

		return EstoqueLiberadoSaidaLoteEfetuadaEvent.of(listaEstoqueMovimento.getEstoquesSaida().get(0).getUnidadeId(),
														OrigemSaidaLote.of(listaEstoqueMovimento.getMovimentosSaida()
																								.get(0)
																								.getOrigem()
																								.getOrigem(),
																		   listaEstoqueMovimento.getMovimentosSaida()
																								.get(0)
																								.getOrigem()
																								.getId()
																								.toString()),
														estoquesSaida);

	}
}
