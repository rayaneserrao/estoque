package com.totvs.sl.wms.estoque.atributoestoque.exception;

import com.totvs.tjf.api.context.stereotype.ApiErrorParameter;
import com.totvs.tjf.api.context.stereotype.error.ApiBadRequest;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
@ApiBadRequest
public class WMSAtributoEstoqueDuplicadoException extends RuntimeException {

	private static final long serialVersionUID = 8986294024800996922L;

	@ApiErrorParameter
	private final String descricao;
}
