package com.totvs.sl.wms.estoque.estoque.amqp;

import java.util.ArrayList;

import org.springframework.cloud.stream.annotation.EnableBinding;
import org.springframework.cloud.stream.annotation.StreamListener;

import com.totvs.sl.wms.estoque.config.amqp.WMSChannel;
import com.totvs.sl.wms.estoque.config.amqp.WMSPublisher;
import com.totvs.sl.wms.estoque.estoque.amqp.cmd.AdicionarAtributoEstoqueSaldoCmd;
import com.totvs.sl.wms.estoque.estoque.amqp.cmd.AdicionarCaracteristicaConfiguracaoEstoqueCmd;
import com.totvs.sl.wms.estoque.estoque.amqp.cmd.RemoverAtributoEstoqueSaldoCmd;
import com.totvs.sl.wms.estoque.estoque.amqp.cmd.RemoverCaracteristicaConfiguracaoEstoqueCmd;
import com.totvs.sl.wms.estoque.estoque.amqp.event.EstoqueAtributoNaoAdicionadoEvent;
import com.totvs.sl.wms.estoque.estoque.amqp.event.EstoqueAtributoNaoRemovidoEvent;
import com.totvs.sl.wms.estoque.estoque.amqp.event.EstoqueCaracteristicaConfiguracaoNaoAdicionadaEvent;
import com.totvs.sl.wms.estoque.estoque.amqp.event.EstoqueCaracteristicaConfiguracaoNaoRemovidaEvent;
import com.totvs.sl.wms.estoque.estoque.application.EstoqueAdicionarRemoverAtributoApplicationService;
import com.totvs.sl.wms.estoque.estoque.application.EstoqueAdicionarRemoverCaracteristicaApplicationService;
import com.totvs.sl.wms.estoque.estoque.application.command.AdicionarAtributoEstoqueCommand;
import com.totvs.sl.wms.estoque.estoque.application.command.AdicionarCaracteristicaEstoqueCommand;
import com.totvs.sl.wms.estoque.estoque.application.command.RemoverAtributoEstoqueCommand;
import com.totvs.sl.wms.estoque.estoque.application.command.RemoverCaracteristicaEstoqueCommand;
import com.totvs.sl.wms.estoque.estoque.exception.WMSAdicionarCaracteristicaConfiguracaoEstoqueConstraintException;
import com.totvs.sl.wms.estoque.estoque.exception.WMSEstoqueAtributoConstraintException;
import com.totvs.sl.wms.estoque.estoque.exception.WMSExisteEstoqueComMesmoHashException;
import com.totvs.sl.wms.estoque.estoque.exception.WMSRemoverCaracteristicaConfiguracaoEstoqueConstraintException;
import com.totvs.sl.wms.estoque.util.amqp.AMQPUtil;
import com.totvs.tjf.api.response.error.converter.ErrorExceptionConverter;
import com.totvs.tjf.core.i18n.I18nService;
import com.totvs.tjf.core.validation.ValidatorService;
import com.totvs.tjf.messaging.context.TOTVSMessage;

import lombok.AllArgsConstructor;

@AllArgsConstructor
@EnableBinding(WMSChannel.WMSEstoqueConfiguracaoCommandsInput.class)
public class EstoqueConfiguracaoCommandsSubscriber {

	private EstoqueAdicionarRemoverCaracteristicaApplicationService service;
	private EstoqueAdicionarRemoverAtributoApplicationService atributoService;
	private ValidatorService validator;
	private WMSPublisher wmsPublisher;
	private I18nService i18nService;

	@StreamListener(target = WMSChannel.WMS_ESTOQUE_CONFIGURACAO_COMMANDS_IN, condition = AdicionarCaracteristicaConfiguracaoEstoqueCmd.CONDITIONAL_EXPRESSION)
	public void adicionarCaracteristicaEstoque(final TOTVSMessage<AdicionarCaracteristicaConfiguracaoEstoqueCmd> message) {

		AMQPUtil.gerarLog(this.getClass(),
						  message,
						  AdicionarCaracteristicaConfiguracaoEstoqueCmd.CONDITIONAL_EXPRESSION);

		var cmd = message.getContent();

		validator.validate(cmd).ifPresent(violations -> {
			throw new WMSAdicionarCaracteristicaConfiguracaoEstoqueConstraintException(violations);
		});

		var command = AdicionarCaracteristicaEstoqueCommand.of(cmd.getProdutoId(),
															   cmd.getCaracteristicaConfiguracaoId(),
															   cmd.getValorPadrao());

		try {
			service.handle(command);
		} catch (WMSExisteEstoqueComMesmoHashException excecao) {
			throw excecao;
		} catch (RuntimeException excecao) {
			rejeitarAdicionarCaracteristicaEstoqueCmd(cmd, excecao);
		}
	}

	private void rejeitarAdicionarCaracteristicaEstoqueCmd(AdicionarCaracteristicaConfiguracaoEstoqueCmd cmd,
														   RuntimeException excecao) {

		var inconsistencias = new ArrayList<EstoqueCaracteristicaConfiguracaoNaoAdicionadaEvent.Inconsistencia>();

		var id = excecao.getClass().getSimpleName();
		var mensagem = "";
		var detalhe = "";

		if (!id.startsWith("WMS"))
			throw excecao;

		var erroConverter = new ErrorExceptionConverter(i18nService);
		var erro = erroConverter.convert(excecao).getError();

		mensagem = erro.getMessage();
		detalhe = erro.getDetailedMessage();
		inconsistencias.add(EstoqueCaracteristicaConfiguracaoNaoAdicionadaEvent.Inconsistencia.of(id,
																								  mensagem,
																								  detalhe));

		var eventoRejeicao = EstoqueCaracteristicaConfiguracaoNaoAdicionadaEvent.of(cmd.getProdutoId(),
																					cmd.getCaracteristicaConfiguracaoId(),
																					inconsistencias);
		wmsPublisher.dispatch(eventoRejeicao);
	}

	@StreamListener(target = WMSChannel.WMS_ESTOQUE_CONFIGURACAO_COMMANDS_IN, condition = RemoverCaracteristicaConfiguracaoEstoqueCmd.CONDITIONAL_EXPRESSION)
	public void removerCaracteristicaEstoque(final TOTVSMessage<RemoverCaracteristicaConfiguracaoEstoqueCmd> message) {

		AMQPUtil.gerarLog(this.getClass(), message, RemoverCaracteristicaConfiguracaoEstoqueCmd.CONDITIONAL_EXPRESSION);

		var cmd = message.getContent();

		validator.validate(cmd).ifPresent(violations -> {
			throw new WMSRemoverCaracteristicaConfiguracaoEstoqueConstraintException(violations);
		});

		var command = RemoverCaracteristicaEstoqueCommand.of(cmd.getProdutoId(), cmd.getCaracteristicaConfiguracaoId());

		try {
			service.handle(command);
		} catch (WMSExisteEstoqueComMesmoHashException excecao) {
			throw excecao;
		} catch (RuntimeException excecao) {
			rejeitarRemoverCaracteristicaEstoqueCmd(cmd, excecao);
		}
	}

	private void rejeitarRemoverCaracteristicaEstoqueCmd(RemoverCaracteristicaConfiguracaoEstoqueCmd cmd,
														 RuntimeException excecao) {

		var inconsistencias = new ArrayList<EstoqueCaracteristicaConfiguracaoNaoRemovidaEvent.Inconsistencia>();

		var id = excecao.getClass().getSimpleName();
		var mensagem = "";
		var detalhe = "";

		if (!id.startsWith("WMS"))
			throw excecao;

		var erroConverter = new ErrorExceptionConverter(i18nService);
		var erro = erroConverter.convert(excecao).getError();

		mensagem = erro.getMessage();
		detalhe = erro.getDetailedMessage();
		inconsistencias.add(EstoqueCaracteristicaConfiguracaoNaoRemovidaEvent.Inconsistencia.of(id, mensagem, detalhe));

		var eventoRejeicao = EstoqueCaracteristicaConfiguracaoNaoRemovidaEvent.of(cmd.getProdutoId(),
																				  cmd.getCaracteristicaConfiguracaoId(),
																				  inconsistencias);
		wmsPublisher.dispatch(eventoRejeicao);
	}

	@StreamListener(target = WMSChannel.WMS_ESTOQUE_CONFIGURACAO_COMMANDS_IN, condition = AdicionarAtributoEstoqueSaldoCmd.CONDITIONAL_EXPRESSION)
	public void adicionarAtributoEstoque(final TOTVSMessage<AdicionarAtributoEstoqueSaldoCmd> message) {
		AMQPUtil.gerarLog(this.getClass(), message, AdicionarAtributoEstoqueSaldoCmd.CONDITIONAL_EXPRESSION);

		var cmd = message.getContent();

		validator.validate(cmd).ifPresent(violations -> {
			throw new WMSEstoqueAtributoConstraintException(violations);
		});

		var command = AdicionarAtributoEstoqueCommand.of(cmd.getAtributoEstoqueId(),
														 cmd.getProdutoId(),
														 cmd.getValorPadrao());

		try {
			atributoService.handle(command);
		} catch (RuntimeException excecao) {
			rejeitarAdicionarAtributoEstoqueCmd(cmd, excecao);
		}
	}

	private void rejeitarAdicionarAtributoEstoqueCmd(AdicionarAtributoEstoqueSaldoCmd cmd, RuntimeException excecao) {

		var id = excecao.getClass().getSimpleName();
		var mensagem = "";
		var detalhe = "";

		if (!id.startsWith("WMS"))
			throw excecao;

		var erroConverter = new ErrorExceptionConverter(i18nService);
		var erro = erroConverter.convert(excecao).getError();

		mensagem = erro.getMessage();
		detalhe = erro.getDetailedMessage();

		var eventoRejeicao = EstoqueAtributoNaoAdicionadoEvent.of(cmd.getAtributoEstoqueId(),
																  cmd.getProdutoId(),
																  EstoqueAtributoNaoAdicionadoEvent.Inconsistencia.of(id,
																													  mensagem,
																													  detalhe));
		wmsPublisher.dispatch(eventoRejeicao);
	}

	@StreamListener(target = WMSChannel.WMS_ESTOQUE_CONFIGURACAO_COMMANDS_IN, condition = RemoverAtributoEstoqueSaldoCmd.CONDITIONAL_EXPRESSION)
	public void removerAtributoEstoque(final TOTVSMessage<RemoverAtributoEstoqueSaldoCmd> message) {
		AMQPUtil.gerarLog(this.getClass(), message, RemoverAtributoEstoqueSaldoCmd.CONDITIONAL_EXPRESSION);

		var cmd = message.getContent();

		validator.validate(cmd).ifPresent(violations -> {
			throw new WMSEstoqueAtributoConstraintException(violations);
		});

		var command = RemoverAtributoEstoqueCommand.of(cmd.getAtributoEstoqueId(), cmd.getProdutoId());

		try {
			atributoService.handle(command);
		} catch (RuntimeException excecao) {
			rejeitarRemoverAtributoEstoqueCmd(cmd, excecao);
		}
	}

	private void rejeitarRemoverAtributoEstoqueCmd(RemoverAtributoEstoqueSaldoCmd cmd, RuntimeException excecao) {

		var id = excecao.getClass().getSimpleName();
		var mensagem = "";
		var detalhe = "";

		if (!id.startsWith("WMS"))
			throw excecao;

		var erroConverter = new ErrorExceptionConverter(i18nService);
		var erro = erroConverter.convert(excecao).getError();

		mensagem = erro.getMessage();
		detalhe = erro.getDetailedMessage();

		var eventoRejeicao = EstoqueAtributoNaoRemovidoEvent.of(cmd.getAtributoEstoqueId(),
																cmd.getProdutoId(),
																EstoqueAtributoNaoRemovidoEvent.Inconsistencia.of(id,
																												  mensagem,
																												  detalhe));
		wmsPublisher.dispatch(eventoRejeicao);
	}

}
