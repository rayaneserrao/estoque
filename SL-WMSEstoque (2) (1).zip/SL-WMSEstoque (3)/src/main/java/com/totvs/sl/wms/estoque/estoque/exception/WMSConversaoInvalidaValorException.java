package com.totvs.sl.wms.estoque.estoque.exception;

import com.totvs.tjf.api.context.stereotype.ApiErrorParameter;
import com.totvs.tjf.api.context.stereotype.error.ApiBadRequest;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
@ApiBadRequest
public class WMSConversaoInvalidaValorException extends RuntimeException {

	private static final long serialVersionUID = -7970549003925488324L;

	@ApiErrorParameter
	private final String valor;

}
