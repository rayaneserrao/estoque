package com.totvs.sl.wms.estoque.estoque.application.command;

import com.totvs.sl.wms.estoque.atributoestoque.domain.model.AtributoEstoqueId;
import com.totvs.sl.wms.estoque.produto.domain.model.ProdutoId;

import lombok.Data;

@Data(staticConstructor = "of")
public final class RemoverAtributoEstoqueCommand {

	private final AtributoEstoqueId id;
	private final ProdutoId produtoId;

}
