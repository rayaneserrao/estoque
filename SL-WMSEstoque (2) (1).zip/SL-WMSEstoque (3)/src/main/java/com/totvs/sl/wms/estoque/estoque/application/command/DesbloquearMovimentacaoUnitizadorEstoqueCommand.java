package com.totvs.sl.wms.estoque.estoque.application.command;

import com.totvs.sl.wms.estoque.bloqueiomovimentacaounitizador.domain.model.BloqueioMovimentacaoUnitizadorId;

import lombok.Data;

@Data(staticConstructor = "of")
public final class DesbloquearMovimentacaoUnitizadorEstoqueCommand {

	private final BloqueioMovimentacaoUnitizadorId bloqueioMovimentacaoUnitizadorId;

}
