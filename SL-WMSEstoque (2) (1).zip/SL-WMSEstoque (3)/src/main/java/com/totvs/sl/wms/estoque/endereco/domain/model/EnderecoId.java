package com.totvs.sl.wms.estoque.endereco.domain.model;

import java.util.UUID;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.totvs.tjf.core.common.domain.DomainObjectId;

public final class EnderecoId extends DomainObjectId<UUID> {

	private static final long serialVersionUID = 2701917249011479212L;

	protected EnderecoId(UUID id) {
		super(id);
	}

	@JsonCreator
	public static EnderecoId from(String uuid) {
		return uuid == null ? null : new EnderecoId(UUID.fromString(uuid));
	}
}