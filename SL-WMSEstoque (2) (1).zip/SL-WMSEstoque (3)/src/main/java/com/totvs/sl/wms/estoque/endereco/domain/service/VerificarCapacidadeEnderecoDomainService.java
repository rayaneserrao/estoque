package com.totvs.sl.wms.estoque.endereco.domain.service;

import java.math.BigDecimal;
import java.util.Collection;
import java.util.Objects;

import org.springframework.stereotype.Service;

import com.totvs.sl.wms.estoque.endereco.domain.model.CapacidadeEndereco;
import com.totvs.sl.wms.estoque.endereco.domain.model.Endereco;
import com.totvs.sl.wms.estoque.endereco.domain.model.EnderecoDomainRepository;
import com.totvs.sl.wms.estoque.endereco.exception.WMSEstouroDeCapacidadeDeEnderecoCubagemException;
import com.totvs.sl.wms.estoque.endereco.exception.WMSEstouroDeCapacidadeDeEnderecoPesoException;
import com.totvs.sl.wms.estoque.estoque.domain.model.Estoque;
import com.totvs.sl.wms.estoque.estoque.domain.model.EstoqueDomainRepository;
import com.totvs.sl.wms.estoque.sku.domain.model.DimensaoSKU;
import com.totvs.sl.wms.estoque.sku.domain.model.SKU;

import lombok.AllArgsConstructor;

@Service
@AllArgsConstructor
public class VerificarCapacidadeEnderecoDomainService {

	private EstoqueDomainRepository estoqueRepository;
	private EnderecoDomainRepository enderecoRepository;

	public void verificar(SKU sku, BigDecimal novoPeso, DimensaoSKU novaDimensao) {

		if (Objects.nonNull(novoPeso) || Objects.nonNull(novaDimensao)) {
			var estoques = estoqueRepository.findBySKUId(sku.getId());
			var enderecosAtualId = estoques.stream().map(Estoque::getEnderecoId).distinct().toList();

			enderecosAtualId.forEach(enderecoId -> {
				var endereco = enderecoRepository.findWithLockByIdOrThrowNotFound(enderecoId);

				endereco.getCapacidade().ifPresent(capacidade -> {
					var estoquesEndereco = estoqueRepository.findByEnderecoId(enderecoId);

					var estoquesSku = estoquesEndereco.stream()
													  .filter(estoque -> estoque.getSkuId().equals(sku.getId()))
													  .toList();

					this.validarPeso(sku, novoPeso, endereco, capacidade, estoquesSku);
					this.validarDimensao(sku, novaDimensao, endereco, capacidade, estoquesSku);
				});

			});
		}
	}

	private void validarPeso(SKU sku,
							 BigDecimal novoPeso,
							 Endereco endereco,
							 CapacidadeEndereco capacidade,
							 Collection<Estoque> estoquesSku) {

		if (Objects.nonNull(novoPeso))
			capacidade.getPeso().ifPresent(capacidadePeso -> {
				var somaPesoAtualSku = estoquesSku.stream()
												  .map(estoque -> sku.getPesoParaQuantidade(estoque.getSaldo()))
												  .reduce(BigDecimal.ZERO, BigDecimal::add);

				var ocupacaoPesoDescontandoSkuAtual = endereco.getOcupacao().getPeso().subtract(somaPesoAtualSku);

				var somaPesoNovoSku = estoquesSku.stream()
												 .map(estoque -> estoque.getSaldo()
																		.divide(sku.getQuantidadeUnidadesProduto())
																		.multiply(novoPeso))
												 .reduce(BigDecimal.ZERO, BigDecimal::add);

				var somaOcupacaoPeso = ocupacaoPesoDescontandoSkuAtual.add(somaPesoNovoSku);
				var somaOcupacaoTotalPeso = somaOcupacaoPeso.add(endereco.getOcupacaoPrevista().getPeso());
				if (somaOcupacaoTotalPeso.compareTo(capacidadePeso) > 0) {
					throw new WMSEstouroDeCapacidadeDeEnderecoPesoException();
				}
			});

	}

	private void validarDimensao(SKU sku,
								 DimensaoSKU novaDimensao,
								 Endereco endereco,
								 CapacidadeEndereco capacidade,
								 Collection<Estoque> estoquesSku) {

		if (Objects.nonNull(novaDimensao))
			capacidade.getDimensao().ifPresent(capacidadeDimensao -> {
				var somaCubagemAtualSku = estoquesSku.stream()
													 .map(estoque -> sku.getCubagemParaQuantidade(estoque.getSaldo()))
													 .reduce(BigDecimal.ZERO, BigDecimal::add);

				var ocupacaoCubagemDescontandoSkuAtual = endereco.getOcupacao()
																 .getCubagem()
																 .subtract(somaCubagemAtualSku);

				var somaCubagemNovoSku = estoquesSku.stream()
													.map(estoque -> estoque.getSaldo()
																		   .divide(sku.getQuantidadeUnidadesProduto())
																		   .multiply(novaDimensao.getCubagem()))
													.reduce(BigDecimal.ZERO, BigDecimal::add);

				var somaOcupacaoCubagem = ocupacaoCubagemDescontandoSkuAtual.add(somaCubagemNovoSku);

				var somaOcupacaoTotalCubagem = somaOcupacaoCubagem.add(endereco.getOcupacaoPrevista().getCubagem());

				if (somaOcupacaoTotalCubagem.compareTo(capacidadeDimensao.getCubagem()) > 0) {
					throw new WMSEstouroDeCapacidadeDeEnderecoCubagemException();
				}
			});

	}
}
