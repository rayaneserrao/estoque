package com.totvs.sl.wms.estoque.atributoestoquevalor.domain.model;

import static com.totvs.tjf.autoconfigure.ValidationUtils.validateIntegrity;

import java.math.BigDecimal;
import java.util.Comparator;
import java.util.Set;
import java.util.TreeSet;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.totvs.sl.wms.estoque.atributoestoque.domain.model.AtributoEstoqueId;
import com.totvs.sl.wms.estoque.atributoestoque.domain.model.ControleQuantidadeAtributoEstoqueValor;
import com.totvs.sl.wms.estoque.atributoestoque.domain.model.FormatoAtributoEstoqueValor;
import com.totvs.sl.wms.estoque.atributoestoquevalor.exception.WMSAtributoEstoqueValorNumeroConstraintException;
import com.totvs.sl.wms.estoque.atributoestoquevalor.exception.WMSAtributoEstoqueValorNumeroNaoSerialDeveTerSomenteUmaOcorrenciaException;
import com.totvs.sl.wms.estoque.util.ConversionUtils;

import lombok.AccessLevel;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Getter
@ToString
@EqualsAndHashCode
@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class AtributoEstoqueValorNumero implements AtributoEstoqueValor<BigDecimal> {

	@NotNull(message = "{AtributoEstoqueValorNumero.id.NotNull}")
	private AtributoEstoqueId id;

	@NotNull(message = "{AtributoEstoqueValorNumero.valor.NotNull}")
	@Size(min = 1, message = "{AtributoEstoqueValorNumero.valor.Size}")
	private TreeSet<BigDecimal> valores;

	@NotNull(message = "{AtributoEstoqueValorNumero.controleQuantidade.NotNull}")
	private ControleQuantidadeAtributoEstoqueValor controleQuantidade;

	@Builder
	private AtributoEstoqueValorNumero(AtributoEstoqueId id,
									   TreeSet<BigDecimal> valores,
									   ControleQuantidadeAtributoEstoqueValor controleQuantidade) {

		this.id = id;
		this.valores = valores;
		this.controleQuantidade = controleQuantidade;

		validateIntegrity(this).ifPresent(violations -> {
			throw new WMSAtributoEstoqueValorNumeroConstraintException(violations);
		});

		this.validarControleQuantidadeSerial();
	}

	@Override
	public FormatoAtributoEstoqueValor getFormato() {
		return FormatoAtributoEstoqueValor.NUMERO;
	}

	@Override
	public void adicionarValorSerial(Object valor) {
		if (this.controleQuantidade.isSerial()) {
			this.valores.add(ConversionUtils.toBigDecimal(valor));
			this.validarControleQuantidadeSerial();
		}
	}

	@Override
	public void removerValorSerial(Object valor) {
		if (this.controleQuantidade.isSerial()) {
			this.valores.remove(ConversionUtils.toBigDecimal(valor));
			this.validarControleQuantidadeSerial();
		}
	}

	@Override
	public void atualizarValorVariavel(Object valor) {
		this.valores = new TreeSet<>(Set.of(ConversionUtils.toBigDecimal(valor)));
	}

	private void validarControleQuantidadeSerial() {
		if (!this.controleQuantidade.equals(ControleQuantidadeAtributoEstoqueValor.SERIAL) && this.valores.size() > 1)
			throw new WMSAtributoEstoqueValorNumeroNaoSerialDeveTerSomenteUmaOcorrenciaException();
	}

	@Override
	public int compareTo(AtributoEstoqueValor<BigDecimal> atributo) {

		return atributo instanceof AtributoEstoqueValorNumero atributoNumero

				? Comparator.comparing(AtributoEstoqueValorNumero::getId)
							.thenComparing(AtributoEstoqueValorNumero::getValores,
										   (a, b) -> new AtributoEstoqueValorComparator<BigDecimal>().compare(a, b))
							.compare(this, atributoNumero)

				: this.getId().compareTo(atributo.getId());
	}
}
