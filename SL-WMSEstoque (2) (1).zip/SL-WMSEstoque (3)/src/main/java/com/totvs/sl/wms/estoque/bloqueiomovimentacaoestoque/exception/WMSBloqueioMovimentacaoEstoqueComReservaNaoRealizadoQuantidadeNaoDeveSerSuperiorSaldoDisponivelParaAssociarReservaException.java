package com.totvs.sl.wms.estoque.bloqueiomovimentacaoestoque.exception;

import com.totvs.tjf.api.context.stereotype.ApiErrorParameter;
import com.totvs.tjf.api.context.stereotype.error.ApiBadRequest;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
@ApiBadRequest
public class WMSBloqueioMovimentacaoEstoqueComReservaNaoRealizadoQuantidadeNaoDeveSerSuperiorSaldoDisponivelParaAssociarReservaException
        extends RuntimeException {

	private static final long serialVersionUID = -1460199444825145261L;

	@ApiErrorParameter
	private final String saldoDisponivelParaAssociarReserva;
}
