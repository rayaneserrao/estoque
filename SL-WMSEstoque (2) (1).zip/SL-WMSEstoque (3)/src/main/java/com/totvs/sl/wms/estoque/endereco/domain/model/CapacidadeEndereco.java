package com.totvs.sl.wms.estoque.endereco.domain.model;

import static com.totvs.sl.wms.estoque.util.Constants.QUANTIDADE_MAXIMA_DECIMAIS;
import static com.totvs.sl.wms.estoque.util.Constants.QUANTIDADE_MAXIMA_INTEIROS;
import static com.totvs.tjf.autoconfigure.ValidationUtils.validateIntegrity;

import java.math.BigDecimal;
import java.util.Optional;

import javax.validation.constraints.Digits;
import javax.validation.constraints.Positive;

import com.totvs.sl.wms.estoque.endereco.exception.WMSCapacidadeEnderecoConstraintException;

import lombok.AccessLevel;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor(access = AccessLevel.PRIVATE, force = true)
public final class CapacidadeEndereco {

	@Positive(message = "{CapacidadeEndereco.unitizador.Positive}")
	private final Integer unitizador;

	@Positive(message = "{CapacidadeEndereco.peso.Positive}")
	@Digits(fraction = QUANTIDADE_MAXIMA_DECIMAIS, integer = QUANTIDADE_MAXIMA_INTEIROS, message = "{CapacidadeEndereco.peso.Digits}")
	private final BigDecimal peso;

	private final DimensaoEndereco dimensao;

	private CapacidadeEndereco(Integer unitizador, BigDecimal peso, DimensaoEndereco dimensao) {

		this.unitizador = unitizador;
		this.peso = peso;
		this.dimensao = dimensao;

		validateIntegrity(this).ifPresent(violations -> {
		    throw new WMSCapacidadeEnderecoConstraintException(violations);
		});
	}

	public Optional<Integer> getUnitizador() {
		return Optional.ofNullable(this.unitizador);
	}

	public Optional<BigDecimal> getPeso() {
		return Optional.ofNullable(this.peso);
	}

	public Optional<DimensaoEndereco> getDimensao() {
		return Optional.ofNullable(this.dimensao);
	}

	public static CapacidadeEndereco of(Integer unitizador, BigDecimal peso, DimensaoEndereco dimensao) {
		return new CapacidadeEndereco(unitizador, peso, dimensao);
	}

}
