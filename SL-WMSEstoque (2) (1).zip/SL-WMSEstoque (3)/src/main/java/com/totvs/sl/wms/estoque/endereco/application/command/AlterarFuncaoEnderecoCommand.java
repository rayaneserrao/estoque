package com.totvs.sl.wms.estoque.endereco.application.command;

import com.totvs.sl.wms.estoque.endereco.domain.model.EnderecoId;
import com.totvs.sl.wms.estoque.endereco.domain.model.FuncaoEndereco;

import lombok.Data;

@Data(staticConstructor = "of")
public final class AlterarFuncaoEnderecoCommand {

	private final EnderecoId id;

	private final FuncaoEndereco funcao;
}