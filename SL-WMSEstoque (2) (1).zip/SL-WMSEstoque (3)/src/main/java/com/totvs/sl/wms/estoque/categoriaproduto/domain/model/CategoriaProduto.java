package com.totvs.sl.wms.estoque.categoriaproduto.domain.model;

import static com.totvs.tjf.autoconfigure.ValidationUtils.validateIntegrity;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Table;
import javax.validation.constraints.NotBlank;

import com.totvs.sl.wms.estoque.categoriaproduto.domain.event.CategoriaProdutoAlteradoEvent;
import com.totvs.sl.wms.estoque.categoriaproduto.domain.event.CategoriaProdutoAtivadoEvent;
import com.totvs.sl.wms.estoque.categoriaproduto.domain.event.CategoriaProdutoCriadoEvent;
import com.totvs.sl.wms.estoque.categoriaproduto.domain.event.CategoriaProdutoInativadoEvent;
import com.totvs.sl.wms.estoque.categoriaproduto.exception.WMSCategoriaProdutoConstraintException;
import com.totvs.tjf.core.stereotype.Aggregate;
import com.totvs.tjf.repository.aggregate.metadata.AggregateDomainMetadataInfo;

import lombok.AccessLevel;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;

@ToString
@Getter
@Aggregate
@Table(name = "categoria_produto")
@EqualsAndHashCode(callSuper = true)
@NoArgsConstructor(access = AccessLevel.PROTECTED, force = true)
public class CategoriaProduto extends AggregateDomainMetadataInfo<CategoriaProdutoId> {

	@NotBlank(message = "{CategoriaProduto.descricao.NotBlank}")
	private String descricao;

	private SituacaoCategoriaProduto situacao;

	private List<SituacaoCategoriaProduto> historicoSituacoes = new ArrayList<>();

	@Builder
	public CategoriaProduto(CategoriaProdutoId id, String descricao) {
		super(id);
		this.descricao = descricao;
		this.situacao = SituacaoCategoriaProduto.ofAtivo();

		validateIntegrity(this).ifPresent(violations -> {
			throw new WMSCategoriaProdutoConstraintException(violations);
		});

		this.registerEvent(CategoriaProdutoCriadoEvent.from(this));
	}

	public void alterar(String descricao) {
		this.descricao = descricao;

		validateIntegrity(this).ifPresent(violations -> {
			throw new WMSCategoriaProdutoConstraintException(violations);
		});

		this.registerEvent(CategoriaProdutoAlteradoEvent.from(this));
	}

	public void ativar() {

		if (this.situacao.isAtivo())
			return;

		this.historicoSituacoes.add(this.situacao);
		this.situacao = SituacaoCategoriaProduto.ofAtivo();

		this.registerEvent(CategoriaProdutoAtivadoEvent.from(this));
	}

	public void inativar() {

		if (this.situacao.isInativo())
			return;

		this.historicoSituacoes.add(this.situacao);
		this.situacao = SituacaoCategoriaProduto.ofInativo();
		this.registerEvent(CategoriaProdutoInativadoEvent.from(this));
	}
}
