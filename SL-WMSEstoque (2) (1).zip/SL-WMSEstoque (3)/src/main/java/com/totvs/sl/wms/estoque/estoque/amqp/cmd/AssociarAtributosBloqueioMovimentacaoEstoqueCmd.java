package com.totvs.sl.wms.estoque.estoque.amqp.cmd;

import com.totvs.sl.wms.estoque.bloqueiomovimentacaoestoque.domain.model.BloqueioMovimentacaoEstoqueId;
import com.totvs.sl.wms.estoque.estoque.domain.model.EstoqueAtributoSaldo;
import com.totvs.sl.wms.estoque.estoque.domain.model.EstoqueId;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.ToString;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import java.util.List;

@Getter
@ToString
@AllArgsConstructor(staticName = "of")
public final class AssociarAtributosBloqueioMovimentacaoEstoqueCmd {

	public static final String NAME = "AssociarAtributosBloqueioMovimentacaoEstoqueCmd";
	public static final String CONDITIONAL_EXPRESSION = "headers['type']=='" + NAME + "'";

	@NotNull(message = "{AssociarAtributosBloqueioMovimentacaoEstoqueCmd.estoqueId.NotNull}")
	private final EstoqueId estoqueId;

	@NotNull(message = "{AssociarAtributosBloqueioMovimentacaoEstoqueCmd.bloqueioMovimentacaoEstoqueId.NotNull}")
	private final BloqueioMovimentacaoEstoqueId bloqueioMovimentacaoEstoqueId;

	@Valid
	private final List<EstoqueAtributoSaldoCmd> atributosSaldo;

	public List<EstoqueAtributoSaldo> getAtributosSaldo() {
		return EstoqueAtributoSaldoCmd.toEstoqueAtributoSaldo(this.atributosSaldo);
	}
}
