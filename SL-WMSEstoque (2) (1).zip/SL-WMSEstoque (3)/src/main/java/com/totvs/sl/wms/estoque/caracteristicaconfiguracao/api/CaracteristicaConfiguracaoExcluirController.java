package com.totvs.sl.wms.estoque.caracteristicaconfiguracao.api;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

import javax.annotation.security.RolesAllowed;

import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.totvs.sl.wms.estoque.caracteristicaconfiguracao.application.CaracteristicaConfiguracaoExcluirApplicationService;
import com.totvs.sl.wms.estoque.caracteristicaconfiguracao.application.command.ExcluirCaracteristicaConfiguracaoCommand;
import com.totvs.sl.wms.estoque.caracteristicaconfiguracao.domain.model.CaracteristicaConfiguracaoId;
import com.totvs.sl.wms.estoque.usuario.domain.model.UsuarioPerfil;
import com.totvs.tjf.api.context.stereotype.ApiGuideline;
import com.totvs.tjf.api.context.stereotype.ApiGuideline.ApiGuidelineVersion;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.AllArgsConstructor;

@Tag(name = "caracteristica-configuracao")

@RestController
@AllArgsConstructor
@RequestMapping(path = CaracteristicaConfiguracaoExcluirController.PATH, produces = APPLICATION_JSON_VALUE, consumes = APPLICATION_JSON_VALUE)
@ApiGuideline(ApiGuidelineVersion.V2)
@RolesAllowed({ UsuarioPerfil.Perfil.PLANEJADOR_WMS, UsuarioPerfil.Perfil.PLANEJADOR_WMS_SENIOR })
public class CaracteristicaConfiguracaoExcluirController {

	public static final String PATH = "/api/v1/caracteristicasConfiguracao";

	private final CaracteristicaConfiguracaoExcluirApplicationService excluirService;

	@Operation(description = "Excluir uma característica de estoque.", method = "POST")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "204", description = "Característica de estoque excluida com sucesso."),
			@ApiResponse(responseCode = "400", description = "A característica de estoque não pôde ser alterada pois possui alguma informação inválida."),
			@ApiResponse(responseCode = "404", description = "A característica de estoque não foi encontrada."), })
	@PostMapping(path = "/{id}/excluir", consumes = MediaType.ALL_VALUE)
	public ResponseEntity<Void> excluir(@PathVariable CaracteristicaConfiguracaoId id) {

		var cmd = ExcluirCaracteristicaConfiguracaoCommand.of(id);

		excluirService.handle(cmd);

		return ResponseEntity.noContent().build();
	}
}
