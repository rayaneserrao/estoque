package com.totvs.sl.wms.estoque.estoque.domain.model;

public enum SituacaoEstoqueValor {
	LIBERADO, BLOQUEADO
}
