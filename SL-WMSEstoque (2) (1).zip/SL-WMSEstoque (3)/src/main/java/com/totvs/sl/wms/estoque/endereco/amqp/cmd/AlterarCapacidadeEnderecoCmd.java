package com.totvs.sl.wms.estoque.endereco.amqp.cmd;

import static com.totvs.sl.wms.estoque.util.Constants.QUANTIDADE_MAXIMA_DECIMAIS;
import static com.totvs.sl.wms.estoque.util.Constants.QUANTIDADE_MAXIMA_DE_4_INTEIROS;

import java.math.BigDecimal;

import javax.validation.Valid;
import javax.validation.constraints.Digits;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Positive;

import com.totvs.sl.wms.estoque.endereco.domain.model.EnderecoId;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public final class AlterarCapacidadeEnderecoCmd {

	public static final String NAME = "AlterarCapacidadeEnderecoCmd";

	public static final String CONDITIONAL_EXPRESSION = "headers['type']=='" + NAME + "'";

	@NotNull(message = "{AlterarCapacidadeEnderecoCmd.id.NotNull}")
	private final EnderecoId id;

	@Positive(message = "{AlterarCapacidadeEnderecoCmd.unitizador.Positive}")
	private final Integer unitizador;

	@Positive(message = "{AlterarCapacidadeEnderecoCmd.peso.Positive}")
	@Digits(fraction = 4, integer = 11, message = "{AlterarCapacidadeEnderecoCmd.peso.Digits}")
	private final BigDecimal peso;

	@Valid
	private final AlterarCapacidadeEnderecoCmdDimensao dimensao;

	@Data(staticConstructor = "of")
	public static final class AlterarCapacidadeEnderecoCmdDimensao {

		@Positive(message = "{AlterarCapacidadeEnderecoCmdDimensao.altura.Positive}")
		@Digits(fraction = QUANTIDADE_MAXIMA_DECIMAIS, integer = QUANTIDADE_MAXIMA_DE_4_INTEIROS, message = "{AlterarCapacidadeEnderecoCmdDimensao.altura.Digits}")
		private final BigDecimal altura;

		@Positive(message = "{AlterarCapacidadeEnderecoCmdDimensao.largura.Positive}")
		@Digits(fraction = QUANTIDADE_MAXIMA_DECIMAIS, integer = QUANTIDADE_MAXIMA_DE_4_INTEIROS, message = "{AlterarCapacidadeEnderecoCmdDimensao.largura.Digits}")
		private final BigDecimal largura;

		@Positive(message = "{AlterarCapacidadeEnderecoCmdDimensao.comprimento.Positive}")
		@Digits(fraction = QUANTIDADE_MAXIMA_DECIMAIS, integer = QUANTIDADE_MAXIMA_DE_4_INTEIROS, message = "{AlterarCapacidadeEnderecoCmdDimensao.comprimento.Digits}")
		private final BigDecimal comprimento;
	}
}
