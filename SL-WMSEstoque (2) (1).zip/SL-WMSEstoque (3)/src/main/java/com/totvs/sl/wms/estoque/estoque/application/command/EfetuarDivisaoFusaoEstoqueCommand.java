package com.totvs.sl.wms.estoque.estoque.application.command;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

import com.totvs.sl.wms.estoque.atributoestoquevalor.domain.model.AtributoEstoqueValor;
import com.totvs.sl.wms.estoque.endereco.domain.model.EnderecoId;
import com.totvs.sl.wms.estoque.estoque.domain.model.EstoqueId;
import com.totvs.sl.wms.estoque.tipoestoque.domain.model.TipoEstoqueId;
import com.totvs.sl.wms.estoque.unitizador.domain.model.UnitizadorId;

import lombok.Data;

@Data(staticConstructor = "of")
public final class EfetuarDivisaoFusaoEstoqueCommand {
	private final EstoqueId estoqueId;
	private final BigDecimal quantidade;
	private final UnitizadorId unitizadorIdDestino;
	private final EnderecoId enderecoIdDestino;
	private final List<AtributoEstoqueValor<?>> atributos;
	private final Optional<TipoEstoqueId> novoTipoEstoqueId;
}
