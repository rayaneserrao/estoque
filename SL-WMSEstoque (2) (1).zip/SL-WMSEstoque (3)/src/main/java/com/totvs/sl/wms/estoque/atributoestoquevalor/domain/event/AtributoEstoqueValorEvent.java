package com.totvs.sl.wms.estoque.atributoestoquevalor.domain.event;

import java.util.List;
import java.util.TreeSet;

import com.totvs.sl.wms.estoque.atributoestoque.domain.model.AtributoEstoqueId;
import com.totvs.sl.wms.estoque.atributoestoque.domain.model.ControleQuantidadeAtributoEstoqueValor;
import com.totvs.sl.wms.estoque.atributoestoque.domain.model.FormatoAtributoEstoqueValor;
import com.totvs.sl.wms.estoque.atributoestoquevalor.domain.model.AtributoEstoqueValor;
import com.totvs.sl.wms.estoque.estoque.domain.model.EstoqueAtributoSaldo;

import lombok.Builder;
import lombok.Getter;
import lombok.ToString;

@Getter
@ToString
@Builder
public final class AtributoEstoqueValorEvent {

	private final AtributoEstoqueId id;
	private final FormatoAtributoEstoqueValor formato;
	private final ControleQuantidadeAtributoEstoqueValor controleQuantidade;
	private final TreeSet<String> valores;

	public static List<AtributoEstoqueValorEvent> from(EstoqueAtributoSaldo atributoSaldo) {
		return atributoSaldo.getAtributos()
							.stream()
							.map(atributo -> AtributoEstoqueValorEvent.builder()
																	  .id(atributo.getId())
																	  .formato(atributo.getFormato())
																	  .controleQuantidade(atributo.getControleQuantidade())
																	  .valores(new TreeSet<>(atributo.getValores()
																									 .stream()
																									 .map(String::valueOf)
																									 .toList()))
																	  .build())
							.toList();
	}

	public static List<AtributoEstoqueValorEvent> from(List<AtributoEstoqueValor<?>> atributos) {
		return atributos.stream()
						.map(atributo -> AtributoEstoqueValorEvent.builder()
																  .id(atributo.getId())
																  .formato(atributo.getFormato())
																  .controleQuantidade(atributo.getControleQuantidade())
																  .valores(new TreeSet<>(atributo.getValores()
																								 .stream()
																								 .map(String::valueOf)
																								 .toList()))
																  .build())
						.toList();
	}
}
