package com.totvs.sl.wms.estoque.estoque.domain.service;

import java.math.BigDecimal;

import org.springframework.stereotype.Service;

import com.totvs.sl.wms.estoque.estoque.domain.model.Estoque;
import com.totvs.sl.wms.estoque.estoque.domain.model.EstoqueDomainRepository;

import lombok.AllArgsConstructor;

@Service
@AllArgsConstructor
public class AtualizaSaldoEstoqueSaidaDomainService {

	private final EstoqueDomainRepository estoqueRepository;

	public void atualizar(Estoque estoque) {
		if (estoque.getSaldo().compareTo(BigDecimal.ZERO) == 0) {
			estoqueRepository.delete(estoque.getId());
		} else {
			estoqueRepository.update(estoque);
		}
	}

}
