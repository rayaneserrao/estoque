package com.totvs.sl.wms.estoque.estoque.api.dto;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.totvs.sl.wms.estoque.atributoestoque.domain.model.AtributoEstoqueId;
import com.totvs.sl.wms.estoque.estoque.domain.model.EstoqueAtributoSaldoId;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Builder
@AllArgsConstructor
@NoArgsConstructor(force = true)
@Getter
@Schema(description = "Informações para alteração do atributo do estoque")
public final class AlterarEstoqueAtributoDTO {

	@NotNull(message = "{AlterarEstoqueAtributoDTO.estoqueAtributoSaldoId.NotNull}")
	@Schema(description = "Identificador do saldo do atributo que terá o valor alterado")
	private final EstoqueAtributoSaldoId estoqueAtributoSaldoId;

	@NotNull(message = "{AlterarEstoqueAtributoDTO.atributoEstoqueId.NotNull}")
	@Schema(description = "Identificador do atributo que terá o valor alterado no saldo")
	private final AtributoEstoqueId atributoEstoqueId;

	@NotBlank(message = "{AlterarEstoqueAtributoDTO.valorAtual.NotBlank}")
	@Size(max = 255, message = "{AlterarEstoqueAtributoDTO.valorAtual.Size}")
	@Schema(description = "Valor atual do atributo")
	private final String valorAtual;

	@NotBlank(message = "{AlterarEstoqueAtributoDTO.novoValor.NotBlank}")
	@Size(max = 255, message = "{AlterarEstoqueAtributoDTO.novoValor.Size}")
	@Schema(description = "Novo valor para o atributo")
	private final String novoValor;
}
