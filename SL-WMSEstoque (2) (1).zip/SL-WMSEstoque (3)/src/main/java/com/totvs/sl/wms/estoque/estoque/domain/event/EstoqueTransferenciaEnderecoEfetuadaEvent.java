package com.totvs.sl.wms.estoque.estoque.domain.event;

import java.math.BigDecimal;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.util.CollectionUtils;

import com.totvs.sl.wms.estoque.bloqueiomovimentacaoestoque.domain.model.BloqueioMovimentacaoEstoqueId;
import com.totvs.sl.wms.estoque.caracteristicaconfiguracao.domain.model.CaracteristicaConfiguracaoId;
import com.totvs.sl.wms.estoque.caracteristicaconfiguracao.domain.model.FormatoCaracteristicaValor;
import com.totvs.sl.wms.estoque.caracteristicavalor.domain.model.CaracteristicaValor;
import com.totvs.sl.wms.estoque.endereco.domain.model.EnderecoId;
import com.totvs.sl.wms.estoque.estoque.domain.model.Estoque;
import com.totvs.sl.wms.estoque.estoque.domain.model.EstoqueId;
import com.totvs.sl.wms.estoque.estoque.domain.model.SituacaoEstoque;
import com.totvs.sl.wms.estoque.estoque.domain.model.SituacaoEstoqueBloqueado;
import com.totvs.sl.wms.estoque.estoque.domain.model.SituacaoEstoqueLiberado;
import com.totvs.sl.wms.estoque.estoque.domain.model.SituacaoEstoqueValor;
import com.totvs.sl.wms.estoque.origem.domain.model.Origem;
import com.totvs.sl.wms.estoque.produto.domain.model.ProdutoId;
import com.totvs.sl.wms.estoque.rastreio.domain.model.RastreioId;
import com.totvs.sl.wms.estoque.reservadefinitivaestoque.domain.model.ReservaDefinitivaEstoque;
import com.totvs.sl.wms.estoque.reservadefinitivaestoque.domain.model.ReservaDefinitivaEstoqueId;
import com.totvs.sl.wms.estoque.sku.domain.model.SKUId;
import com.totvs.sl.wms.estoque.tipoestoque.domain.model.TipoEstoqueId;
import com.totvs.sl.wms.estoque.unidade.domain.model.UnidadeId;
import com.totvs.sl.wms.estoque.unitizador.domain.model.UnitizadorId;
import com.totvs.sl.wms.estoque.util.amqp.TransactionalEvent;

import lombok.Builder;
import lombok.Data;
import lombok.Getter;
import lombok.ToString;

@Getter
@ToString
public final class EstoqueTransferenciaEnderecoEfetuadaEvent extends TransactionalEvent
		implements SubjectMovimentacaoEstoque {

	private final UnidadeId unidadeId;
	private final EstoqueTransferencia estoque;

	private EstoqueTransferenciaEnderecoEfetuadaEvent(UnidadeId unidadeId,
													  EstoqueTransferencia estoque,
													  Origem origem) {

		super(origem.getOrigem(), origem.getId().toString());
		this.unidadeId = unidadeId;
		this.estoque = estoque;
	}

	@Data(staticConstructor = "of")
	public static final class EstoqueTransferencia {
		private final EstoqueTransferenciaSaida saida;
		private final EstoqueTransferenciaEntrada entrada;
	}

	@Data
	@Builder
	public static final class EstoqueTransferenciaSaida {
		private final EstoqueId id;
		private final BigDecimal saldo;
		private final BigDecimal saldoReservado;
		private final BigDecimal saldoDisponivel;
		private final BigDecimal quantidadeBloqueadaMovimentacaoNaoReservada;
		private final BigDecimal quantidadeBloqueadaMovimentacaoReservada;
		private final BigDecimal quantidadeBloqueadaMovimentacaoTotal;
		private final BloqueioMovimentacaoEstoqueId bloqueioMovimentacaoEstoqueId;
		private final boolean unitizadorPossuiSaldoRestante;
		private final List<EstoqueAtributoSaldoEvent> atributosSaldo;
	}

	@Data
	@Builder
	public static final class EstoqueTransferenciaEntrada {
		private final EstoqueId id;
		private final ProdutoId produtoId;
		private final SKUId skuId;
		private final UnitizadorId unitizadorId;
		private final TipoEstoqueId tipoEstoqueId;
		private final EnderecoId enderecoId;
		private final Set<SituacaoEstoqueTransferencia> situacoes;
		private final Boolean avariado;
		private final RastreioId rastreioId;
		private final List<CaracteristicaEstoqueEntrada> caracteristicas;
		private final List<EstoqueAtributoSaldoEvent> atributosSaldo;
		private final List<ReservaDefinitiva> reservasDefinitivas;
		private final BigDecimal saldo;
		private final BigDecimal saldoReservado;
		private final BigDecimal saldoDisponivel;
		private final BigDecimal quantidadeBloqueadaMovimentacaoNaoReservada;
		private final BigDecimal quantidadeBloqueadaMovimentacaoReservada;
		private final BigDecimal quantidadeBloqueadaMovimentacaoTotal;
		private final List<SeloEstoqueEvent> selos;
		private final ZonedDateTime dataHoraEntrada;
	}

	@Data
	@Builder
	public static final class SituacaoEstoqueTransferencia {
		private final SituacaoEstoqueValor situacao;
		private final ZonedDateTime quando;
		private final String chaveAcesso;
		private final String motivo;
	}

	@Data(staticConstructor = "of")
	public static final class CaracteristicaEstoqueEntrada {
		private final CaracteristicaConfiguracaoId caracteristicaConfiguracaoId;
		private final FormatoCaracteristicaValor formato;
		private final String valor;
	}

	@Data(staticConstructor = "of")
	public static final class ReservaDefinitiva {
		private final ReservaDefinitivaEstoqueId id;
		private final BigDecimal quantidade;
	}

	@Data(staticConstructor = "of")
	public static final class SeloEstoqueEvent {
		private final String chave;
		private final String valor;
	}

	public static EstoqueTransferenciaEnderecoEfetuadaEvent from(Estoque estoqueOrigem,
																 Estoque estoqueDestino,
																 List<ReservaDefinitivaEstoque> reservasDefinitivas,
																 BloqueioMovimentacaoEstoqueId bloqueioMovimentacaoEstoqueId,
																 boolean unitizadorPossuiSaldoRestante,
																 Origem origem) {

		var transfSaida = EstoqueTransferenciaSaida.builder()
												   .id(estoqueOrigem.getId())
												   .saldo(estoqueOrigem.getSaldo())
												   .saldoReservado(estoqueOrigem.getQuantidadeReservada())
												   .saldoDisponivel(estoqueOrigem.getSaldoDisponivel())
												   .quantidadeBloqueadaMovimentacaoNaoReservada(estoqueOrigem.getQuantidadeBloqueadaParaMovimentacaoEstoqueNaoReservada())
												   .quantidadeBloqueadaMovimentacaoReservada(estoqueOrigem.getQuantidadeBloqueadaParaMovimentacaoEstoqueReservada())
												   .quantidadeBloqueadaMovimentacaoTotal(estoqueOrigem.getQuantidadeBloqueadaParaMovimentacaoEstoqueTotal())
												   .bloqueioMovimentacaoEstoqueId(bloqueioMovimentacaoEstoqueId)
												   .unitizadorPossuiSaldoRestante(unitizadorPossuiSaldoRestante)
												   .atributosSaldo(EstoqueAtributoSaldoEvent.from(estoqueOrigem.getAtributosSaldo()))
												   .build();

		var transfEntrada = EstoqueTransferenciaEntrada.builder()
													   .id(estoqueDestino.getId())
													   .produtoId(estoqueDestino.getProdutoId())
													   .skuId(estoqueDestino.getSkuId())
													   .unitizadorId(estoqueDestino.getUnitizadorId())
													   .tipoEstoqueId(estoqueDestino.getTipoEstoqueId())
													   .enderecoId(estoqueDestino.getEnderecoId())
													   .situacoes(montarSituacoesEstoqueDestino(estoqueDestino.getSituacoes()))
													   .avariado(estoqueDestino.getAvariado())
													   .caracteristicas(montarCaracteristicasEstoqueDestino(estoqueDestino.getCaracteristicas()))
													   .atributosSaldo(EstoqueAtributoSaldoEvent.from(estoqueDestino.getAtributosSaldo()))
													   .reservasDefinitivas(montarReservasDefinitivasEstoqueDestino(reservasDefinitivas))
													   .rastreioId(estoqueDestino.getRastreioId())
													   .saldo(estoqueDestino.getSaldo())
													   .saldoReservado(estoqueDestino.getQuantidadeReservada())
													   .saldoDisponivel(estoqueDestino.getSaldoDisponivel())
													   .quantidadeBloqueadaMovimentacaoNaoReservada(estoqueDestino.getQuantidadeBloqueadaParaMovimentacaoEstoqueNaoReservada())
													   .quantidadeBloqueadaMovimentacaoReservada(estoqueDestino.getQuantidadeBloqueadaParaMovimentacaoEstoqueReservada())
													   .quantidadeBloqueadaMovimentacaoTotal(estoqueDestino.getQuantidadeBloqueadaParaMovimentacaoEstoqueTotal())
													   .selos(estoqueDestino.getSelos()
																			.stream()
																			.map(selo -> SeloEstoqueEvent.of(selo.getChave(),
																											 selo.getValor()))
																			.collect(Collectors.toList()))
													   .dataHoraEntrada(estoqueDestino.getDataHoraEntrada())
													   .build();

		return new EstoqueTransferenciaEnderecoEfetuadaEvent(estoqueDestino.getUnidadeId(),
															 EstoqueTransferencia.of(transfSaida, transfEntrada),
															 origem);
	}

	private static Set<SituacaoEstoqueTransferencia> montarSituacoesEstoqueDestino(Set<SituacaoEstoque> situacoes) {
		return situacoes.stream().map(EstoqueTransferenciaEnderecoEfetuadaEvent::criar).collect(Collectors.toSet());
	}

	private static SituacaoEstoqueTransferencia criar(SituacaoEstoque situacao) {
		return situacao.getSituacaoEstoque().equals(SituacaoEstoqueValor.LIBERADO) ? criarSituacaoLiberado(situacao)
				: criarSituacaoBloqueado(situacao);
	}

	private static SituacaoEstoqueTransferencia criarSituacaoLiberado(SituacaoEstoque situacao) {
		var situacaoLiberado = (SituacaoEstoqueLiberado) situacao;

		return SituacaoEstoqueTransferencia.builder()
										   .situacao(SituacaoEstoqueValor.LIBERADO)
										   .quando(situacaoLiberado.getQuando())
										   .build();
	}

	private static SituacaoEstoqueTransferencia criarSituacaoBloqueado(SituacaoEstoque situacao) {
		var situacaoBloqueado = (SituacaoEstoqueBloqueado) situacao;

		return SituacaoEstoqueTransferencia.builder()
										   .situacao(SituacaoEstoqueValor.BLOQUEADO)
										   .quando(situacaoBloqueado.getQuando())
										   .chaveAcesso(situacaoBloqueado.getChaveAcesso())
										   .motivo(situacaoBloqueado.getMotivo())
										   .build();
	}

	private static List<CaracteristicaEstoqueEntrada> montarCaracteristicasEstoqueDestino(List<CaracteristicaValor<?>> caracteristicas) {
		if (CollectionUtils.isEmpty(caracteristicas)) {
			return new ArrayList<>();
		}
		return caracteristicas.stream()
							  .map(caracteristica -> CaracteristicaEstoqueEntrada.of(caracteristica.getCaracteristicaConfiguracaoId(),
																					 caracteristica.getFormato(),
																					 caracteristica.getValor()
																								   .toString()))
							  .collect(Collectors.toList());
	}

	private static List<ReservaDefinitiva> montarReservasDefinitivasEstoqueDestino(List<ReservaDefinitivaEstoque> reservasDefinitivas) {
		if (CollectionUtils.isEmpty(reservasDefinitivas)) {
			return new ArrayList<>();
		}
		return reservasDefinitivas.stream()
								  .map(reserva -> ReservaDefinitiva.of(reserva.getId(), reserva.getQuantidade()))
								  .collect(Collectors.toList());
	}
}
