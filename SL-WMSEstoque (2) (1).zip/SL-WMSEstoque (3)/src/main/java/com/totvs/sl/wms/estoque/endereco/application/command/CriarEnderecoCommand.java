package com.totvs.sl.wms.estoque.endereco.application.command;

import com.totvs.sl.wms.estoque.endereco.domain.model.CapacidadeEndereco;
import com.totvs.sl.wms.estoque.endereco.domain.model.EnderecoId;
import com.totvs.sl.wms.estoque.endereco.domain.model.FuncaoEndereco;
import com.totvs.sl.wms.estoque.unidade.domain.model.UnidadeId;

import lombok.Builder;
import lombok.Data;

@Builder
@Data
public final class CriarEnderecoCommand {

	private final EnderecoId id;

	private final UnidadeId unidadeId;

	private final FuncaoEndereco funcao;

	private final CapacidadeEndereco capacidade;
}