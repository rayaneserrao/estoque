package com.totvs.sl.wms.estoque.endereco.repository;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.totvs.sl.wms.estoque.endereco.domain.model.Endereco;
import com.totvs.sl.wms.estoque.endereco.domain.model.EnderecoDomainRepository;
import com.totvs.sl.wms.estoque.endereco.domain.model.EnderecoId;
import com.totvs.sl.wms.estoque.endereco.exception.WMSEnderecoNaoEncontradoException;
import com.totvs.sl.wms.estoque.unidade.domain.model.UnidadeId;
import com.totvs.sl.wms.estoque.util.repository.SqlWhereBuilder;
import com.totvs.tjf.repository.aggregate.CrudAggregateRepository;
import org.springframework.jdbc.core.SqlParameterValue;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.LockModeType;
import java.sql.Types;
import java.util.Optional;

@Repository
public class EnderecoRepository extends CrudAggregateRepository<Endereco, EnderecoId>
		implements EnderecoDomainRepository {

	private static final String CONDICAO_ID = "id = ?";
	private static final String CONDICAO_UNIDADE = "data ->> 'unidadeId' = ?";

	public EnderecoRepository(EntityManager em, ObjectMapper mapper) {
		super(em, mapper.copy());
	}

	@Override
	public Optional<Endereco> findById(EnderecoId id) {
		var clause = SqlWhereBuilder.builder().where(CONDICAO_ID).build();
		return this.findOne(clause, new SqlParameterValue(Types.VARCHAR, id));
	}

	@Override
	public Endereco findByIdOrThrowNotFound(EnderecoId id) {
		return findById(id).orElseThrow(WMSEnderecoNaoEncontradoException::new);
	}

	@Override
	public Endereco findByIdAndUnidadeIdOrThrowNotFound(EnderecoId id, UnidadeId unidadeId) {
		var clause = SqlWhereBuilder.builder().where(CONDICAO_ID).and(CONDICAO_UNIDADE).build();
		return this.findOne(clause,
		                    new SqlParameterValue(Types.VARCHAR, id),
		                    new SqlParameterValue(Types.VARCHAR, unidadeId))
		           .orElseThrow(WMSEnderecoNaoEncontradoException::new);
	}

	@Override
	public boolean existeEnderecoComIdEUnidadeId(EnderecoId id, UnidadeId unidadeId) {
		var clause = SqlWhereBuilder.builder().where(CONDICAO_ID).and(CONDICAO_UNIDADE).build();
		return this.exists(clause,
		                   new SqlParameterValue(Types.VARCHAR, id),
		                   new SqlParameterValue(Types.VARCHAR, unidadeId));
	}

	@Override
	public Endereco findWithLockByIdOrThrowNotFound(EnderecoId id) {
		var clause = SqlWhereBuilder.builder().where(CONDICAO_ID).build();
		return this.findOne(clause,LockModeType.PESSIMISTIC_READ, new SqlParameterValue(Types.VARCHAR, id))
		           .orElseThrow(WMSEnderecoNaoEncontradoException::new);
	}
}