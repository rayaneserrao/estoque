package com.totvs.sl.wms.estoque.categoriaproduto.application;

import com.totvs.sl.wms.estoque.config.amqp.WMSPublisher;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.totvs.sl.wms.estoque.categoriaproduto.application.command.AlterarCategoriaProdutoCommand;
import com.totvs.sl.wms.estoque.categoriaproduto.application.command.AtivarCategoriaProdutoCommand;
import com.totvs.sl.wms.estoque.categoriaproduto.application.command.CriarCategoriaProdutoCommand;
import com.totvs.sl.wms.estoque.categoriaproduto.application.command.InativarCategoriaProdutoCommand;
import com.totvs.sl.wms.estoque.categoriaproduto.domain.model.CategoriaProduto;
import com.totvs.sl.wms.estoque.categoriaproduto.domain.model.CategoriaProdutoDomainRepository;
import com.totvs.sl.wms.estoque.categoriaproduto.domain.model.CategoriaProdutoId;
import com.totvs.sl.wms.estoque.categoriaproduto.exception.WMSDescricaoCategoriaJaExistenteException;

import lombok.AllArgsConstructor;

@Service
@Transactional
@AllArgsConstructor
public class CategoriaProdutoApplicationService {

	private CategoriaProdutoDomainRepository categoriaRepository;

	private final WMSPublisher publisher;

	public CategoriaProdutoId handle(CriarCategoriaProdutoCommand cmd) {

		this.validarExisteCategoriaMesmaDescricao(cmd.getDescricao());

		var categoria = CategoriaProduto.builder()
		                                .id(CategoriaProdutoId.generate())
		                                .descricao(cmd.getDescricao())
		                                .build();

		categoriaRepository.insert(categoria);

		publisher.dispatch(categoria.getEvents());
		
		return categoria.getId();

	}

	public void handle(final AlterarCategoriaProdutoCommand cmd) {

		var categoria = categoriaRepository.findByIdOrThrowNotFound(cmd.getId());

		this.validarExisteCategoriaMesmaDescricao(categoria.getId(), cmd.getDescricao());

		categoria.alterar(cmd.getDescricao());

		categoriaRepository.update(categoria);

		publisher.dispatch(categoria.getEvents());

	}

	public void handle(final AtivarCategoriaProdutoCommand cmd) {

		var categoria = categoriaRepository.findByIdOrThrowNotFound(cmd.getId());

		categoria.ativar();

		categoriaRepository.update(categoria);

		publisher.dispatch(categoria.getEvents());

	}

	public void handle(final InativarCategoriaProdutoCommand cmd) {

		var categoria = categoriaRepository.findByIdOrThrowNotFound(cmd.getId());

		categoria.inativar();

		categoriaRepository.update(categoria);

		publisher.dispatch(categoria.getEvents());

	}

	private void validarExisteCategoriaMesmaDescricao(String descricao) {
		if (categoriaRepository.existeCategoriaMesmaDescricao(descricao))
			throw new WMSDescricaoCategoriaJaExistenteException(descricao);
	}

	private void validarExisteCategoriaMesmaDescricao(CategoriaProdutoId id, String descricao) {
		if (categoriaRepository.existeCategoriaMesmaDescricao(id, descricao))
			throw new WMSDescricaoCategoriaJaExistenteException(descricao);
	}
}
