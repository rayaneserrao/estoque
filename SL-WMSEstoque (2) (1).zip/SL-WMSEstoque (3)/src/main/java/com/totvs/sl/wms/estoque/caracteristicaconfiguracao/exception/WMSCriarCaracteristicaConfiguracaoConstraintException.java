package com.totvs.sl.wms.estoque.caracteristicaconfiguracao.exception;

import java.util.Set;

import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;

import com.totvs.tjf.api.context.stereotype.error.ApiBadRequest;

@ApiBadRequest
public class WMSCriarCaracteristicaConfiguracaoConstraintException extends ConstraintViolationException {

	private static final long serialVersionUID = 2883589665613349255L;

	public WMSCriarCaracteristicaConfiguracaoConstraintException(Set<? extends ConstraintViolation<?>> constraintViolations) {
		super(constraintViolations);
	}

}