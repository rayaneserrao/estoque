package com.totvs.sl.wms.estoque.endereco.domain.model;

import static com.totvs.sl.wms.estoque.util.Constants.QUANTIDADE_MAXIMA_DECIMAIS;
import static com.totvs.sl.wms.estoque.util.Constants.QUANTIDADE_MAXIMA_INTEIROS;
import static com.totvs.tjf.autoconfigure.ValidationUtils.validateIntegrity;

import java.math.BigDecimal;

import javax.validation.constraints.Digits;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;

import com.totvs.sl.wms.estoque.endereco.exception.WMSOcupacaoEnderecoConstraintException;

import lombok.AccessLevel;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor(access = AccessLevel.PRIVATE, force = true)
public final class OcupacaoEndereco {

	@NotNull(message = "{OcupacaoEndereco.unitizador.NotNull}")
	@Min(value = 0, message = "{OcupacaoEndereco.unitizador.Min}")
	private final Integer unitizador;

	@NotNull(message = "{OcupacaoEndereco.peso.NotNull}")
	@Min(value = 0, message = "{OcupacaoEndereco.peso.Min}")
	@Digits(fraction = QUANTIDADE_MAXIMA_DECIMAIS, integer = QUANTIDADE_MAXIMA_INTEIROS, message = "{OcupacaoEndereco.peso.Digits}")
	private final BigDecimal peso;

	@NotNull(message = "{OcupacaoEndereco.cubagem.NotNull}")
	@Min(value = 0, message = "{OcupacaoEndereco.cubagem.Min}")
	@Digits(fraction = QUANTIDADE_MAXIMA_DECIMAIS, integer = QUANTIDADE_MAXIMA_INTEIROS, message = "{OcupacaoEndereco.cubagem.Digits}")
	private final BigDecimal cubagem;

	private OcupacaoEndereco(Integer unitizador, BigDecimal peso, BigDecimal cubagem) {

		this.unitizador = unitizador;
		this.peso = peso;
		this.cubagem = cubagem;

		validateIntegrity(this).ifPresent(violations -> {
			throw new WMSOcupacaoEnderecoConstraintException(violations);
		});
	}

	public static OcupacaoEndereco of(Integer unitizador, BigDecimal peso, BigDecimal cubagem) {
		return new OcupacaoEndereco(unitizador, peso, cubagem);
	}

}
