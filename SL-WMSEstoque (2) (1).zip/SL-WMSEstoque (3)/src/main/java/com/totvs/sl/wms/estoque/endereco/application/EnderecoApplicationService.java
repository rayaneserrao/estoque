package com.totvs.sl.wms.estoque.endereco.application;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.totvs.sl.wms.estoque.bloqueiomovimentacaoestoque.domain.model.BloqueioMovimentacaoEstoqueDomainRepository;
import com.totvs.sl.wms.estoque.bloqueiomovimentacaounitizador.domain.model.BloqueioMovimentacaoUnitizador;
import com.totvs.sl.wms.estoque.bloqueiomovimentacaounitizador.domain.model.BloqueioMovimentacaoUnitizadorDomainRepository;
import com.totvs.sl.wms.estoque.config.amqp.WMSPublisher;
import com.totvs.sl.wms.estoque.endereco.application.command.AlterarCapacidadeEnderecoCommand;
import com.totvs.sl.wms.estoque.endereco.application.command.AlterarFuncaoEnderecoCommand;
import com.totvs.sl.wms.estoque.endereco.application.command.AtualizarOcupacaoEnderecoCommand;
import com.totvs.sl.wms.estoque.endereco.application.command.AtualizarOcupacaoEnderecoSKUCommand;
import com.totvs.sl.wms.estoque.endereco.application.command.AtualizarOcupacaoPrevistaEnderecoCommand;
import com.totvs.sl.wms.estoque.endereco.application.command.AtualizarOcupacoesEnderecoCommand;
import com.totvs.sl.wms.estoque.endereco.application.command.BloquearEntradaEstoqueEnderecoCommand;
import com.totvs.sl.wms.estoque.endereco.application.command.BloquearEntradaSaidaEstoqueEnderecoCommand;
import com.totvs.sl.wms.estoque.endereco.application.command.BloquearSaidaEstoqueEnderecoCommand;
import com.totvs.sl.wms.estoque.endereco.application.command.CriarEnderecoCommand;
import com.totvs.sl.wms.estoque.endereco.application.command.DesbloquearEntradaEstoqueEnderecoCommand;
import com.totvs.sl.wms.estoque.endereco.application.command.DesbloquearEntradaSaidaEstoqueEnderecoCommand;
import com.totvs.sl.wms.estoque.endereco.application.command.DesbloquearSaidaEstoqueEnderecoCommand;
import com.totvs.sl.wms.estoque.endereco.domain.model.Endereco;
import com.totvs.sl.wms.estoque.endereco.domain.model.EnderecoDomainRepository;
import com.totvs.sl.wms.estoque.endereco.domain.model.EnderecoId;
import com.totvs.sl.wms.estoque.endereco.domain.model.OcupacaoEndereco;
import com.totvs.sl.wms.estoque.estoque.application.EstoqueBloquearDesbloquearApplicationService;
import com.totvs.sl.wms.estoque.estoque.domain.model.Estoque;
import com.totvs.sl.wms.estoque.estoque.domain.model.EstoqueDomainRepository;
import com.totvs.sl.wms.estoque.estoque.domain.model.SituacaoEstoqueBloqueado;
import com.totvs.sl.wms.estoque.estoque.domain.model.SituacaoEstoqueLiberado;
import com.totvs.sl.wms.estoque.estoque.domain.service.EstoqueUnitizadorService;
import com.totvs.sl.wms.estoque.movimentoestoque.domain.model.TipoMovimentoEstoque;
import com.totvs.sl.wms.estoque.sku.domain.model.SKUDomainRepository;
import com.totvs.sl.wms.estoque.sku.domain.model.SKUId;
import com.totvs.sl.wms.estoque.unitizador.domain.model.Unitizador;
import com.totvs.sl.wms.estoque.unitizador.domain.model.UnitizadorDomainRepository;
import com.totvs.tjf.core.common.domain.DomainEvent;

import lombok.AllArgsConstructor;

@Service
@Transactional
@AllArgsConstructor
public class EnderecoApplicationService {

	private EstoqueBloquearDesbloquearApplicationService estoqueBloquearDesbloquearService;

	private EnderecoDomainRepository enderecoRepository;
	private EstoqueDomainRepository estoqueRepository;
	private BloqueioMovimentacaoEstoqueDomainRepository bloqueioMovimentacaoEstoqueRepository;
	private BloqueioMovimentacaoUnitizadorDomainRepository bloqueioMovimentacaoUnitizadorRepository;
	private WMSPublisher publisher;
	private SKUDomainRepository skuRepository;
	private UnitizadorDomainRepository unitizadorRepository;
	private EstoqueUnitizadorService estoqueUnitizadorService;

	public void handle(CriarEnderecoCommand cmd) {
		var endereco = Endereco.builder()
							   .id(cmd.getId())
							   .funcao(cmd.getFuncao())
							   .unidadeId(cmd.getUnidadeId())
							   .capacidade(cmd.getCapacidade())
							   .build();

		enderecoRepository.insert(endereco);

		publisher.dispatch(endereco.getEvents());
	}

	public void handle(AlterarFuncaoEnderecoCommand cmd) {

		var endereco = enderecoRepository.findByIdOrThrowNotFound(cmd.getId());

		endereco.alterarFuncao(cmd.getFuncao());

		enderecoRepository.update(endereco);

	}

	public void handle(BloquearEntradaSaidaEstoqueEnderecoCommand cmd) {

		var endereco = enderecoRepository.findByIdOrThrowNotFound(cmd.getId());

		var estoques = estoqueRepository.findWithLockByEnderecoId(endereco.getId());

		var bloqueiosMovimentacaoEstoque = bloqueioMovimentacaoEstoqueRepository.findWithLockByEnderecoIdDestino(endereco.getId());

		var bloqueiosMovimentacaoUnitizador = bloqueioMovimentacaoUnitizadorRepository.findWithLockByEnderecoIdDestino(endereco.getId());

		var eventosBloqueioEstoque = new ArrayList<DomainEvent>();

		var removerUnitizador = endereco.getFuncao().isPicking();

		var skus = estoques.stream()
						   .map(Estoque::getSkuId)
						   .distinct()
						   .map(skuRepository::findByIdOrThrowNotFound)
						   .collect(Collectors.toSet());

		Set<Unitizador> unitizadores = estoques.stream()
											   .map(Estoque::getUnitizadorId)
											   .filter(Objects::nonNull)
											   .distinct()
											   .map(unitizadorRepository::findWithLockByIdOrThrowNotFound)
											   .collect(Collectors.toSet());

		if (cmd.isBloquearEstoques()) {

			var situacao = SituacaoEstoqueBloqueado.of(cmd.getChaveAcesso(), cmd.getMotivo());

			estoques.stream()
					.filter(estoque -> cmd.isPermiteSkuFracionado() || estoque.isSkuNaoFracionado())
					.forEach(estoque -> {

						var eventoMovimentos = estoqueBloquearDesbloquearService.efetuarBloqueioEstoque(estoque,
																										estoque.getSaldo(),
																										situacao,
																										cmd.getOrigem(),
																										removerUnitizador,
																										estoque.getAtributosSaldo());

						eventosBloqueioEstoque.addAll(eventoMovimentos.getMovimentoSaida().getEvents());
						eventosBloqueioEstoque.addAll(eventoMovimentos.getMovimentoEntrada().getEvents());
						eventosBloqueioEstoque.add(eventoMovimentos.getEvento());
					});
		}

		estoques = estoqueRepository.findWithLockByEnderecoId(endereco.getId());

		endereco.bloquearEntradaSaidaEstoque(cmd.getOrigem(),
											 cmd.getChaveAcesso(),
											 bloqueiosMovimentacaoEstoque,
											 bloqueiosMovimentacaoUnitizador,
											 estoques,
											 skus,
											 unitizadores);

		enderecoRepository.update(endereco);
		publisher.dispatch(endereco.getEvents());
		publisher.dispatch(eventosBloqueioEstoque);

	}

	public void handle(DesbloquearEntradaSaidaEstoqueEnderecoCommand cmd) {

		var endereco = enderecoRepository.findByIdOrThrowNotFound(cmd.getId());

		var estoques = estoqueRepository.findWithLockByEnderecoId(endereco.getId());

		var eventosDesbloqueioEstoque = new ArrayList<DomainEvent>();

		if (cmd.isDesbloquearEstoques()) {

			var situacao = SituacaoEstoqueLiberado.of();

			estoques.stream()
					.filter(estoque -> cmd.isPermiteSkuFracionado() || estoque.isSkuNaoFracionado())
					.forEach(estoque -> {

						var eventoMovimentos = estoqueBloquearDesbloquearService.efetuarDesbloqueioEstoque(estoque,
																										   estoque.getSaldo(),
																										   cmd.getChaveAcesso(),
																										   situacao,
																										   cmd.getOrigem(),
																										   estoque.getAtributosSaldo());

						eventosDesbloqueioEstoque.addAll(eventoMovimentos.getMovimentoSaida().getEvents());
						eventosDesbloqueioEstoque.addAll(eventoMovimentos.getMovimentoEntrada().getEvents());
						eventosDesbloqueioEstoque.add(eventoMovimentos.getEvento());
					});

		}

		endereco.desbloquearEntradaSaidaEstoque(cmd.getChaveAcesso(), estoques.size());
		enderecoRepository.update(endereco);
		publisher.dispatch(endereco.getEvents());
		publisher.dispatch(eventosDesbloqueioEstoque);
	}

	public void handle(BloquearEntradaEstoqueEnderecoCommand cmd) {

		var endereco = enderecoRepository.findByIdOrThrowNotFound(cmd.getId());

		var estoques = estoqueRepository.findWithLockByEnderecoId(endereco.getId());

		var bloqueiosMovimentacaoEstoque = bloqueioMovimentacaoEstoqueRepository.findWithLockByEnderecoIdDestino(endereco.getId());

		var bloqueiosMovimentacaoUnitizador = bloqueioMovimentacaoUnitizadorRepository.findWithLockByEnderecoIdDestino(endereco.getId());

		endereco.bloquearEntradaEstoque(cmd.getOrigem(),
										cmd.getChaveAcesso(),
										bloqueiosMovimentacaoEstoque,
										bloqueiosMovimentacaoUnitizador,
										estoques);

		enderecoRepository.update(endereco);

		publisher.dispatch(endereco.getEvents());
	}

	public void handle(DesbloquearEntradaEstoqueEnderecoCommand cmd) {

		var endereco = enderecoRepository.findByIdOrThrowNotFound(cmd.getId());

		endereco.desbloquearEntradaEstoque(cmd.getChaveAcesso());

		enderecoRepository.update(endereco);

		publisher.dispatch(endereco.getEvents());
	}

	public void handle(BloquearSaidaEstoqueEnderecoCommand cmd) {

		var endereco = enderecoRepository.findByIdOrThrowNotFound(cmd.getId());

		var estoques = estoqueRepository.findWithLockByEnderecoId(endereco.getId());

		endereco.bloquearSaidaEstoque(cmd.getOrigem(), cmd.getChaveAcesso(), estoques);

		enderecoRepository.update(endereco);

		publisher.dispatch(endereco.getEvents());
	}

	public void handle(DesbloquearSaidaEstoqueEnderecoCommand cmd) {

		var endereco = enderecoRepository.findByIdOrThrowNotFound(cmd.getId());

		endereco.desbloquearSaidaEstoque(cmd.getChaveAcesso());

		enderecoRepository.update(endereco);

		publisher.dispatch(endereco.getEvents());
	}

	public void handle(AlterarCapacidadeEnderecoCommand cmd) {

		var endereco = enderecoRepository.findByIdOrThrowNotFound(cmd.getId());

		endereco.alterarCapacidade(cmd.getCapacidade());

		enderecoRepository.update(endereco);

		publisher.dispatch(endereco.getEvents());
	}

	public void handle(AtualizarOcupacaoEnderecoCommand cmd) {
		atualizarOcupacaoEndereco(cmd.getId(), cmd.getSkuId(), cmd.getQuantidade(), cmd.getTipoMovimento());
	}

	private void atualizarOcupacaoEndereco(EnderecoId id) {

		var endereco = enderecoRepository.findByIdOrThrowNotFound(id);

		if (this.deveAtualizarOcupacaoEndereco(endereco)) {

			endereco = enderecoRepository.findWithLockByIdOrThrowNotFound(id);

			Collection<Estoque> estoques = estoqueRepository.findByEnderecoId(endereco.getId());

			Long quantidadeUnitizadores = estoques.stream().map(Estoque::getUnitizadorId).distinct().count();

			var somaPesoSkuEstoque = BigDecimal.ZERO;
			var somaCubagemSkuEstoque = BigDecimal.ZERO;

			for (var estoque : estoques) {
				var sku = skuRepository.findByIdOrThrowNotFound(estoque.getSkuId());
				somaPesoSkuEstoque = somaPesoSkuEstoque.add(sku.getPesoParaQuantidade(estoque.getSaldo()));
				somaCubagemSkuEstoque = somaCubagemSkuEstoque.add(sku.getCubagemParaQuantidade(estoque.getSaldo()));
			}

			endereco.atualizarOcupacao(OcupacaoEndereco.of(quantidadeUnitizadores.intValue(),
														   somaPesoSkuEstoque,
														   somaCubagemSkuEstoque));
			enderecoRepository.update(endereco);
			publisher.dispatch(endereco.getEvents());

		}

	}

	private void atualizarOcupacaoEndereco(EnderecoId id,
										   SKUId skuId,
										   BigDecimal quantidade,
										   TipoMovimentoEstoque tipoMovimento) {

		var endereco = enderecoRepository.findByIdOrThrowNotFound(id);

		if (this.deveAtualizarOcupacaoEndereco(endereco)) {

			endereco = enderecoRepository.findWithLockByIdOrThrowNotFound(id);

			var quantidadeUnitizadores = estoqueUnitizadorService.contarUnitizadoresEstoqueByEnderecoId(id);

			var pesoAtual = endereco.getOcupacao().getPeso();
			var cubagemAtual = endereco.getOcupacao().getCubagem();

			var sku = skuRepository.findByIdOrThrowNotFound(skuId);
			var pesoMovimento = sku.getPesoParaQuantidade(quantidade);
			var cubagemMovimento = sku.getCubagemParaQuantidade(quantidade);

			if (tipoMovimento == TipoMovimentoEstoque.ENTRADA) {
				pesoAtual = pesoAtual.add(pesoMovimento);
				cubagemAtual = cubagemAtual.add(cubagemMovimento);
			} else {
				pesoAtual = pesoAtual.subtract(pesoMovimento);
				cubagemAtual = cubagemAtual.subtract(cubagemMovimento);
			}

			endereco.atualizarOcupacao(OcupacaoEndereco.of(quantidadeUnitizadores.intValue(), pesoAtual, cubagemAtual));

			enderecoRepository.update(endereco);
			publisher.dispatch(endereco.getEvents());
		}
	}

	public void handle(AtualizarOcupacaoPrevistaEnderecoCommand cmd) {
		atualizarOcupacaoPrevistaEndereco(cmd.getId());
	}

	private void atualizarOcupacaoPrevistaEndereco(EnderecoId id) {

		var endereco = enderecoRepository.findWithLockByIdOrThrowNotFound(id);

		var bloqueiosMovimentacaoEstoque = bloqueioMovimentacaoEstoqueRepository.findByEnderecoIdDestino(endereco.getId());

		var somaPesoSkuEstoque = BigDecimal.ZERO;
		var somaCubagemSkuEstoque = BigDecimal.ZERO;

		for (var bloqueio : bloqueiosMovimentacaoEstoque) {

			var estoque = estoqueRepository.findByIdOrThrowNotFound(bloqueio.getEstoqueId());
			var sku = skuRepository.findByIdOrThrowNotFound(estoque.getSkuId());

			somaPesoSkuEstoque = somaPesoSkuEstoque.add(sku.getPesoParaQuantidade(bloqueio.getQuantidade()));
			somaCubagemSkuEstoque = somaCubagemSkuEstoque.add(sku.getCubagemParaQuantidade(bloqueio.getQuantidade()));
		}

		var bloqueiosMovimentoUnitizador = bloqueioMovimentacaoUnitizadorRepository.findByEnderecoIdDestino(endereco.getId());
		Long unitizadoresPrevistos = bloqueiosMovimentoUnitizador.stream()
																 .map(BloqueioMovimentacaoUnitizador::getUnitizadorId)
																 .distinct()
																 .count();

		for (var bloqueio : bloqueiosMovimentoUnitizador) {

			var estoques = estoqueRepository.findByUnitizadorIdOrThrowNotFound(bloqueio.getUnitizadorId());

			for (var estoque : estoques) {

				var sku = skuRepository.findByIdOrThrowNotFound(estoque.getSkuId());

				somaPesoSkuEstoque = somaPesoSkuEstoque.add(sku.getPesoParaQuantidade(estoque.getSaldo()));
				somaCubagemSkuEstoque = somaCubagemSkuEstoque.add(sku.getCubagemParaQuantidade(estoque.getSaldo()));

			}
		}

		endereco.atualizarOcupacaoPrevista(OcupacaoEndereco.of(unitizadoresPrevistos.intValue(),
															   somaPesoSkuEstoque,
															   somaCubagemSkuEstoque));
		enderecoRepository.update(endereco);
		publisher.dispatch(endereco.getEvents());
	}

	public void handle(AtualizarOcupacaoEnderecoSKUCommand cmd) {

		var estoques = estoqueRepository.findBySKUId(cmd.getId());

		var enderecosAtualId = estoques.stream().map(Estoque::getEnderecoId).distinct().toList();
		enderecosAtualId.forEach(this::atualizarOcupacaoEndereco);

		Collection<EnderecoId> enderecosId = new ArrayList<>();
		enderecosId.addAll(this.obterEnderecosIdDestinoBloqueioMovimentacaoEstoque(estoques));
		enderecosId.addAll(this.obterEnderecosIdDestinoBloqueioMovimentacaoUnitizador(estoques));

		enderecosId.stream().distinct().forEach(this::atualizarOcupacaoPrevistaEndereco);

	}

	private Collection<EnderecoId> obterEnderecosIdDestinoBloqueioMovimentacaoEstoque(Collection<Estoque> estoques) {

		List<EnderecoId> enderecosId = new ArrayList<>();

		var bloqueiosEstoques = estoques.stream()
										.filter(estoque -> !estoque.getBloqueiosMovimentacaoEstoque().isEmpty())
										.map(Estoque::getBloqueiosMovimentacaoEstoque)
										.toList();

		bloqueiosEstoques.forEach(bloqueiosEstoque -> bloqueiosEstoque.forEach(bloqueioEstoque -> {
			var bloqueio = bloqueioMovimentacaoEstoqueRepository.findWithLockByIdOrThrowNotFound(bloqueioEstoque.getBloqueioMovimentacaoEstoqueId());
			if (bloqueio.getEnderecoIdDestino().isPresent())
				enderecosId.add(bloqueio.getEnderecoIdDestino().get());
		}));

		return enderecosId;

	}

	private Collection<EnderecoId> obterEnderecosIdDestinoBloqueioMovimentacaoUnitizador(Collection<Estoque> estoques) {

		List<EnderecoId> enderecosId = new ArrayList<>();

		var bloqueiosUnitizador = estoques.stream()
										  .filter(estoque -> estoque.getBloqueioMovimentacaoUnitizadorId().isPresent())
										  .map(Estoque::getBloqueioMovimentacaoUnitizadorId)
										  .toList();

		bloqueiosUnitizador.forEach(bloqueioUnitizador -> {
			if (bloqueioUnitizador.isPresent()) {
				var bloqueio = bloqueioMovimentacaoUnitizadorRepository.findWithLockByIdOrThrowNotFound(bloqueioUnitizador.get());
				if (bloqueio.getEnderecoIdDestino().isPresent())
					enderecosId.add(bloqueio.getEnderecoIdDestino().get());
			}
		});

		return enderecosId;

	}

	private boolean deveAtualizarOcupacaoEndereco(Endereco endereco) {
		return !endereco.isDoca() && !endereco.isStage();
	}

	public void handle(AtualizarOcupacoesEnderecoCommand cmd) {
		atualizarOcupacaoEndereco(cmd.getId());
		atualizarOcupacaoPrevistaEndereco(cmd.getId());
	}
}
