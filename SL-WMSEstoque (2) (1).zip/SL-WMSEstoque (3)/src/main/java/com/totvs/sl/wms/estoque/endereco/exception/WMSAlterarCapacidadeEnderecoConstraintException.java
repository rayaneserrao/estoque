package com.totvs.sl.wms.estoque.endereco.exception;

import java.util.Set;

import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;

import com.totvs.tjf.api.context.stereotype.error.ApiBadRequest;

@ApiBadRequest("WMSGenericConstraintViolationException")
public class WMSAlterarCapacidadeEnderecoConstraintException extends ConstraintViolationException {

	private static final long serialVersionUID = 7084004008590737549L;

	public WMSAlterarCapacidadeEnderecoConstraintException(Set<? extends ConstraintViolation<?>> constraintViolations) {
		super(constraintViolations);
	}

}
