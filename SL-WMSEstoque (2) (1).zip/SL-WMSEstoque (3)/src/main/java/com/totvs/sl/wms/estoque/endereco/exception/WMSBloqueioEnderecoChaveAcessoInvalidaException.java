package com.totvs.sl.wms.estoque.endereco.exception;

import com.totvs.tjf.api.context.stereotype.error.ApiBadRequest;

@ApiBadRequest
public class WMSBloqueioEnderecoChaveAcessoInvalidaException extends RuntimeException {

	private static final long serialVersionUID = -4249293397347247727L;
}
