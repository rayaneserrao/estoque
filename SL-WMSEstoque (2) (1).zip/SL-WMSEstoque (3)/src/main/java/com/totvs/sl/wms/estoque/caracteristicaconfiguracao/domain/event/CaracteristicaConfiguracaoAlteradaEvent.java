package com.totvs.sl.wms.estoque.caracteristicaconfiguracao.domain.event;

import com.totvs.sl.wms.estoque.caracteristicaconfiguracao.domain.model.CaracteristicaConfiguracao;
import com.totvs.sl.wms.estoque.caracteristicaconfiguracao.domain.model.CaracteristicaConfiguracaoId;
import com.totvs.sl.wms.estoque.caracteristicaconfiguracao.domain.model.FormatoCaracteristicaValor;
import com.totvs.sl.wms.estoque.util.amqp.SubjectConfiguracao;
import com.totvs.sl.wms.estoque.util.amqp.SubjectDomainEvent;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;

@Getter
@EqualsAndHashCode(callSuper = false)
@AllArgsConstructor(staticName = "of", access = AccessLevel.PRIVATE)
public final class CaracteristicaConfiguracaoAlteradaEvent extends SubjectDomainEvent implements SubjectConfiguracao {

	private final CaracteristicaConfiguracaoId id;
	private final String descricao;
	private final FormatoCaracteristicaValor formato;

	public static CaracteristicaConfiguracaoAlteradaEvent from(CaracteristicaConfiguracao caracteristicaConfiguracao) {
		return CaracteristicaConfiguracaoAlteradaEvent.of(caracteristicaConfiguracao.getId(),
														  caracteristicaConfiguracao.getDescricao(),
														  caracteristicaConfiguracao.getFormato());
	}
}
