package com.totvs.sl.wms.estoque.estoque.exception;

import com.totvs.tjf.api.context.stereotype.error.ApiBadRequest;

@ApiBadRequest("WMSChaveAcessoSaidaEstoqueInvalidaException")
public class WMSChaveAcessoSaidaEstoqueInvalidaException extends RuntimeException {

	private static final long serialVersionUID = -7004440096382258052L;

}