package com.totvs.sl.wms.estoque.categoriaproduto.domain.event;

import com.totvs.sl.wms.estoque.categoriaproduto.domain.model.CategoriaProduto;
import com.totvs.sl.wms.estoque.categoriaproduto.domain.model.CategoriaProdutoId;
import com.totvs.sl.wms.estoque.util.amqp.SubjectConfiguracao;
import com.totvs.sl.wms.estoque.util.amqp.SubjectDomainEvent;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data(staticConstructor = "of")
@EqualsAndHashCode(callSuper = false)
public final class CategoriaProdutoInativadoEvent extends SubjectDomainEvent implements SubjectConfiguracao {

	private final CategoriaProdutoId id;

	public static CategoriaProdutoInativadoEvent from(CategoriaProduto categoriaProduto) {
		return CategoriaProdutoInativadoEvent.of(categoriaProduto.getId());
	}

}
