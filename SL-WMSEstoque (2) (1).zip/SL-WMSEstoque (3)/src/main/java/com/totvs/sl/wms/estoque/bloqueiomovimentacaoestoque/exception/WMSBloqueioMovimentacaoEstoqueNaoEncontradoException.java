package com.totvs.sl.wms.estoque.bloqueiomovimentacaoestoque.exception;

import com.totvs.tjf.api.context.stereotype.error.ApiBadRequest;

@ApiBadRequest
public class WMSBloqueioMovimentacaoEstoqueNaoEncontradoException extends RuntimeException {

	private static final long serialVersionUID = 6234600114436993196L;

}
