package com.totvs.sl.wms.estoque.estoque.amqp.event;

import java.util.List;

import com.totvs.sl.wms.estoque.estoque.domain.event.SubjectEntradaEstoque;
import com.totvs.sl.wms.estoque.unidade.domain.model.UnidadeId;
import com.totvs.sl.wms.estoque.util.amqp.RejectedEvent;
import com.totvs.tjf.api.context.response.ApiErrorResponse;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public final class EstoqueBloqueadoEntradaRejeitadaEvent extends RejectedEvent implements SubjectEntradaEstoque {

	private UnidadeId unidadeId;
	private ApiErrorResponse inconsistencia;

	@Deprecated(forRemoval = true)
	private List<Inconsistencia> inconsistencias;

	@Data(staticConstructor = "of")
	public static final class Inconsistencia {
		private final String id;
		private final String mensagem;
		private final String detalhe;
	}

}
