package com.totvs.sl.wms.estoque.estoque.domain.event;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.totvs.sl.wms.estoque.util.amqp.SubjectMessage;

public interface SubjectSaidaEstoqueLoteEvent extends SubjectMessage {

	@JsonIgnore
	@Override
	default String getSubject() {
		return "saida-estoque-lote";
	}
}
