package com.totvs.sl.wms.estoque.estoque.amqp.cmd;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import com.totvs.sl.wms.estoque.atributoestoque.domain.model.AtributoEstoqueId;
import com.totvs.sl.wms.estoque.produto.domain.model.ProdutoId;
import com.totvs.sl.wms.estoque.util.amqp.EstoqueOutput;
import com.totvs.sl.wms.estoque.util.amqp.SubjectConfiguracao;
import com.totvs.sl.wms.estoque.util.amqp.TransactionalCmd;

import lombok.Getter;
import lombok.ToString;

@Getter
@ToString
public final class AdicionarAtributoEstoqueSaldoCmd extends TransactionalCmd
		implements SubjectConfiguracao, EstoqueOutput {

	public static final String NAME = "AdicionarAtributoEstoqueSaldoCmd";

	public static final String CONDITIONAL_EXPRESSION = "headers['type']=='" + NAME + "'";

	@NotNull(message = "{AdicionarAtributoEstoqueSaldoCmd.atributoEstoqueId.NotNull}")
	private final AtributoEstoqueId atributoEstoqueId;

	@NotNull(message = "{AdicionarAtributoEstoqueSaldoCmd.produtoId.NotNull}")
	private final ProdutoId produtoId;

	@NotBlank(message = "{AdicionarAtributoEstoqueSaldoCmd.valorPadrao.NotBlank}")
	private final String valorPadrao;

	private AdicionarAtributoEstoqueSaldoCmd(AtributoEstoqueId atributoEstoqueId,
											 ProdutoId produtoId,
											 String valorPadrao) {
		super(null, null);
		this.atributoEstoqueId = atributoEstoqueId;
		this.produtoId = produtoId;
		this.valorPadrao = valorPadrao;
	}

	public static AdicionarAtributoEstoqueSaldoCmd of(AtributoEstoqueId atributoEstoqueId,
													  ProdutoId produtoId,
													  String valorPadrao) {
		return new AdicionarAtributoEstoqueSaldoCmd(atributoEstoqueId, produtoId, valorPadrao);
	}
}
