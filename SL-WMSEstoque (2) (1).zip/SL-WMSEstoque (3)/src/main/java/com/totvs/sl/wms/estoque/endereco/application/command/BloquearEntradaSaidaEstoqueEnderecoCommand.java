package com.totvs.sl.wms.estoque.endereco.application.command;

import com.totvs.sl.wms.estoque.endereco.domain.model.EnderecoId;
import com.totvs.sl.wms.estoque.origem.domain.model.Origem;

import lombok.Builder;
import lombok.Data;
import lombok.NonNull;

@Data
@Builder
public final class BloquearEntradaSaidaEstoqueEnderecoCommand {

	@NonNull
	private final EnderecoId id;

	@NonNull
	private final Origem origem;

	@NonNull
	private final String chaveAcesso;

	private final boolean bloquearEstoques;

	private final String motivo;

	private final boolean permiteSkuFracionado;

}
