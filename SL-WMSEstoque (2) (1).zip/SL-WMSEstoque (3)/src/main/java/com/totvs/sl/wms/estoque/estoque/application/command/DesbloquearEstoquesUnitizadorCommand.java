package com.totvs.sl.wms.estoque.estoque.application.command;

import com.totvs.sl.wms.estoque.bloqueiomovimentacaounitizador.domain.model.BloqueioMovimentacaoUnitizadorId;
import com.totvs.sl.wms.estoque.origem.domain.model.Origem;
import com.totvs.sl.wms.estoque.unidade.domain.model.UnidadeId;
import com.totvs.sl.wms.estoque.unitizador.domain.model.UnitizadorId;
import lombok.Data;

import java.util.Optional;

@Data(staticConstructor = "of")
public final class DesbloquearEstoquesUnitizadorCommand {

	private final UnitizadorId unitizadorId;
	private final UnidadeId unidadeId;
	private final String chaveAcesso;
	private final Origem origem;
	private final Optional<BloqueioMovimentacaoUnitizadorId> bloqueioMovimentacaoUnitizadorId;

}
