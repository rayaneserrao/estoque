package com.totvs.sl.wms.estoque.estoque.domain.event;

import java.math.BigDecimal;
import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

import com.totvs.sl.wms.estoque.bloqueiomovimentacaounitizador.domain.model.BloqueioMovimentacaoUnitizador;
import com.totvs.sl.wms.estoque.bloqueiomovimentacaounitizador.domain.model.BloqueioMovimentacaoUnitizadorId;
import com.totvs.sl.wms.estoque.endereco.domain.model.EnderecoId;
import com.totvs.sl.wms.estoque.estoque.domain.model.Estoque;
import com.totvs.sl.wms.estoque.estoque.domain.model.EstoqueId;
import com.totvs.sl.wms.estoque.unitizador.domain.model.UnitizadorId;
import com.totvs.sl.wms.estoque.util.amqp.SubjectDomainEvent;

import lombok.Builder;
import lombok.Data;
import lombok.Getter;
import lombok.ToString;

@ToString
@Getter
@Builder
public final class EstoqueBloqueioMovimentacaoUnitizadorEfetuadoEvent extends SubjectDomainEvent
		implements SubjectBloqueioEstoque {

	private final BloqueioMovimentacaoUnitizadorId id;
	private final UnitizadorId unitizadorId;
	private final EnderecoId enderecoIdOrigem;
	private final EnderecoId enderecoIdDestino;
	private final List<BloqueioMovimentacaoUnitizadorEstoque> estoques;

	@Data(staticConstructor = "of")
	public static final class BloqueioMovimentacaoUnitizadorEstoque {
		private final EstoqueId estoqueId;
		private final BloqueioMovimentacaoUnitizadorQuantidade quantidadeBloqueada;
	}

	@Data(staticConstructor = "of")
	public static final class BloqueioMovimentacaoUnitizadorQuantidade {
		private final BigDecimal naoReservada;
		private final BigDecimal reservada;
		private final BigDecimal total;
	}

	public static EstoqueBloqueioMovimentacaoUnitizadorEfetuadoEvent from(BloqueioMovimentacaoUnitizador bloqueioMovimentacaoUnitizador,
																		  Collection<Estoque> estoques) {

		var primeiroEstoque = estoques.iterator().next();

		return EstoqueBloqueioMovimentacaoUnitizadorEfetuadoEvent.builder()
																 .id(bloqueioMovimentacaoUnitizador.getId())
																 .unitizadorId(bloqueioMovimentacaoUnitizador.getUnitizadorId())
																 .enderecoIdOrigem(primeiroEstoque.getEnderecoId())
																 .enderecoIdDestino(bloqueioMovimentacaoUnitizador.getEnderecoIdDestino()
																												  .orElse(null))
																 .estoques(estoques.stream()
																				   .map(estoque -> BloqueioMovimentacaoUnitizadorEstoque.of(estoque.getId(),
																																			BloqueioMovimentacaoUnitizadorQuantidade.of(estoque.getQuantidadeBloqueadaParaMovimentacaoEstoqueNaoReservada(),
																																														estoque.getQuantidadeBloqueadaParaMovimentacaoEstoqueReservada(),
																																														estoque.getQuantidadeBloqueadaParaMovimentacaoEstoqueTotal())))
																				   .collect(Collectors.toList()))
																 .build();

	}
}
