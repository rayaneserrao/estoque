package com.totvs.sl.wms.estoque.estoque.amqp;

import com.totvs.sl.wms.estoque.config.amqp.WMSChannel;
import com.totvs.sl.wms.estoque.config.amqp.WMSPublisher;
import com.totvs.sl.wms.estoque.estoque.amqp.cmd.EfetuarDivisaoFusaoEstoqueCmd;
import com.totvs.sl.wms.estoque.estoque.amqp.event.EstoqueDivisaoFusaoRejeitadoEvent;
import com.totvs.sl.wms.estoque.estoque.application.EstoqueDividirFundirApplicationService;
import com.totvs.sl.wms.estoque.estoque.application.command.EfetuarDivisaoFusaoEstoqueCommand;
import com.totvs.sl.wms.estoque.estoque.exception.WMSEfetuarDivisaoFusaoEstoqueConstraintException;
import com.totvs.sl.wms.estoque.util.amqp.AMQPUtil;
import com.totvs.tjf.api.response.error.converter.ErrorExceptionConverter;
import com.totvs.tjf.core.i18n.I18nService;
import com.totvs.tjf.core.validation.ValidatorService;
import com.totvs.tjf.messaging.context.TOTVSMessage;
import lombok.AllArgsConstructor;
import org.springframework.cloud.stream.annotation.EnableBinding;
import org.springframework.cloud.stream.annotation.StreamListener;

@AllArgsConstructor
@EnableBinding(WMSChannel.WMSDivisaoFusaoEstoqueCommandsInput.class)
public class EstoqueDivisaoFusaoCommandsSubscriber {

	private ValidatorService validator;
	private EstoqueDividirFundirApplicationService service;
	private I18nService i18nService;
	private WMSPublisher wmsPublisher;

	@StreamListener(target = WMSChannel.WMS_DIVISAO_FUSAO_ESTOQUE_COMMANDS_IN, condition = EfetuarDivisaoFusaoEstoqueCmd.CONDITIONAL_EXPRESSION)
	public void efetuarDivisaoFusaoEstoque(final TOTVSMessage<EfetuarDivisaoFusaoEstoqueCmd> message) {

		AMQPUtil.gerarLog(this.getClass(), message, EfetuarDivisaoFusaoEstoqueCmd.CONDITIONAL_EXPRESSION);
		var cmd = message.getContent();

		validator.validate(cmd).ifPresent(violations -> {
			throw new WMSEfetuarDivisaoFusaoEstoqueConstraintException(violations);
		});

		var command = EfetuarDivisaoFusaoEstoqueCommand.of(cmd.getEstoqueId(),
														   cmd.getQuantidade(),
														   cmd.getUnitizadorIdDestino(),
														   cmd.getEnderecoIdDestino(),
														   cmd.getAtributos(),
														   cmd.getNovoTipoEstoqueId());

		try {
			service.handle(command);
		} catch (RuntimeException excecao) {
			rejeitarEfetuarDivisaoFusaoEstoqueCmd(cmd, excecao);
		}
	}

	private void rejeitarEfetuarDivisaoFusaoEstoqueCmd(EfetuarDivisaoFusaoEstoqueCmd cmd, RuntimeException excecao) {

		var id = excecao.getClass().getSimpleName();

		if (!id.startsWith("WMS"))
			throw excecao;

		var erroConverter = new ErrorExceptionConverter(i18nService);
		var erro = erroConverter.convert(excecao).getError();

		var eventoRejeicao = EstoqueDivisaoFusaoRejeitadoEvent.of(cmd.getEstoqueId(),
																  cmd.getUnitizadorIdDestino(),
																  cmd.getEnderecoIdDestino(),
																  erro);

		wmsPublisher.dispatch(eventoRejeicao);
	}
}
