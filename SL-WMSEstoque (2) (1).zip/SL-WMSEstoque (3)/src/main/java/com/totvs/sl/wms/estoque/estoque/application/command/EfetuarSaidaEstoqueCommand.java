package com.totvs.sl.wms.estoque.estoque.application.command;

import java.math.BigDecimal;
import java.util.List;

import com.totvs.sl.wms.estoque.atributoestoquevalor.domain.model.AtributoEstoqueValor;
import com.totvs.sl.wms.estoque.estoque.domain.model.EstoqueId;

import lombok.Data;

@Data(staticConstructor = "of")
public final class EfetuarSaidaEstoqueCommand {
	private final EstoqueId estoqueId;
	private final BigDecimal quantidade;
	private final List<AtributoEstoqueValor<?>> atributos;
}
