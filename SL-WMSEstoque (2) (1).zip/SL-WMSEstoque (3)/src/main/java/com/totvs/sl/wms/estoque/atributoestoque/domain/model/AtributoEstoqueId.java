package com.totvs.sl.wms.estoque.atributoestoque.domain.model;

import java.util.UUID;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.totvs.tjf.core.common.domain.DomainObjectId;

public final class AtributoEstoqueId extends DomainObjectId<UUID> implements Comparable<AtributoEstoqueId> {

	private static final long serialVersionUID = -8888860224562603456L;

	protected AtributoEstoqueId(UUID id) {
		super(id);
	}

	public static AtributoEstoqueId generate() {
		return new AtributoEstoqueId(UUID.randomUUID());
	}

	@JsonCreator
	public static AtributoEstoqueId from(String uuid) {
		return uuid == null ? null : new AtributoEstoqueId(UUID.fromString(uuid));
	}

	public int compareTo(AtributoEstoqueId o) {// NOSONAR
		return this.getId().compareTo(o.getId());
	}
}
