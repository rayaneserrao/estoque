package com.totvs.sl.wms.estoque.estoque.amqp.event;

import com.totvs.sl.wms.estoque.estoque.domain.event.SubjectSaidaEstoqueLoteEvent;
import com.totvs.sl.wms.estoque.unidade.domain.model.UnidadeId;
import com.totvs.sl.wms.estoque.util.amqp.RejectedEvent;
import com.totvs.tjf.api.context.response.ApiErrorResponse;

import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
@Builder
public final class EstoqueLiberadoSaidaLoteRejeitadaEvent extends RejectedEvent
		implements SubjectSaidaEstoqueLoteEvent {

	private final UnidadeId unidadeId;
	private final ApiErrorResponse inconsistencia;

}
