package com.totvs.sl.wms.estoque.categoriaproduto.api;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.totvs.sl.wms.estoque.categoriaproduto.api.dto.AlterarCategoriaProdutoDTO;
import com.totvs.sl.wms.estoque.categoriaproduto.api.dto.CriarCategoriaProdutoDTO;
import com.totvs.sl.wms.estoque.categoriaproduto.application.CategoriaProdutoApplicationService;
import com.totvs.sl.wms.estoque.categoriaproduto.application.command.AlterarCategoriaProdutoCommand;
import com.totvs.sl.wms.estoque.categoriaproduto.application.command.AtivarCategoriaProdutoCommand;
import com.totvs.sl.wms.estoque.categoriaproduto.application.command.CriarCategoriaProdutoCommand;
import com.totvs.sl.wms.estoque.categoriaproduto.application.command.InativarCategoriaProdutoCommand;
import com.totvs.sl.wms.estoque.categoriaproduto.domain.model.CategoriaProdutoId;
import com.totvs.sl.wms.estoque.categoriaproduto.exception.WMSAlterarCategoriaProdutoConstraintException;
import com.totvs.sl.wms.estoque.categoriaproduto.exception.WMSCriarCategoriaProdutoConstraintException;
import com.totvs.tjf.api.context.stereotype.ApiGuideline;
import com.totvs.tjf.api.context.stereotype.ApiGuideline.ApiGuidelineVersion;
import com.totvs.tjf.core.validation.ValidatorService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import lombok.AllArgsConstructor;

@RestController
@AllArgsConstructor
@ApiGuideline(ApiGuidelineVersion.V2)
@RequestMapping(path = CategoriaProdutoController.PATH, produces = APPLICATION_JSON_VALUE, consumes = APPLICATION_JSON_VALUE)
public class CategoriaProdutoController {

	public static final String PATH = "/api/v1/categoriasProduto"; // NOSONAR

	private CategoriaProdutoApplicationService service;
	private ValidatorService validator;

	@PostMapping
	@Operation(description = "Cadastrar uma nova categoria de um produto.", method = "POST")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "201", description = "Categoria produto cadastrada com sucesso."),
			@ApiResponse(responseCode = "400", description = "A categoria produto não pode ser cadastrada pois possui alguma informação inválida.") })
	public ResponseEntity<Void> criar(@RequestBody CriarCategoriaProdutoDTO dto) {

		validator.validate(dto).ifPresent(violations -> {
			throw new WMSCriarCategoriaProdutoConstraintException(violations);
		});

		var id = service.handle(CriarCategoriaProdutoCommand.of(dto.getDescricao()));

		var uri = ServletUriComponentsBuilder.fromCurrentRequest().path("/").path(id.toString()).build().toUri();

		return ResponseEntity.created(uri).build();
	}

	@Operation(description = "Alterar uma categoria de um produto.", method = "POST")
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "Categoria produto alterada com sucesso."),
			@ApiResponse(responseCode = "400", description = "Solicitação de alteração inválida e alteração não realizada."),
			@ApiResponse(responseCode = "404", description = "A categoria do produto não foi encontrado."), })
	@PostMapping(path = "/{id}/alterar")
	public ResponseEntity<Void> alterar(@PathVariable String id, @RequestBody AlterarCategoriaProdutoDTO dto) {

		validator.validate(dto).ifPresent(violations -> {
			throw new WMSAlterarCategoriaProdutoConstraintException(violations);
		});

		service.handle(AlterarCategoriaProdutoCommand.of(CategoriaProdutoId.from(id), dto.getDescricao()));

		return ResponseEntity.ok().build();
	}

	@Operation(description = "Ativar a categoria de um produto.", method = "POST")
	@ApiResponses(value = { @ApiResponse(responseCode = "204", description = "Categoria produto ativada com sucesso."),
			@ApiResponse(responseCode = "400", description = "Solicitação de ativação inválida e ativação não realizada."),
			@ApiResponse(responseCode = "404", description = "A categoria produto não foi encontrado."), })
	@PostMapping(path = "/{id}/ativar", consumes = MediaType.ALL_VALUE)
	public ResponseEntity<Void> ativar(@PathVariable String id) {

		service.handle(AtivarCategoriaProdutoCommand.of(CategoriaProdutoId.from(id)));

		return ResponseEntity.noContent().build();

	}

	@Operation(description = "Inativar uma categoria de um produto.", method = "POST")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "204", description = "Categoria produto inativada com sucesso."),
			@ApiResponse(responseCode = "400", description = "Solicitação de inativação inválida e inativação não realizada."),
			@ApiResponse(responseCode = "404", description = "A categoria produto não foi encontrado."), })
	@PostMapping(path = "/{id}/inativar", consumes = MediaType.ALL_VALUE)
	public ResponseEntity<Void> inativar(@PathVariable String id) {

		service.handle(InativarCategoriaProdutoCommand.of(CategoriaProdutoId.from(id)));

		return ResponseEntity.noContent().build();
	}
}
