package com.totvs.sl.wms.estoque.caracteristicavalor.domain.model;

import static com.totvs.tjf.autoconfigure.ValidationUtils.validateIntegrity;

import java.util.Comparator;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import com.totvs.sl.wms.estoque.caracteristicaconfiguracao.domain.model.CaracteristicaConfiguracaoId;
import com.totvs.sl.wms.estoque.caracteristicaconfiguracao.domain.model.FormatoCaracteristicaValor;
import com.totvs.sl.wms.estoque.caracteristicavalor.exception.WMSCaracteristicaValorTextoConstraintException;

import lombok.AccessLevel;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Getter
@ToString
@EqualsAndHashCode
@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class CaracteristicaValorTexto implements CaracteristicaValor<String> {

	@NotNull(message = "{CaracteristicaValorTexto.caracteristicaConfiguracaoId.NotNull}")
	private CaracteristicaConfiguracaoId caracteristicaConfiguracaoId;

	@NotBlank(message = "{CaracteristicaValorTexto.valor.NotBlank}")
	private String valor;

	@Builder
	private CaracteristicaValorTexto(CaracteristicaConfiguracaoId caracteristicaConfiguracaoId, String valor) {

		this.caracteristicaConfiguracaoId = caracteristicaConfiguracaoId;
		this.valor = valor;

		validateIntegrity(this).ifPresent(violations -> {
			throw new WMSCaracteristicaValorTextoConstraintException(violations);
		});

	}

	@Override
	public FormatoCaracteristicaValor getFormato() {
		return FormatoCaracteristicaValor.TEXTO;
	}

	@Override
	public int compareTo(CaracteristicaValor<String> caracteristica) {

		return caracteristica instanceof CaracteristicaValorTexto caracteristicaTexto

				? Comparator.comparing(CaracteristicaValorTexto::getCaracteristicaConfiguracaoId)
							.thenComparing(CaracteristicaValorTexto::getValor)
							.compare(this, caracteristicaTexto)

				: this.getCaracteristicaConfiguracaoId().compareTo(caracteristica.getCaracteristicaConfiguracaoId());
	}
}
