package com.totvs.sl.wms.estoque.estoque.api.dto;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.totvs.sl.wms.estoque.caracteristicaconfiguracao.domain.model.CaracteristicaConfiguracaoId;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

@AllArgsConstructor(staticName = "of")
@NoArgsConstructor(force = true)
@Getter
@Schema(description = "Informações para alteração de uma caracaterística no saldo")
public final class AlterarEstoqueCaracteristicaDTO {

	@NotNull(message = "{AlterarEstoqueCaracteristicaDTO.caracteristicaConfiguracaoId.NotNull}")
	@Schema(description = "Identificador da característica que terá o valor alterado no saldo")
	private final CaracteristicaConfiguracaoId caracteristicaConfiguracaoId;

	@NotBlank(message = "{AlterarEstoqueCaracteristicaDTO.valor.NotBlank}")
	@Size(max = 255, message = "{AlterarEstoqueCaracteristicaDTO.valor.Size}")
	@Schema(description = "Novo valor para a característica")
	private final String valor;

}
