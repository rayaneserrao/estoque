package com.totvs.sl.wms.estoque.atributoestoque.amqp;

import org.springframework.cloud.stream.annotation.EnableBinding;
import org.springframework.cloud.stream.annotation.StreamListener;

import com.totvs.sl.wms.estoque.atributoestoque.amqp.cmd.MarcarUtilizacaoAtributoEstoqueCmd;
import com.totvs.sl.wms.estoque.atributoestoque.application.AtributoEstoqueMarcarUtilizacaoApplicationService;
import com.totvs.sl.wms.estoque.atributoestoque.application.command.MarcarUtilizacaoAtributoEstoqueCommand;
import com.totvs.sl.wms.estoque.atributoestoque.exception.WMSAtributoEstoqueConstraintException;
import com.totvs.sl.wms.estoque.config.amqp.WMSChannel;
import com.totvs.sl.wms.estoque.util.amqp.AMQPUtil;
import com.totvs.tjf.core.validation.ValidatorService;
import com.totvs.tjf.messaging.context.TOTVSMessage;

import lombok.AllArgsConstructor;

@AllArgsConstructor
@EnableBinding(WMSChannel.WMSEstoqueConfiguracaoCommandsInput.class)
public class AtributoEstoqueMarcarUtilizacaoSubscriber {

	private final AtributoEstoqueMarcarUtilizacaoApplicationService service;

	private final ValidatorService validator;

	@StreamListener(target = WMSChannel.WMS_ESTOQUE_CONFIGURACAO_COMMANDS_IN, condition = MarcarUtilizacaoAtributoEstoqueCmd.CONDITIONAL_EXPRESSION)
	public void marcarUtilizacao(final TOTVSMessage<MarcarUtilizacaoAtributoEstoqueCmd> message) {

		AMQPUtil.gerarLog(this.getClass(), message, MarcarUtilizacaoAtributoEstoqueCmd.CONDITIONAL_EXPRESSION);

		var transactionInfo = message.getHeader().getTransactionInfo();
		var cmd = message.getContent();

		validator.validate(cmd).ifPresent(violations -> {
			throw new WMSAtributoEstoqueConstraintException(violations);
		});

		var command = MarcarUtilizacaoAtributoEstoqueCommand.of(cmd.getId(), transactionInfo.getGeneratedBy());

		service.handle(command);
	}
}
