package com.totvs.sl.wms.estoque.endereco.application.command;

import com.totvs.sl.wms.estoque.endereco.domain.model.EnderecoId;

import lombok.Data;

@Data(staticConstructor = "of")
public final class AtualizarOcupacoesEnderecoCommand {
	private final EnderecoId id;
}
