package com.totvs.sl.wms.estoque.endereco.exception;

import com.totvs.tjf.api.context.stereotype.ApiErrorParameter;
import com.totvs.tjf.api.context.stereotype.error.ApiBadRequest;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
@ApiBadRequest
public class WMSEnderecoOcupacaoUnitizadorNaoPodeSerSuperiorCapacidadeException extends RuntimeException {

	private static final long serialVersionUID = 9043355461157567268L;

	@ApiErrorParameter
	private final Integer capacidade;

	@ApiErrorParameter
	private final Integer ocupacao;
}
