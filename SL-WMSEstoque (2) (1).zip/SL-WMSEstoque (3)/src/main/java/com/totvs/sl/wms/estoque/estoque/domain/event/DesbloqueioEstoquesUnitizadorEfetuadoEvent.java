package com.totvs.sl.wms.estoque.estoque.domain.event;

import com.totvs.sl.wms.estoque.unitizador.domain.model.UnitizadorId;
import com.totvs.sl.wms.estoque.util.amqp.SubjectDomainEvent;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.ToString;

@ToString
@Getter
@AllArgsConstructor(staticName = "of")
public final class DesbloqueioEstoquesUnitizadorEfetuadoEvent extends SubjectDomainEvent
		implements SubjectBloqueioEstoque {

	private final UnitizadorId unitizadorId;
}
