package com.totvs.sl.wms.estoque.estoque.amqp.cmd;

import java.math.BigDecimal;
import java.util.List;
import javax.validation.constraints.NotNull;
import com.totvs.sl.wms.estoque.endereco.domain.model.EnderecoId;
import com.totvs.sl.wms.estoque.estoque.domain.model.EstoqueAtributoSaldo;
import com.totvs.sl.wms.estoque.estoque.domain.model.EstoqueId;
import com.totvs.sl.wms.estoque.unitizador.domain.model.UnitizadorId;
import lombok.Builder;
import lombok.Getter;

@Getter
@Builder
public final class BloquearMovimentacaoEstoqueCmd {

	public static final String NAME = "BloquearMovimentacaoEstoqueCmd";

	public static final String CONDITIONAL_EXPRESSION = "headers['type']=='" + NAME + "'";

	@NotNull(message = "{BloquearMovimentacaoEstoqueCmd.estoqueId.NotNull}")
	private final EstoqueId estoqueId;

	@NotNull(message = "{BloquearMovimentacaoEstoqueCmd.quantidade.NotNull}")
	private final BigDecimal quantidade;

	private final EnderecoId enderecoIdDestino;

	private final UnitizadorId unitizadorIdDestino;

	private final List<EstoqueAtributoSaldoCmd> atributosSaldo;

	public List<EstoqueAtributoSaldo> getAtributosSaldo() {
		return EstoqueAtributoSaldoCmd.toEstoqueAtributoSaldo(this.atributosSaldo);
	}

}
