package com.totvs.sl.wms.estoque.endereco.application.command;

import java.math.BigDecimal;

import com.totvs.sl.wms.estoque.endereco.domain.model.EnderecoId;
import com.totvs.sl.wms.estoque.movimentoestoque.domain.model.TipoMovimentoEstoque;
import com.totvs.sl.wms.estoque.sku.domain.model.SKUId;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public final class AtualizarOcupacaoEnderecoCommand {
	private final EnderecoId id;
	private final SKUId skuId;
	private final BigDecimal quantidade;
	private final TipoMovimentoEstoque tipoMovimento;
}
