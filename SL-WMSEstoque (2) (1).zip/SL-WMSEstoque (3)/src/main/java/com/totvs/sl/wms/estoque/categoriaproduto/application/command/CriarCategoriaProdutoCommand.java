package com.totvs.sl.wms.estoque.categoriaproduto.application.command;

import lombok.Data;

@Data(staticConstructor = "of")
public final class CriarCategoriaProdutoCommand {

	private final String descricao;
}
