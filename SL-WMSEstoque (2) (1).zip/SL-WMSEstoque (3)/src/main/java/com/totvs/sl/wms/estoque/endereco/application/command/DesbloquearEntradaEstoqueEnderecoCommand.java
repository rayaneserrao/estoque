package com.totvs.sl.wms.estoque.endereco.application.command;

import com.totvs.sl.wms.estoque.endereco.domain.model.EnderecoId;

import lombok.Data;
import lombok.NonNull;

@Data(staticConstructor = "of")
public final class DesbloquearEntradaEstoqueEnderecoCommand {

	@NonNull
	private final EnderecoId id;

	@NonNull
	private final String chaveAcesso;
}
