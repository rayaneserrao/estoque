package com.totvs.sl.wms.estoque.endereco.amqp.event;

import com.totvs.sl.wms.estoque.endereco.domain.model.EnderecoId;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor(access = AccessLevel.PRIVATE, force = true)
@AllArgsConstructor(staticName = "of")
public class EnderecoTransformadoFuncaoArmazenagemEvent {

	public static final String NAME = "EnderecoTransformadoFuncaoArmazenagemEvent";
	public static final String CONDITIONAL_EXPRESSION = "headers['type']=='" + NAME + "'";

	private final EnderecoId id;

}
