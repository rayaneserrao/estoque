package com.totvs.sl.wms.estoque.atributoestoque.amqp.cmd;

import javax.validation.constraints.NotNull;

import com.totvs.sl.wms.estoque.atributoestoque.domain.model.AtributoEstoqueId;
import com.totvs.sl.wms.estoque.util.amqp.EstoqueOutput;
import com.totvs.sl.wms.estoque.util.amqp.SubjectConfiguracao;
import com.totvs.sl.wms.estoque.util.amqp.TransactionalCmd;

import lombok.Getter;
import lombok.ToString;

@Getter
@ToString
public final class MarcarUtilizacaoAtributoEstoqueCmd extends TransactionalCmd
		implements SubjectConfiguracao, EstoqueOutput {

	public static final String GENERATED_BY_PRODUTO_ATRIBUTO = "PRODUTO_ATRIBUTO";

	public static final String NAME = "MarcarUtilizacaoAtributoEstoqueCmd";
	public static final String CONDITIONAL_EXPRESSION = "headers['type']=='" + NAME + "'";

	@NotNull(message = "{MarcarUtilizacaoAtributoEstoqueCmd.id.NotNull}")
	private final AtributoEstoqueId id;

	private MarcarUtilizacaoAtributoEstoqueCmd(String generatedBy, String transactionId, AtributoEstoqueId id) {
		super(generatedBy, transactionId);
		this.id = id;
	}

	public static MarcarUtilizacaoAtributoEstoqueCmd of(String generatedBy,
														String transactionId,
														AtributoEstoqueId id) {
		return new MarcarUtilizacaoAtributoEstoqueCmd(generatedBy, transactionId, id);
	}
}
