package com.totvs.sl.wms.estoque.estoque.amqp.event;

import com.totvs.sl.wms.estoque.estoque.domain.event.SubjectMovimentacaoEstoque;
import com.totvs.sl.wms.estoque.util.amqp.RejectedEvent;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;

@ToString
@Getter
@AllArgsConstructor(staticName = "of")
@NoArgsConstructor(force = true)
public final class EstoqueTransferenciaEnderecoUnitizadorRejeitadaEvent extends RejectedEvent
		implements SubjectMovimentacaoEstoque {

	public static final String NAME = "EstoqueTransferenciaEnderecoUnitizadorRejeitadaEvent";
	public static final String CONDITIONAL_EXPRESSION = "headers['type']=='" + NAME + "'";

	private final TransferenciaUnitizadorInconsistencia inconsistencia;

	@Data(staticConstructor = "of")
	public static final class TransferenciaUnitizadorInconsistencia {
		private final String id;
		private final String mensagem;
		private final String detalhe;
	}
}
