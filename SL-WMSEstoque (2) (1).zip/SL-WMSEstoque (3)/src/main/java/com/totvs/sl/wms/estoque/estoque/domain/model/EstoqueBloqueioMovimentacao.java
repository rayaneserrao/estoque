package com.totvs.sl.wms.estoque.estoque.domain.model;

import static com.totvs.tjf.autoconfigure.ValidationUtils.validateIntegrity;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.NotNull;

import org.springframework.util.CollectionUtils;

import com.totvs.sl.wms.estoque.atributoestoque.domain.model.AtributoEstoqueId;
import com.totvs.sl.wms.estoque.bloqueiomovimentacaoestoque.domain.model.BloqueioMovimentacaoEstoqueId;
import com.totvs.sl.wms.estoque.estoque.exception.WMSEstoqueBloqueioMovimentacaoJaPossuiAtributosAssociadosException;
import com.totvs.sl.wms.estoque.estoque.exception.WMSEstoqueEstoqueBloqueioMovimentacaoConstraintException;
import com.totvs.sl.wms.estoque.estoque.exception.WMSEstoqueQuantidadeTotalAtributosDeveSerIgualQuantidadeBloqueioMovimentacaoException;
import com.totvs.sl.wms.estoque.estoque.exception.WMSQuantidadeAtributosDeveSerIgualQuantidadeBloqueioMovimentacaoEstoqueException;
import com.totvs.sl.wms.estoque.produto.domain.model.Produto;
import com.totvs.sl.wms.estoque.reservadefinitivaestoque.domain.model.ReservaDefinitivaEstoque;
import com.totvs.sl.wms.estoque.reservadefinitivaestoque.domain.model.ReservaDefinitivaEstoqueId;
import com.totvs.sl.wms.estoque.util.CompareUtils;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Getter
@NoArgsConstructor(access = AccessLevel.PRIVATE)
@AllArgsConstructor(access = AccessLevel.PRIVATE)
public final class EstoqueBloqueioMovimentacao {

	@NotNull(message = "{EstoqueBloqueioMovimentacao.bloqueioMovimentacaoEstoqueId.NotNull}")
	private BloqueioMovimentacaoEstoqueId bloqueioMovimentacaoEstoqueId;

	@NotNull(message = "{EstoqueBloqueioMovimentacao.quantidade.NotNull}")
	@DecimalMin(value = "0.0001", message = "{EstoqueBloqueioMovimentacao.quantidade.DecimalMin}")
	private BigDecimal quantidade;

	private Set<EstoqueReservaDefinitiva> reservasDefinitivas = new HashSet<>();

	private List<EstoqueAtributoSaldo> atributosSaldo = new ArrayList<>();

	private EstoqueBloqueioMovimentacao(BloqueioMovimentacaoEstoqueId bloqueioMovimentacaoEstoqueId,
										BigDecimal quantidade,
										Collection<EstoqueReservaDefinitiva> reservasDefinitivas,
										Produto produto,
										List<EstoqueAtributoSaldo> atributosSaldo) {

		this.bloqueioMovimentacaoEstoqueId = bloqueioMovimentacaoEstoqueId;
		this.quantidade = quantidade;

		if (!CollectionUtils.isEmpty(atributosSaldo)) {
			produto.validarIntegridadeAtributos(atributosSaldo);

			var quantidadeAtributos = atributosSaldo.stream()
													.map(EstoqueAtributoSaldo::getSaldo)
													.reduce(BigDecimal.ZERO, BigDecimal::add);

			if (!CompareUtils.equalTo(quantidadeAtributos, quantidade))
				throw new WMSQuantidadeAtributosDeveSerIgualQuantidadeBloqueioMovimentacaoEstoqueException();

			this.atributosSaldo.addAll(atributosSaldo);
		}

		if (!CollectionUtils.isEmpty(reservasDefinitivas))
			this.reservasDefinitivas.addAll(reservasDefinitivas);

		validateIntegrity(this).ifPresent(violations -> {
			throw new WMSEstoqueEstoqueBloqueioMovimentacaoConstraintException(violations);
		});
	}

	public static EstoqueBloqueioMovimentacao of(BloqueioMovimentacaoEstoqueId bloqueioMovimentacaoEstoqueId,
												 BigDecimal quantidade,
												 Collection<EstoqueReservaDefinitiva> reservasDefinitivas,
												 Produto produto,
												 List<EstoqueAtributoSaldo> atributoSaldo) {

		return new EstoqueBloqueioMovimentacao(bloqueioMovimentacaoEstoqueId,
											   quantidade,
											   reservasDefinitivas,
											   produto,
											   atributoSaldo);
	}

	public BigDecimal getQuantidadeReservada() {
		return this.reservasDefinitivas.stream()
									   .map(EstoqueReservaDefinitiva::getQuantidade)
									   .reduce(BigDecimal.ZERO, BigDecimal::add);
	}

	public BigDecimal getQuantidadeNaoReservada() {
		return this.quantidade.subtract(this.getQuantidadeReservada());
	}

	public void adicionarReservaDefinitivaEstoque(ReservaDefinitivaEstoque reservaDefinitivaEstoque,
												  List<EstoqueAtributoSaldo> estoqueAtributos) {

		var estoqueReservaDefinitiva = EstoqueReservaDefinitiva.builder()
															   .reservaDefinitivaEstoqueId(reservaDefinitivaEstoque.getId())
															   .quantidade(reservaDefinitivaEstoque.getQuantidade())
															   .atributos(estoqueAtributos)
															   .build();

		this.reservasDefinitivas.add(estoqueReservaDefinitiva);
	}

	public void removerReservaDefinitivaEstoque(ReservaDefinitivaEstoqueId reservaDefinitivaEstoqueId) {
		this.reservasDefinitivas.removeIf(reserva -> reserva.getReservaDefinitivaEstoqueId()
															.equals(reservaDefinitivaEstoqueId));
	}

	public void aumentarQuantidadeBloqueada(BigDecimal quantidadeSolicitada) {
		this.quantidade = this.quantidade.add(quantidadeSolicitada);
	}

	public void associarAtributos(Produto produto, List<EstoqueAtributoSaldo> atributosSaldo) {

		if (!CollectionUtils.isEmpty(this.atributosSaldo))
			throw new WMSEstoqueBloqueioMovimentacaoJaPossuiAtributosAssociadosException();

		produto.validarIntegridadeAtributos(atributosSaldo);

		var quantidadeTotalAtributos = atributosSaldo.stream()
													 .map(EstoqueAtributoSaldo::getSaldo)
													 .reduce(BigDecimal.ZERO, BigDecimal::add);

		if (!quantidadeTotalAtributos.equals(this.quantidade))
			throw new WMSEstoqueQuantidadeTotalAtributosDeveSerIgualQuantidadeBloqueioMovimentacaoException(this.quantidade,
																											quantidadeTotalAtributos);

		List<EstoqueAtributoSaldo> atributosSaldoAssociar = new ArrayList<>();

		atributosSaldo.forEach(atributoSaldo -> {

			atributosSaldoAssociar.stream()
								  .filter(atributoSaldoAssociar -> atributoSaldoAssociar.equals(atributoSaldo))
								  .findAny()
								  .ifPresentOrElse(estoqueAtributo -> {
									  var estoqueAtributoAtualizado = estoqueAtributo.somandoQuantidade(atributoSaldo.getAtributos(),
																										atributoSaldo.getSaldo());
									  atributosSaldoAssociar.remove(estoqueAtributo);
									  atributosSaldoAssociar.add(estoqueAtributoAtualizado);
								  }, () -> {
									  atributosSaldoAssociar.add(EstoqueAtributoSaldo.of(atributoSaldo.getAtributos(),
																						 atributoSaldo.getSaldo()));
								  });

		});

		this.atributosSaldo = atributosSaldoAssociar;
	}

	public BigDecimal getQuantidadeBloqueadaAtributo(EstoqueAtributoSaldo atributoSaldo) {

		var atributoOpt = this.atributosSaldo.stream().filter(atributo -> atributo.equals(atributoSaldo)).findAny();

		if (atributoOpt.isPresent())
			return atributoOpt.orElseThrow().getSaldo();
		else
			return BigDecimal.ZERO;
	}

	public boolean existeAtributoSerial(AtributoEstoqueId atributoEstoqueId, Object valor) {

		return this.atributosSaldo.stream()
								  .flatMap(atributoSaldo -> atributoSaldo.getAtributos().stream())
								  .anyMatch(atributo -> atributo.getId().equals(atributoEstoqueId)
										  && atributo.getValores()
													 .stream()
													 .map(Object::toString)
													 .anyMatch(v -> v.equals(valor.toString())));
	}

	public BigDecimal getQuantidadeBloqueadaNaoReservada(EstoqueAtributoSaldo estoqueAtributo) {

		var quantidadeReservadaAtributo = this.reservasDefinitivas.stream()
																  .map(reservaDefinitiva -> reservaDefinitiva.getQuantidadeReservadaAtributo(estoqueAtributo))
																  .reduce(BigDecimal.ZERO, BigDecimal::add);

		var quantidadeBloqueadaAtributo = this.atributosSaldo.stream()
															 .filter(atributoSaldo -> atributoSaldo.equals(estoqueAtributo))
															 .map(EstoqueAtributoSaldo::getSaldo)
															 .reduce(BigDecimal.ZERO, BigDecimal::add);

		return CompareUtils.greatherThanOrEqualTo(quantidadeBloqueadaAtributo, quantidadeReservadaAtributo)
				? quantidadeBloqueadaAtributo.subtract(quantidadeReservadaAtributo)
				: BigDecimal.ZERO;
	}

}
