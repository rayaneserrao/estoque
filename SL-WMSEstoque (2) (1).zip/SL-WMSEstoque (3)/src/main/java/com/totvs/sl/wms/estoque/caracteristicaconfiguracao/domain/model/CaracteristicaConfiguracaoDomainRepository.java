package com.totvs.sl.wms.estoque.caracteristicaconfiguracao.domain.model;

import java.util.Optional;

import com.totvs.tjf.repository.aggregate.AggregateRepository;

public interface CaracteristicaConfiguracaoDomainRepository
		extends AggregateRepository<CaracteristicaConfiguracao, CaracteristicaConfiguracaoId> {

	Optional<CaracteristicaConfiguracao> findById(CaracteristicaConfiguracaoId id);

	CaracteristicaConfiguracao findByIdOrThrowNotFound(CaracteristicaConfiguracaoId id);

	boolean existeCaracteristicaConfiguracaoComMesmaDescricao(String descricao);

	boolean existeCaracteristicaConfiguracaoComMesmaDescricao(CaracteristicaConfiguracaoId id, String descricao);
}
