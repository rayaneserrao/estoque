package com.totvs.sl.wms.estoque.atributoestoquevalor.domain.model;

import java.util.Comparator;
import java.util.Iterator;
import java.util.TreeSet;

public class AtributoEstoqueValorComparator<T extends Comparable<T>> implements Comparator<TreeSet<T>> {

	@Override
	public int compare(TreeSet<T> a, TreeSet<T> b) {

		if (a.equals(b))
			return 0;

		if (a.size() < b.size())
			return -1;

		if (a.size() > b.size())
			return 1;

		Iterator<T> it1 = a.iterator();
		Iterator<T> it2 = b.iterator();
		while (it1.hasNext()) {
			var t1 = it1.next();
			var t2 = it2.next();
			var result = t1.compareTo(t2);
			if (result != 0)
				return result;
		}

		return 0;
	}

}
