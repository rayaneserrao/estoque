package com.totvs.sl.wms.estoque.caracteristicavalor.validator;

import static java.lang.annotation.ElementType.FIELD;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.Target;

import javax.validation.Constraint;
import javax.validation.Payload;

@Documented
@Target(FIELD)
@Retention(RUNTIME)
@Constraint(validatedBy = { UniqueListCaracteristicaValorValidator.class })
public @interface UniqueListCaracteristicaValor {

    String message() default "{com.totvs.sl.wms.estoque.caracteristicavalor.validators.UniqueListCaracteristicaValor}";

    Class<?>[] groups() default {};

    Class<? extends Payload>[] payload() default {};
}