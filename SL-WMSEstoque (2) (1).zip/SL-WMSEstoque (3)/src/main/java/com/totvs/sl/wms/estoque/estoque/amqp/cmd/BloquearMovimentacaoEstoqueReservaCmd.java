package com.totvs.sl.wms.estoque.estoque.amqp.cmd;

import java.util.List;

import javax.validation.constraints.NotNull;

import com.totvs.sl.wms.estoque.estoque.domain.model.EstoqueAtributoSaldo;
import com.totvs.sl.wms.estoque.reservadefinitivaestoque.domain.model.ReservaDefinitivaEstoqueId;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Getter
@AllArgsConstructor(staticName = "of")
@NoArgsConstructor(access = AccessLevel.PRIVATE, force = true)
@EqualsAndHashCode
public final class BloquearMovimentacaoEstoqueReservaCmd {

	public static final String NAME = "BloquearMovimentacaoEstoqueReservaCmd";
	public static final String CONDITIONAL_EXPRESSION = "headers['type']=='" + NAME + "'";

	@NotNull(message = "{BloquearMovimentacaoEstoqueReservaCmd.reservaDefinitivaEstoqueId.NotNull}")
	private final ReservaDefinitivaEstoqueId reservaDefinitivaEstoqueId;

	private final List<EstoqueAtributoSaldoCmd> atributosSaldo;

	public List<EstoqueAtributoSaldo> getAtributosSaldo() {
		return EstoqueAtributoSaldoCmd.toEstoqueAtributoSaldo(this.atributosSaldo);
	}
}
