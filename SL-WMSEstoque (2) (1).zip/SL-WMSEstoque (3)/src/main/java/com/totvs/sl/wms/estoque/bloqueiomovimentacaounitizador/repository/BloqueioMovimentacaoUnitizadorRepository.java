package com.totvs.sl.wms.estoque.bloqueiomovimentacaounitizador.repository;

import java.sql.Types;
import java.util.Collection;
import java.util.Optional;

import javax.persistence.EntityManager;
import javax.persistence.LockModeType;

import org.springframework.jdbc.core.SqlParameterValue;
import org.springframework.stereotype.Repository;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.totvs.sl.wms.estoque.bloqueiomovimentacaounitizador.domain.model.BloqueioMovimentacaoUnitizador;
import com.totvs.sl.wms.estoque.bloqueiomovimentacaounitizador.domain.model.BloqueioMovimentacaoUnitizadorDomainRepository;
import com.totvs.sl.wms.estoque.bloqueiomovimentacaounitizador.domain.model.BloqueioMovimentacaoUnitizadorId;
import com.totvs.sl.wms.estoque.bloqueiomovimentacaounitizador.exception.WMSBloqueioMovimentacaoUnitizadorNaoEncontradoException;
import com.totvs.sl.wms.estoque.endereco.domain.model.EnderecoId;
import com.totvs.sl.wms.estoque.unitizador.domain.model.UnitizadorId;
import com.totvs.sl.wms.estoque.util.repository.SqlWhereBuilder;
import com.totvs.tjf.repository.aggregate.CrudAggregateRepository;

@Repository
public class BloqueioMovimentacaoUnitizadorRepository
        extends CrudAggregateRepository<BloqueioMovimentacaoUnitizador, BloqueioMovimentacaoUnitizadorId>
        implements BloqueioMovimentacaoUnitizadorDomainRepository {

	private static final String CONDICAO_ID = "id = ?";

	private static final String CONDICAO_UNITIZADOR = "data ->> 'unitizadorId' = ?";

	private static final String CONDICAO_ENDERECO_ID_DESTINO = "data ->> 'enderecoIdDestino' = ?";

	public BloqueioMovimentacaoUnitizadorRepository(EntityManager em, ObjectMapper mapper) {
		super(em, mapper.copy());
	}

	@Override
	public Optional<BloqueioMovimentacaoUnitizador> findById(BloqueioMovimentacaoUnitizadorId id) {
		var clause = SqlWhereBuilder.builder().where(CONDICAO_ID).build();
		return this.findOne(clause, new SqlParameterValue(Types.VARCHAR, id));
	}

	@Override
	public BloqueioMovimentacaoUnitizador findWithLockByIdOrThrowNotFound(BloqueioMovimentacaoUnitizadorId id) {
		var clause = SqlWhereBuilder.builder().where(CONDICAO_ID).build();
		return this.findOne(clause, LockModeType.PESSIMISTIC_READ, new SqlParameterValue(Types.VARCHAR, id))
		           .orElseThrow(WMSBloqueioMovimentacaoUnitizadorNaoEncontradoException::new);
	}

	@Override
	public boolean existsByUnitizadorId(UnitizadorId unitizadorId) {
		var clause = SqlWhereBuilder.builder().where(CONDICAO_UNITIZADOR).build();
		return this.exists(clause, new SqlParameterValue(Types.VARCHAR, unitizadorId));
	}

	@Override
	public Collection<BloqueioMovimentacaoUnitizador> findWithLockByEnderecoIdDestino(EnderecoId enderecoIdDestino) {
		var clause = SqlWhereBuilder.builder().where(CONDICAO_ENDERECO_ID_DESTINO).build();
		return this.findAll(clause,
		                    LockModeType.PESSIMISTIC_READ,
		                    null,
		                    new SqlParameterValue(Types.VARCHAR, enderecoIdDestino));

	}

	@Override
	public Collection<BloqueioMovimentacaoUnitizador> findByEnderecoIdDestino(EnderecoId enderecoIdDestino) {
		var clause = SqlWhereBuilder.builder().where(CONDICAO_ENDERECO_ID_DESTINO).build();
		return this.findAll(clause,
		                    null,
		                    new SqlParameterValue(Types.VARCHAR, enderecoIdDestino));
	}

}
