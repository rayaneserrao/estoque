package com.totvs.sl.wms.estoque.estoque.amqp.cmd;

import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import com.totvs.sl.wms.estoque.atributoestoquevalor.amqp.cmd.AtributoEstoqueValorCmd;
import com.totvs.sl.wms.estoque.atributoestoquevalor.domain.model.AtributoEstoqueValor;
import com.totvs.sl.wms.estoque.bloqueiomovimentacaoestoque.domain.model.BloqueioMovimentacaoEstoqueId;
import com.totvs.sl.wms.estoque.endereco.domain.model.EnderecoId;
import com.totvs.sl.wms.estoque.reservadefinitivaestoque.domain.model.ReservaDefinitivaEstoqueId;
import com.totvs.sl.wms.estoque.unidade.domain.model.UnidadeId;
import com.totvs.sl.wms.estoque.unitizador.domain.model.UnitizadorId;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public final class EfetuarTransferenciaEnderecoEstoquePorReservaDefinitivaEstoqueCmd {

	public static final String NAME = "EfetuarTransferenciaEnderecoEstoquePorReservaDefinitivaEstoqueCmd";

	public static final String CONDITIONAL_EXPRESSION = "headers['type']=='" + NAME + "'";

	@NotNull(message = "{EfetuarTransferenciaEnderecoEstoquePorReservaDefinitivaEstoqueCmd.unidadeId.NotNull}")
	private final UnidadeId unidadeId;

	@NotNull(message = "{EfetuarTransferenciaEnderecoEstoquePorReservaDefinitivaEstoqueCmd.reservaDefinitivaEstoqueId.NotNull}")
	private final ReservaDefinitivaEstoqueId reservaDefinitivaEstoqueId;

	@NotNull(message = "{EfetuarTransferenciaEnderecoEstoquePorReservaDefinitivaEstoqueCmd.enderecoId.NotNull}")
	private final EnderecoId enderecoId;

	private final BloqueioMovimentacaoEstoqueId bloqueioMovimentacaoEstoqueId;

	private final UnitizadorId unitizadorId;

	@Valid
	private final List<AtributoEstoqueValorCmd> atributos;

	public final List<AtributoEstoqueValor<?>> getAtributos() {
		return AtributoEstoqueValorCmd.toAtributoEstoqueValor(this.atributos);
	}
}
