package com.totvs.sl.wms.estoque.estoque.application;

import java.util.Objects;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.totvs.sl.wms.estoque.bloqueiomovimentacaoestoque.domain.model.BloqueioMovimentacaoEstoqueDomainRepository;
import com.totvs.sl.wms.estoque.bloqueiomovimentacaounitizador.domain.model.BloqueioMovimentacaoUnitizador;
import com.totvs.sl.wms.estoque.bloqueiomovimentacaounitizador.domain.model.BloqueioMovimentacaoUnitizadorDomainRepository;
import com.totvs.sl.wms.estoque.bloqueiomovimentacaounitizador.domain.model.BloqueioMovimentacaoUnitizadorId;
import com.totvs.sl.wms.estoque.config.amqp.WMSPublisher;
import com.totvs.sl.wms.estoque.endereco.domain.model.Endereco;
import com.totvs.sl.wms.estoque.endereco.domain.model.EnderecoDomainRepository;
import com.totvs.sl.wms.estoque.endereco.domain.service.AtualizarOcupacaoPrevistaEnderecoDomainService;
import com.totvs.sl.wms.estoque.estoque.application.command.AssociarAtributosBloqueioMovimentacaoEstoqueCommand;
import com.totvs.sl.wms.estoque.estoque.application.command.AumentarBloqueioMovimentacaoEstoqueCommand;
import com.totvs.sl.wms.estoque.estoque.application.command.BloquearMovimentacaoEstoqueCommand;
import com.totvs.sl.wms.estoque.estoque.application.command.BloquearMovimentacaoEstoqueReservaCommand;
import com.totvs.sl.wms.estoque.estoque.application.command.BloquearMovimentacaoUnitizadorEstoqueCommand;
import com.totvs.sl.wms.estoque.estoque.application.command.DesbloquearMovimentacaoEstoqueCommand;
import com.totvs.sl.wms.estoque.estoque.application.command.DesbloquearMovimentacaoUnitizadorEstoqueCommand;
import com.totvs.sl.wms.estoque.estoque.domain.model.EstoqueDomainRepository;
import com.totvs.sl.wms.estoque.estoque.exception.WMSBloqueioMovimentacaoUnitizadorEnderecoOrigemDiferenteException;
import com.totvs.sl.wms.estoque.estoque.exception.WMSBloqueioMovimentacaoUnitizadorEstoqueNaoEncontradoException;
import com.totvs.sl.wms.estoque.produto.domain.model.ProdutoDomainRepository;
import com.totvs.sl.wms.estoque.sku.domain.model.SKUDomainRepository;

import lombok.AllArgsConstructor;

@Service
@Transactional
@AllArgsConstructor
public class EstoqueBloquearDesbloquearMovimentacaoApplicationService {

	private final EstoqueDomainRepository estoqueRepository;
	private final SKUDomainRepository skuRepository;
	private final EnderecoDomainRepository enderecoRepository;
	private final BloqueioMovimentacaoUnitizadorDomainRepository bloqueioMovimentacaoUnitizadorRepository;
	private final BloqueioMovimentacaoEstoqueDomainRepository bloqueioMovimentacaoEstoqueRepository;
	private final ProdutoDomainRepository produtoRepository;
	private final AtualizarOcupacaoPrevistaEnderecoDomainService atualizarOcupacaoPrevistaEnderecoService;
	private final WMSPublisher publisher;

	public void handle(final BloquearMovimentacaoUnitizadorEstoqueCommand cmd) {

		var estoques = estoqueRepository.findByUnidadeIdAndUnitizadorId(cmd.getUnidadeId(), cmd.getUnitizadorId());

		if (estoques.isEmpty()) {
			throw new WMSBloqueioMovimentacaoUnitizadorEstoqueNaoEncontradoException();
		} else {
			if (cmd.getEnderecoIdOrigem() != null
					&& !estoques.iterator().next().getEnderecoId().equals(cmd.getEnderecoIdOrigem())) {
				throw new WMSBloqueioMovimentacaoUnitizadorEnderecoOrigemDiferenteException();
			}
		}

		var enderecoDestino = Objects.nonNull(cmd.getEnderecoIdDestino())
				? enderecoRepository.findByIdAndUnidadeIdOrThrowNotFound(cmd.getEnderecoIdDestino(), cmd.getUnidadeId())
				: null;

		var bloqueioMovimentacaoUnitizadorId = BloqueioMovimentacaoUnitizadorId.generate();

		var bloqueioMovimentacaoUnitizador = BloqueioMovimentacaoUnitizador.builder()
																		   .id(bloqueioMovimentacaoUnitizadorId)
																		   .unitizadorId(cmd.getUnitizadorId())
																		   .origem(cmd.getOrigem())
																		   .estoques(estoques)
																		   .enderecoDestino(enderecoDestino)
																		   .chaveAcesso(cmd.getChaveAcesso())
																		   .build();

		bloqueioMovimentacaoUnitizadorRepository.insert(bloqueioMovimentacaoUnitizador);
		estoques.forEach(estoque -> estoqueRepository.update(estoque));

		if (bloqueioMovimentacaoUnitizador.getEnderecoIdDestino().isPresent()) {
			var endereco = atualizarOcupacaoPrevistaEnderecoService.aumentar(bloqueioMovimentacaoUnitizador.getEnderecoIdDestino()
																										   .orElseThrow(),
																			 estoques);
			publisher.dispatch(endereco.getEvents());
		}

		publisher.dispatch(bloqueioMovimentacaoUnitizador.getEvents());
	}

	public void handle(final BloquearMovimentacaoEstoqueReservaCommand cmd) {

		var estoque = estoqueRepository.findWithLockByReservaDefinitivaEstoqueIdOrThrowNotFound(cmd.getReservaDefinitivaEstoqueId());

		var sku = skuRepository.findByIdOrThrowNotFound(estoque.getSkuId());

		var reservasDefinitivas = estoque.getReservasDefinitivas()
										 .stream()
										 .filter(reserva -> reserva.getReservaDefinitivaEstoqueId()
																   .equals(cmd.getReservaDefinitivaEstoqueId()))
										 .findFirst()
										 .orElseThrow();

		var produto = produtoRepository.findByIdOrThrowNotFound(estoque.getProdutoId());

		var bloqueio = estoque.bloquearMovimentacaoEstoque(sku,
														   cmd.getOrigem(),
														   reservasDefinitivas.getQuantidade(),
														   cmd.getReservaDefinitivaEstoqueId(),
														   null,
														   null,
														   produto,
														   cmd.getAtributosSaldo());

		estoqueRepository.update(estoque);
		bloqueioMovimentacaoEstoqueRepository.insert(bloqueio);

		bloqueio.getEvents().forEach(publisher::dispatch);
		estoque.getEvents().forEach(publisher::dispatch);

	}

	public void handle(final BloquearMovimentacaoEstoqueCommand cmd) {

		var estoque = estoqueRepository.findWithLockByIdOrThrowNotFound(cmd.getEstoqueId());

		var sku = skuRepository.findByIdOrThrowNotFound(estoque.getSkuId());

		var enderecoDestino = enderecoRepository.findByIdOrThrowNotFound(cmd.getEnderecoIdDestino());

		var produto = produtoRepository.findByIdOrThrowNotFound(estoque.getProdutoId());

		var bloqueio = estoque.bloquearMovimentacaoEstoque(sku,
														   cmd.getOrigem(),
														   cmd.getQuantidade(),
														   null,
														   enderecoDestino,
														   cmd.getUnitizadorIdDestino(),
														   produto,
														   cmd.getAtributosSaldo());
		estoqueRepository.update(estoque);
		bloqueioMovimentacaoEstoqueRepository.insert(bloqueio);

		var endereco = atualizarOcupacaoPrevistaEnderecoService.aumentar(bloqueio.getEnderecoIdDestino().orElseThrow(),
																		 sku,
																		 cmd.getQuantidade());

		bloqueio.getEvents().forEach(publisher::dispatch);
		estoque.getEvents().forEach(publisher::dispatch);
		endereco.getEvents().forEach(publisher::dispatch);
	}

	public void handle(final DesbloquearMovimentacaoEstoqueCommand cmd) {

		var estoque = estoqueRepository.findWithLockByIdOrThrowNotFound(cmd.getEstoqueId());

		var bloqueio = bloqueioMovimentacaoEstoqueRepository.findWithLockByIdOrThrowNotFound(cmd.getBloqueioMovimentacaoEstoqueId());

		estoque.desbloquearMovimentacaoEstoque(cmd.getBloqueioMovimentacaoEstoqueId());

		estoqueRepository.update(estoque);
		bloqueioMovimentacaoEstoqueRepository.delete(cmd.getBloqueioMovimentacaoEstoqueId());

		if (bloqueio.getEnderecoIdDestino().isPresent()) {
			var sku = skuRepository.findByIdOrThrowNotFound(estoque.getSkuId());
			var endereco = atualizarOcupacaoPrevistaEnderecoService.diminuir(bloqueio.getEnderecoIdDestino()
																					 .orElseThrow(),
																			 sku,
																			 bloqueio.getQuantidade());
			endereco.getEvents().forEach(publisher::dispatch);
		}

		estoque.getEvents().forEach(publisher::dispatch);

	}

	public void handle(final AumentarBloqueioMovimentacaoEstoqueCommand cmd) {

		var estoque = estoqueRepository.findWithLockByIdOrThrowNotFound(cmd.getEstoqueId());

		var sku = skuRepository.findByIdOrThrowNotFound(estoque.getSkuId());

		var bloqueioMovimentacaoEstoque = bloqueioMovimentacaoEstoqueRepository.findWithLockByIdOrThrowNotFound(cmd.getBloqueioMovimentacaoEstoqueId());

		estoque.aumentarQuantidadeBloqueioMovimentacao(bloqueioMovimentacaoEstoque, cmd.getQuantidade(), sku);

		bloqueioMovimentacaoEstoqueRepository.update(bloqueioMovimentacaoEstoque);

		estoqueRepository.update(estoque);

		if (bloqueioMovimentacaoEstoque.getEnderecoIdDestino().isPresent()) {
			var endereco = atualizarOcupacaoPrevistaEnderecoService.aumentar(bloqueioMovimentacaoEstoque.getEnderecoIdDestino()
																										.orElseThrow(),
																			 sku,
																			 cmd.getQuantidade());
			endereco.getEvents().forEach(publisher::dispatch);
		}

		estoque.getEvents().forEach(publisher::dispatch);
	}

	public void handle(DesbloquearMovimentacaoUnitizadorEstoqueCommand cmd) {

		var bloqueioMovimentacaoUnitizador = bloqueioMovimentacaoUnitizadorRepository.findWithLockByIdOrThrowNotFound(cmd.getBloqueioMovimentacaoUnitizadorId());

		var estoques = estoqueRepository.findWithLockByBloqueioMovimentacaoUnitizadorId(cmd.getBloqueioMovimentacaoUnitizadorId());

		bloqueioMovimentacaoUnitizador.desbloquearEstoques(estoques);

		Endereco endereco = null;
		if (bloqueioMovimentacaoUnitizador.getEnderecoIdDestino().isPresent())
			endereco = atualizarOcupacaoPrevistaEnderecoService.diminuir(bloqueioMovimentacaoUnitizador.getEnderecoIdDestino()
																									   .orElseThrow(),
																		 estoques);

		estoques.forEach(estoque -> estoqueRepository.update(estoque));

		bloqueioMovimentacaoUnitizadorRepository.delete(bloqueioMovimentacaoUnitizador.getId());

		bloqueioMovimentacaoUnitizador.getEvents().forEach(publisher::dispatch);

		if (endereco != null)
			publisher.dispatch(endereco.getEvents());
	}

	public void handle(AssociarAtributosBloqueioMovimentacaoEstoqueCommand cmd) {

		var estoque = estoqueRepository.findWithLockByIdOrThrowNotFound(cmd.getEstoqueId());

		var produto = produtoRepository.findWithLockByIdOrThrowNotFound(estoque.getProdutoId());

		estoque.associarAtributosBloqueioMovimentacao(cmd.getBloqueioMovimentacaoEstoqueId(),
													  produto,
													  cmd.getAtributosSaldo());

		estoqueRepository.update(estoque);
		estoque.getEvents().forEach(publisher::dispatch);
	}
}
