package com.totvs.sl.wms.estoque.estoque.amqp.cmd;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import com.totvs.sl.wms.estoque.caracteristicaconfiguracao.domain.model.CaracteristicaConfiguracaoId;
import com.totvs.sl.wms.estoque.produto.domain.model.ProdutoId;
import com.totvs.sl.wms.estoque.util.amqp.EstoqueOutput;
import com.totvs.sl.wms.estoque.util.amqp.SubjectConfiguracao;
import com.totvs.sl.wms.estoque.util.amqp.TransactionalCmd;

import lombok.Getter;
import lombok.ToString;

@Getter
@ToString
public final class AdicionarCaracteristicaConfiguracaoEstoqueCmd extends TransactionalCmd
		implements SubjectConfiguracao, EstoqueOutput {

	public static final String NAME = "AdicionarCaracteristicaConfiguracaoEstoqueCmd";

	public static final String CONDITIONAL_EXPRESSION = "headers['type']=='" + NAME + "'";

	@NotNull(message = "{AdicionarCaracteristicaConfiguracaoEstoqueCmd.produtoId.NotNull}")
	private final ProdutoId produtoId;

	@NotNull(message = "{AdicionarCaracteristicaConfiguracaoEstoqueCmd.caracteristicaConfiguracaoId.NotNull}")
	private final CaracteristicaConfiguracaoId caracteristicaConfiguracaoId;

	@NotBlank(message = "{AdicionarCaracteristicaConfiguracaoEstoqueCmd.valorPadrao.NotBlank}")
	private final String valorPadrao;

	private AdicionarCaracteristicaConfiguracaoEstoqueCmd(ProdutoId produtoId,
														  CaracteristicaConfiguracaoId caracteristicaConfiguracaoId,
														  String valorPadrao) {
		super(null, null);
		this.produtoId = produtoId;
		this.caracteristicaConfiguracaoId = caracteristicaConfiguracaoId;
		this.valorPadrao = valorPadrao;
	}

	public static AdicionarCaracteristicaConfiguracaoEstoqueCmd of(ProdutoId produtoId,
																   CaracteristicaConfiguracaoId caracteristicaConfiguracaoId,
																   String valorPadrao) {
		return new AdicionarCaracteristicaConfiguracaoEstoqueCmd(produtoId, caracteristicaConfiguracaoId, valorPadrao);
	}
}
