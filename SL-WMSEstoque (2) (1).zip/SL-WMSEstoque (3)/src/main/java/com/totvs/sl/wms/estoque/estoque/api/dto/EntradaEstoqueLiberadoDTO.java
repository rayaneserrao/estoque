package com.totvs.sl.wms.estoque.estoque.api.dto;

import static com.totvs.sl.wms.estoque.util.Constants.QUANTIDADE_MAXIMA_DECIMAIS;
import static com.totvs.sl.wms.estoque.util.Constants.QUANTIDADE_MAXIMA_INTEIROS;

import java.math.BigDecimal;
import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.Digits;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Positive;

import com.totvs.sl.wms.estoque.atributoestoquevalor.api.dto.AtributoEstoqueValorDTO;
import com.totvs.sl.wms.estoque.caracteristicavalor.api.dto.CaracteristicaValorDTO;
import com.totvs.sl.wms.estoque.endereco.domain.model.EnderecoId;
import com.totvs.sl.wms.estoque.produto.domain.model.ProdutoId;
import com.totvs.sl.wms.estoque.selo.api.dto.SeloEstoqueDTO;
import com.totvs.sl.wms.estoque.sku.domain.model.SKUId;
import com.totvs.sl.wms.estoque.tipoestoque.domain.model.TipoEstoqueId;
import com.totvs.sl.wms.estoque.unidade.domain.model.UnidadeId;
import com.totvs.sl.wms.estoque.unitizador.domain.model.UnitizadorId;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor(access = AccessLevel.PRIVATE, force = true)
public final class EntradaEstoqueLiberadoDTO {

	@Schema(description = "Identificador da unidade")
	@NotNull(message = "{EntradaEstoqueLiberadoDTO.unidadeId.NotNull}")
	private final UnidadeId unidadeId;

	@Schema(description = "Identificador do produto")
	@NotNull(message = "{EntradaEstoqueLiberadoDTO.produtoId.NotNull}")
	private final ProdutoId produtoId;

	@Schema(description = "Identificador do sku")
	@NotNull(message = "{EntradaEstoqueLiberadoDTO.skuId.NotNull}")
	private final SKUId skuId;

	@Schema(description = "Identificador do unitizador")
	private final UnitizadorId unitizadorId;

	@Schema(description = "Identificador do tipo de estoque")
	@NotNull(message = "{EntradaEstoqueLiberadoDTO.tipoEstoqueId.NotNull}")
	private final TipoEstoqueId tipoEstoqueId;

	@Schema(description = "Identificador do endereço")
	@NotNull(message = "{EntradaEstoqueLiberadoDTO.enderecoId.NotNull}")
	private final EnderecoId enderecoId;

	@Schema(description = "Identificador do indicador de avaria do estoque")
	@NotNull(message = "{EntradaEstoqueLiberadoDTO.avariado.NotNull}")
	private final Boolean avariado;

	@Schema(description = "Quantidade de entrada estoque liberado")
	@NotNull(message = "{EntradaEstoqueLiberadoDTO.quantidade.NotNull}")
	@Positive(message = "{EntradaEstoqueLiberadoDTO.quantidade.Positive}")
	@Digits(fraction = QUANTIDADE_MAXIMA_DECIMAIS, integer = QUANTIDADE_MAXIMA_INTEIROS, message = "{EntradaEstoqueLiberadoDTO.quantidade.Digits}")
	private final BigDecimal quantidade;

	@Valid
	@Schema(description = "Informações das características de estoque")
	private final List<CaracteristicaValorDTO> caracteristicas;

	@Valid
	@Schema(description = "Informações dos atributos do estoque")
	private final List<AtributoEstoqueValorDTO> atributos;

	@Valid
	@Schema(description = "Informações dos selos do estoque")
	private final List<SeloEstoqueDTO> selos;
}
