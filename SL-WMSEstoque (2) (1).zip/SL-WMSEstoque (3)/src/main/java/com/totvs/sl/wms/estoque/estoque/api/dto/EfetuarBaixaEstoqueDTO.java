package com.totvs.sl.wms.estoque.estoque.api.dto;

import static com.totvs.sl.wms.estoque.util.Constants.QUANTIDADE_MAXIMA_DECIMAIS;
import static com.totvs.sl.wms.estoque.util.Constants.QUANTIDADE_MAXIMA_INTEIROS;

import java.math.BigDecimal;
import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.Digits;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Positive;

import com.totvs.sl.wms.estoque.atributoestoquevalor.api.dto.AtributoEstoqueValorDTO;
import com.totvs.sl.wms.estoque.estoque.domain.model.EstoqueId;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor(force = true)
@AllArgsConstructor(staticName = "of")
@Schema(description = "Informações para efetuar baixa de estoque")
public final class EfetuarBaixaEstoqueDTO {

	@NotNull(message = "{EfetuarBaixaEstoqueDTO.estoqueId.NotNull}")
	@Schema(description = "Identificador do estoque.")
	private final EstoqueId estoqueId;

	@NotNull(message = "{EfetuarBaixaEstoqueDTO.quantidade.NotNull}")
	@Positive(message = "{EfetuarBaixaEstoqueDTO.quantidade.Positive}")
	@Digits(fraction = QUANTIDADE_MAXIMA_DECIMAIS, integer = QUANTIDADE_MAXIMA_INTEIROS, message = "{EfetuarBaixaEstoqueDTO.quantidade.Digits}")
	@Schema(description = "Quantidade que será feita a baixa.")
	private final BigDecimal quantidade;

	@Valid
	@Schema(description = "Atributos do estoque.")
	private final List<AtributoEstoqueValorDTO> atributos;
}
