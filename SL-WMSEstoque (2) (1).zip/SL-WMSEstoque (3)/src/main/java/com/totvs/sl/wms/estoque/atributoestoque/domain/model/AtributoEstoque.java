package com.totvs.sl.wms.estoque.atributoestoque.domain.model;

import static com.totvs.tjf.autoconfigure.ValidationUtils.validateIntegrity;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.TreeSet;

import javax.persistence.Table;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.totvs.sl.wms.estoque.atributoestoque.domain.event.AtributoEstoqueAlteradoEvent;
import com.totvs.sl.wms.estoque.atributoestoque.domain.event.AtributoEstoqueAtivadoEvent;
import com.totvs.sl.wms.estoque.atributoestoque.domain.event.AtributoEstoqueCriadoEvent;
import com.totvs.sl.wms.estoque.atributoestoque.domain.event.AtributoEstoqueExcluidoEvent;
import com.totvs.sl.wms.estoque.atributoestoque.domain.event.AtributoEstoqueInativadoEvent;
import com.totvs.sl.wms.estoque.atributoestoque.exception.WMSAtributoEstoqueConstraintException;
import com.totvs.sl.wms.estoque.atributoestoque.exception.WMSAtributoEstoqueControleQuantidadeUtilizadoException;
import com.totvs.sl.wms.estoque.atributoestoque.exception.WMSAtributoEstoqueFormatoDataNaoPodeSerControleQuantidadeSerialException;
import com.totvs.sl.wms.estoque.atributoestoque.exception.WMSAtributoEstoqueFormatoUtilizadoException;
import com.totvs.sl.wms.estoque.atributoestoque.exception.WMSAtributoEstoqueNaoPermiteExclusaoException;
import com.totvs.tjf.core.stereotype.Aggregate;
import com.totvs.tjf.repository.aggregate.metadata.AggregateDomainMetadataInfo;

import lombok.AccessLevel;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;

@ToString
@Getter
@Aggregate
@Table(name = "atributo_estoque")
@EqualsAndHashCode(callSuper = true)
@NoArgsConstructor(access = AccessLevel.PROTECTED, force = true)
public class AtributoEstoque extends AggregateDomainMetadataInfo<AtributoEstoqueId> {

	@NotBlank(message = "{AtributoEstoque.descricao.NotBlank}")
	@Size(min = 1, max = 60, message = "{AtributoEstoque.descricao.Size}")
	private String descricao;

	@NotNull(message = "{AtributoEstoque.formato.NotNull}")
	private FormatoAtributoEstoqueValor formato;

	@NotNull(message = "{AtributoEstoque.controleQuantidade.NotNull}")
	private ControleQuantidadeAtributoEstoqueValor controleQuantidade;

	private SituacaoAtributoEstoque situacao;

	private List<SituacaoAtributoEstoque> historicoSituacoes = new ArrayList<>();

	private final TreeSet<String> utilizado = new TreeSet<>();

	@Builder
	public AtributoEstoque(AtributoEstoqueId id,
						   String descricao,
						   FormatoAtributoEstoqueValor formato,
						   ControleQuantidadeAtributoEstoqueValor controleQuantidade) {

		super(id);
		this.descricao = descricao;
		this.formato = formato;
		this.controleQuantidade = controleQuantidade;
		this.situacao = SituacaoAtributoEstoque.ofAtivo();

		validateIntegrity(this).ifPresent(violations -> {
			throw new WMSAtributoEstoqueConstraintException(violations);
		});

		if (this.formato.equals(FormatoAtributoEstoqueValor.DATA)
				&& this.controleQuantidade.equals(ControleQuantidadeAtributoEstoqueValor.SERIAL))
			throw new WMSAtributoEstoqueFormatoDataNaoPodeSerControleQuantidadeSerialException();

		this.registerEvent(AtributoEstoqueCriadoEvent.from(this));

	}

	public void marcarUtilizado(String funcionalidade) {
		this.utilizado.add(funcionalidade);
	}

	public void desmarcarUtilizado(String funcionalidade) {
		this.utilizado.remove(funcionalidade);
	}

	public void alterar(String descricao,
						FormatoAtributoEstoqueValor formato,
						ControleQuantidadeAtributoEstoqueValor controleQuantidade) {

		if (Objects.nonNull(formato) && !formato.equals(this.formato) && !this.utilizado.isEmpty())
			throw new WMSAtributoEstoqueFormatoUtilizadoException(this.utilizado);

		if (Objects.nonNull(controleQuantidade) && !controleQuantidade.equals(this.controleQuantidade)
				&& !this.utilizado.isEmpty())
			throw new WMSAtributoEstoqueControleQuantidadeUtilizadoException(this.utilizado);

		this.descricao = descricao;
		this.controleQuantidade = controleQuantidade;
		this.formato = formato;

		validateIntegrity(this).ifPresent(violations -> {
			throw new WMSAtributoEstoqueConstraintException(violations);
		});

		if (this.formato.equals(FormatoAtributoEstoqueValor.DATA)
				&& this.controleQuantidade.equals(ControleQuantidadeAtributoEstoqueValor.SERIAL))
			throw new WMSAtributoEstoqueFormatoDataNaoPodeSerControleQuantidadeSerialException();

		this.registerEvent(AtributoEstoqueAlteradoEvent.from(this));

	}

	public boolean ativar() {

		if (this.situacao.isAtivo())
			return false;

		this.historicoSituacoes.add(this.situacao);
		this.situacao = SituacaoAtributoEstoque.ofAtivo();
		this.registerEvent(AtributoEstoqueAtivadoEvent.from(this));

		return true;

	}

	public boolean inativar() {

		if (this.situacao.isInativo())
			return false;

		this.historicoSituacoes.add(this.situacao);
		this.situacao = SituacaoAtributoEstoque.ofInativo();
		this.registerEvent(AtributoEstoqueInativadoEvent.from(this));

		return true;

	}

	public void excluir() {

		if (!this.utilizado.isEmpty())
			throw new WMSAtributoEstoqueNaoPermiteExclusaoException(this.utilizado);

		this.registerEvent(AtributoEstoqueExcluidoEvent.from(this));

	}

	public String getValorPadrao() {
		switch (this.formato) {
		case DATA:
			return AtributoEstoqueValorPadrao.ATRIBUTO_DATA.getValor();
		case NUMERO:
			return AtributoEstoqueValorPadrao.ATRIBUTO_NUMERO.getValor();
		default:
			return AtributoEstoqueValorPadrao.ATRIBUTO_TEXTO.getValor();
		}
	}

}
