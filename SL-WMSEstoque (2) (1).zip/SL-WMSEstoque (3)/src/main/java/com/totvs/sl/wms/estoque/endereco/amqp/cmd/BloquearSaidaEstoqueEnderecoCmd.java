package com.totvs.sl.wms.estoque.endereco.amqp.cmd;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import com.totvs.sl.wms.estoque.endereco.domain.model.EnderecoId;

import lombok.Data;

@Data(staticConstructor = "of")
public final class BloquearSaidaEstoqueEnderecoCmd {

	public static final String NAME = "BloquearSaidaEstoqueEnderecoCmd";

	public static final String CONDITIONAL_EXPRESSION = "headers['type']=='" + NAME + "'";

	@NotNull(message = "{BloquearSaidaEstoqueEnderecoCmd.id.NotNull}")
	private final EnderecoId id;

	@NotBlank(message = "{BloquearSaidaEstoqueEnderecoCmd.chaveAcesso.NotBlank}")
	private final String chaveAcesso;
}
