package com.totvs.sl.wms.estoque.atributoestoque.domain.model;

public enum ControleQuantidadeAtributoEstoqueValor {
	SERIAL, VARIAVEL;

	public boolean isSerial() {
		return this.equals(SERIAL);
	}

	public boolean isVariavel() {
		return this.equals(VARIAVEL);
	}
}
