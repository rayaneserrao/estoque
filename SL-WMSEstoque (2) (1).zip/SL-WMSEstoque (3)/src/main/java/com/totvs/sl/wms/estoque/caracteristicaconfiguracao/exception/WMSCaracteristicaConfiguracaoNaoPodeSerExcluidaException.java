package com.totvs.sl.wms.estoque.caracteristicaconfiguracao.exception;

import java.util.TreeSet;

import com.totvs.tjf.api.context.stereotype.ApiErrorParameter;
import com.totvs.tjf.api.context.stereotype.error.ApiBadRequest;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
@ApiBadRequest
public class WMSCaracteristicaConfiguracaoNaoPodeSerExcluidaException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	@ApiErrorParameter
	private final TreeSet<String> utilizado;

}
