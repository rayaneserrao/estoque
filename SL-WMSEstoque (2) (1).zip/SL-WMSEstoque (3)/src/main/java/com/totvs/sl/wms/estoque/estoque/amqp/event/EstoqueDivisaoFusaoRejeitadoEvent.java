package com.totvs.sl.wms.estoque.estoque.amqp.event;

import com.totvs.sl.wms.estoque.endereco.domain.model.EnderecoId;
import com.totvs.sl.wms.estoque.estoque.domain.model.EstoqueId;
import com.totvs.sl.wms.estoque.unitizador.domain.model.UnitizadorId;
import com.totvs.sl.wms.estoque.util.amqp.RejectedEvent;
import com.totvs.sl.wms.estoque.util.amqp.SubjectConfiguracao;
import com.totvs.tjf.api.context.response.ApiErrorResponse;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data(staticConstructor = "of")
@EqualsAndHashCode(callSuper = false)
public final class EstoqueDivisaoFusaoRejeitadoEvent extends RejectedEvent implements SubjectConfiguracao {

	public static final String NAME = "EstoqueDivisaoFusaoRejeitadoEvent";

	public static final String CONDITIONAL_EXPRESSION = "headers['type']=='" + NAME + "'";

	private final EstoqueId estoqueId;
	private final UnitizadorId unitizadorIdDestino;
	private final EnderecoId enderecoIdDestino;
	private final ApiErrorResponse inconsistencia;
}
