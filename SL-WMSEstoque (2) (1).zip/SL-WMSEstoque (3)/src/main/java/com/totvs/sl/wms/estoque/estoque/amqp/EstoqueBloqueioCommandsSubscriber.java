package com.totvs.sl.wms.estoque.estoque.amqp;

import java.util.ArrayList;
import java.util.Optional;

import org.springframework.cloud.stream.annotation.EnableBinding;
import org.springframework.cloud.stream.annotation.StreamListener;

import com.totvs.sl.wms.estoque.config.amqp.WMSChannel;
import com.totvs.sl.wms.estoque.config.amqp.WMSPublisher;
import com.totvs.sl.wms.estoque.estoque.amqp.cmd.AssociarAtributosBloqueioMovimentacaoEstoqueCmd;
import com.totvs.sl.wms.estoque.estoque.amqp.cmd.AumentarBloqueioMovimentacaoEstoqueCmd;
import com.totvs.sl.wms.estoque.estoque.amqp.cmd.BloquearEstoqueCmd;
import com.totvs.sl.wms.estoque.estoque.amqp.cmd.BloquearMovimentacaoEstoqueCmd;
import com.totvs.sl.wms.estoque.estoque.amqp.cmd.BloquearMovimentacaoEstoqueReservaCmd;
import com.totvs.sl.wms.estoque.estoque.amqp.cmd.BloquearMovimentacaoUnitizadorEstoqueCmd;
import com.totvs.sl.wms.estoque.estoque.amqp.cmd.DesbloquearEstoqueCmd;
import com.totvs.sl.wms.estoque.estoque.amqp.cmd.DesbloquearEstoquesUnitizadorCmd;
import com.totvs.sl.wms.estoque.estoque.amqp.cmd.DesbloquearMovimentacaoEstoqueCmd;
import com.totvs.sl.wms.estoque.estoque.amqp.cmd.DesbloquearMovimentacaoUnitizadorEstoqueCmd;
import com.totvs.sl.wms.estoque.estoque.amqp.event.EstoqueAumentoBloqueioMovimentacaoRejeitadoEvent;
import com.totvs.sl.wms.estoque.estoque.amqp.event.EstoqueBloqueioMovimentacaoAssociacaoAtributosRejeitadaEvent;
import com.totvs.sl.wms.estoque.estoque.amqp.event.EstoqueBloqueioMovimentacaoRejeitadoEvent;
import com.totvs.sl.wms.estoque.estoque.amqp.event.EstoqueBloqueioMovimentacaoReservaRejeitadoEvent;
import com.totvs.sl.wms.estoque.estoque.amqp.event.EstoqueBloqueioMovimentacaoUnitizadorRejeitadoEvent;
import com.totvs.sl.wms.estoque.estoque.amqp.event.EstoqueBloqueioRejeitadoEvent;
import com.totvs.sl.wms.estoque.estoque.amqp.event.EstoqueDesbloqueioMovimentacaoRejeitadoEvent;
import com.totvs.sl.wms.estoque.estoque.amqp.event.EstoqueDesbloqueioRejeitadoEvent;
import com.totvs.sl.wms.estoque.estoque.application.EstoqueBloquearDesbloquearApplicationService;
import com.totvs.sl.wms.estoque.estoque.application.EstoqueBloquearDesbloquearMovimentacaoApplicationService;
import com.totvs.sl.wms.estoque.estoque.application.command.AssociarAtributosBloqueioMovimentacaoEstoqueCommand;
import com.totvs.sl.wms.estoque.estoque.application.command.AumentarBloqueioMovimentacaoEstoqueCommand;
import com.totvs.sl.wms.estoque.estoque.application.command.BloquearEstoqueCommand;
import com.totvs.sl.wms.estoque.estoque.application.command.BloquearMovimentacaoEstoqueCommand;
import com.totvs.sl.wms.estoque.estoque.application.command.BloquearMovimentacaoEstoqueReservaCommand;
import com.totvs.sl.wms.estoque.estoque.application.command.BloquearMovimentacaoUnitizadorEstoqueCommand;
import com.totvs.sl.wms.estoque.estoque.application.command.DesbloquearEstoqueCommand;
import com.totvs.sl.wms.estoque.estoque.application.command.DesbloquearEstoquesUnitizadorCommand;
import com.totvs.sl.wms.estoque.estoque.application.command.DesbloquearMovimentacaoEstoqueCommand;
import com.totvs.sl.wms.estoque.estoque.application.command.DesbloquearMovimentacaoUnitizadorEstoqueCommand;
import com.totvs.sl.wms.estoque.estoque.exception.WMSAssociarAtributosBloqueioMovimentacaoEstoqueConstraintException;
import com.totvs.sl.wms.estoque.estoque.exception.WMSAumentarBloqueioMovimentacaoEstoqueConstraintException;
import com.totvs.sl.wms.estoque.estoque.exception.WMSBloquearEstoqueConstraintException;
import com.totvs.sl.wms.estoque.estoque.exception.WMSBloquearMovimentacaoEstoqueReservaConstraintException;
import com.totvs.sl.wms.estoque.estoque.exception.WMSBloquearMovimentacaoEstoqueUnitizadorConstraintException;
import com.totvs.sl.wms.estoque.estoque.exception.WMSDesbloquearEstoqueConstraintException;
import com.totvs.sl.wms.estoque.estoque.exception.WMSDesbloquearEstoqueUnitizadorConstraintException;
import com.totvs.sl.wms.estoque.estoque.exception.WMSDesbloquearMovimentacaoEstoqueConstraintException;
import com.totvs.sl.wms.estoque.estoque.exception.WMSEstoqueBloquearMovimentacaoEstoqueConstrainException;
import com.totvs.sl.wms.estoque.estoque.exception.WMSEstoqueDesbloquearMovimentacaoEstoqueConstrainException;
import com.totvs.sl.wms.estoque.estoque.exception.WMSExisteEstoqueComMesmoHashException;
import com.totvs.sl.wms.estoque.origem.domain.model.Origem;
import com.totvs.sl.wms.estoque.origem.domain.model.OrigemId;
import com.totvs.sl.wms.estoque.util.amqp.AMQPUtil;
import com.totvs.tjf.api.response.error.converter.ErrorExceptionConverter;
import com.totvs.tjf.core.i18n.I18nService;
import com.totvs.tjf.core.validation.ValidatorService;
import com.totvs.tjf.messaging.context.TOTVSMessage;

import lombok.AllArgsConstructor;

@AllArgsConstructor
@EnableBinding({ WMSChannel.WMSBloqueioEstoqueCommandsInput.class,
		WMSChannel.WMSBloqueioEstoqueLoteCommandsInput.class })
public class EstoqueBloqueioCommandsSubscriber {

	private EstoqueBloquearDesbloquearApplicationService bloquearDesbloquearService;
	private EstoqueBloquearDesbloquearMovimentacaoApplicationService bloquearDesbloquearMovimentacaoService;
	private ValidatorService validator;
	private WMSPublisher wmsPublisher;
	private I18nService i18nService;

	@StreamListener(target = WMSChannel.WMS_BLOQUEIO_ESTOQUE_COMMANDS_IN, condition = BloquearMovimentacaoEstoqueReservaCmd.CONDITIONAL_EXPRESSION)
	public void bloquearEstoqueMovimentacaoReserva(final TOTVSMessage<BloquearMovimentacaoEstoqueReservaCmd> message) {

		AMQPUtil.gerarLog(this.getClass(), message, BloquearMovimentacaoEstoqueReservaCmd.CONDITIONAL_EXPRESSION);

		var cmd = message.getContent();

		validator.validate(cmd).ifPresent(violations -> {
			throw new WMSBloquearMovimentacaoEstoqueReservaConstraintException(violations);
		});

		var transactionInfo = message.getHeader().getTransactionInfo();

		var origem = Origem.of(OrigemId.from(transactionInfo.getTransactionId()), transactionInfo.getGeneratedBy());

		var command = BloquearMovimentacaoEstoqueReservaCommand.builder()
															   .reservaDefinitivaEstoqueId(cmd.getReservaDefinitivaEstoqueId())
															   .origem(origem)
															   .atributosSaldo(cmd.getAtributosSaldo())
															   .build();

		try {
			bloquearDesbloquearMovimentacaoService.handle(command);
		} catch (RuntimeException excecao) {
			rejeitarBloquearMovimentacaoEstoqueReservaCmd(cmd, excecao);
		}
	}

	private void rejeitarBloquearMovimentacaoEstoqueReservaCmd(BloquearMovimentacaoEstoqueReservaCmd cmd,
															   RuntimeException excecao) {

		var id = excecao.getClass().getSimpleName();

		if (!id.startsWith("WMS"))
			throw excecao;

		var erroConverter = new ErrorExceptionConverter(i18nService);
		var erro = erroConverter.convert(excecao).getError();

		var eventoRejeicao = EstoqueBloqueioMovimentacaoReservaRejeitadoEvent.of(cmd.getReservaDefinitivaEstoqueId(),
																				 erro);

		wmsPublisher.dispatch(eventoRejeicao);
	}

	@StreamListener(target = WMSChannel.WMS_BLOQUEIO_ESTOQUE_COMMANDS_IN, condition = BloquearMovimentacaoUnitizadorEstoqueCmd.CONDITIONAL_EXPRESSION)
	public void bloquearMovimentacaoUnitizadorEstoque(final TOTVSMessage<BloquearMovimentacaoUnitizadorEstoqueCmd> message) {

		AMQPUtil.gerarLog(this.getClass(), message, BloquearMovimentacaoUnitizadorEstoqueCmd.CONDITIONAL_EXPRESSION);

		var cmd = message.getContent();

		validator.validate(cmd).ifPresent(violations -> {
			throw new WMSBloquearMovimentacaoEstoqueUnitizadorConstraintException(violations);
		});

		var transactionInfo = message.getHeader().getTransactionInfo();

		var origem = Origem.of(OrigemId.from(transactionInfo.getTransactionId()), transactionInfo.getGeneratedBy());

		var command = BloquearMovimentacaoUnitizadorEstoqueCommand.builder()
																  .unidadeId(cmd.getUnidadeId())
																  .origem(origem)
																  .unitizadorId(cmd.getUnitizadorId())
																  .enderecoIdOrigem(cmd.getEnderecoIdOrigem())
																  .enderecoIdDestino(cmd.getEnderecoIdDestino())
																  .chaveAcesso(cmd.getChaveAcesso())
																  .build();
		try {
			bloquearDesbloquearMovimentacaoService.handle(command);
		} catch (RuntimeException excecao) {
			rejeitarBloquearMovimentacaoUnitizadorEstoqueCmd(cmd, excecao);
		}

	}

	private void rejeitarBloquearMovimentacaoUnitizadorEstoqueCmd(BloquearMovimentacaoUnitizadorEstoqueCmd cmd,
																  RuntimeException excecao) {

		var id = excecao.getClass().getSimpleName();

		if (!id.startsWith("WMS"))
			throw excecao;

		var erroConverter = new ErrorExceptionConverter(i18nService);
		var erro = erroConverter.convert(excecao).getError();

		var inconsistencias = new ArrayList<EstoqueBloqueioMovimentacaoUnitizadorRejeitadoEvent.Inconsistencia>();

		inconsistencias.add(EstoqueBloqueioMovimentacaoUnitizadorRejeitadoEvent.Inconsistencia.of(id,
																								  erro.getMessage(),
																								  erro.getDetailedMessage()));

		var eventoRejeicao = EstoqueBloqueioMovimentacaoUnitizadorRejeitadoEvent.of(cmd.getUnidadeId(),
																					inconsistencias);
		wmsPublisher.dispatch(eventoRejeicao);

	}

	@StreamListener(target = WMSChannel.WMS_BLOQUEIO_ESTOQUE_COMMANDS_IN, condition = BloquearMovimentacaoEstoqueCmd.CONDITIONAL_EXPRESSION)
	public void bloquearMovimentacaoEstoque(final TOTVSMessage<BloquearMovimentacaoEstoqueCmd> message) {

		AMQPUtil.gerarLog(this.getClass(), message, BloquearMovimentacaoEstoqueCmd.CONDITIONAL_EXPRESSION);

		var cmd = message.getContent();

		validator.validate(cmd).ifPresent(violations -> {
			throw new WMSEstoqueBloquearMovimentacaoEstoqueConstrainException(violations);
		});

		var transactionInfo = message.getHeader().getTransactionInfo();

		var origem = Origem.of(OrigemId.from(transactionInfo.getTransactionId()), transactionInfo.getGeneratedBy());

		var command = BloquearMovimentacaoEstoqueCommand.builder()
														.enderecoIdDestino(cmd.getEnderecoIdDestino())
														.estoqueId(cmd.getEstoqueId())
														.origem(origem)
														.quantidade(cmd.getQuantidade())
														.unitizadorIdDestino(cmd.getUnitizadorIdDestino())
														.atributosSaldo(cmd.getAtributosSaldo())
														.build();

		try {
			bloquearDesbloquearMovimentacaoService.handle(command);
		} catch (RuntimeException excecao) {
			rejeitarBloquearMovimentacaoEstoqueCmd(cmd, excecao);
		}
	}

	private void rejeitarBloquearMovimentacaoEstoqueCmd(BloquearMovimentacaoEstoqueCmd cmd, RuntimeException excecao) {

		var id = excecao.getClass().getSimpleName();

		if (!id.startsWith("WMS"))
			throw excecao;

		var erroConverter = new ErrorExceptionConverter(i18nService);
		var erro = erroConverter.convert(excecao).getError();

		var eventoRejeicao = EstoqueBloqueioMovimentacaoRejeitadoEvent.of(cmd.getEstoqueId(), erro);

		wmsPublisher.dispatch(eventoRejeicao);

	}

	@StreamListener(target = WMSChannel.WMS_BLOQUEIO_ESTOQUE_COMMANDS_IN, condition = DesbloquearMovimentacaoEstoqueCmd.CONDITIONAL_EXPRESSION)
	public void desbloquearMovimentacaoEstoque(final TOTVSMessage<DesbloquearMovimentacaoEstoqueCmd> message) {

		AMQPUtil.gerarLog(this.getClass(), message, DesbloquearMovimentacaoEstoqueCmd.CONDITIONAL_EXPRESSION);

		var cmd = message.getContent();

		validator.validate(cmd).ifPresent(violations -> {
			throw new WMSDesbloquearMovimentacaoEstoqueConstraintException(violations);
		});

		var command = DesbloquearMovimentacaoEstoqueCommand.of(cmd.getEstoqueId(),
															   cmd.getBloqueioMovimentacaoEstoqueId());
		try {
			bloquearDesbloquearMovimentacaoService.handle(command);
		} catch (RuntimeException excecao) {
			rejeitarDesbloquearMovimentacaoEstoqueCmd(cmd, excecao);
		}

	}

	private void rejeitarDesbloquearMovimentacaoEstoqueCmd(DesbloquearMovimentacaoEstoqueCmd cmd,
														   RuntimeException excecao) {

		var id = excecao.getClass().getSimpleName();

		if (!id.startsWith("WMS"))
			throw excecao;

		var erroConverter = new ErrorExceptionConverter(i18nService);
		var erro = erroConverter.convert(excecao).getError();

		var eventoRejeicao = EstoqueDesbloqueioMovimentacaoRejeitadoEvent.of(cmd.getEstoqueId(),
																			 cmd.getBloqueioMovimentacaoEstoqueId(),
																			 erro);
		wmsPublisher.dispatch(eventoRejeicao);

	}

	@StreamListener(target = WMSChannel.WMS_BLOQUEIO_ESTOQUE_COMMANDS_IN, condition = DesbloquearMovimentacaoUnitizadorEstoqueCmd.CONDITIONAL_EXPRESSION)
	public void desbloquearMovimentacaoUnitizadorEstoque(TOTVSMessage<DesbloquearMovimentacaoUnitizadorEstoqueCmd> message) {

		AMQPUtil.gerarLog(this.getClass(), message, DesbloquearMovimentacaoUnitizadorEstoqueCmd.CONDITIONAL_EXPRESSION);

		var cmd = message.getContent();

		validator.validate(cmd).ifPresent(violations -> {
			throw new WMSEstoqueDesbloquearMovimentacaoEstoqueConstrainException(violations);
		});

		var command = DesbloquearMovimentacaoUnitizadorEstoqueCommand.of(cmd.getBloqueioMovimentacaoUnitizadorId());

		bloquearDesbloquearMovimentacaoService.handle(command);
	}

	@StreamListener(target = WMSChannel.WMS_BLOQUEIO_ESTOQUE_COMMANDS_IN, condition = AumentarBloqueioMovimentacaoEstoqueCmd.CONDITIONAL_EXPRESSION)
	public void aumentarBloqueioMovimentacaoEstoque(final TOTVSMessage<AumentarBloqueioMovimentacaoEstoqueCmd> message) {

		AMQPUtil.gerarLog(this.getClass(), message, AumentarBloqueioMovimentacaoEstoqueCmd.CONDITIONAL_EXPRESSION);

		var cmd = message.getContent();

		validator.validate(cmd).ifPresent(violations -> {
			throw new WMSAumentarBloqueioMovimentacaoEstoqueConstraintException(violations);
		});

		var command = AumentarBloqueioMovimentacaoEstoqueCommand.of(cmd.getEstoqueId(),
																	cmd.getBloqueioMovimentacaoEstoqueId(),
																	cmd.getQuantidade());

		try {
			bloquearDesbloquearMovimentacaoService.handle(command);
		} catch (RuntimeException e) {
			rejeitarAumentoBloqueioMovimentacaoEstoqueCmd(cmd, e);
		}

	}

	private void rejeitarAumentoBloqueioMovimentacaoEstoqueCmd(AumentarBloqueioMovimentacaoEstoqueCmd cmd,
															   RuntimeException excecao) {

		var id = excecao.getClass().getSimpleName();

		if (!id.startsWith("WMS"))
			throw excecao;

		var erroConverter = new ErrorExceptionConverter(i18nService);
		var erro = erroConverter.convert(excecao).getError();

		var inconsistencias = new ArrayList<EstoqueAumentoBloqueioMovimentacaoRejeitadoEvent.Inconsistencia>();

		inconsistencias.add(EstoqueAumentoBloqueioMovimentacaoRejeitadoEvent.Inconsistencia.of(id,
																							   erro.getMessage(),
																							   erro.getDetailedMessage()));

		var eventoRejeicao = EstoqueAumentoBloqueioMovimentacaoRejeitadoEvent.of(cmd.getEstoqueId(),
																				 cmd.getBloqueioMovimentacaoEstoqueId(),
																				 inconsistencias);
		wmsPublisher.dispatch(eventoRejeicao);

	}

	@StreamListener(target = WMSChannel.WMS_BLOQUEIO_ESTOQUE_LOTE_COMMANDS_IN, condition = BloquearEstoqueCmd.CONDITIONAL_EXPRESSION)
	public void efetuarBloqueioEstoqueLote(final TOTVSMessage<BloquearEstoqueCmd> message) {

		AMQPUtil.gerarLog(this.getClass(), message, BloquearEstoqueCmd.CONDITIONAL_EXPRESSION);

		processarBloquearEstoqueCmd(message);
	}

	@StreamListener(target = WMSChannel.WMS_BLOQUEIO_ESTOQUE_COMMANDS_IN, condition = BloquearEstoqueCmd.CONDITIONAL_EXPRESSION)
	public void efetuarBloqueioEstoque(final TOTVSMessage<BloquearEstoqueCmd> message) {

		AMQPUtil.gerarLog(this.getClass(), message, BloquearEstoqueCmd.CONDITIONAL_EXPRESSION);

		processarBloquearEstoqueCmd(message);
	}

	private void processarBloquearEstoqueCmd(final TOTVSMessage<BloquearEstoqueCmd> message) {
		var cmd = message.getContent();

		validator.validate(cmd).ifPresent(violations -> {
			throw new WMSBloquearEstoqueConstraintException(violations);
		});

		var transactionInfo = message.getHeader().getTransactionInfo();

		var origem = Origem.of(OrigemId.from(transactionInfo.getTransactionId()), transactionInfo.getGeneratedBy());

		var command = BloquearEstoqueCommand.builder()
											.unidadeId(cmd.getUnidadeId())
											.origem(origem)
											.estoqueId(cmd.getEstoqueId())
											.quantidade(cmd.getQuantidade())
											.chaveAcesso(cmd.getChaveAcesso())
											.motivo(cmd.getMotivo())
											.atributos(cmd.getAtributos())
											.build();

		try {
			bloquearDesbloquearService.handle(command);
		} catch (WMSExisteEstoqueComMesmoHashException excecao) {
			throw excecao;
		} catch (RuntimeException excecao) {
			rejeitarBloqueioEstoqueCmd(cmd, excecao, origem);
		}
	}

	private void rejeitarBloqueioEstoqueCmd(BloquearEstoqueCmd cmd, RuntimeException excecao, Origem origem) {

		var inconsistencias = new ArrayList<EstoqueBloqueioRejeitadoEvent.Inconsistencia>();

		var id = excecao.getClass().getSimpleName();
		var mensagem = "";
		var detalhe = "";

		if (!id.startsWith("WMS"))
			throw excecao;

		var erroConverter = new ErrorExceptionConverter(i18nService);
		var erro = erroConverter.convert(excecao).getError();

		mensagem = erro.getMessage();
		detalhe = erro.getDetailedMessage();
		inconsistencias.add(EstoqueBloqueioRejeitadoEvent.Inconsistencia.of(id, mensagem, detalhe));

		var eventoRejeicao = new EstoqueBloqueioRejeitadoEvent();
		eventoRejeicao.setUnidadeId(cmd.getUnidadeId());
		eventoRejeicao.setInconsistencias(inconsistencias);
		eventoRejeicao.setOrigem(origem);
		wmsPublisher.dispatch(eventoRejeicao);
	}

	@StreamListener(target = WMSChannel.WMS_BLOQUEIO_ESTOQUE_LOTE_COMMANDS_IN, condition = DesbloquearEstoqueCmd.CONDITIONAL_EXPRESSION)
	public void efetuarDesbloqueioEstoqueLote(final TOTVSMessage<DesbloquearEstoqueCmd> message) {

		AMQPUtil.gerarLog(this.getClass(), message, DesbloquearEstoqueCmd.CONDITIONAL_EXPRESSION);

		processarDesbloquearEstoqueCmd(message);
	}

	@StreamListener(target = WMSChannel.WMS_BLOQUEIO_ESTOQUE_COMMANDS_IN, condition = DesbloquearEstoqueCmd.CONDITIONAL_EXPRESSION)
	public void efetuarDesbloqueioEstoque(final TOTVSMessage<DesbloquearEstoqueCmd> message) {

		AMQPUtil.gerarLog(this.getClass(), message, DesbloquearEstoqueCmd.CONDITIONAL_EXPRESSION);

		processarDesbloquearEstoqueCmd(message);
	}

	@StreamListener(target = WMSChannel.WMS_BLOQUEIO_ESTOQUE_COMMANDS_IN, condition = DesbloquearEstoquesUnitizadorCmd.CONDITIONAL_EXPRESSION)
	public void desbloquearEstoquesUnitizadorCmd(TOTVSMessage<DesbloquearEstoquesUnitizadorCmd> message) {

		AMQPUtil.gerarLog(this.getClass(), message, DesbloquearEstoquesUnitizadorCmd.CONDITIONAL_EXPRESSION);

		var cmd = message.getContent();

		validator.validate(cmd).ifPresent(violations -> {
			throw new WMSDesbloquearEstoqueUnitizadorConstraintException(violations);
		});

		var transactionInfo = message.getHeader().getTransactionInfo();

		var origem = Origem.of(OrigemId.from(transactionInfo.getTransactionId()), transactionInfo.getGeneratedBy());

		var command = DesbloquearEstoquesUnitizadorCommand.of(cmd.getUnitizadorId(),
															  cmd.getUnidadeId(),
															  cmd.getChaveAcesso(),
															  origem,
															  Optional.ofNullable(cmd.getBloqueioMovimentacaoUnitizadorId()));

		bloquearDesbloquearService.handle(command);
	}

	private void processarDesbloquearEstoqueCmd(final TOTVSMessage<DesbloquearEstoqueCmd> message) {

		var cmd = message.getContent();

		validator.validate(cmd).ifPresent(violations -> {
			throw new WMSDesbloquearEstoqueConstraintException(violations);
		});

		var transactionInfo = message.getHeader().getTransactionInfo();

		var origem = Origem.of(OrigemId.from(transactionInfo.getTransactionId()), transactionInfo.getGeneratedBy());

		try {

			var command = DesbloquearEstoqueCommand.builder()
												   .unidadeId(cmd.getUnidadeId())
												   .origem(origem)
												   .estoqueId(cmd.getEstoqueId())
												   .quantidade(cmd.getQuantidade())
												   .chaveAcesso(cmd.getChaveAcesso())
												   .bloqueioMovimentacaoUnitizadorId(cmd.getBloqueioMovimentacaoUnitizadorId())
												   .atributos(cmd.getAtributos())
												   .build();

			bloquearDesbloquearService.handle(command);

		} catch (WMSExisteEstoqueComMesmoHashException excecao) {
			throw excecao;
		} catch (RuntimeException excecao) {
			rejeitarDesbloqueioEstoqueCmd(cmd, excecao, origem);
		}
	}

	private void rejeitarDesbloqueioEstoqueCmd(DesbloquearEstoqueCmd cmd, RuntimeException excecao, Origem origem) {

		var inconsistencias = new ArrayList<EstoqueDesbloqueioRejeitadoEvent.Inconsistencia>();

		var id = excecao.getClass().getSimpleName();
		var mensagem = "";
		var detalhe = "";

		if (!id.startsWith("WMS"))
			throw excecao;

		var erroConverter = new ErrorExceptionConverter(i18nService);
		var erro = erroConverter.convert(excecao).getError();

		mensagem = erro.getMessage();
		detalhe = erro.getDetailedMessage();
		inconsistencias.add(EstoqueDesbloqueioRejeitadoEvent.Inconsistencia.of(id, mensagem, detalhe));

		var eventoRejeicao = new EstoqueDesbloqueioRejeitadoEvent();
		eventoRejeicao.setUnidadeId(cmd.getUnidadeId());
		eventoRejeicao.setInconsistencias(inconsistencias);
		eventoRejeicao.setOrigem(origem);
		eventoRejeicao.setInconsistencia(erro);
		wmsPublisher.dispatch(eventoRejeicao);
	}

	@StreamListener(target = WMSChannel.WMS_BLOQUEIO_ESTOQUE_COMMANDS_IN, condition = AssociarAtributosBloqueioMovimentacaoEstoqueCmd.CONDITIONAL_EXPRESSION)
	public void associarAtributosBloqueioMovimentacaoEstoque(TOTVSMessage<AssociarAtributosBloqueioMovimentacaoEstoqueCmd> message) {

		AMQPUtil.gerarLog(this.getClass(),
						  message,
						  AssociarAtributosBloqueioMovimentacaoEstoqueCmd.CONDITIONAL_EXPRESSION);

		var cmd = message.getContent();

		validator.validate(cmd).ifPresent(violations -> {
			throw new WMSAssociarAtributosBloqueioMovimentacaoEstoqueConstraintException(violations);
		});

		var command = AssociarAtributosBloqueioMovimentacaoEstoqueCommand.of(cmd.getEstoqueId(),
																			 cmd.getBloqueioMovimentacaoEstoqueId(),
																			 cmd.getAtributosSaldo());

		try {
			bloquearDesbloquearMovimentacaoService.handle(command);
		} catch (RuntimeException excecao) {
			rejeitarAssociarAtributosBloqueioMovimentacaoEstoqueCmd(cmd, excecao);
		}
	}

	private void rejeitarAssociarAtributosBloqueioMovimentacaoEstoqueCmd(AssociarAtributosBloqueioMovimentacaoEstoqueCmd cmd,
																		 RuntimeException excecao) {

		var id = excecao.getClass().getSimpleName();

		if (!id.startsWith("WMS")) {
			throw excecao;
		}

		var erroConverter = new ErrorExceptionConverter(i18nService);
		var erro = erroConverter.convert(excecao).getError();

		var eventoRejeicao = EstoqueBloqueioMovimentacaoAssociacaoAtributosRejeitadaEvent.of(cmd.getEstoqueId(),
																							 cmd.getBloqueioMovimentacaoEstoqueId(),
																							 erro);

		wmsPublisher.dispatch(eventoRejeicao);
	}

}
