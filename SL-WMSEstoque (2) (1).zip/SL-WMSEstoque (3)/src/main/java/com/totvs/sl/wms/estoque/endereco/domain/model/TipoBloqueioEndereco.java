package com.totvs.sl.wms.estoque.endereco.domain.model;

public enum TipoBloqueioEndereco {
	ENTRADA, SAIDA, ENTRADA_SAIDA
}
