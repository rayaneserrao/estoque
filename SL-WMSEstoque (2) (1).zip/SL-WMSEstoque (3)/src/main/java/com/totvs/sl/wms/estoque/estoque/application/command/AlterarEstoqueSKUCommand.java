package com.totvs.sl.wms.estoque.estoque.application.command;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

import com.totvs.sl.wms.estoque.atributoestoquevalor.domain.model.AtributoEstoqueValor;
import com.totvs.sl.wms.estoque.estoque.domain.model.Estoque;
import com.totvs.sl.wms.estoque.estoque.domain.model.EstoqueId;
import com.totvs.sl.wms.estoque.estoque.domain.model.EstoqueReservaDefinitiva;
import com.totvs.sl.wms.estoque.estoque.exception.WMSSomaQuantidadeReservasNaoDeveSerMaiorQueQuantidadeAlteracaoSKUException;
import com.totvs.sl.wms.estoque.reservadefinitivaestoque.domain.model.ReservaDefinitivaEstoqueId;
import com.totvs.sl.wms.estoque.sku.domain.model.SKU;
import com.totvs.sl.wms.estoque.sku.domain.model.SKUId;
import com.totvs.tjf.core.common.CollectionUtils;

import lombok.Builder;
import lombok.Data;

@Data
public final class AlterarEstoqueSKUCommand {
	private final EstoqueId id;
	private final SKUId skuId;
	private final boolean aceitarParcialConvertendoSaldoDisponivel;
	private final Optional<Integer> quantidadeSKU;
	private final List<ReservaDefinitivaEstoqueId> reservasDefinitivasId;
	private final List<AtributoEstoqueValor<?>> atributos;
	private final boolean manterAtributosReserva;

	@Builder
	public AlterarEstoqueSKUCommand(EstoqueId id,
									SKUId skuId,
									boolean aceitarParcialConvertendoSaldoDisponivel,
									Integer quantidadeSKU,
									List<ReservaDefinitivaEstoqueId> reservasDefinitivasId,
									List<AtributoEstoqueValor<?>> atributos,
									boolean manterAtributosReserva) {
		this.id = id;
		this.skuId = skuId;
		this.aceitarParcialConvertendoSaldoDisponivel = aceitarParcialConvertendoSaldoDisponivel;
		this.quantidadeSKU = Optional.ofNullable(quantidadeSKU);
		this.reservasDefinitivasId = CollectionUtils.unmodifiable(reservasDefinitivasId);
		this.atributos = CollectionUtils.unmodifiable(atributos);
		this.manterAtributosReserva = manterAtributosReserva;
	}

	public BigDecimal getQuantidadeAlteracaoSKU(Estoque estoqueSaida, SKU skuEstoqueSaida) {

		var somaQuantidadeReservas = estoqueSaida.getReservasDefinitivas()
												 .stream()
												 .filter(reserva -> this.getReservasDefinitivasId()
																		.contains(reserva.getReservaDefinitivaEstoqueId()))
												 .map(EstoqueReservaDefinitiva::getQuantidade)
												 .reduce(BigDecimal.ZERO, BigDecimal::add);

		var quantidadeAlteracaoSKU = this.quantidadeSKU.map(quantidade -> skuEstoqueSaida.converterEmQuantidadeDeUnidades(BigDecimal.valueOf(quantidade)))
													   .orElse(estoqueSaida.getSaldo());

		if (somaQuantidadeReservas.compareTo(quantidadeAlteracaoSKU) > 0)
			throw new WMSSomaQuantidadeReservasNaoDeveSerMaiorQueQuantidadeAlteracaoSKUException();

		var quantidadeAlteracaoSKUSemReservas = quantidadeAlteracaoSKU.subtract(somaQuantidadeReservas);

		if (aceitarParcialConvertendoSaldoDisponivel
				&& quantidadeAlteracaoSKUSemReservas.compareTo(estoqueSaida.getSaldoDisponivelDescontandoBloqueioMovimentacaoNaoReservado()) > 0) {

			var quantidadePossivelParaAlteracaoSKU = estoqueSaida.getSaldoDisponivelDescontandoBloqueioMovimentacaoNaoReservado()
																 .add(somaQuantidadeReservas);

			var quantidadeSKUPossivelParaAlteracaoSKU = skuEstoqueSaida.converterEmQuantidadeSKUArredondandoParaBaixo(quantidadePossivelParaAlteracaoSKU);

			quantidadeAlteracaoSKU = skuEstoqueSaida.converterEmQuantidadeDeUnidades(BigDecimal.valueOf(quantidadeSKUPossivelParaAlteracaoSKU));
		}

		return quantidadeAlteracaoSKU;

	}
}
