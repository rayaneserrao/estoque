package com.totvs.sl.wms.estoque.estoque.exception;

import com.totvs.tjf.api.context.stereotype.error.ApiBadRequest;

@ApiBadRequest
public class WMSBloqueioMovimentacaoUnitizadorIdDiferenteDoEstoqueException extends RuntimeException {

	private static final long serialVersionUID = 4661772135899113251L;
	
}
