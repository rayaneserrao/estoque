package com.totvs.sl.wms.estoque.caracteristicaconfiguracao.amqp;

import java.util.Objects;

import org.springframework.cloud.stream.annotation.EnableBinding;
import org.springframework.cloud.stream.annotation.StreamListener;

import com.totvs.sl.wms.estoque.caracteristicaconfiguracao.amqp.cmd.CriarCaracteristicaConfiguracaoCmd;
import com.totvs.sl.wms.estoque.caracteristicaconfiguracao.application.CaracteristicaConfiguracaoCriarApplicationService;
import com.totvs.sl.wms.estoque.caracteristicaconfiguracao.application.command.CriarCaracteristicaConfiguracaoCommand;
import com.totvs.sl.wms.estoque.caracteristicaconfiguracao.domain.model.CaracteristicaConfiguracaoOrigem;
import com.totvs.sl.wms.estoque.caracteristicaconfiguracao.domain.model.FormatoCaracteristicaValor;
import com.totvs.sl.wms.estoque.caracteristicaconfiguracao.exception.WMSCriarCaracteristicaConfiguracaoConstraintException;
import com.totvs.sl.wms.estoque.config.amqp.WMSChannel;
import com.totvs.sl.wms.estoque.util.amqp.AMQPUtil;
import com.totvs.tjf.core.validation.ValidatorService;
import com.totvs.tjf.messaging.context.TOTVSMessage;

import lombok.AllArgsConstructor;

@AllArgsConstructor
@EnableBinding({ WMSChannel.WMSEstoqueConfiguracaoCommandsInput.class })
public class CaracteristicaConfiguracaoCriarSubscriber {

	private final CaracteristicaConfiguracaoCriarApplicationService service;

	private final ValidatorService validator;

	@StreamListener(target = WMSChannel.WMS_ESTOQUE_CONFIGURACAO_COMMANDS_IN, condition = CriarCaracteristicaConfiguracaoCmd.CONDITIONAL_EXPRESSION)
	public void criarCaracteristica(final TOTVSMessage<CriarCaracteristicaConfiguracaoCmd> message) {

		AMQPUtil.gerarLog(this.getClass(), message, CriarCaracteristicaConfiguracaoCmd.CONDITIONAL_EXPRESSION);

		var cmd = message.getContent();

		validator.validate(cmd).ifPresent(violations -> {
			throw new WMSCriarCaracteristicaConfiguracaoConstraintException(violations);
		});

		var command = CriarCaracteristicaConfiguracaoCommand.of(cmd.getDescricao(),
																FormatoCaracteristicaValor.valueOf(cmd.getFormato()),
																Objects.nonNull(cmd.getOrigem())
																		? CaracteristicaConfiguracaoOrigem.valueOf(cmd.getOrigem())
																		: null);

		service.handle(command);
	}
}
