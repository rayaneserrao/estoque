package com.totvs.sl.wms.estoque.caracteristicaconfiguracao.api;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

import javax.annotation.security.RolesAllowed;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.totvs.sl.wms.estoque.caracteristicaconfiguracao.api.dto.AlterarCaracteristicaConfiguracaoDTO;
import com.totvs.sl.wms.estoque.caracteristicaconfiguracao.application.CaracteristicaConfiguracaoAlterarApplicationService;
import com.totvs.sl.wms.estoque.caracteristicaconfiguracao.application.command.AlterarCaracteristicaConfiguracaoCommand;
import com.totvs.sl.wms.estoque.caracteristicaconfiguracao.domain.model.CaracteristicaConfiguracaoId;
import com.totvs.sl.wms.estoque.caracteristicaconfiguracao.exception.WMSCaracteristicaConfiguracaoConstraintException;
import com.totvs.sl.wms.estoque.usuario.domain.model.UsuarioPerfil;
import com.totvs.tjf.api.context.stereotype.ApiGuideline;
import com.totvs.tjf.api.context.stereotype.ApiGuideline.ApiGuidelineVersion;
import com.totvs.tjf.core.validation.ValidatorService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.AllArgsConstructor;

@Tag(name = "caracteristica-configuracao")

@RestController
@AllArgsConstructor
@RequestMapping(path = CaracteristicaConfiguracaoAlterarController.PATH, produces = APPLICATION_JSON_VALUE, consumes = APPLICATION_JSON_VALUE)
@ApiGuideline(ApiGuidelineVersion.V2)
@RolesAllowed({ UsuarioPerfil.Perfil.PLANEJADOR_WMS, UsuarioPerfil.Perfil.PLANEJADOR_WMS_SENIOR })
public class CaracteristicaConfiguracaoAlterarController {

	public static final String PATH = "/api/v1/caracteristicasConfiguracao";

	private final CaracteristicaConfiguracaoAlterarApplicationService alterarService;
	private final ValidatorService validator;

	@Operation(description = "Alterar uma característica de estoque.", method = "POST")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "Característica de estoque alterada com sucesso."),
			@ApiResponse(responseCode = "400", description = "A característica de estoque não pôde ser alterada pois possui alguma informação inválida."),
			@ApiResponse(responseCode = "404", description = "A característica de estoque não foi encontrada."), })
	@PostMapping(path = "/{id}/alterar")
	public ResponseEntity<Void> alterar(@PathVariable CaracteristicaConfiguracaoId id,
										@RequestBody AlterarCaracteristicaConfiguracaoDTO dto) {

		validator.validate(dto).ifPresent(violations -> {
			throw new WMSCaracteristicaConfiguracaoConstraintException(violations);
		});

		var cmd = AlterarCaracteristicaConfiguracaoCommand.of(id, dto.getDescricao(), dto.getFormato());

		alterarService.handle(cmd);

		return ResponseEntity.ok().build();
	}
}
