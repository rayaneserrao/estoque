package com.totvs.sl.wms.estoque.caracteristicaconfiguracao.domain.model;

public enum CaracteristicaConfiguracaoOrigem {
	PADRAO, INCLUSAO_MANUAL;
}
