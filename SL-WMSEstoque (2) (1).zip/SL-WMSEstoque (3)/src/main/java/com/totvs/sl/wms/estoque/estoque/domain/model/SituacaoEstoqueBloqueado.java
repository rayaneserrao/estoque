package com.totvs.sl.wms.estoque.estoque.domain.model;

import java.time.ZonedDateTime;

import org.springframework.util.StringUtils;

import com.totvs.sl.wms.estoque.util.DateTimeUtils;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Getter
@EqualsAndHashCode
@NoArgsConstructor(access = AccessLevel.PRIVATE)
@AllArgsConstructor(access = AccessLevel.PRIVATE)
public class SituacaoEstoqueBloqueado implements SituacaoEstoque {

	private String chaveAcesso;

	private String motivo;

	private ZonedDateTime quando;

	private SituacaoEstoqueBloqueado(String chaveAcesso, String motivo) {
		this.chaveAcesso = chaveAcesso;
		this.motivo = motivo;
		this.quando = DateTimeUtils.format(DateTimeUtils.getNow());
	}

	public static SituacaoEstoqueBloqueado of(String chaveAcesso, String motivo) {
		return new SituacaoEstoqueBloqueado(chaveAcesso, motivo);
	}

	@Override
	public SituacaoEstoqueValor getSituacaoEstoque() {
		return SituacaoEstoqueValor.BLOQUEADO;
	}

	@Override
	public String toString() {
		var chaveAcessoStr = StringUtils.hasText(this.chaveAcesso) ? this.chaveAcesso : "";
		return SituacaoEstoqueValor.BLOQUEADO.toString() + chaveAcessoStr;
	}
}
