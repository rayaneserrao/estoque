package com.totvs.sl.wms.estoque.caracteristicaconfiguracao.amqp;

import org.springframework.cloud.stream.annotation.EnableBinding;
import org.springframework.cloud.stream.annotation.StreamListener;

import com.totvs.sl.wms.estoque.caracteristicaconfiguracao.amqp.cmd.DesmarcarUtilizacaoCaracteristicaConfiguracaoCmd;
import com.totvs.sl.wms.estoque.caracteristicaconfiguracao.application.CaracteristicaConfiguracaoDesmarcarUtilizacaoApplicationService;
import com.totvs.sl.wms.estoque.caracteristicaconfiguracao.application.command.DesmarcarUtilizacaoCaracteristicaConfiguracaoCommand;
import com.totvs.sl.wms.estoque.caracteristicaconfiguracao.exception.WMSDesmarcarUtilizacaoCaracteristicaConfiguracaoConstraintException;
import com.totvs.sl.wms.estoque.config.amqp.WMSChannel;
import com.totvs.sl.wms.estoque.util.amqp.AMQPUtil;
import com.totvs.tjf.core.validation.ValidatorService;
import com.totvs.tjf.messaging.context.TOTVSMessage;

import lombok.AllArgsConstructor;

@AllArgsConstructor
@EnableBinding(WMSChannel.WMSEstoqueConfiguracaoCommandsInput.class)
public class CaracteristicaConfiguracaoDesmarcarUtilizacaoSubscriber {

	private final CaracteristicaConfiguracaoDesmarcarUtilizacaoApplicationService service;

	private final ValidatorService validator;

	@StreamListener(target = WMSChannel.WMS_ESTOQUE_CONFIGURACAO_COMMANDS_IN, condition = DesmarcarUtilizacaoCaracteristicaConfiguracaoCmd.CONDITIONAL_EXPRESSION)
	public void desmarcarUtilizacaoCaracteristica(final TOTVSMessage<DesmarcarUtilizacaoCaracteristicaConfiguracaoCmd> message) {

		AMQPUtil.gerarLog(this.getClass(),
						  message,
						  DesmarcarUtilizacaoCaracteristicaConfiguracaoCmd.CONDITIONAL_EXPRESSION);

		var transactionInfo = message.getHeader().getTransactionInfo();

		var cmd = message.getContent();

		validator.validate(cmd).ifPresent(violations -> {
			throw new WMSDesmarcarUtilizacaoCaracteristicaConfiguracaoConstraintException(violations);
		});

		var command = DesmarcarUtilizacaoCaracteristicaConfiguracaoCommand.of(cmd.getId(),
																			  transactionInfo.getGeneratedBy());

		service.handle(command);
	}

}
