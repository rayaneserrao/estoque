package com.totvs.sl.wms.estoque.estoque.amqp.cmd;

import com.totvs.sl.wms.estoque.bloqueiomovimentacaounitizador.domain.model.BloqueioMovimentacaoUnitizadorId;
import com.totvs.sl.wms.estoque.unidade.domain.model.UnidadeId;
import com.totvs.sl.wms.estoque.unitizador.domain.model.UnitizadorId;
import lombok.Builder;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

@Data
@Builder
public final class DesbloquearEstoquesUnitizadorCmd {

	public static final String NAME = "DesbloquearEstoquesUnitizadorCmd";

	public static final String CONDITIONAL_EXPRESSION = "headers['type']=='" + NAME + "'";

	@NotNull(message = "{DesbloquearEstoquesUnitizadorCmd.unitizadorId.NotNull}")
	private final UnitizadorId unitizadorId;

	@NotNull(message = "{DesbloquearEstoquesUnitizadorCmd.unidadeId.NotNull}")
	private final UnidadeId unidadeId;

	@NotBlank(message = "{DesbloquearEstoquesUnitizadorCmd.chaveAcesso.NotBlank}")
	private final String chaveAcesso;

	private final BloqueioMovimentacaoUnitizadorId bloqueioMovimentacaoUnitizadorId;
}
