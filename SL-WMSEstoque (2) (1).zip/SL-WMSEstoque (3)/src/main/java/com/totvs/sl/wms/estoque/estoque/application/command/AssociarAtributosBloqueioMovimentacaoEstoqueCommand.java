package com.totvs.sl.wms.estoque.estoque.application.command;

import com.totvs.sl.wms.estoque.bloqueiomovimentacaoestoque.domain.model.BloqueioMovimentacaoEstoqueId;
import com.totvs.sl.wms.estoque.estoque.domain.model.Estoque;
import com.totvs.sl.wms.estoque.estoque.domain.model.EstoqueAtributoSaldo;
import com.totvs.sl.wms.estoque.estoque.domain.model.EstoqueId;
import lombok.Data;
import org.springframework.util.CollectionUtils;

import java.util.List;

@Data(staticConstructor = "of")
public final class AssociarAtributosBloqueioMovimentacaoEstoqueCommand {

	private final EstoqueId estoqueId;
	private final BloqueioMovimentacaoEstoqueId bloqueioMovimentacaoEstoqueId;
	private final List<EstoqueAtributoSaldo> atributosSaldo;

	public List<EstoqueAtributoSaldo> getAtributosSaldo(Estoque estoque) {

		if (!CollectionUtils.isEmpty(atributosSaldo))
			return this.atributosSaldo;

		return estoque.getAtributosSaldo();
	}

}
