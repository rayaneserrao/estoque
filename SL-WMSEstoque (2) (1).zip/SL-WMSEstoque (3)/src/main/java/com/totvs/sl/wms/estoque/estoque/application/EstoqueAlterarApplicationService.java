package com.totvs.sl.wms.estoque.estoque.application;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Set;
import java.util.UUID;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import com.totvs.sl.wms.estoque.atributoestoque.domain.model.AtributoEstoque;
import com.totvs.sl.wms.estoque.atributoestoque.domain.model.AtributoEstoqueDomainRepository;
import com.totvs.sl.wms.estoque.atributoestoque.domain.model.AtributoEstoqueId;
import com.totvs.sl.wms.estoque.atributoestoquevalor.domain.model.AtributoEstoqueValor;
import com.totvs.sl.wms.estoque.caracteristicaconfiguracao.domain.model.CaracteristicaConfiguracao;
import com.totvs.sl.wms.estoque.caracteristicaconfiguracao.domain.model.CaracteristicaConfiguracaoDomainRepository;
import com.totvs.sl.wms.estoque.caracteristicavalor.domain.model.CaracteristicaValor;
import com.totvs.sl.wms.estoque.config.amqp.WMSPublisher;
import com.totvs.sl.wms.estoque.endereco.domain.model.Endereco;
import com.totvs.sl.wms.estoque.endereco.domain.model.EnderecoDomainRepository;
import com.totvs.sl.wms.estoque.estoque.application.command.AlterarEstoqueAtributoCommand;
import com.totvs.sl.wms.estoque.estoque.application.command.AlterarEstoqueAvariadoCommand;
import com.totvs.sl.wms.estoque.estoque.application.command.AlterarEstoqueCaracteristicaCommand;
import com.totvs.sl.wms.estoque.estoque.application.command.AlterarEstoqueSKUCommand;
import com.totvs.sl.wms.estoque.estoque.application.command.AlterarEstoqueSituacaoCommand;
import com.totvs.sl.wms.estoque.estoque.application.command.AlterarEstoqueTipoEstoqueCommand;
import com.totvs.sl.wms.estoque.estoque.domain.event.EstoqueAlteradoEvent;
import com.totvs.sl.wms.estoque.estoque.domain.model.Estoque;
import com.totvs.sl.wms.estoque.estoque.domain.model.EstoqueAtributoSaldo;
import com.totvs.sl.wms.estoque.estoque.domain.model.EstoqueAtributoSaldoId;
import com.totvs.sl.wms.estoque.estoque.domain.model.EstoqueDomainRepository;
import com.totvs.sl.wms.estoque.estoque.domain.model.EstoqueHash;
import com.totvs.sl.wms.estoque.estoque.domain.model.EstoqueId;
import com.totvs.sl.wms.estoque.estoque.domain.model.FracionadoId;
import com.totvs.sl.wms.estoque.estoque.domain.model.SituacaoEstoque;
import com.totvs.sl.wms.estoque.estoque.domain.model.SituacaoEstoqueBloqueado;
import com.totvs.sl.wms.estoque.estoque.domain.model.SituacaoEstoqueLiberado;
import com.totvs.sl.wms.estoque.estoque.domain.model.SituacaoEstoqueValor;
import com.totvs.sl.wms.estoque.estoque.domain.service.AtualizaSaldoEstoqueEntradaDomainService;
import com.totvs.sl.wms.estoque.estoque.domain.service.AtualizaSaldoEstoqueSaidaDomainService;
import com.totvs.sl.wms.estoque.estoque.domain.service.ConfiguraEstoqueParaEntradaDomainService;
import com.totvs.sl.wms.estoque.estoque.domain.service.ValidaEstoqueHashIgualAlteracaoDomainService;
import com.totvs.sl.wms.estoque.estoque.exception.WMSEstoqueAtributoValorJaInformadoParaAtributoSerialException;
import com.totvs.sl.wms.estoque.estoque.exception.WMSEstoqueAtributoValorNaoEncontradoNoSaldoException;
import com.totvs.sl.wms.estoque.movimentoestoque.domain.model.MovimentoEstoque;
import com.totvs.sl.wms.estoque.movimentoestoque.domain.model.MovimentoEstoqueDomainRepository;
import com.totvs.sl.wms.estoque.movimentoestoque.domain.model.MovimentoEstoqueId;
import com.totvs.sl.wms.estoque.origem.domain.model.Origem;
import com.totvs.sl.wms.estoque.origem.domain.model.OrigemId;
import com.totvs.sl.wms.estoque.produto.domain.model.ProdutoDomainRepository;
import com.totvs.sl.wms.estoque.reservadefinitivaestoque.domain.model.ReservaDefinitivaEstoque;
import com.totvs.sl.wms.estoque.reservadefinitivaestoque.domain.model.ReservaDefinitivaEstoqueDomainRepository;
import com.totvs.sl.wms.estoque.reservadefinitivaestoque.domain.model.ReservaDefinitivaEstoqueId;
import com.totvs.sl.wms.estoque.sku.domain.model.SKU;
import com.totvs.sl.wms.estoque.sku.domain.model.SKUDomainRepository;
import com.totvs.sl.wms.estoque.sku.domain.model.SKUId;
import com.totvs.sl.wms.estoque.tipoestoque.domain.model.TipoEstoqueDomainRepository;
import com.totvs.sl.wms.estoque.tipoestoque.domain.model.TipoEstoqueId;
import com.totvs.sl.wms.estoque.util.ConversionUtils;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Service
@Transactional
@AllArgsConstructor
public class EstoqueAlterarApplicationService {

	private final MovimentoEstoqueDomainRepository movimentoEstoqueRepository;
	private final EstoqueDomainRepository estoqueRepository;
	private final ReservaDefinitivaEstoqueDomainRepository reservaDefinitivaEstoqueRepository;
	private final ProdutoDomainRepository produtoRepository;
	private final SKUDomainRepository skuRepository;
	private final TipoEstoqueDomainRepository tipoEstoqueRepository;
	private final AtributoEstoqueDomainRepository atributoEstoqueRepository;
	private final CaracteristicaConfiguracaoDomainRepository configuracaoRepository;
	private final EnderecoDomainRepository enderecoRepository;
	private final ConfiguraEstoqueParaEntradaDomainService configuraEstoqueEntradaService;
	private final AtualizaSaldoEstoqueEntradaDomainService atualizaSaldoEntradaService;
	private final AtualizaSaldoEstoqueSaidaDomainService atualizaSaldoSaidaService;
	private final WMSPublisher publisher;

	@Getter
	@AllArgsConstructor(staticName = "of")
	public static final class EstoqueAlteradoEventMovimentos {
		private EstoqueAlteradoEvent evento;
		private MovimentoEstoque movimentoSaida;
		private MovimentoEstoque movimentoEntrada;
	}

	public EstoqueId handle(final AlterarEstoqueSKUCommand cmd) {

		var estoqueSaida = estoqueRepository.findWithLockByIdOrThrowNotFound(cmd.getId());

		var skuEstoqueSaida = skuRepository.findByIdAndProdutoIdThrowNotFound(estoqueSaida.getSkuId(),
																			  estoqueSaida.getProdutoId());

		List<EstoqueAtributoSaldo> atributosSaldo = !CollectionUtils.isEmpty(cmd.getAtributos())
				? List.of(EstoqueAtributoSaldo.of(cmd.getAtributos(),
												  cmd.getQuantidadeAlteracaoSKU(estoqueSaida, skuEstoqueSaida)))
				: estoqueSaida.getAtributosSaldo();

		var eventoMovimentos = this.efetuarAlteracaoEstoqueSKU(estoqueSaida,
															   cmd.getSkuId(),
															   cmd.getQuantidadeAlteracaoSKU(estoqueSaida,
																							 skuEstoqueSaida),
															   cmd.getReservasDefinitivasId(),
															   atributosSaldo,
															   cmd.isManterAtributosReserva());

		eventoMovimentos.getMovimentoSaida().getEvents().forEach(publisher::dispatch);
		eventoMovimentos.getMovimentoEntrada().getEvents().forEach(publisher::dispatch);

		publisher.dispatch(eventoMovimentos.getEvento());

		return eventoMovimentos.getMovimentoEntrada().getEstoqueId();
	}

	public EstoqueId handle(final AlterarEstoqueTipoEstoqueCommand cmd) {

		var estoqueSaida = estoqueRepository.findWithLockByIdOrThrowNotFound(cmd.getId());

		tipoEstoqueRepository.findByIdAndAtivoOrThrowNotFound(cmd.getTipoEstoqueId());

		var eventoMovimentos = this.efetuarAlteracaoEstoqueTipoEstoque(estoqueSaida, cmd.getTipoEstoqueId());

		eventoMovimentos.getMovimentoSaida().getEvents().forEach(publisher::dispatch);
		eventoMovimentos.getMovimentoEntrada().getEvents().forEach(publisher::dispatch);

		publisher.dispatch(eventoMovimentos.getEvento());

		return eventoMovimentos.getMovimentoEntrada().getEstoqueId();
	}

	public EstoqueId handle(final AlterarEstoqueCaracteristicaCommand cmd) {

		var estoqueSaida = estoqueRepository.findWithLockByIdOrThrowNotFound(cmd.getId());

		var caracteristica = configuracaoRepository.findByIdOrThrowNotFound(cmd.getCaracteristicaConfiguracaoId());

		var eventoMovimentos = this.efetuarAlteracaoEstoqueCaracteristica(estoqueSaida, caracteristica, cmd.getValor());

		eventoMovimentos.getMovimentoSaida().getEvents().forEach(publisher::dispatch);
		eventoMovimentos.getMovimentoEntrada().getEvents().forEach(publisher::dispatch);

		publisher.dispatch(eventoMovimentos.getEvento());

		return eventoMovimentos.getMovimentoEntrada().getEstoqueId();
	}

	public EstoqueId handle(AlterarEstoqueAtributoCommand cmd) {

		var estoqueSaida = estoqueRepository.findWithLockByIdOrThrowNotFound(cmd.getId());

		var atributoEstoque = atributoEstoqueRepository.findByIdOrThrowNotFound(cmd.getAtributoEstoqueId());

		if (atributoEstoque.getControleQuantidade().isSerial()
				&& estoqueRepository.existsAtributoSerialRepetidoByProdutoIdAndAtributoIdAndValor(estoqueSaida.getProdutoId(),
																								  atributoEstoque.getId(),
																								  cmd.getNovoValor()))
			throw new WMSEstoqueAtributoValorJaInformadoParaAtributoSerialException(cmd.getNovoValor());

		var novoValor = cmd.getNovoValor();
		var valorAtual = cmd.getValorAtual();

		if (atributoEstoque.getFormato().isNumero()) {
			novoValor = ConversionUtils.toBigDecimal(novoValor).toString();
			valorAtual = ConversionUtils.toBigDecimal(valorAtual).toString();
		}

		var eventoMovimentos = this.efetuarAlteracaoEstoqueAtributo(cmd.getEstoqueAtributoSaldoId(),
																	novoValor,
																	valorAtual,
																	atributoEstoque,
																	estoqueSaida);

		eventoMovimentos.getMovimentoSaida().getEvents().forEach(publisher::dispatch);
		eventoMovimentos.getMovimentoEntrada().getEvents().forEach(publisher::dispatch);

		publisher.dispatch(eventoMovimentos.getEvento());

		return eventoMovimentos.getMovimentoEntrada().getEstoqueId();
	}

	public EstoqueId handle(final AlterarEstoqueAvariadoCommand cmd) {

		var estoqueSaida = estoqueRepository.findWithLockByIdOrThrowNotFound(cmd.getId());

		var eventoMovimentos = this.efetuarAlteracaoEstoqueAvariado(estoqueSaida, cmd.isAvariado());

		eventoMovimentos.getMovimentoSaida().getEvents().forEach(publisher::dispatch);
		eventoMovimentos.getMovimentoEntrada().getEvents().forEach(publisher::dispatch);

		publisher.dispatch(eventoMovimentos.getEvento());

		return eventoMovimentos.getMovimentoEntrada().getEstoqueId();
	}

	public EstoqueId handle(final AlterarEstoqueSituacaoCommand cmd) {

		var estoqueSaida = estoqueRepository.findWithLockByIdOrThrowNotFound(cmd.getId());

		SituacaoEstoque situacao = null;
		if (cmd.getSituacao().equals(SituacaoEstoqueValor.LIBERADO)) {
			situacao = SituacaoEstoqueLiberado.of();
		} else {
			situacao = SituacaoEstoqueBloqueado.of(null, null);
		}

		var eventoMovimentos = this.efetuarAlteracaoEstoqueSituacao(estoqueSaida, situacao);

		eventoMovimentos.getMovimentoSaida().getEvents().forEach(publisher::dispatch);
		eventoMovimentos.getMovimentoEntrada().getEvents().forEach(publisher::dispatch);

		publisher.dispatch(eventoMovimentos.getEvento());

		return eventoMovimentos.getMovimentoEntrada().getEstoqueId();
	}

	private EstoqueAlteradoEventMovimentos efetuarAlteracaoEstoqueSKU(Estoque estoqueSaida,
																	  SKUId skuId,
																	  BigDecimal quantidade,
																	  Collection<ReservaDefinitivaEstoqueId> reservasDefinitivasId,
																	  List<EstoqueAtributoSaldo> atributosSaldo,
																	  boolean manterAtributosReserva) {

		var skuEstoqueSaida = skuRepository.findByIdAndProdutoIdThrowNotFound(estoqueSaida.getSkuId(),
																			  estoqueSaida.getProdutoId());

		var skuEstoqueEntrada = skuRepository.findByIdAndProdutoIdAndAtivoOrThrowNotFound(skuId,
																						  estoqueSaida.getProdutoId());

		var estoqueHash = EstoqueHash.builder()
									 .unidadeId(estoqueSaida.getUnidadeId())
									 .produtoId(estoqueSaida.getProdutoId())
									 .skuId(skuId)
									 .unitizadorId(estoqueSaida.getUnitizadorId())
									 .tipoEstoqueId(estoqueSaida.getTipoEstoqueId())
									 .enderecoId(estoqueSaida.getEnderecoId())
									 .fracionadoId(skuEstoqueSaida.isFracionado() ? FracionadoId.generate() : null)
									 .situacoes(estoqueSaida.getSituacoes())
									 .avariado(estoqueSaida.getAvariado())
									 .caracteristicas(estoqueSaida.getCaracteristicas())
									 .build();

		var reservasDefinitivas = reservasDefinitivasId.stream()
													   .map(reservaDefinitivaEstoqueRepository::findWithLockByIdOrThrowNotFound)
													   .toList();

		var atributosSaldoEntrada = new ArrayList<>(atributosSaldo);

		var endereco = enderecoRepository.findByIdOrThrowNotFound(estoqueSaida.getEnderecoId());

		return this.processarAlteracaoEstoque(estoqueSaida,
											  skuEstoqueSaida,
											  skuEstoqueEntrada,
											  estoqueHash,
											  reservasDefinitivas,
											  quantidade,
											  "AlterarEstoqueSKUCommand",
											  this.determinarAlteraOcupacaoEndereco(endereco),
											  atributosSaldo,
											  atributosSaldoEntrada,
											  false,
											  manterAtributosReserva);
	}

	private EstoqueAlteradoEventMovimentos efetuarAlteracaoEstoqueTipoEstoque(Estoque estoqueSaida,
																			  TipoEstoqueId tipoEstoqueId) {

		var sku = skuRepository.findByIdAndProdutoIdThrowNotFound(estoqueSaida.getSkuId(), estoqueSaida.getProdutoId());

		var estoqueHash = EstoqueHash.builder()
									 .unidadeId(estoqueSaida.getUnidadeId())
									 .produtoId(estoqueSaida.getProdutoId())
									 .skuId(estoqueSaida.getSkuId())
									 .unitizadorId(estoqueSaida.getUnitizadorId())
									 .tipoEstoqueId(tipoEstoqueId)
									 .enderecoId(estoqueSaida.getEnderecoId())
									 .fracionadoId(sku.isFracionado() ? FracionadoId.generate() : null)
									 .situacoes(estoqueSaida.getSituacoes())
									 .avariado(estoqueSaida.getAvariado())
									 .caracteristicas(estoqueSaida.getCaracteristicas())
									 .build();

		var atributosSaldoEntrada = new ArrayList<>(estoqueSaida.getAtributosSaldo());

		return this.processarAlteracaoEstoque(estoqueSaida,
											  sku,
											  estoqueHash,
											  "AlterarEstoqueTipoEstoqueCommand",
											  false,
											  estoqueSaida.getAtributosSaldo(),
											  atributosSaldoEntrada,
											  false,
											  false);

	}

	private EstoqueAlteradoEventMovimentos efetuarAlteracaoEstoqueCaracteristica(Estoque estoqueSaida,
																				 CaracteristicaConfiguracao caracteristicaConfiguracao,
																				 String valor) {

		var sku = skuRepository.findByIdAndProdutoIdThrowNotFound(estoqueSaida.getSkuId(), estoqueSaida.getProdutoId());

		var estoqueHash = EstoqueHash.builder()
									 .unidadeId(estoqueSaida.getUnidadeId())
									 .produtoId(estoqueSaida.getProdutoId())
									 .skuId(estoqueSaida.getSkuId())
									 .unitizadorId(estoqueSaida.getUnitizadorId())
									 .tipoEstoqueId(estoqueSaida.getTipoEstoqueId())
									 .enderecoId(estoqueSaida.getEnderecoId())
									 .situacoes(estoqueSaida.getSituacoes())
									 .avariado(estoqueSaida.getAvariado())
									 .caracteristicas(atualizarValorCaracteristica(estoqueSaida.getCaracteristicas(),
																				   caracteristicaConfiguracao,
																				   valor))
									 .build();

		var atributosSaldoEntrada = new ArrayList<>(estoqueSaida.getAtributosSaldo());

		return this.processarAlteracaoEstoque(estoqueSaida,
											  sku,
											  estoqueHash,
											  "AlterarEstoqueCaracteristicaCommand",
											  false,
											  estoqueSaida.getAtributosSaldo(),
											  atributosSaldoEntrada,
											  false,
											  false);
	}

	private EstoqueAlteradoEventMovimentos efetuarAlteracaoEstoqueAtributo(EstoqueAtributoSaldoId estoqueAtributoSaldoId,
																		   String novoValorAtributo,
																		   String valorAtual,
																		   AtributoEstoque atributoEstoque,
																		   Estoque estoqueSaida) {

		var sku = skuRepository.findByIdAndProdutoIdThrowNotFound(estoqueSaida.getSkuId(), estoqueSaida.getProdutoId());

		var novaListaAtributo = substituirValorAtributo(estoqueAtributoSaldoId,
														novoValorAtributo,
														valorAtual,
														atributoEstoque.getId(),
														estoqueSaida);

		var estoqueHash = EstoqueHash.builder()
									 .unidadeId(estoqueSaida.getUnidadeId())
									 .produtoId(estoqueSaida.getProdutoId())
									 .skuId(estoqueSaida.getSkuId())
									 .unitizadorId(estoqueSaida.getUnitizadorId())
									 .tipoEstoqueId(estoqueSaida.getTipoEstoqueId())
									 .enderecoId(estoqueSaida.getEnderecoId())
									 .situacoes(estoqueSaida.getSituacoes())
									 .avariado(estoqueSaida.getAvariado())
									 .caracteristicas(estoqueSaida.getCaracteristicas())
									 .build();

		return this.processarAlteracaoEstoque(estoqueSaida,
											  sku,
											  estoqueHash,
											  "AlterarEstoqueAtributoCommand",
											  false,
											  estoqueSaida.getAtributosSaldo(),
											  novaListaAtributo,
											  true,
											  false);
	}

	private static List<EstoqueAtributoSaldo> substituirValorAtributo(EstoqueAtributoSaldoId estoqueAtributoSaldoId,
																	  String novoValorAtributo,
																	  String valorAtual,
																	  AtributoEstoqueId atributoEstoqueId,
																	  Estoque estoqueSaida) {

		List<EstoqueAtributoSaldo> novaListaAtributosSaldo = new ArrayList<>();

		boolean atributoEncontrado = false;

		var estoqueAtributoSaldoSaidaOptional = estoqueSaida.getAtributosSaldo()
															.stream()
															.filter(atributoSaldo -> atributoSaldo.getId()
																								  .equals(estoqueAtributoSaldoId))
															.findAny();

		if (estoqueAtributoSaldoSaidaOptional.isPresent()) {

			var estoqueAtributoSaldoSaida = estoqueAtributoSaldoSaidaOptional.get();

			novaListaAtributosSaldo.addAll(new ArrayList<>(estoqueSaida.getAtributosSaldo()
																	   .stream()
																	   .filter(atrSaldoSaida -> !atrSaldoSaida.equals(estoqueAtributoSaldoSaida))
																	   .toList()));

			List<AtributoEstoqueValor<?>> novaListaAtributos = new ArrayList<>();

			for (AtributoEstoqueValor<?> atributo : estoqueAtributoSaldoSaida.getAtributos()) {

				var novoAtributo = atributo.getFormato()
										   .getInstance(atributo.getId(),
														atributo.getValores(),
														atributo.getControleQuantidade());

				if (novoAtributo.getId().equals(atributoEstoqueId)
						&& novoAtributo.getValores().toString().contains(valorAtual)) {

					if (novoAtributo.getControleQuantidade().isSerial()) {
						novoAtributo.removerValorSerial(valorAtual);
						novoAtributo.adicionarValorSerial(novoValorAtributo);
					} else {
						novoAtributo.atualizarValorVariavel(novoValorAtributo);
					}

					atributoEncontrado = true;
				}

				novaListaAtributos.add(novoAtributo);

			}

			novaListaAtributosSaldo.add(EstoqueAtributoSaldo.of(novaListaAtributos,
																estoqueAtributoSaldoSaida.getSaldo()));

		}

		if (!atributoEncontrado) {
			throw new WMSEstoqueAtributoValorNaoEncontradoNoSaldoException(valorAtual);
		}

		return novaListaAtributosSaldo;
	}

	private EstoqueAlteradoEventMovimentos efetuarAlteracaoEstoqueAvariado(Estoque estoqueSaida, boolean avariado) {

		var sku = skuRepository.findByIdAndProdutoIdThrowNotFound(estoqueSaida.getSkuId(), estoqueSaida.getProdutoId());

		var estoqueHash = EstoqueHash.builder()
									 .unidadeId(estoqueSaida.getUnidadeId())
									 .produtoId(estoqueSaida.getProdutoId())
									 .skuId(estoqueSaida.getSkuId())
									 .unitizadorId(estoqueSaida.getUnitizadorId())
									 .tipoEstoqueId(estoqueSaida.getTipoEstoqueId())
									 .enderecoId(estoqueSaida.getEnderecoId())
									 .fracionadoId(sku.isFracionado() ? FracionadoId.generate() : null)
									 .situacoes(estoqueSaida.getSituacoes())
									 .avariado(avariado)
									 .caracteristicas(estoqueSaida.getCaracteristicas())
									 .build();

		var atributosSaldoEntrada = new ArrayList<>(estoqueSaida.getAtributosSaldo());

		return this.processarAlteracaoEstoque(estoqueSaida,
											  sku,
											  estoqueHash,
											  "AlterarEstoqueAvariadoCommand",
											  false,
											  estoqueSaida.getAtributosSaldo(),
											  atributosSaldoEntrada,
											  false,
											  false);
	}

	private EstoqueAlteradoEventMovimentos efetuarAlteracaoEstoqueSituacao(Estoque estoqueSaida,
																		   SituacaoEstoque situacao) {

		var sku = skuRepository.findByIdAndProdutoIdThrowNotFound(estoqueSaida.getSkuId(), estoqueSaida.getProdutoId());

		var estoqueHash = EstoqueHash.builder()
									 .unidadeId(estoqueSaida.getUnidadeId())
									 .produtoId(estoqueSaida.getProdutoId())
									 .skuId(estoqueSaida.getSkuId())
									 .unitizadorId(estoqueSaida.getUnitizadorId())
									 .tipoEstoqueId(estoqueSaida.getTipoEstoqueId())
									 .enderecoId(estoqueSaida.getEnderecoId())
									 .fracionadoId(sku.isFracionado() ? FracionadoId.generate() : null)
									 .situacoes(Set.of(situacao))
									 .avariado(estoqueSaida.getAvariado())
									 .caracteristicas(estoqueSaida.getCaracteristicas())
									 .build();

		var atributosSaldoEntrada = new ArrayList<>(estoqueSaida.getAtributosSaldo());

		return this.processarAlteracaoEstoque(estoqueSaida,
											  sku,
											  estoqueHash,
											  "AlterarEstoqueSituacaoCommand",
											  false,
											  estoqueSaida.getAtributosSaldo(),
											  atributosSaldoEntrada,
											  false,
											  false);

	}

	private EstoqueAlteradoEventMovimentos processarAlteracaoEstoque(Estoque estoqueSaida, // NOSONAR
																	 SKU sku,
																	 EstoqueHash estoqueHash,
																	 String cmdOrigem,
																	 boolean alteraOcupacaoEndereco,
																	 List<EstoqueAtributoSaldo> atributosSaldoSaida,
																	 List<EstoqueAtributoSaldo> atributosSaldoEntrada,
																	 boolean isAlteracaoAtributo,
																	 boolean manterAtributosReserva) {
		return this.processarAlteracaoEstoque(estoqueSaida,
											  sku,
											  sku,
											  estoqueHash,
											  List.of(),
											  estoqueSaida.getSaldo(),
											  cmdOrigem,
											  alteraOcupacaoEndereco,
											  atributosSaldoSaida,
											  atributosSaldoEntrada,
											  isAlteracaoAtributo,
											  manterAtributosReserva);
	}

	private EstoqueAlteradoEventMovimentos processarAlteracaoEstoque(Estoque estoqueSaida, // NOSONAR
																	 SKU skuEstoqueSaida,
																	 SKU skuEstoqueEntrada,
																	 EstoqueHash estoqueHash,
																	 List<ReservaDefinitivaEstoque> reservasDefinitivas,
																	 BigDecimal quantidadeSaida,
																	 String cmdOrigem,
																	 boolean alteraOcupacaoEndereco,
																	 List<EstoqueAtributoSaldo> atributosSaldoSaida,
																	 List<EstoqueAtributoSaldo> atributosSaldoEntrada,
																	 boolean isAlteracaoAtributo,
																	 boolean manterAtributosReserva) {

		if (!isAlteracaoAtributo) {
			var validarHashService = new ValidaEstoqueHashIgualAlteracaoDomainService();
			validarHashService.validar(estoqueSaida, estoqueHash);
		}

		var origem = Origem.of(OrigemId.from(UUID.randomUUID().toString()), cmdOrigem);

		var movimentoEstoqueIdSaida = MovimentoEstoqueId.generate();
		var movimentoEstoqueIdEntrada = MovimentoEstoqueId.generate();

		var produto = produtoRepository.findByIdOrThrowNotFound(estoqueSaida.getProdutoId());

		Estoque estoqueEntrada = null;

		if (isAlteracaoAtributo) {
			estoqueEntrada = estoqueSaida;
		} else {
			estoqueEntrada = configuraEstoqueEntradaService.configurar(produto,
																	   skuEstoqueEntrada,
																	   estoqueHash.getSituacoes().iterator().next(),
																	   estoqueHash,
																	   estoqueSaida.getBloqueioMovimentacaoUnitizadorId()
																				   .orElse(null),
																	   estoqueSaida.getRastreioId(),
																	   estoqueSaida.getSelos(),
																	   estoqueSaida.getDataHoraEntrada());
		}

		MovimentoEstoque movimentoEstoqueSaida = null;

		movimentoEstoqueSaida = estoqueSaida.efetuarSaidaAlteracaoEstoque(origem,
																		  produto,
																		  skuEstoqueSaida,
																		  quantidadeSaida,
																		  reservasDefinitivas,
																		  movimentoEstoqueIdSaida,
																		  movimentoEstoqueIdEntrada,
																		  estoqueEntrada.getRastreioId(),
																		  alteraOcupacaoEndereco,
																		  atributosSaldoSaida);

		atualizaSaldoSaidaService.atualizar(estoqueSaida);

		movimentoEstoqueRepository.insert(movimentoEstoqueSaida);

		MovimentoEstoque movimentoEstoqueEntrada = null;

		movimentoEstoqueEntrada = estoqueEntrada.efetuarEntradaAlteracaoEstoque(produto,
																				skuEstoqueEntrada,
																				quantidadeSaida,
																				reservasDefinitivas,
																				origem,
																				movimentoEstoqueIdEntrada,
																				movimentoEstoqueIdSaida,
																				estoqueSaida.getRastreioId(),
																				alteraOcupacaoEndereco,
																				atributosSaldoEntrada,
																				manterAtributosReserva);

		atualizaSaldoEntradaService.atualizar(estoqueEntrada);

		movimentoEstoqueRepository.insert(movimentoEstoqueEntrada);

		if (!CollectionUtils.isEmpty(reservasDefinitivas))
			reservasDefinitivas.forEach(reserva -> reservaDefinitivaEstoqueRepository.update(reserva));

		estoqueSaida.removeEvents();
		estoqueEntrada.removeEvents();

		var event = EstoqueAlteradoEvent.from(estoqueSaida, estoqueEntrada, reservasDefinitivas);

		return EstoqueAlteradoEventMovimentos.of(event, movimentoEstoqueSaida, movimentoEstoqueEntrada);

	}

	private List<CaracteristicaValor<?>> atualizarValorCaracteristica(List<CaracteristicaValor<?>> caracteristicas,
																	  CaracteristicaConfiguracao caracteristicaConfiguracao,
																	  String valor) {

		var caracteristicasAtualizadas = new ArrayList<>(caracteristicas);

		caracteristicasAtualizadas.removeIf(caracteristica -> caracteristica.getCaracteristicaConfiguracaoId()
																			.equals(caracteristicaConfiguracao.getId()));

		caracteristicasAtualizadas.add(caracteristicaConfiguracao.getFormato()
																 .getInstance(caracteristicaConfiguracao.getId(),
																			  valor));

		return caracteristicasAtualizadas;
	}

	private boolean determinarAlteraOcupacaoEndereco(Endereco endereco) {
		return !endereco.isDoca() && !endereco.isStage();
	}
}
