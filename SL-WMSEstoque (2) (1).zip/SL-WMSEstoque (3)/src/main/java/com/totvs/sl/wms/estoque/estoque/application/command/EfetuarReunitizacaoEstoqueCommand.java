package com.totvs.sl.wms.estoque.estoque.application.command;

import java.math.BigDecimal;
import java.util.List;

import com.totvs.sl.wms.estoque.atributoestoquevalor.domain.model.AtributoEstoqueValor;
import com.totvs.sl.wms.estoque.endereco.domain.model.EnderecoId;
import com.totvs.sl.wms.estoque.estoque.domain.model.EstoqueId;
import com.totvs.sl.wms.estoque.sku.domain.model.SKUId;
import com.totvs.sl.wms.estoque.tipoestoque.domain.model.TipoEstoqueId;
import com.totvs.sl.wms.estoque.unidade.domain.model.UnidadeId;
import com.totvs.sl.wms.estoque.unitizador.domain.model.UnitizadorId;

import lombok.Builder;
import lombok.Data;

@Builder
@Data
public final class EfetuarReunitizacaoEstoqueCommand {

	private final UnidadeId unidadeId;

	private final EstoqueId estoqueId;

	private final Destino destino;

	private final List<AtributoEstoqueValor<?>> atributos;

	@Data
	@Builder
	public static final class Destino {
		private final SKUId skuId;
		private final EnderecoId enderecoId;
		private final UnitizadorId unitizadorId;
		private final TipoEstoqueId tipoEstoqueId;
		private final Boolean avariado;
		private final BigDecimal quantidadeSku;
	}

}
