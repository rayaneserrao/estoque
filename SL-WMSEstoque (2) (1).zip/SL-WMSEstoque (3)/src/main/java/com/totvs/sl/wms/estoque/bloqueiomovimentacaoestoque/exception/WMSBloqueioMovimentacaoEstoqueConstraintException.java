package com.totvs.sl.wms.estoque.bloqueiomovimentacaoestoque.exception;

import com.totvs.tjf.api.context.stereotype.error.ApiBadRequest;

import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;
import java.util.Set;

@ApiBadRequest
public class WMSBloqueioMovimentacaoEstoqueConstraintException extends ConstraintViolationException {

    private static final long serialVersionUID = -8110916833243857918L;

    public WMSBloqueioMovimentacaoEstoqueConstraintException(Set<? extends ConstraintViolation<?>> constraintViolations) {
        super(constraintViolations);
    }
}
