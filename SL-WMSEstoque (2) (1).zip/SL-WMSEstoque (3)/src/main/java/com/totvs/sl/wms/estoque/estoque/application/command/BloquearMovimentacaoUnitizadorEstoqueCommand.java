package com.totvs.sl.wms.estoque.estoque.application.command;

import com.totvs.sl.wms.estoque.endereco.domain.model.EnderecoId;
import com.totvs.sl.wms.estoque.origem.domain.model.Origem;
import com.totvs.sl.wms.estoque.unidade.domain.model.UnidadeId;
import com.totvs.sl.wms.estoque.unitizador.domain.model.UnitizadorId;

import lombok.Builder;
import lombok.Data;
import lombok.NonNull;

@Data
@Builder
public final class BloquearMovimentacaoUnitizadorEstoqueCommand {
	@NonNull
	private final UnidadeId unidadeId;

	@NonNull
	private final UnitizadorId unitizadorId;

	@NonNull
	private final Origem origem;

	private final EnderecoId enderecoIdOrigem;

	private final EnderecoId enderecoIdDestino;

	private final String chaveAcesso;
}
