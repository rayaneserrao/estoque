package com.totvs.sl.wms.estoque.estoque.domain.event;

import java.math.BigDecimal;
import java.util.Collection;
import java.util.List;

import com.totvs.sl.wms.estoque.bloqueiomovimentacaounitizador.domain.model.BloqueioMovimentacaoUnitizador;
import com.totvs.sl.wms.estoque.bloqueiomovimentacaounitizador.domain.model.BloqueioMovimentacaoUnitizadorId;
import com.totvs.sl.wms.estoque.estoque.domain.model.Estoque;
import com.totvs.sl.wms.estoque.estoque.domain.model.EstoqueId;
import com.totvs.sl.wms.estoque.unitizador.domain.model.UnitizadorId;
import com.totvs.sl.wms.estoque.util.amqp.SubjectDomainEvent;

import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
@Builder
public final class EstoqueDesbloqueioMovimentacaoUnitizadorEfetuadoEvent extends SubjectDomainEvent
		implements SubjectBloqueioEstoque {

	private final BloqueioMovimentacaoUnitizadorId id;
	private final UnitizadorId unitizadorId;
	private final List<DesbloqueioMovimentacaoUnitizador> estoques;

	@Data(staticConstructor = "of")
	public static final class DesbloqueioMovimentacaoUnitizador {
		private final EstoqueId estoqueId;
		private final DesbloqueioMovimentacaoUnitizadorQuantidade quantidadeBloqueada;
	}

	@Data(staticConstructor = "of")
	public static final class DesbloqueioMovimentacaoUnitizadorQuantidade {
		private final BigDecimal naoReservada;
		private final BigDecimal reservada;
		private final BigDecimal total;
	}

	public static EstoqueDesbloqueioMovimentacaoUnitizadorEfetuadoEvent from(BloqueioMovimentacaoUnitizador bloqueio,
																			 Collection<Estoque> estoques) {

		return EstoqueDesbloqueioMovimentacaoUnitizadorEfetuadoEvent.builder()
																	.id(bloqueio.getId())
																	.unitizadorId(bloqueio.getUnitizadorId())
																	.estoques(estoques.stream()
																					  .map(EstoqueDesbloqueioMovimentacaoUnitizadorEfetuadoEvent::constroiDesbloqueioMovimentacaoUnitizador)
																					  .toList())
																	.build();
	}

	private static final DesbloqueioMovimentacaoUnitizador constroiDesbloqueioMovimentacaoUnitizador(Estoque estoque) {
		return DesbloqueioMovimentacaoUnitizador.of(estoque.getId(),
													DesbloqueioMovimentacaoUnitizadorQuantidade.of(estoque.getQuantidadeBloqueadaParaMovimentacaoEstoqueNaoReservada(),
																								   estoque.getQuantidadeBloqueadaParaMovimentacaoEstoqueReservada(),
																								   estoque.getQuantidadeBloqueadaParaMovimentacaoEstoqueTotal()));
	}
}
