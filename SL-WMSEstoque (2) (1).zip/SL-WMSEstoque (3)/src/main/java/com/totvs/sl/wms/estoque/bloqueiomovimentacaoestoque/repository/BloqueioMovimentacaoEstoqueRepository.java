package com.totvs.sl.wms.estoque.bloqueiomovimentacaoestoque.repository;

import java.sql.Types;
import java.util.Collection;

import javax.persistence.EntityManager;
import javax.persistence.LockModeType;

import org.springframework.jdbc.core.SqlParameterValue;
import org.springframework.stereotype.Repository;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.totvs.sl.wms.estoque.bloqueiomovimentacaoestoque.domain.model.BloqueioMovimentacaoEstoque;
import com.totvs.sl.wms.estoque.bloqueiomovimentacaoestoque.domain.model.BloqueioMovimentacaoEstoqueDomainRepository;
import com.totvs.sl.wms.estoque.bloqueiomovimentacaoestoque.domain.model.BloqueioMovimentacaoEstoqueId;
import com.totvs.sl.wms.estoque.bloqueiomovimentacaoestoque.exception.WMSBloqueioMovimentacaoEstoqueNaoEncontradoException;
import com.totvs.sl.wms.estoque.endereco.domain.model.EnderecoId;
import com.totvs.sl.wms.estoque.estoque.domain.model.EstoqueId;
import com.totvs.sl.wms.estoque.util.repository.SqlWhereBuilder;
import com.totvs.tjf.repository.aggregate.CrudAggregateRepository;

@Repository
public class BloqueioMovimentacaoEstoqueRepository
		extends CrudAggregateRepository<BloqueioMovimentacaoEstoque, BloqueioMovimentacaoEstoqueId>
		implements BloqueioMovimentacaoEstoqueDomainRepository {

	private static final String CONDICAO_ID = "id = ?";
	private static final String CONDICAO_ESTOQUE_ID = "data ->> 'estoqueId' = ?";
	private static final String CONDICAO_ENDERECO_ID_DESTINO = "data ->> 'enderecoIdDestino' = ?";

	public BloqueioMovimentacaoEstoqueRepository(EntityManager em, ObjectMapper mapper) {
		super(em, mapper.copy());
	}

	@Override
	public BloqueioMovimentacaoEstoque findWithLockByIdOrThrowNotFound(BloqueioMovimentacaoEstoqueId id) {
		var clause = SqlWhereBuilder.builder().where(CONDICAO_ID).build();
		return this.findOne(clause, LockModeType.PESSIMISTIC_READ, new SqlParameterValue(Types.VARCHAR, id))
				   .orElseThrow(WMSBloqueioMovimentacaoEstoqueNaoEncontradoException::new);
	}

	@Override
	public Collection<BloqueioMovimentacaoEstoque> findWithLockByEstoqueId(EstoqueId estoqueId) {
		var clause = SqlWhereBuilder.builder().where(CONDICAO_ESTOQUE_ID).build();
		return this.findAll(clause,
							LockModeType.PESSIMISTIC_READ,
							null,
							new SqlParameterValue(Types.VARCHAR, estoqueId));

	}

	@Override
	public Collection<BloqueioMovimentacaoEstoque> findWithLockByEnderecoIdDestino(EnderecoId enderecoIdDestino) {
		var clause = SqlWhereBuilder.builder().where(CONDICAO_ENDERECO_ID_DESTINO).build();
		return this.findAll(clause,
							LockModeType.PESSIMISTIC_READ,
							null,
							new SqlParameterValue(Types.VARCHAR, enderecoIdDestino));

	}

	@Override
	public Collection<BloqueioMovimentacaoEstoque> findByEnderecoIdDestino(EnderecoId enderecoIdDestino) {
		var clause = SqlWhereBuilder.builder().where(CONDICAO_ENDERECO_ID_DESTINO).build();
		return this.findAll(clause, null, new SqlParameterValue(Types.VARCHAR, enderecoIdDestino));
	}
}
