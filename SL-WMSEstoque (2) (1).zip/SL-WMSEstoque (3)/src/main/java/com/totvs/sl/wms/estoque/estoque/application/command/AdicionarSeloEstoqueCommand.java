package com.totvs.sl.wms.estoque.estoque.application.command;

import com.totvs.sl.wms.estoque.estoque.domain.model.EstoqueId;
import com.totvs.sl.wms.estoque.estoque.domain.model.SeloEstoque;

import lombok.Data;

@Data(staticConstructor = "of")
public final class AdicionarSeloEstoqueCommand {
	private final EstoqueId id;
	private final SeloEstoque selo;
}
