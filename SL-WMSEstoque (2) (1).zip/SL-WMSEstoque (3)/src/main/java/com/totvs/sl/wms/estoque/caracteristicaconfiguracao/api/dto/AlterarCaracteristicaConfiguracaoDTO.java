package com.totvs.sl.wms.estoque.caracteristicaconfiguracao.api.dto;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.totvs.sl.wms.estoque.caracteristicaconfiguracao.domain.model.FormatoCaracteristicaValor;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

@AllArgsConstructor(staticName = "of")
@NoArgsConstructor(force = true)
@Getter
public final class AlterarCaracteristicaConfiguracaoDTO {

	@Schema(description = "Descrição da característica de estoque.", required = true)
	@NotBlank(message = "{AlterarCaracteristicaConfiguracaoDTO.descricao.NotBlank}")
	@Size(min = 1, max = 60, message = "{AlterarCaracteristicaConfiguracaoDTO.descricao.Size}")
	private final String descricao;

	@NotNull(message = "{AlterarCaracteristicaConfiguracaoDTO.formato.NotNull}")
	private final FormatoCaracteristicaValor formato;
}
