package com.totvs.sl.wms.estoque.estoque.domain.model;

import java.util.UUID;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.totvs.tjf.core.common.domain.DomainObjectId;

public final class EstoqueAtributoSaldoId extends DomainObjectId<UUID> {

	private static final long serialVersionUID = 1L;

	protected EstoqueAtributoSaldoId(UUID id) {
		super(id);
	}

	public static EstoqueAtributoSaldoId generate() {
		return new EstoqueAtributoSaldoId(UUID.randomUUID());
	}

	@JsonCreator
	public static EstoqueAtributoSaldoId from(String uuid) {
		return uuid == null ? null : new EstoqueAtributoSaldoId(UUID.fromString(uuid));
	}
}