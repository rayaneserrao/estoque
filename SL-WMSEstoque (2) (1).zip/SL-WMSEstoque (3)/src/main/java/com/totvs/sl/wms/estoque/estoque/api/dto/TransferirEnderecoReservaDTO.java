package com.totvs.sl.wms.estoque.estoque.api.dto;

import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import com.totvs.sl.wms.estoque.atributoestoquevalor.api.dto.AtributoEstoqueValorDTO;
import com.totvs.sl.wms.estoque.endereco.domain.model.EnderecoId;
import com.totvs.sl.wms.estoque.reservadefinitivaestoque.domain.model.ReservaDefinitivaEstoqueId;
import com.totvs.sl.wms.estoque.unidade.domain.model.UnidadeId;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Getter
@Builder
@AllArgsConstructor
@NoArgsConstructor(force = true)
public final class TransferirEnderecoReservaDTO {

	@NotNull(message = "{TransferirEnderecoReservaDTO.unidadeId.NotNull}")
	private final UnidadeId unidadeId;

	@NotNull(message = "{TransferirEnderecoReservaDTO.reservaDefinitivaEstoqueId.NotNull}")
	private final ReservaDefinitivaEstoqueId reservaDefinitivaEstoqueId;

	@NotNull(message = "{TransferirEnderecoReservaDTO.enderecoId.NotNull}")
	private final EnderecoId enderecoId;

	private final OrigemTransferenciaDTO origem;

	@Valid
	private final List<AtributoEstoqueValorDTO> atributos;

	@Getter
	@NoArgsConstructor(force = true)
	@AllArgsConstructor(staticName = "of")
	public static final class OrigemTransferenciaDTO {

		private final String id;
		private final String descricao;

	}
}
