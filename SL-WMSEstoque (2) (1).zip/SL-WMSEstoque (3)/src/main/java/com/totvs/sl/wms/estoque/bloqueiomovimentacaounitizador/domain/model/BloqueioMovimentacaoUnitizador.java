package com.totvs.sl.wms.estoque.bloqueiomovimentacaounitizador.domain.model;

import static com.totvs.tjf.autoconfigure.ValidationUtils.validateIntegrity;

import java.util.Collection;
import java.util.Objects;
import java.util.Optional;

import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import com.totvs.sl.wms.estoque.bloqueiomovimentacaoestoque.exception.WMSEstoqueNaoPertenteAoBloqueioMovimentacaoUnitizadorException;
import com.totvs.sl.wms.estoque.bloqueiomovimentacaounitizador.exception.WMSBloqueioMovimentacaoUnitizadorConstraintException;
import com.totvs.sl.wms.estoque.endereco.domain.model.Endereco;
import com.totvs.sl.wms.estoque.endereco.domain.model.EnderecoId;
import com.totvs.sl.wms.estoque.estoque.domain.event.EstoqueBloqueioMovimentacaoUnitizadorEfetuadoEvent;
import com.totvs.sl.wms.estoque.estoque.domain.event.EstoqueDesbloqueioMovimentacaoUnitizadorEfetuadoEvent;
import com.totvs.sl.wms.estoque.estoque.domain.model.Estoque;
import com.totvs.sl.wms.estoque.estoque.exception.WMSEnderecoBloqueadoParaEntradaEstoqueException;
import com.totvs.sl.wms.estoque.origem.domain.model.Origem;
import com.totvs.sl.wms.estoque.unitizador.domain.model.UnitizadorId;
import com.totvs.tjf.core.stereotype.Aggregate;
import com.totvs.tjf.repository.aggregate.metadata.AggregateDomainMetadataInfo;

import lombok.AccessLevel;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;

@ToString
@Getter
@Aggregate
@Table(name = "bloqueio_movimentacao_unitizador")
@EqualsAndHashCode(callSuper = true)
@NoArgsConstructor(access = AccessLevel.PROTECTED, force = true)
public class BloqueioMovimentacaoUnitizador extends AggregateDomainMetadataInfo<BloqueioMovimentacaoUnitizadorId> {

	@NotNull(message = "{BloqueioMovimentacaoUnitizador.unitizadorId.NotNull}")
	private UnitizadorId unitizadorId;

	@NotNull(message = "{BloqueioMovimentacaoUnitizador.origem.NotNull}")
	private Origem origem;

	private EnderecoId enderecoIdDestino;

	private String chaveAcesso;

	@Builder
	private BloqueioMovimentacaoUnitizador(BloqueioMovimentacaoUnitizadorId id,
										   UnitizadorId unitizadorId,
										   Origem origem,
										   Collection<Estoque> estoques,
										   Endereco enderecoDestino,
										   String chaveAcesso) {
		super(id);
		this.unitizadorId = unitizadorId;
		this.origem = origem;
		this.enderecoIdDestino = Objects.nonNull(enderecoDestino) ? enderecoDestino.getId() : null;
		this.chaveAcesso = chaveAcesso;

		validateIntegrity(this).ifPresent(violations -> {
			throw new WMSBloqueioMovimentacaoUnitizadorConstraintException(violations);
		});

		if (Objects.nonNull(enderecoDestino)
				&& (enderecoDestino.isBloqueadoEntrada() || enderecoDestino.isBloqueadoEntradaSaida()))
			throw new WMSEnderecoBloqueadoParaEntradaEstoqueException();

		estoques.forEach(estoque -> estoque.bloquearMovimentacaoUnitizador(id, chaveAcesso));

		this.registerEvent(EstoqueBloqueioMovimentacaoUnitizadorEfetuadoEvent.from(this, estoques));

	}

	public Optional<EnderecoId> getEnderecoIdDestino() {
		return Optional.ofNullable(this.enderecoIdDestino);
	}

	public void desbloquearEstoques(Collection<Estoque> estoques) {

		if (estoques.stream()
					.anyMatch(estoque -> !estoque.getBloqueioMovimentacaoUnitizadorId().equals(Optional.of(id))))
			throw new WMSEstoqueNaoPertenteAoBloqueioMovimentacaoUnitizadorException();

		estoques.forEach(estoque -> estoque.desbloquearMovimentacaoUnitizador(id));

		this.registerEvent(EstoqueDesbloqueioMovimentacaoUnitizadorEfetuadoEvent.from(this, estoques));
	}
}