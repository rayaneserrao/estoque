package com.totvs.sl.wms.estoque.categoriaproduto.repository;

import java.sql.Types;
import java.util.Optional;

import javax.persistence.EntityManager;

import org.springframework.jdbc.core.SqlParameterValue;
import org.springframework.stereotype.Repository;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.totvs.sl.wms.estoque.categoriaproduto.domain.model.CategoriaProduto;
import com.totvs.sl.wms.estoque.categoriaproduto.domain.model.CategoriaProdutoDomainRepository;
import com.totvs.sl.wms.estoque.categoriaproduto.domain.model.CategoriaProdutoId;
import com.totvs.sl.wms.estoque.categoriaproduto.exception.WMSCategoriaProdutoNaoEncontradaException;
import com.totvs.sl.wms.estoque.util.repository.SqlWhereBuilder;
import com.totvs.tjf.repository.aggregate.CrudAggregateRepository;

@Repository
public class CategoriaProdutoRepository extends CrudAggregateRepository<CategoriaProduto, CategoriaProdutoId>
        implements CategoriaProdutoDomainRepository {

	private static final String CONDICAO_ID = "id = ?";

	private static final String CONDICAO_ID_DIFERENTE = "id != ?";

	private static final String CONDICAO_DESCRICAO = "lower(data ->> 'descricao') = ?";

	public CategoriaProdutoRepository(EntityManager em, ObjectMapper mapper) {
		super(em, mapper.copy());
	}

	@Override
	public Optional<CategoriaProduto> findById(CategoriaProdutoId id) {

		var clause = SqlWhereBuilder.builder().where(CONDICAO_ID).build();

		return this.findOne(clause, new SqlParameterValue(Types.VARCHAR, id));

	}

	@Override
	public CategoriaProduto findByIdOrThrowNotFound(CategoriaProdutoId id) {
		return findById(id).orElseThrow(WMSCategoriaProdutoNaoEncontradaException::new);
	}

	@Override
	public boolean existeCategoriaMesmaDescricao(String descricao) {

		var clause = SqlWhereBuilder.builder().where(CONDICAO_DESCRICAO).build();

		return exists(clause, new SqlParameterValue(Types.VARCHAR, descricao.trim().toLowerCase()));

	}

	@Override
	public boolean existeCategoriaMesmaDescricao(CategoriaProdutoId id, String descricao) {

		var clause = SqlWhereBuilder.builder().where(CONDICAO_ID_DIFERENTE).and(CONDICAO_DESCRICAO).build();

		return exists(clause,
		              new SqlParameterValue(Types.VARCHAR, id),
		              new SqlParameterValue(Types.VARCHAR, descricao.trim().toLowerCase()));

	}
}
