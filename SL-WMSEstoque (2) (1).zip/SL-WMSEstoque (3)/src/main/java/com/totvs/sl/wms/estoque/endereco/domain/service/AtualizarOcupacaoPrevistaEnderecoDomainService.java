package com.totvs.sl.wms.estoque.endereco.domain.service;

import java.math.BigDecimal;
import java.util.Collection;

import org.springframework.stereotype.Service;

import com.totvs.sl.wms.estoque.endereco.domain.model.Endereco;
import com.totvs.sl.wms.estoque.endereco.domain.model.EnderecoDomainRepository;
import com.totvs.sl.wms.estoque.endereco.domain.model.EnderecoId;
import com.totvs.sl.wms.estoque.estoque.domain.model.Estoque;
import com.totvs.sl.wms.estoque.sku.domain.model.SKU;
import com.totvs.sl.wms.estoque.sku.domain.model.SKUDomainRepository;

import lombok.AllArgsConstructor;
import lombok.Data;

@Service
@AllArgsConstructor
public class AtualizarOcupacaoPrevistaEnderecoDomainService {

	private EnderecoDomainRepository enderecoRepository;
	private SKUDomainRepository skuRepository;

	@Data(staticConstructor = "of")
	private static final class PesoCubagem {
		private final BigDecimal peso;
		private final BigDecimal cubagem;
	}

	public Endereco aumentar(EnderecoId enderecoId, SKU sku, BigDecimal quantidade, Integer unitizador) {

		var endereco = enderecoRepository.findByIdOrThrowNotFound(enderecoId);

		if (this.deveAtualizarOcupacaoEndereco(endereco)) {

			// Agora que já sabe que precisa atualizar a capacidade então faz o lock
			endereco = enderecoRepository.findWithLockByIdOrThrowNotFound(endereco.getId());

			endereco.aumentarOcupacaoPrevista(unitizador,
											  sku.getPesoParaQuantidade(quantidade),
											  sku.getCubagemParaQuantidade(quantidade));

			enderecoRepository.update(endereco);
		}

		return endereco;
	}

	public Endereco aumentar(EnderecoId enderecoId, Collection<Estoque> estoques, Integer unitizador) {

		var endereco = enderecoRepository.findByIdOrThrowNotFound(enderecoId);

		if (this.deveAtualizarOcupacaoEndereco(endereco)) {

			// Agora que já sabe que precisa atualizar a capacidade então faz o lock
			endereco = enderecoRepository.findWithLockByIdOrThrowNotFound(enderecoId);

			var pesoCubagemTotal = determinarPesoCubagemTotal(estoques);

			endereco.aumentarOcupacaoPrevista(unitizador, pesoCubagemTotal.getPeso(), pesoCubagemTotal.getCubagem());

			enderecoRepository.update(endereco);

		}

		return endereco;
	}

	public Endereco aumentar(EnderecoId enderecoId, Collection<Estoque> estoques) {
		return this.aumentar(enderecoId, estoques, 1);
	}

	public Endereco aumentar(EnderecoId enderecoId, SKU sku, BigDecimal quantidade) {
		return this.aumentar(enderecoId, sku, quantidade, 0);
	}

	public Endereco diminuir(EnderecoId enderecoId, SKU sku, BigDecimal quantidade, Integer unitizador) {

		var endereco = enderecoRepository.findByIdOrThrowNotFound(enderecoId);

		if (this.deveAtualizarOcupacaoEndereco(endereco)) {

			// Agora que já sabe que precisa atualizar a capacidade então faz o lock
			endereco = enderecoRepository.findWithLockByIdOrThrowNotFound(enderecoId);

			endereco.diminuirOcupacaoPrevista(unitizador,
											  sku.getPesoParaQuantidade(quantidade),
											  sku.getCubagemParaQuantidade(quantidade));

			enderecoRepository.update(endereco);

		}

		return endereco;
	}

	public Endereco diminuir(EnderecoId enderecoId, Collection<Estoque> estoques, Integer unitizador) {

		var endereco = enderecoRepository.findByIdOrThrowNotFound(enderecoId);

		if (this.deveAtualizarOcupacaoEndereco(endereco)) {

			// Agora que já sabe que precisa atualizar a capacidade então faz o lock
			endereco = enderecoRepository.findWithLockByIdOrThrowNotFound(enderecoId);

			var pesoCubagemTotal = determinarPesoCubagemTotal(estoques);

			endereco.diminuirOcupacaoPrevista(unitizador, pesoCubagemTotal.getPeso(), pesoCubagemTotal.getCubagem());

			enderecoRepository.update(endereco);

		}

		return endereco;
	}

	public Endereco diminuir(EnderecoId enderecoId, SKU sku, BigDecimal quantidade) {
		return this.diminuir(enderecoId, sku, quantidade, 0);
	}

	public Endereco diminuir(EnderecoId enderecoId, Collection<Estoque> estoques) {
		return this.diminuir(enderecoId, estoques, 1);
	}

	private PesoCubagem determinarPesoCubagemTotal(Collection<Estoque> estoques) {

		BigDecimal pesoTotal = BigDecimal.ZERO;
		BigDecimal cubagemTotal = BigDecimal.ZERO;

		for (var estoque : estoques) {
			var sku = skuRepository.findByIdOrThrowNotFound(estoque.getSkuId());
			pesoTotal = pesoTotal.add(sku.getPesoParaQuantidade(estoque.getSaldo()));
			cubagemTotal = cubagemTotal.add(sku.getCubagemParaQuantidade(estoque.getSaldo()));
		}

		return PesoCubagem.of(pesoTotal, cubagemTotal);

	}

	private boolean deveAtualizarOcupacaoEndereco(Endereco endereco) {
		return !endereco.isDoca() && !endereco.isStage();
	}
}
