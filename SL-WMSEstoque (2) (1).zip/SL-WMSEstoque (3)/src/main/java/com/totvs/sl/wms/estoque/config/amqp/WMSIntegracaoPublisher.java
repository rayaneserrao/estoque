package com.totvs.sl.wms.estoque.config.amqp;

import java.util.Collection;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.stream.annotation.EnableBinding;

import com.totvs.sl.wms.estoque.config.amqp.WMSChannel.WMSIntegracaoOut;
import com.totvs.tjf.core.security.context.SecurityDetails;
import com.totvs.tjf.messaging.context.TOTVSMessageBuilder;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@EnableBinding(WMSChannel.WMSIntegracaoOut.class)
public class WMSIntegracaoPublisher {

	// Remover o evento dessa lista apenas quando a equipe responsável pelo uso do
	// evento notificar que vez a expansão
	private static final Collection<Class<?>> eventosAguardandoExpansaoLadoIntegracao = List.of();

	@Autowired
	private WMSIntegracaoOut wmsIntegracaoOut;

	public <T> void dispatch(T contentToBeDispatched) {

		if (eventosAguardandoExpansaoLadoIntegracao.contains(contentToBeDispatched.getClass())) {
			log.info("Publishing ignored: {} | TenantId: {}",
					 contentToBeDispatched.toString(),
					 SecurityDetails.getTenant());
			return;
		}

		var totvsMessage = TOTVSMessageBuilder.<T>withDefaultType()
											  .setContent(contentToBeDispatched)
											  .asTOTVSLegacyEvent()
											  .build();

		wmsIntegracaoOut.output().send(totvsMessage);

		log.info("Publishing integration content: {} | TenantId: {}",
				 contentToBeDispatched.toString(),
				 SecurityDetails.getTenant());
	}
}
