package com.totvs.sl.wms.estoque.endereco.amqp;

import java.util.ArrayList;

import org.springframework.cloud.stream.annotation.EnableBinding;
import org.springframework.cloud.stream.annotation.StreamListener;

import com.totvs.sl.wms.estoque.config.amqp.WMSChannel;
import com.totvs.sl.wms.estoque.config.amqp.WMSPublisher;
import com.totvs.sl.wms.estoque.endereco.amqp.cmd.BloquearEntradaEstoqueEnderecoCmd;
import com.totvs.sl.wms.estoque.endereco.amqp.cmd.BloquearEntradaSaidaEstoqueEnderecoCmd;
import com.totvs.sl.wms.estoque.endereco.amqp.cmd.BloquearSaidaEstoqueEnderecoCmd;
import com.totvs.sl.wms.estoque.endereco.amqp.cmd.DesbloquearEntradaEstoqueEnderecoCmd;
import com.totvs.sl.wms.estoque.endereco.amqp.cmd.DesbloquearEntradaSaidaEstoqueEnderecoCmd;
import com.totvs.sl.wms.estoque.endereco.amqp.cmd.DesbloquearSaidaEstoqueEnderecoCmd;
import com.totvs.sl.wms.estoque.endereco.amqp.event.BloquearEntradaEstoqueEnderecoRejeitadoEvent;
import com.totvs.sl.wms.estoque.endereco.amqp.event.BloquearEntradaSaidaEstoqueEnderecoRejeitadoEvent;
import com.totvs.sl.wms.estoque.endereco.amqp.event.BloquearSaidaEstoqueEnderecoRejeitadoEvent;
import com.totvs.sl.wms.estoque.endereco.amqp.event.DesbloquearEntradaEstoqueEnderecoRejeitadoEvent;
import com.totvs.sl.wms.estoque.endereco.amqp.event.DesbloquearEntradaSaidaEstoqueEnderecoRejeitadoEvent;
import com.totvs.sl.wms.estoque.endereco.amqp.event.DesbloquearSaidaEstoqueEnderecoRejeitadoEvent;
import com.totvs.sl.wms.estoque.endereco.application.EnderecoApplicationService;
import com.totvs.sl.wms.estoque.endereco.application.command.BloquearEntradaEstoqueEnderecoCommand;
import com.totvs.sl.wms.estoque.endereco.application.command.BloquearEntradaSaidaEstoqueEnderecoCommand;
import com.totvs.sl.wms.estoque.endereco.application.command.BloquearSaidaEstoqueEnderecoCommand;
import com.totvs.sl.wms.estoque.endereco.application.command.DesbloquearEntradaEstoqueEnderecoCommand;
import com.totvs.sl.wms.estoque.endereco.application.command.DesbloquearEntradaSaidaEstoqueEnderecoCommand;
import com.totvs.sl.wms.estoque.endereco.application.command.DesbloquearSaidaEstoqueEnderecoCommand;
import com.totvs.sl.wms.estoque.endereco.exception.WMSBloquearEntradaEstoqueEnderecoConstraintException;
import com.totvs.sl.wms.estoque.endereco.exception.WMSBloquearEntradaSaidaEstoqueEnderecoConstraintException;
import com.totvs.sl.wms.estoque.endereco.exception.WMSBloquearSaidaEstoqueEnderecoConstraintException;
import com.totvs.sl.wms.estoque.endereco.exception.WMSDesbloquearEntradaEstoqueEnderecoConstraintException;
import com.totvs.sl.wms.estoque.endereco.exception.WMSDesbloquearEntradaSaidaEstoqueEnderecoConstraintException;
import com.totvs.sl.wms.estoque.endereco.exception.WMSDesbloquearSaidaEstoqueEnderecoConstraintException;
import com.totvs.sl.wms.estoque.origem.domain.model.Origem;
import com.totvs.sl.wms.estoque.origem.domain.model.OrigemId;
import com.totvs.sl.wms.estoque.util.amqp.AMQPUtil;
import com.totvs.tjf.api.response.error.converter.ErrorExceptionConverter;
import com.totvs.tjf.core.i18n.I18nService;
import com.totvs.tjf.core.validation.ValidatorService;
import com.totvs.tjf.messaging.context.TOTVSMessage;

import lombok.AllArgsConstructor;

@AllArgsConstructor
@EnableBinding(value = { WMSChannel.WMSBloqueioEnderecoCommandsInput.class,
		WMSChannel.WMSBloqueioEnderecoLoteCommandsInput.class })
public class EnderecoBloqueioCommandsSubscriber {

	private EnderecoApplicationService service;

	private ValidatorService validator;

	private WMSPublisher wmsPublisher;

	private I18nService i18nService;

	@StreamListener(target = WMSChannel.WMS_BLOQUEIO_ENDERECO_LOTE_COMMANDS_IN, condition = BloquearEntradaSaidaEstoqueEnderecoCmd.CONDITIONAL_EXPRESSION)
	public void bloquearEntradaSaidaEstoqueEnderecoLote(final TOTVSMessage<BloquearEntradaSaidaEstoqueEnderecoCmd> message) {

		AMQPUtil.gerarLog(this.getClass(), message, BloquearEntradaSaidaEstoqueEnderecoCmd.CONDITIONAL_EXPRESSION);

		processarBloquearEntradaSaidaEstoqueEnderecoCmd(message);
	}

	@StreamListener(target = WMSChannel.WMS_BLOQUEIO_ENDERECO_COMMANDS_IN, condition = BloquearEntradaSaidaEstoqueEnderecoCmd.CONDITIONAL_EXPRESSION)
	public void bloquearEntradaSaidaEstoqueEndereco(final TOTVSMessage<BloquearEntradaSaidaEstoqueEnderecoCmd> message) {

		AMQPUtil.gerarLog(this.getClass(), message, BloquearEntradaSaidaEstoqueEnderecoCmd.CONDITIONAL_EXPRESSION);

		processarBloquearEntradaSaidaEstoqueEnderecoCmd(message);
	}

	private void processarBloquearEntradaSaidaEstoqueEnderecoCmd(final TOTVSMessage<BloquearEntradaSaidaEstoqueEnderecoCmd> message) {
		var cmd = message.getContent();

		validator.validate(cmd).ifPresent(violations -> {
			throw new WMSBloquearEntradaSaidaEstoqueEnderecoConstraintException(violations);
		});

		var origemId = message.getHeader().getTransactionInfo().getTransactionId();
		var origem = message.getHeader().getTransactionInfo().getGeneratedBy();

		var command = BloquearEntradaSaidaEstoqueEnderecoCommand.builder()
																.id(cmd.getId())
																.origem(Origem.of(OrigemId.from(origemId), origem))
																.chaveAcesso(cmd.getChaveAcesso())
																.bloquearEstoques(cmd.isBloquearEstoques())
																.motivo(cmd.getMotivo())
																.permiteSkuFracionado(cmd.isPermiteSkuFracionado())
																.build();
		try {
			service.handle(command);
		} catch (RuntimeException e) {
			rejeitarBloquearEntradaSaidaEstoqueEnderecoCmd(cmd, e);
		}

	}

	private void rejeitarBloquearEntradaSaidaEstoqueEnderecoCmd(BloquearEntradaSaidaEstoqueEnderecoCmd cmd,
																RuntimeException excecao) {

		var id = excecao.getClass().getSimpleName();

		if (!id.startsWith("WMS")) {
			throw excecao;
		}

		var inconsistencias = new ArrayList<BloquearEntradaSaidaEstoqueEnderecoRejeitadoEvent.Inconsistencia>();

		var erroConverter = new ErrorExceptionConverter(i18nService);
		var erro = erroConverter.convert(excecao).getError();

		inconsistencias.add(BloquearEntradaSaidaEstoqueEnderecoRejeitadoEvent.Inconsistencia.of(id,
																								erro.getMessage(),
																								erro.getDetailedMessage()));

		var eventoRejeicao = new BloquearEntradaSaidaEstoqueEnderecoRejeitadoEvent();

		eventoRejeicao.setEnderecoId(cmd.getId());
		eventoRejeicao.setInconsistencias(inconsistencias);

		wmsPublisher.dispatch(eventoRejeicao);
	}

	@StreamListener(target = WMSChannel.WMS_BLOQUEIO_ENDERECO_LOTE_COMMANDS_IN, condition = DesbloquearEntradaSaidaEstoqueEnderecoCmd.CONDITIONAL_EXPRESSION)
	public void desbloquearEntradaSaidaEstoqueEnderecoLote(final TOTVSMessage<DesbloquearEntradaSaidaEstoqueEnderecoCmd> message) {

		AMQPUtil.gerarLog(this.getClass(), message, DesbloquearEntradaSaidaEstoqueEnderecoCmd.CONDITIONAL_EXPRESSION);

		processarDesbloquearEntradaSaidaEstoqueEnderecoCmd(message);
	}

	@StreamListener(target = WMSChannel.WMS_BLOQUEIO_ENDERECO_COMMANDS_IN, condition = DesbloquearEntradaSaidaEstoqueEnderecoCmd.CONDITIONAL_EXPRESSION)
	public void desbloquearEntradaSaidaEstoqueEndereco(final TOTVSMessage<DesbloquearEntradaSaidaEstoqueEnderecoCmd> message) {

		AMQPUtil.gerarLog(this.getClass(), message, DesbloquearEntradaSaidaEstoqueEnderecoCmd.CONDITIONAL_EXPRESSION);

		processarDesbloquearEntradaSaidaEstoqueEnderecoCmd(message);
	}

	private void processarDesbloquearEntradaSaidaEstoqueEnderecoCmd(final TOTVSMessage<DesbloquearEntradaSaidaEstoqueEnderecoCmd> message) {
		var cmd = message.getContent();

		validator.validate(cmd).ifPresent(violations -> {
			throw new WMSDesbloquearEntradaSaidaEstoqueEnderecoConstraintException(violations);
		});

		var origemId = message.getHeader().getTransactionInfo().getTransactionId();
		var origem = message.getHeader().getTransactionInfo().getGeneratedBy();

		var command = DesbloquearEntradaSaidaEstoqueEnderecoCommand.of(cmd.getId(),
																	   Origem.of(OrigemId.from(origemId), origem),
																	   cmd.getChaveAcesso(),
																	   cmd.isDesbloquearEstoques(),
																	   cmd.isPermiteSkuFracionado());

		try {
			service.handle(command);
		} catch (RuntimeException e) {
			rejeitarDesbloquearEntradaSaidaEstoqueEnderecoCmd(cmd, e);
		}
	}

	private void rejeitarDesbloquearEntradaSaidaEstoqueEnderecoCmd(DesbloquearEntradaSaidaEstoqueEnderecoCmd cmd,
																   RuntimeException excecao) {

		var id = excecao.getClass().getSimpleName();

		if (!id.startsWith("WMS")) {
			throw excecao;
		}

		var inconsistencias = new ArrayList<DesbloquearEntradaSaidaEstoqueEnderecoRejeitadoEvent.Inconsistencia>();

		var erroConverter = new ErrorExceptionConverter(i18nService);
		var erro = erroConverter.convert(excecao).getError();

		inconsistencias.add(DesbloquearEntradaSaidaEstoqueEnderecoRejeitadoEvent.Inconsistencia.of(id,
																								   erro.getMessage(),
																								   erro.getDetailedMessage()));

		var eventoRejeicao = new DesbloquearEntradaSaidaEstoqueEnderecoRejeitadoEvent();

		eventoRejeicao.setEnderecoId(cmd.getId());
		eventoRejeicao.setInconsistencias(inconsistencias);

		wmsPublisher.dispatch(eventoRejeicao);
	}

	@StreamListener(target = WMSChannel.WMS_BLOQUEIO_ENDERECO_COMMANDS_IN, condition = BloquearEntradaEstoqueEnderecoCmd.CONDITIONAL_EXPRESSION)
	public void bloquearEntradaEstoqueEndereco(final TOTVSMessage<BloquearEntradaEstoqueEnderecoCmd> message) {

		AMQPUtil.gerarLog(this.getClass(), message, BloquearEntradaEstoqueEnderecoCmd.CONDITIONAL_EXPRESSION);

		var cmd = message.getContent();

		validator.validate(cmd).ifPresent(violations -> {
			throw new WMSBloquearEntradaEstoqueEnderecoConstraintException(violations);
		});

		var origemId = message.getHeader().getTransactionInfo().getTransactionId();
		var origem = message.getHeader().getTransactionInfo().getGeneratedBy();

		var command = BloquearEntradaEstoqueEnderecoCommand.of(cmd.getId(),
															   Origem.of(OrigemId.from(origemId), origem),
															   cmd.getChaveAcesso());
		try {
			service.handle(command);
		} catch (RuntimeException e) {
			rejeitarBloquearEntradaEstoqueEnderecoCmd(cmd, e);
		}

	}

	private void rejeitarBloquearEntradaEstoqueEnderecoCmd(BloquearEntradaEstoqueEnderecoCmd cmd,
														   RuntimeException excecao) {

		var id = excecao.getClass().getSimpleName();

		if (!id.startsWith("WMS")) {
			throw excecao;
		}

		var inconsistencias = new ArrayList<BloquearEntradaEstoqueEnderecoRejeitadoEvent.Inconsistencia>();

		var erroConverter = new ErrorExceptionConverter(i18nService);
		var erro = erroConverter.convert(excecao).getError();

		inconsistencias.add(BloquearEntradaEstoqueEnderecoRejeitadoEvent.Inconsistencia.of(id,
																						   erro.getMessage(),
																						   erro.getDetailedMessage()));

		var eventoRejeicao = BloquearEntradaEstoqueEnderecoRejeitadoEvent.of(cmd.getId(), inconsistencias);

		wmsPublisher.dispatch(eventoRejeicao);
	}

	@StreamListener(target = WMSChannel.WMS_BLOQUEIO_ENDERECO_COMMANDS_IN, condition = DesbloquearEntradaEstoqueEnderecoCmd.CONDITIONAL_EXPRESSION)
	public void desbloquearEntradaEstoqueEndereco(final TOTVSMessage<DesbloquearEntradaEstoqueEnderecoCmd> message) {

		AMQPUtil.gerarLog(this.getClass(), message, DesbloquearEntradaEstoqueEnderecoCmd.CONDITIONAL_EXPRESSION);

		var cmd = message.getContent();

		validator.validate(cmd).ifPresent(violations -> {
			throw new WMSDesbloquearEntradaEstoqueEnderecoConstraintException(violations);
		});

		var command = DesbloquearEntradaEstoqueEnderecoCommand.of(cmd.getId(), cmd.getChaveAcesso());

		try {
			service.handle(command);
		} catch (RuntimeException e) {
			rejeitarDesbloquearEntradaEstoqueEnderecoCmd(cmd, e);
		}
	}

	private void rejeitarDesbloquearEntradaEstoqueEnderecoCmd(DesbloquearEntradaEstoqueEnderecoCmd cmd,
															  RuntimeException excecao) {

		var id = excecao.getClass().getSimpleName();

		if (!id.startsWith("WMS")) {
			throw excecao;
		}

		var inconsistencias = new ArrayList<DesbloquearEntradaEstoqueEnderecoRejeitadoEvent.Inconsistencia>();

		var erroConverter = new ErrorExceptionConverter(i18nService);
		var erro = erroConverter.convert(excecao).getError();

		inconsistencias.add(DesbloquearEntradaEstoqueEnderecoRejeitadoEvent.Inconsistencia.of(id,
																							  erro.getMessage(),
																							  erro.getDetailedMessage()));

		var eventoRejeicao = DesbloquearEntradaEstoqueEnderecoRejeitadoEvent.of(cmd.getId(), inconsistencias);

		wmsPublisher.dispatch(eventoRejeicao);
	}

	@StreamListener(target = WMSChannel.WMS_BLOQUEIO_ENDERECO_COMMANDS_IN, condition = BloquearSaidaEstoqueEnderecoCmd.CONDITIONAL_EXPRESSION)
	public void bloquearSaidaEstoqueEndereco(final TOTVSMessage<BloquearSaidaEstoqueEnderecoCmd> message) {

		AMQPUtil.gerarLog(this.getClass(), message, BloquearSaidaEstoqueEnderecoCmd.CONDITIONAL_EXPRESSION);

		var cmd = message.getContent();

		validator.validate(cmd).ifPresent(violations -> {
			throw new WMSBloquearSaidaEstoqueEnderecoConstraintException(violations);
		});

		var origemId = message.getHeader().getTransactionInfo().getTransactionId();
		var origem = message.getHeader().getTransactionInfo().getGeneratedBy();

		var command = BloquearSaidaEstoqueEnderecoCommand.of(cmd.getId(),
															 Origem.of(OrigemId.from(origemId), origem),
															 cmd.getChaveAcesso());
		try {
			service.handle(command);
		} catch (RuntimeException e) {
			rejeitarBloquearSaidaEstoqueEnderecoCmd(cmd, e);
		}

	}

	private void rejeitarBloquearSaidaEstoqueEnderecoCmd(BloquearSaidaEstoqueEnderecoCmd cmd,
														 RuntimeException excecao) {

		var id = excecao.getClass().getSimpleName();

		if (!id.startsWith("WMS")) {
			throw excecao;
		}

		var inconsistencias = new ArrayList<BloquearSaidaEstoqueEnderecoRejeitadoEvent.Inconsistencia>();

		var erroConverter = new ErrorExceptionConverter(i18nService);
		var erro = erroConverter.convert(excecao).getError();

		inconsistencias.add(BloquearSaidaEstoqueEnderecoRejeitadoEvent.Inconsistencia.of(id,
																						 erro.getMessage(),
																						 erro.getDetailedMessage()));

		var eventoRejeicao = BloquearSaidaEstoqueEnderecoRejeitadoEvent.of(cmd.getId(), inconsistencias);

		wmsPublisher.dispatch(eventoRejeicao);
	}

	@StreamListener(target = WMSChannel.WMS_BLOQUEIO_ENDERECO_COMMANDS_IN, condition = DesbloquearSaidaEstoqueEnderecoCmd.CONDITIONAL_EXPRESSION)
	public void desbloquearSaidaEstoqueEndereco(final TOTVSMessage<DesbloquearSaidaEstoqueEnderecoCmd> message) {

		AMQPUtil.gerarLog(this.getClass(), message, DesbloquearSaidaEstoqueEnderecoCmd.CONDITIONAL_EXPRESSION);

		var cmd = message.getContent();

		validator.validate(cmd).ifPresent(violations -> {
			throw new WMSDesbloquearSaidaEstoqueEnderecoConstraintException(violations);
		});

		var command = DesbloquearSaidaEstoqueEnderecoCommand.of(cmd.getId(), cmd.getChaveAcesso());

		try {
			service.handle(command);
		} catch (RuntimeException e) {
			rejeitarDesbloquearSaidaEstoqueEnderecoCmd(cmd, e);
		}

	}

	private void rejeitarDesbloquearSaidaEstoqueEnderecoCmd(DesbloquearSaidaEstoqueEnderecoCmd cmd,
															RuntimeException excecao) {

		var id = excecao.getClass().getSimpleName();

		if (!id.startsWith("WMS")) {
			throw excecao;
		}

		var inconsistencias = new ArrayList<DesbloquearSaidaEstoqueEnderecoRejeitadoEvent.Inconsistencia>();

		var erroConverter = new ErrorExceptionConverter(i18nService);
		var erro = erroConverter.convert(excecao).getError();

		inconsistencias.add(DesbloquearSaidaEstoqueEnderecoRejeitadoEvent.Inconsistencia.of(id,
																							erro.getMessage(),
																							erro.getDetailedMessage()));

		var eventoRejeicao = DesbloquearSaidaEstoqueEnderecoRejeitadoEvent.of(cmd.getId(), inconsistencias);

		wmsPublisher.dispatch(eventoRejeicao);
	}

}
