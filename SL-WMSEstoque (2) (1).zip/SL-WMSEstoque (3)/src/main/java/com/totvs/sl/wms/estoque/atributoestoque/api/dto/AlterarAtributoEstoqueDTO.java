package com.totvs.sl.wms.estoque.atributoestoque.api.dto;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.totvs.sl.wms.estoque.atributoestoque.domain.model.ControleQuantidadeAtributoEstoqueValor;
import com.totvs.sl.wms.estoque.atributoestoque.domain.model.FormatoAtributoEstoqueValor;
import com.totvs.tjf.core.validation.ValueOfEnum;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Value;

@AllArgsConstructor(staticName = "of")
@Value
public final class AlterarAtributoEstoqueDTO {

	@Schema(description = "Descrição do atributo de estoque.", required = true)
	@NotBlank(message = "{AlterarAtributoEstoqueDTO.descricao.NotBlank}")
	@Size(min = 1, max = 60, message = "{AlterarAtributoEstoqueDTO.descricao.Size}")
	private final String descricao;

	@Schema(description = "Formato do atributo de estoque.", required = true)
	@NotNull(message = "{AlterarAtributoEstoqueDTO.formato.NotNull}")
	@ValueOfEnum(enumClass = FormatoAtributoEstoqueValor.class, message = "{AlterarAtributoEstoqueDTO.formato.ValueOfENum}")
	private final String formato;

	@Schema(description = "Controle de quantidade do atributo de estoque.", required = true)
	@NotNull(message = "{AlterarAtributoEstoqueDTO.controleQuantidade.NotNull}")
	@ValueOfEnum(enumClass = ControleQuantidadeAtributoEstoqueValor.class, message = "{AlterarAtributoEstoqueDTO.controleQuantidade.ValueOfENum}")
	private final String controleQuantidade;
}
