package com.totvs.sl.wms.estoque.estoque.application.command;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

import org.springframework.util.CollectionUtils;

import com.totvs.sl.wms.estoque.atributoestoquevalor.domain.model.AtributoEstoqueValor;
import com.totvs.sl.wms.estoque.bloqueiomovimentacaounitizador.domain.model.BloqueioMovimentacaoUnitizadorId;
import com.totvs.sl.wms.estoque.estoque.domain.model.Estoque;
import com.totvs.sl.wms.estoque.estoque.domain.model.EstoqueAtributoSaldo;
import com.totvs.sl.wms.estoque.estoque.domain.model.EstoqueId;
import com.totvs.sl.wms.estoque.origem.domain.model.Origem;
import com.totvs.sl.wms.estoque.unidade.domain.model.UnidadeId;

import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;

@Getter
@Builder
@EqualsAndHashCode
public final class DesbloquearEstoqueCommand {
	private final UnidadeId unidadeId;
	private final EstoqueId estoqueId;
	private final BigDecimal quantidade;
	private final String chaveAcesso;
	private final Origem origem;
	private final BloqueioMovimentacaoUnitizadorId bloqueioMovimentacaoUnitizadorId;
	private final List<AtributoEstoqueValor<?>> atributos;

	public Optional<BloqueioMovimentacaoUnitizadorId> getBloqueioMovimentacaoUnitizadorId() {
		return Optional.ofNullable(this.bloqueioMovimentacaoUnitizadorId);
	}

	public List<EstoqueAtributoSaldo> getAtributosSaldo(Estoque estoque) {
		return CollectionUtils.isEmpty(atributos) ? estoque.getAtributosSaldo()
				: List.of(EstoqueAtributoSaldo.of(atributos, quantidade));
	}
}
