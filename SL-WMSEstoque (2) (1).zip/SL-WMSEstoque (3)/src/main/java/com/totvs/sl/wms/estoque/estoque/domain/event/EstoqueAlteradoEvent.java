package com.totvs.sl.wms.estoque.estoque.domain.event;

import java.math.BigDecimal;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.util.CollectionUtils;

import com.totvs.sl.wms.estoque.caracteristicaconfiguracao.domain.model.CaracteristicaConfiguracaoId;
import com.totvs.sl.wms.estoque.caracteristicaconfiguracao.domain.model.FormatoCaracteristicaValor;
import com.totvs.sl.wms.estoque.config.amqp.ConsumeMessage;
import com.totvs.sl.wms.estoque.endereco.domain.model.EnderecoId;
import com.totvs.sl.wms.estoque.estoque.domain.event.EstoqueTransferenciaEnderecoEfetuadaEvent.ReservaDefinitiva;
import com.totvs.sl.wms.estoque.estoque.domain.model.Estoque;
import com.totvs.sl.wms.estoque.estoque.domain.model.EstoqueId;
import com.totvs.sl.wms.estoque.estoque.domain.model.SituacaoEstoque;
import com.totvs.sl.wms.estoque.estoque.domain.model.SituacaoEstoqueBloqueado;
import com.totvs.sl.wms.estoque.estoque.domain.model.SituacaoEstoqueLiberado;
import com.totvs.sl.wms.estoque.estoque.domain.model.SituacaoEstoqueValor;
import com.totvs.sl.wms.estoque.produto.domain.model.ProdutoId;
import com.totvs.sl.wms.estoque.rastreio.domain.model.RastreioId;
import com.totvs.sl.wms.estoque.reservadefinitivaestoque.domain.model.ReservaDefinitivaEstoque;
import com.totvs.sl.wms.estoque.sku.domain.model.SKUId;
import com.totvs.sl.wms.estoque.tipoestoque.domain.model.TipoEstoqueId;
import com.totvs.sl.wms.estoque.unidade.domain.model.UnidadeId;
import com.totvs.sl.wms.estoque.unitizador.domain.model.UnitizadorId;
import com.totvs.sl.wms.estoque.util.amqp.SubjectConfiguracao;
import com.totvs.sl.wms.estoque.util.amqp.SubjectDomainEvent;
import com.totvs.sl.wms.estoque.util.amqp.WMSIntegrationMessage;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.Getter;
import lombok.ToString;

@ToString
@Getter
@Builder(access = AccessLevel.PRIVATE)
@AllArgsConstructor(access = AccessLevel.PRIVATE)
public final class EstoqueAlteradoEvent extends SubjectDomainEvent
		implements SubjectConfiguracao, ConsumeMessage, WMSIntegrationMessage {

	public static final String NAME = "EstoqueAlteradoEvent";
	public static final String CONDITIONAL_EXPRESSION = "headers['type']=='" + NAME + "'";

	private final UnidadeId unidadeId;
	private final EstoqueSaida estoqueSaida;
	private final EstoqueEntrada estoqueEntrada;

	@Data
	@Builder
	public static final class EstoqueSaida {
		private final EstoqueId id;
		private final BigDecimal saldo;
		private final BigDecimal saldoReservado;
		private final BigDecimal saldoDisponivel;
		private final BigDecimal quantidadeBloqueadaMovimentacaoNaoReservada;
		private final BigDecimal quantidadeBloqueadaMovimentacaoReservada;
		private final BigDecimal quantidadeBloqueadaMovimentacaoTotal;
		private final TipoEstoqueId tipoEstoqueId;
		private final Boolean avariado;
		private final List<EstoqueAtributoSaldoEvent> atributosSaldo;
		private final UnitizadorId unitizadorId;
	}

	@Data
	@Builder
	public static final class EstoqueEntrada {
		private final EstoqueId id;
		private final ProdutoId produtoId;
		private final SKUId skuId;
		private final UnitizadorId unitizadorId;
		private final TipoEstoqueId tipoEstoqueId;
		private final EnderecoId enderecoId;
		private final Set<SituacaoEstoqueEntrada> situacoes;
		private final Boolean avariado;
		private final RastreioId rastreioId;
		private final List<CaracteristicaEstoqueEntrada> caracteristicas;
		private final List<EstoqueAtributoSaldoEvent> atributosSaldo;
		private final List<ReservaDefinitiva> reservasDefinitivas;
		private final BigDecimal saldo;
		private final BigDecimal saldoReservado;
		private final BigDecimal saldoDisponivel;
		private final BigDecimal quantidadeBloqueadaMovimentacaoNaoReservada;
		private final BigDecimal quantidadeBloqueadaMovimentacaoReservada;
		private final BigDecimal quantidadeBloqueadaMovimentacaoTotal;
		private final List<SeloEstoqueEvent> selos;
		private final ZonedDateTime dataHoraEntrada;

	}

	@Data(staticConstructor = "of")
	public static final class SituacaoEstoqueEntrada {
		private final SituacaoEstoqueValor situacao;
		private final ZonedDateTime quando;
		private final String chaveAcesso;
		private final String motivo;
	}

	@Data(staticConstructor = "of")
	public static final class CaracteristicaEstoqueEntrada {
		private final CaracteristicaConfiguracaoId caracteristicaConfiguracaoId;
		private final FormatoCaracteristicaValor formato;
		private final String valor;
	}

	@Data(staticConstructor = "of")
	public static final class SeloEstoqueEvent {
		private final String chave;
		private final String valor;
	}

	public static EstoqueAlteradoEvent from(Estoque estoqueOrigem,
											Estoque estoqueDestino,
											List<ReservaDefinitivaEstoque> reservasDefinitivas) {

		return EstoqueAlteradoEvent.builder()
								   .unidadeId(estoqueDestino.getUnidadeId())
								   .estoqueSaida(EstoqueSaida.builder()
															 .id(estoqueOrigem.getId())
															 .saldo(estoqueOrigem.getSaldo())
															 .saldoReservado(estoqueOrigem.getQuantidadeReservada())
															 .saldoDisponivel(estoqueOrigem.getSaldoDisponivel())
															 .quantidadeBloqueadaMovimentacaoNaoReservada(estoqueOrigem.getQuantidadeBloqueadaParaMovimentacaoEstoqueNaoReservada())
															 .quantidadeBloqueadaMovimentacaoReservada(estoqueOrigem.getQuantidadeBloqueadaParaMovimentacaoEstoqueReservada())
															 .quantidadeBloqueadaMovimentacaoTotal(estoqueOrigem.getQuantidadeBloqueadaParaMovimentacaoEstoqueTotal())
															 .tipoEstoqueId(estoqueOrigem.getTipoEstoqueId())
															 .avariado(estoqueOrigem.getAvariado())
															 .atributosSaldo(EstoqueAtributoSaldoEvent.from(estoqueOrigem.getAtributosSaldo()))
															 .unitizadorId(estoqueOrigem.getUnitizadorId())
															 .build())
								   .estoqueEntrada(EstoqueEntrada.builder()
																 .id(estoqueDestino.getId())
																 .produtoId(estoqueDestino.getProdutoId())
																 .skuId(estoqueDestino.getSkuId())
																 .unitizadorId(estoqueDestino.getUnitizadorId())
																 .tipoEstoqueId(estoqueDestino.getTipoEstoqueId())
																 .enderecoId(estoqueDestino.getEnderecoId())
																 .situacoes(montarSituacoesEstoque(estoqueDestino.getSituacoes()))
																 .avariado(estoqueDestino.getAvariado())
																 .caracteristicas(montarCaracteristicas(estoqueDestino))
																 .atributosSaldo(EstoqueAtributoSaldoEvent.from(estoqueDestino.getAtributosSaldo()))
																 .reservasDefinitivas(montarReservasDefinitivasEstoqueDestino(reservasDefinitivas))
																 .rastreioId(estoqueDestino.getRastreioId())
																 .saldo(estoqueDestino.getSaldo())
																 .saldoReservado(estoqueDestino.getQuantidadeReservada())
																 .saldoDisponivel(estoqueDestino.getSaldoDisponivel())
																 .quantidadeBloqueadaMovimentacaoNaoReservada(estoqueDestino.getQuantidadeBloqueadaParaMovimentacaoEstoqueNaoReservada())
																 .quantidadeBloqueadaMovimentacaoReservada(estoqueDestino.getQuantidadeBloqueadaParaMovimentacaoEstoqueReservada())
																 .quantidadeBloqueadaMovimentacaoTotal(estoqueDestino.getQuantidadeBloqueadaParaMovimentacaoEstoqueTotal())
																 .selos(estoqueDestino.getSelos()
																					  .stream()
																					  .map(selo -> SeloEstoqueEvent.of(selo.getChave(),
																													   selo.getValor()))
																					  .collect(Collectors.toList()))
																 .dataHoraEntrada(estoqueDestino.getDataHoraEntrada())
																 .build())
								   .build();

	}

	private static Set<SituacaoEstoqueEntrada> montarSituacoesEstoque(Set<SituacaoEstoque> situacoes) {
		return situacoes.stream().map(EstoqueAlteradoEvent::criar).collect(Collectors.toSet());
	}

	private static SituacaoEstoqueEntrada criar(SituacaoEstoque situacao) {
		return situacao.getSituacaoEstoque().equals(SituacaoEstoqueValor.LIBERADO) ? criarSituacaoLiberado(situacao)
				: criarSituacaoBloqueado(situacao);
	}

	private static SituacaoEstoqueEntrada criarSituacaoLiberado(SituacaoEstoque situacao) {
		var situacaoLiberado = (SituacaoEstoqueLiberado) situacao;
		return SituacaoEstoqueEntrada.of(SituacaoEstoqueValor.LIBERADO, situacaoLiberado.getQuando(), null, null);
	}

	private static SituacaoEstoqueEntrada criarSituacaoBloqueado(SituacaoEstoque situacao) {
		var situacaoBloqueado = (SituacaoEstoqueBloqueado) situacao;
		return SituacaoEstoqueEntrada.of(SituacaoEstoqueValor.BLOQUEADO,
										 situacaoBloqueado.getQuando(),
										 situacaoBloqueado.getChaveAcesso(),
										 situacaoBloqueado.getMotivo());
	}

	private static List<CaracteristicaEstoqueEntrada> montarCaracteristicas(Estoque estoque) {
		if (CollectionUtils.isEmpty(estoque.getCaracteristicas())) {
			return new ArrayList<>();
		}
		return estoque.getCaracteristicas()
					  .stream()
					  .map(caracteristica -> CaracteristicaEstoqueEntrada.of(caracteristica.getCaracteristicaConfiguracaoId(),
																			 caracteristica.getFormato(),
																			 caracteristica.getValor().toString()))
					  .collect(Collectors.toList());
	}

	private static List<ReservaDefinitiva> montarReservasDefinitivasEstoqueDestino(List<ReservaDefinitivaEstoque> reservasDefinitivas) {
		if (CollectionUtils.isEmpty(reservasDefinitivas)) {
			return new ArrayList<>();
		}
		return reservasDefinitivas.stream()
								  .map(reserva -> ReservaDefinitiva.of(reserva.getId(), reserva.getQuantidade()))
								  .toList();
	}
}
