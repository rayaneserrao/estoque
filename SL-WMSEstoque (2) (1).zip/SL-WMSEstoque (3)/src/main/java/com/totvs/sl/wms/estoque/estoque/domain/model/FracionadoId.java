package com.totvs.sl.wms.estoque.estoque.domain.model;

import java.util.UUID;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.totvs.tjf.core.common.domain.DomainObjectId;

public final class FracionadoId extends DomainObjectId<UUID> {

	private static final long serialVersionUID = 2520644164660652168L;

	protected FracionadoId(UUID id) {
		super(id);
	}

	public static FracionadoId generate() {
		return new FracionadoId(UUID.randomUUID());
	}

	@JsonCreator
	public static FracionadoId from(String uuid) {
		return uuid == null ? null : new FracionadoId(UUID.fromString(uuid));
	}
}