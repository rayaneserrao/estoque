package com.totvs.sl.wms.estoque.caracteristicaconfiguracao.amqp.cmd;

import javax.validation.constraints.NotNull;

import com.totvs.sl.wms.estoque.caracteristicaconfiguracao.domain.model.CaracteristicaConfiguracaoId;
import com.totvs.sl.wms.estoque.util.amqp.EstoqueOutput;
import com.totvs.sl.wms.estoque.util.amqp.SubjectConfiguracao;
import com.totvs.sl.wms.estoque.util.amqp.TransactionalCmd;

import lombok.Getter;
import lombok.ToString;

@Getter
@ToString
public final class MarcarUtilizacaoCaracteristicaConfiguracaoCmd extends TransactionalCmd
		implements SubjectConfiguracao, EstoqueOutput {

	public static final String NAME = "MarcarUtilizacaoCaracteristicaConfiguracaoCmd";

	public static final String CONDITIONAL_EXPRESSION = "headers['type']=='" + NAME + "'";

	@NotNull(message = "{MarcarUtilizacaoCaracteristicaConfiguracaoCmd.id.NotNull}")
	private final CaracteristicaConfiguracaoId id;

	private MarcarUtilizacaoCaracteristicaConfiguracaoCmd(String generatedBy,
														  String transactionId,
														  CaracteristicaConfiguracaoId id) {
		super(generatedBy, transactionId);
		this.id = id;
	}

	public static MarcarUtilizacaoCaracteristicaConfiguracaoCmd of(String generatedBy,
																   String transactionId,
																   CaracteristicaConfiguracaoId id) {

		return new MarcarUtilizacaoCaracteristicaConfiguracaoCmd(generatedBy, transactionId, id);
	}

}
