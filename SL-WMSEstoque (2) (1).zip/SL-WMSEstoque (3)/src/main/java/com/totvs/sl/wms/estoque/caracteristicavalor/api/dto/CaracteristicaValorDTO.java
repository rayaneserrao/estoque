package com.totvs.sl.wms.estoque.caracteristicavalor.api.dto;

import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import org.springframework.util.CollectionUtils;

import com.totvs.sl.wms.estoque.caracteristicaconfiguracao.domain.model.CaracteristicaConfiguracaoId;
import com.totvs.sl.wms.estoque.caracteristicaconfiguracao.domain.model.FormatoCaracteristicaValor;
import com.totvs.sl.wms.estoque.caracteristicavalor.domain.model.CaracteristicaValor;
import com.totvs.sl.wms.estoque.caracteristicavalor.domain.model.CaracteristicaValorTexto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data(staticConstructor = "of")
public final class CaracteristicaValorDTO {

	@Schema(description = "Identificador da característica de estoque.", required = true)
	@NotNull(message = "{CaracteristicaValorDTO.caracteristicaConfiguracaoId.NotNull}")
	private final CaracteristicaConfiguracaoId caracteristicaConfiguracaoId;

	@Schema(description = "Valor do conteúdo da característica de estoque.", required = true)
	@NotBlank(message = "{CaracteristicaValorDTO.valor.NotBlank}")
	private final String valor;

	@Schema(description = "Formato da característica de estoque.")
	private final FormatoCaracteristicaValor formato;

	public static List<CaracteristicaValor<?>> from(List<CaracteristicaValorDTO> caracteristicas) {

		if (CollectionUtils.isEmpty(caracteristicas))
			return Collections.emptyList();

		// TODO retirar esse if quando for eliminado o método fromOld
		if (caracteristicas.stream().anyMatch(caracteristica -> Objects.isNull(caracteristica.getFormato())))
			return Collections.emptyList();

		return caracteristicas.stream()
							  .map(caracteristica -> caracteristica.getFormato()
																   .getInstance(caracteristica.getCaracteristicaConfiguracaoId(),
																				caracteristica.getValor()))
							  .collect(Collectors.toList());
	}

	@Deprecated(forRemoval = true)
	public static List<CaracteristicaValorTexto> fromOld(List<CaracteristicaValorDTO> caracteristicas) {

		if (CollectionUtils.isEmpty(caracteristicas))
			return Collections.emptyList();

		if (caracteristicas.stream().anyMatch(caracteristica -> Objects.isNull(caracteristica.getFormato())))
			return caracteristicas.stream()
								  .filter(caracteristica -> caracteristica.getFormato() == null)
								  .map(caracteristica -> CaracteristicaValorTexto.builder()
																				 .caracteristicaConfiguracaoId(caracteristica.getCaracteristicaConfiguracaoId())
																				 .valor(caracteristica.getValor())
																				 .build())
								  .toList();
		else
			return Collections.emptyList();
	}
}
