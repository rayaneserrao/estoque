package com.totvs.sl.wms.estoque.categoriaproduto.api.dto;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor(access = AccessLevel.PRIVATE, force = true)
@AllArgsConstructor(access = AccessLevel.PRIVATE)
public final class AlterarCategoriaProdutoDTO {

	@NotBlank(message = "{AlterarCategoriaProdutoDTO.descricao.NotBlank}")
	@Size(max = 60, message = "{AlterarCategoriaProdutoDTO.descricao.Size}")
	private final String descricao;
}
