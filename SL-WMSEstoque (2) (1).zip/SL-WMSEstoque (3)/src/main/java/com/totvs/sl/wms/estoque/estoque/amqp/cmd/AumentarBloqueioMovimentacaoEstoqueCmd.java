package com.totvs.sl.wms.estoque.estoque.amqp.cmd;

import static com.totvs.sl.wms.estoque.util.Constants.QUANTIDADE_MAXIMA_DECIMAIS;
import static com.totvs.sl.wms.estoque.util.Constants.QUANTIDADE_MAXIMA_INTEIROS;

import java.math.BigDecimal;

import javax.validation.constraints.Digits;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Positive;

import com.totvs.sl.wms.estoque.bloqueiomovimentacaoestoque.domain.model.BloqueioMovimentacaoEstoqueId;
import com.totvs.sl.wms.estoque.estoque.domain.model.EstoqueId;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public final class AumentarBloqueioMovimentacaoEstoqueCmd {

	public static final String NAME = "AumentarBloqueioMovimentacaoEstoqueCmd";

	public static final String CONDITIONAL_EXPRESSION = "headers['type']=='" + NAME + "'";

	@NotNull(message = "{AumentarBloqueioMovimentacaoEstoqueCmd.estoqueId.NotNull}")
	private final EstoqueId estoqueId;

	@NotNull(message = "{AumentarBloqueioMovimentacaoEstoqueCmd.bloqueioMovimentacaoEstoqueId.NotNull}")
	private final BloqueioMovimentacaoEstoqueId bloqueioMovimentacaoEstoqueId;

	@NotNull(message = "{AumentarBloqueioMovimentacaoEstoqueCmd.quantidade.NotNull}")
	@Positive(message = "{AumentarBloqueioMovimentacaoEstoqueCmd.quantidade.Positive}")
	@Digits(fraction = QUANTIDADE_MAXIMA_DECIMAIS, integer = QUANTIDADE_MAXIMA_INTEIROS, message = "{AumentarBloqueioMovimentacaoEstoqueCmd.quantidade.Digits}")
	private final BigDecimal quantidade;

}
