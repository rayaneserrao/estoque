package com.totvs.sl.wms.estoque.estoque.domain.model;

import java.util.Collection;
import java.util.Optional;
import java.util.TreeSet;

import com.totvs.sl.wms.estoque.atributoestoque.domain.model.AtributoEstoqueId;
import com.totvs.sl.wms.estoque.bloqueiomovimentacaounitizador.domain.model.BloqueioMovimentacaoUnitizadorId;
import com.totvs.sl.wms.estoque.caracteristicavalor.domain.model.CaracteristicaValorFaixa;
import com.totvs.sl.wms.estoque.endereco.domain.model.EnderecoId;
import com.totvs.sl.wms.estoque.produto.domain.model.ProdutoId;
import com.totvs.sl.wms.estoque.reservadefinitivaestoque.domain.model.ReservaDefinitivaEstoqueId;
import com.totvs.sl.wms.estoque.sku.domain.model.SKUId;
import com.totvs.sl.wms.estoque.tipoestoque.domain.model.TipoEstoqueId;
import com.totvs.sl.wms.estoque.unidade.domain.model.UnidadeId;
import com.totvs.sl.wms.estoque.unitizador.domain.model.UnitizadorId;
import com.totvs.tjf.repository.aggregate.AggregateRepository;

public interface EstoqueDomainRepository extends AggregateRepository<Estoque, EstoqueId> {

	Optional<Estoque> findWithLockById(EstoqueId id);

	Optional<Estoque> findWithLockByHash(String hash);

	Estoque findWithLockByIdOrThrowNotFound(EstoqueId id);

	Estoque findWithLockByIdAndUnidadeIdOrThrowNotFound(EstoqueId id, UnidadeId unidadeId);

	Collection<Estoque> findWithLockByUnitizadorIdAndUnidadeId(UnitizadorId unitizadorId, UnidadeId unidadeId);

	Collection<Estoque> findByUnitizadorIdAndUnidadeId(UnitizadorId unitizadorId, UnidadeId unidadeId);

	Collection<Estoque> findWithLockByProdutoId(ProdutoId produtoId);

	Collection<Estoque> findWithLockByEnderecoId(EnderecoId enderecoId);

	boolean existeEstoqueComSaldoEUnitizadorEmOutroEndereco(UnidadeId unidadeId,
															UnitizadorId unitizadorId,
															EnderecoId enderecoId);

	boolean existeEstoqueComSaldoEUnitizadorEmOutroEndereco(UnidadeId unidadeId,
															UnitizadorId unitizadorId,
															EnderecoId enderecoIdOrigem,
															EnderecoId enderecoIdDestino);

	boolean existeOutroEstoqueComUnitizadorEmOutroEndereco(EstoqueId id,
														   UnidadeId unidadeId,
														   UnitizadorId unitizadorId,
														   EnderecoId enderecoId);

	boolean existeEstoqueComUnidadeIdEUnitizador(UnidadeId unidadeId, UnitizadorId unitizadorId);

	boolean existeEstoquePara(ProdutoId produtoId);

	boolean existeEstoqueBloqueadoComChaveAcessoPara(ProdutoId produtoId);

	boolean existeEstoqueReservadoPara(ProdutoId produtoId);

	boolean existeEstoqueBloqueadoMovimentacaoPara(ProdutoId produtoId);

	boolean existeEstoqueBloqueadoComChaveAcessoPara(SKUId skuId);

	boolean existeEstoqueReservadoPara(SKUId skuId);

	boolean existeEstoqueBloqueadoMovimentacaoPara(SKUId skuId);

	Collection<Estoque> findBy(UnidadeId unidadeId,
							   SKUId skuId,
							   TipoEstoqueId tipoEstoqueId,
							   EnderecoId enderecoId,
							   Boolean avariado,
							   TreeSet<CaracteristicaValorFaixa<?>> caracteristicasValor);

	Collection<Estoque> findByUnidadeIdAndUnitizadorId(UnidadeId unidadeId, UnitizadorId unitizadorId);

	Estoque findWithLockByReservaDefinitivaEstoqueIdOrThrowNotFound(ReservaDefinitivaEstoqueId reservaDefinitivaEstoqueId);

	boolean existeEstoqueComUnitizadorIdAndEnderecoIdAndUnidadeId(UnidadeId unidadeId,
																  EnderecoId enderecoId,
																  UnitizadorId unitizadorId);

	Collection<Estoque> findWithLockByBloqueioMovimentacaoUnitizadorId(BloqueioMovimentacaoUnitizadorId bloqueioMovimentacaoUnitizadorId);

	Collection<Estoque> findByEnderecoId(EnderecoId enderecoId);

	Collection<Estoque> findBySKUIdAndUnitizadorIdIsNotNull(SKUId skuId);

	Collection<Estoque> findBySKUId(SKUId skuId);

	Estoque findByIdOrThrowNotFound(EstoqueId id);

	Collection<Estoque> findByUnitizadorIdOrThrowNotFound(UnitizadorId unitizadorId);

	boolean existsByUnitizadorIdAndEnderecoId(UnitizadorId unitizadorId, EnderecoId enderecoId);

	boolean existsByBloqueioMovimentacaoUnitizadorId(BloqueioMovimentacaoUnitizadorId bloqueioMovimentacaoUnitizadorId);

	Collection<Estoque> findAllFirstFiftyForResetStockOrderedById(UnidadeId unidadeId);

	boolean existsAtributoSerialRepetidoByProdutoIdAndAtributoIdAndValor(ProdutoId produtoId,
																		 AtributoEstoqueId atributoEstoqueId,
																		 String valor);

}
