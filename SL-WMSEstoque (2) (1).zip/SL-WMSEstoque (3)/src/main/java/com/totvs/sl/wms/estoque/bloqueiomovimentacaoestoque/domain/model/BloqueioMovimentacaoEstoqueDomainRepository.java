package com.totvs.sl.wms.estoque.bloqueiomovimentacaoestoque.domain.model;

import java.util.Collection;

import com.totvs.sl.wms.estoque.endereco.domain.model.EnderecoId;
import com.totvs.sl.wms.estoque.estoque.domain.model.EstoqueId;
import com.totvs.tjf.repository.aggregate.AggregateRepository;

public interface BloqueioMovimentacaoEstoqueDomainRepository
		extends AggregateRepository<BloqueioMovimentacaoEstoque, BloqueioMovimentacaoEstoqueId> {

	BloqueioMovimentacaoEstoque findWithLockByIdOrThrowNotFound(BloqueioMovimentacaoEstoqueId id);

	Collection<BloqueioMovimentacaoEstoque> findWithLockByEstoqueId(EstoqueId estoqueId);

	Collection<BloqueioMovimentacaoEstoque> findWithLockByEnderecoIdDestino(EnderecoId enderecoIdDestino);

	Collection<BloqueioMovimentacaoEstoque> findByEnderecoIdDestino(EnderecoId enderecoIdDestino);

}
