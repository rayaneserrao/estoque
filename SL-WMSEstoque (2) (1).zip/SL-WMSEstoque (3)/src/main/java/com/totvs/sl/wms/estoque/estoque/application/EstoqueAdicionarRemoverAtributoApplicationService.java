package com.totvs.sl.wms.estoque.estoque.application;

import java.util.ArrayList;
import java.util.List;
import java.util.TreeSet;
import java.util.UUID;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import com.totvs.sl.wms.estoque.atributoestoque.domain.model.AtributoEstoqueDomainRepository;
import com.totvs.sl.wms.estoque.atributoestoque.domain.model.AtributoEstoqueId;
import com.totvs.sl.wms.estoque.atributoestoquevalor.domain.model.AtributoEstoqueValor;
import com.totvs.sl.wms.estoque.config.amqp.WMSPublisher;
import com.totvs.sl.wms.estoque.estoque.application.command.AdicionarAtributoEstoqueCommand;
import com.totvs.sl.wms.estoque.estoque.application.command.RemoverAtributoEstoqueCommand;
import com.totvs.sl.wms.estoque.estoque.domain.event.EstoqueSaldoAtualizadoEvent;
import com.totvs.sl.wms.estoque.estoque.domain.model.Estoque;
import com.totvs.sl.wms.estoque.estoque.domain.model.EstoqueAtributoSaldo;
import com.totvs.sl.wms.estoque.estoque.domain.model.EstoqueDomainRepository;
import com.totvs.sl.wms.estoque.estoque.domain.model.SituacaoEstoqueBloqueado;
import com.totvs.sl.wms.estoque.estoque.domain.service.AtualizaSaldoEstoqueEntradaDomainService;
import com.totvs.sl.wms.estoque.estoque.domain.service.AtualizaSaldoEstoqueSaidaDomainService;
import com.totvs.sl.wms.estoque.estoque.domain.service.ValidaInformacoesBasicasEstoqueDomainService;
import com.totvs.sl.wms.estoque.estoque.exception.WMSEstoqueBloqueadoComChaveAcessoNaoPodeTerAtributoAdicionadoException;
import com.totvs.sl.wms.estoque.estoque.exception.WMSEstoqueBloqueadoComChaveAcessoNaoPodeTerAtributoRemovidoException;
import com.totvs.sl.wms.estoque.movimentoestoque.domain.model.MovimentoEstoque;
import com.totvs.sl.wms.estoque.movimentoestoque.domain.model.MovimentoEstoqueDomainRepository;
import com.totvs.sl.wms.estoque.movimentoestoque.domain.model.MovimentoEstoqueId;
import com.totvs.sl.wms.estoque.origem.domain.model.Origem;
import com.totvs.sl.wms.estoque.origem.domain.model.OrigemId;
import com.totvs.sl.wms.estoque.produto.domain.model.ProdutoDomainRepository;
import com.totvs.sl.wms.estoque.produto.domain.model.ProdutoId;
import com.totvs.sl.wms.estoque.sku.domain.model.SKUDomainRepository;

import lombok.AllArgsConstructor;

@Service
@Transactional
@AllArgsConstructor
public class EstoqueAdicionarRemoverAtributoApplicationService {

	private final MovimentoEstoqueDomainRepository movimentoEstoqueRepository;
	private final EstoqueDomainRepository estoqueRepository;
	private final ProdutoDomainRepository produtoRepository;
	private final SKUDomainRepository skuRepository;
	private final AtributoEstoqueDomainRepository atributoRepository;
	private final ValidaInformacoesBasicasEstoqueDomainService validaInformacoesBasicasService;
	private final AtualizaSaldoEstoqueEntradaDomainService atualizaSaldoEntradaService;
	private final AtualizaSaldoEstoqueSaidaDomainService atualizaSaldoSaidaService;
	private final WMSPublisher publisher;

	public EstoquesSaidaEntradaMovimentoLista handle(final AdicionarAtributoEstoqueCommand cmd) {

		validaInformacoesBasicasService.existeProdutoAtivo(cmd.getProdutoId());

		var listaEstoquesOrigem = estoqueRepository.findWithLockByProdutoId(cmd.getProdutoId());

		List<EstoqueSaida> estoquesSaida = new ArrayList<>();
		List<Estoque> estoquesEntrada = new ArrayList<>();
		List<MovimentoEstoque> movimentosSaida = new ArrayList<>();
		List<MovimentoEstoque> movimentosEntrada = new ArrayList<>();

		for (var estoqueSaida : listaEstoquesOrigem) {

			if (this.verificarEstoqueBloqueadoComChaveAcessoESemNovoAtributo(estoqueSaida, cmd.getId())) {
				throw new WMSEstoqueBloqueadoComChaveAcessoNaoPodeTerAtributoAdicionadoException();
			}

			if (this.verificarEstoqueContemAtributo(estoqueSaida, cmd.getId()))
				continue;

			var origem = Origem.of(OrigemId.from(UUID.randomUUID().toString()), "AdicionarAtributoEstoqueCommand");

			var estoquesMovimentos = this.adicionarAtributoEstoque(estoqueSaida,
																   cmd.getId(),
																   cmd.getValorPadrao(),
																   origem);

			movimentosSaida.add(estoquesMovimentos.getMovimentoSaida());
			movimentosEntrada.add(estoquesMovimentos.getMovimentoEntrada());
			estoquesSaida.add(estoquesMovimentos.getEstoques().getEstoqueSaida());
			estoquesMovimentos.removerEstoqueComSaldoDesatualizado(estoquesEntrada);
			estoquesEntrada.add(estoquesMovimentos.getEstoques().getEstoqueEntrada());

		}

		this.publicarEventosAtualizacaoAtributo(cmd.getProdutoId(),
												estoquesSaida,
												estoquesEntrada,
												movimentosSaida,
												movimentosEntrada);

		return new EstoquesSaidaEntradaMovimentoLista(estoquesSaida,
													  estoquesEntrada,
													  movimentosSaida,
													  movimentosEntrada);

	}

	public EstoquesSaidaEntradaMovimentoLista handle(final RemoverAtributoEstoqueCommand cmd) {

		validaInformacoesBasicasService.existeProdutoAtivo(cmd.getProdutoId());

		var listaEstoquesOrigem = estoqueRepository.findWithLockByProdutoId(cmd.getProdutoId());

		List<EstoqueSaida> estoquesSaida = new ArrayList<>();
		List<Estoque> estoquesEntrada = new ArrayList<>();
		List<MovimentoEstoque> movimentosSaida = new ArrayList<>();
		List<MovimentoEstoque> movimentosEntrada = new ArrayList<>();

		for (var estoqueSaida : listaEstoquesOrigem) {

			if (this.verificarEstoqueBloqueadoComChaveAcessoEAtributoRemovido(estoqueSaida, cmd.getId())) {
				throw new WMSEstoqueBloqueadoComChaveAcessoNaoPodeTerAtributoRemovidoException();
			}

			if (!this.verificarEstoqueContemAtributo(estoqueSaida, cmd.getId()))
				continue;

			var origem = Origem.of(OrigemId.from(UUID.randomUUID().toString()), "RemoverAtributoEstoqueCommand");

			var estoquesMovimentos = this.removerAtributoEstoque(estoqueSaida, cmd.getId(), origem);

			movimentosSaida.add(estoquesMovimentos.getMovimentoSaida());
			movimentosEntrada.add(estoquesMovimentos.getMovimentoEntrada());
			estoquesSaida.add(estoquesMovimentos.getEstoques().getEstoqueSaida());
			estoquesMovimentos.removerEstoqueComSaldoDesatualizado(estoquesEntrada);
			estoquesEntrada.add(estoquesMovimentos.getEstoques().getEstoqueEntrada());

		}

		this.publicarEventosAtualizacaoAtributo(cmd.getProdutoId(),
												estoquesSaida,
												estoquesEntrada,
												movimentosSaida,
												movimentosEntrada);

		return new EstoquesSaidaEntradaMovimentoLista(estoquesSaida,
													  estoquesEntrada,
													  movimentosSaida,
													  movimentosEntrada);
	}

	private EstoquesSaidaEntradaMovimentos adicionarAtributoEstoque(Estoque estoqueSaida,
																	AtributoEstoqueId atributoEstoqueId,
																	String valorPadrao,
																	Origem origem) {

		var saldoAMovimentar = estoqueSaida.getSaldo();

		var produto = produtoRepository.findByIdOrThrowNotFound(estoqueSaida.getProdutoId());

		var sku = skuRepository.findByIdAndProdutoIdThrowNotFound(estoqueSaida.getSkuId(), estoqueSaida.getProdutoId());

		var movimentoEstoqueIdSaida = MovimentoEstoqueId.generate();
		var movimentoEstoqueIdEntrada = MovimentoEstoqueId.generate();

		var atributo = atributoRepository.findByIdOrThrowNotFound(atributoEstoqueId);

		var valores = new TreeSet<String>();
		valores.add(valorPadrao);

		var atributoEntrada = atributo.getFormato()
									  .getInstance(atributoEstoqueId, valores, atributo.getControleQuantidade());

		var novaListaAtributos = new ArrayList<>(estoqueSaida.getAtributosSaldo());

		if (CollectionUtils.isEmpty(novaListaAtributos))
			novaListaAtributos.add(EstoqueAtributoSaldo.of(List.of(atributoEntrada), saldoAMovimentar));
		else
			novaListaAtributos.forEach(atributoSaldo -> atributoSaldo.getAtributos().add(atributoEntrada));

		var estoqueEntrada = estoqueSaida;

		var movimentoEstoqueSaida = estoqueSaida.efetuarSaidaSaldoTotal(origem,
																		movimentoEstoqueIdSaida,
																		movimentoEstoqueIdEntrada,
																		estoqueEntrada.getRastreioId(),
																		false);

		atualizaSaldoSaidaService.atualizar(estoqueSaida);

		var movimentoEstoqueEntrada = estoqueEntrada.efetuarEntradaAdicaoAtributo(produto,
																				  sku,
																				  saldoAMovimentar,
																				  origem,
																				  movimentoEstoqueIdEntrada,
																				  movimentoEstoqueIdSaida,
																				  estoqueSaida.getRastreioId(),
																				  false,
																				  novaListaAtributos);
		atualizaSaldoEntradaService.atualizar(estoqueEntrada);

		movimentoEstoqueRepository.insert(movimentoEstoqueSaida);
		movimentoEstoqueRepository.insert(movimentoEstoqueEntrada);

		estoqueSaida.removeEvents();
		estoqueEntrada.removeEvents();

		return EstoquesSaidaEntradaMovimentos.of(EstoqueSaidaEntrada.of(estoqueSaida.getUnidadeId(),
																		EstoqueSaida.from(estoqueSaida),
																		estoqueEntrada),
												 movimentoEstoqueSaida,
												 movimentoEstoqueEntrada);
	}

	private EstoquesSaidaEntradaMovimentos removerAtributoEstoque(Estoque estoqueSaida,
																  AtributoEstoqueId atributoEstoqueId,
																  Origem origem) {

		var saldoAMovimentar = estoqueSaida.getSaldo();

		var produto = produtoRepository.findByIdOrThrowNotFound(estoqueSaida.getProdutoId());

		var sku = skuRepository.findByIdAndProdutoIdThrowNotFound(estoqueSaida.getSkuId(), estoqueSaida.getProdutoId());

		var movimentoEstoqueIdSaida = MovimentoEstoqueId.generate();
		var movimentoEstoqueIdEntrada = MovimentoEstoqueId.generate();

		List<EstoqueAtributoSaldo> novaListaAtributos = new ArrayList<>();
		for (EstoqueAtributoSaldo atributoSaldo : estoqueSaida.getAtributosSaldo()) {
			List<AtributoEstoqueValor<?>> atributosEstoqueValor = new ArrayList<>();
			for (AtributoEstoqueValor<?> atributoEstoqueValor : atributoSaldo.getAtributos()) {
				if (!atributoEstoqueId.equals(atributoEstoqueValor.getId()))
					atributosEstoqueValor.add(atributoEstoqueValor);
			}
			if (!CollectionUtils.isEmpty(atributosEstoqueValor))
				novaListaAtributos.add(EstoqueAtributoSaldo.of(atributosEstoqueValor, atributoSaldo.getSaldo()));
		}

		var estoqueEntrada = estoqueSaida;

		var movimentoEstoqueSaida = estoqueSaida.efetuarSaidaSaldoTotal(origem,
																		movimentoEstoqueIdSaida,
																		movimentoEstoqueIdEntrada,
																		estoqueEntrada.getRastreioId(),
																		false);

		atualizaSaldoSaidaService.atualizar(estoqueSaida);

		movimentoEstoqueRepository.insert(movimentoEstoqueSaida);

		var movimentoEstoqueEntrada = estoqueEntrada.efetuarEntradaRemocaoAtributo(produto,
																				   sku,
																				   saldoAMovimentar,
																				   origem,
																				   movimentoEstoqueIdEntrada,
																				   movimentoEstoqueIdSaida,
																				   estoqueSaida.getRastreioId(),
																				   false,
																				   novaListaAtributos);

		atualizaSaldoEntradaService.atualizar(estoqueEntrada);

		movimentoEstoqueRepository.insert(movimentoEstoqueEntrada);

		estoqueSaida.removeEvents();
		estoqueEntrada.removeEvents();

		return EstoquesSaidaEntradaMovimentos.of(EstoqueSaidaEntrada.of(estoqueSaida.getUnidadeId(),
																		EstoqueSaida.from(estoqueSaida),
																		estoqueEntrada),
												 movimentoEstoqueSaida,
												 movimentoEstoqueEntrada);
	}

	private boolean verificarEstoqueBloqueadoComChaveAcessoESemNovoAtributo(Estoque estoque,
																			AtributoEstoqueId atributoEstoqueId) {
		if (estoque.isBloqueado()) {
			var situacao = (SituacaoEstoqueBloqueado) estoque.getSituacoes().iterator().next();
			return (situacao.getChaveAcesso() != null
					&& !this.verificarEstoqueContemAtributo(estoque, atributoEstoqueId));
		} else {
			return false;
		}
	}

	private boolean verificarEstoqueBloqueadoComChaveAcessoEAtributoRemovido(Estoque estoque,
																			 AtributoEstoqueId atributoEstoqueId) {
		if (estoque.isBloqueado()) {
			var situacao = (SituacaoEstoqueBloqueado) estoque.getSituacoes().iterator().next();
			return (situacao.getChaveAcesso() != null
					&& this.verificarEstoqueContemAtributo(estoque, atributoEstoqueId));
		} else {
			return false;
		}
	}

	private boolean verificarEstoqueContemAtributo(Estoque estoque, AtributoEstoqueId atributoEstoqueId) {
		return !CollectionUtils.isEmpty(estoque.getAtributosSaldo()
											   .stream()
											   .flatMap(atributoSaldo -> atributoSaldo.getAtributos()
																					  .stream()
																					  .filter(a -> atributoEstoqueId.equals(a.getId())))
											   .toList());
	}

	private void publicarEventosAtualizacaoAtributo(ProdutoId produtoId,
													List<EstoqueSaida> estoquesSaida,
													List<Estoque> estoquesEntrada,
													List<MovimentoEstoque> movimentosSaida,
													List<MovimentoEstoque> movimentosEntrada) {

		movimentosSaida.forEach(movimento -> movimento.getEvents().forEach(publisher::dispatch));
		movimentosEntrada.forEach(movimento -> movimento.getEvents().forEach(publisher::dispatch));
		publisher.dispatch(EstoqueSaldoAtualizadoEvent.from(produtoId, estoquesEntrada, estoquesSaida));
	}
}
