package com.totvs.sl.wms.estoque.atributoestoque.application;

import javax.transaction.Transactional;

import org.springframework.stereotype.Service;

import com.totvs.sl.wms.estoque.atributoestoque.application.command.MarcarUtilizacaoAtributoEstoqueCommand;
import com.totvs.sl.wms.estoque.atributoestoque.domain.model.AtributoEstoqueDomainRepository;

import lombok.AllArgsConstructor;

@Service
@Transactional
@AllArgsConstructor
public class AtributoEstoqueMarcarUtilizacaoApplicationService {

	private AtributoEstoqueDomainRepository repository;

	public void handle(MarcarUtilizacaoAtributoEstoqueCommand cmd) {

		var atributoEstoque = repository.findByIdOrThrowNotFound(cmd.getId());

		atributoEstoque.marcarUtilizado(cmd.getFuncionalidade());

		repository.update(atributoEstoque);
	}

}
