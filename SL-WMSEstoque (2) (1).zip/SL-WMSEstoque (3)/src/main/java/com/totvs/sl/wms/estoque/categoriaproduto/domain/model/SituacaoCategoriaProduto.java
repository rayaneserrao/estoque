package com.totvs.sl.wms.estoque.categoriaproduto.domain.model;

import java.time.ZonedDateTime;

import com.totvs.sl.wms.estoque.util.DateTimeUtils;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor(access = AccessLevel.PRIVATE)
@AllArgsConstructor(access = AccessLevel.PRIVATE)
public class SituacaoCategoriaProduto {
	private SituacaoCategoriaProdutoValor valor;
	private ZonedDateTime quando;

	public static SituacaoCategoriaProduto ofAtivo() {
		return new SituacaoCategoriaProduto(SituacaoCategoriaProdutoValor.ATIVO, DateTimeUtils.getNow());
	}

	public static SituacaoCategoriaProduto ofInativo() {
		return new SituacaoCategoriaProduto(SituacaoCategoriaProdutoValor.INATIVO, DateTimeUtils.getNow());
	}

	public boolean isAtivo() {
		return this.valor.equals(SituacaoCategoriaProdutoValor.ATIVO);
	}

	public boolean isInativo() {
		return this.valor.equals(SituacaoCategoriaProdutoValor.INATIVO);
	}
}
