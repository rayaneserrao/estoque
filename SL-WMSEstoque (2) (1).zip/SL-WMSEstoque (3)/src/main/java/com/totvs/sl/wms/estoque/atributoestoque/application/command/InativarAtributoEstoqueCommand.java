package com.totvs.sl.wms.estoque.atributoestoque.application.command;

import com.totvs.sl.wms.estoque.atributoestoque.domain.model.AtributoEstoqueId;

import lombok.Data;

@Data(staticConstructor = "of")
public final class InativarAtributoEstoqueCommand {

	private final AtributoEstoqueId id;

}
