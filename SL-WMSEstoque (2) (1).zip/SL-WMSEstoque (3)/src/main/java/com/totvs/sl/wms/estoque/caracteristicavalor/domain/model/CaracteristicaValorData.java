package com.totvs.sl.wms.estoque.caracteristicavalor.domain.model;

import static com.totvs.tjf.autoconfigure.ValidationUtils.validateIntegrity;

import java.time.LocalDate;
import java.util.Comparator;

import javax.validation.constraints.NotNull;

import com.totvs.sl.wms.estoque.caracteristicaconfiguracao.domain.model.CaracteristicaConfiguracaoId;
import com.totvs.sl.wms.estoque.caracteristicaconfiguracao.domain.model.FormatoCaracteristicaValor;
import com.totvs.sl.wms.estoque.caracteristicavalor.exception.WMSCaracteristicaValorDataConstraintException;

import lombok.AccessLevel;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Getter
@ToString
@EqualsAndHashCode
@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class CaracteristicaValorData implements CaracteristicaValor<LocalDate> {

	@NotNull(message = "{CaracteristicaValorData.caracteristicaConfiguracaoId.NotNull}")
	private CaracteristicaConfiguracaoId caracteristicaConfiguracaoId;

	@NotNull(message = "{CaracteristicaValorData.valor.NotNull}")
	private LocalDate valor;

	@Builder
	private CaracteristicaValorData(CaracteristicaConfiguracaoId caracteristicaConfiguracaoId, LocalDate valor) {

		this.caracteristicaConfiguracaoId = caracteristicaConfiguracaoId;
		this.valor = valor;

		validateIntegrity(this).ifPresent(violations -> {
			throw new WMSCaracteristicaValorDataConstraintException(violations);
		});
	}

	@Override
	public FormatoCaracteristicaValor getFormato() {
		return FormatoCaracteristicaValor.DATA;
	}

	@Override
	public int compareTo(CaracteristicaValor<LocalDate> caracteristica) {

		if (caracteristica instanceof CaracteristicaValorData caracteristicaData)
			return Comparator.comparing(CaracteristicaValorData::getCaracteristicaConfiguracaoId)
							 .thenComparing(CaracteristicaValorData::getValor)
							 .compare(this, caracteristicaData);
		else
			return this.caracteristicaConfiguracaoId.compareTo(caracteristica.getCaracteristicaConfiguracaoId());
	}
}
