package com.totvs.sl.wms.estoque.endereco.exception;

import com.totvs.tjf.api.context.stereotype.ApiErrorParameter;
import com.totvs.tjf.api.context.stereotype.error.ApiBadRequest;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
@ApiBadRequest
public class WMSEnderecoOcupacaoPrevistaDeUnitizadorNaoPodeSerNegativaException extends RuntimeException {

	private static final long serialVersionUID = -6284739241805768491L;

	@ApiErrorParameter
	private final Integer unitizador;
	
	@ApiErrorParameter
	private final Integer novaOcupacaoPrevistaUnitizador;
}
