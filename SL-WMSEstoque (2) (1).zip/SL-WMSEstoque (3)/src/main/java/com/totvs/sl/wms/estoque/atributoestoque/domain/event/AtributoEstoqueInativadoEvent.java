package com.totvs.sl.wms.estoque.atributoestoque.domain.event;

import com.totvs.sl.wms.estoque.atributoestoque.domain.model.AtributoEstoque;
import com.totvs.sl.wms.estoque.atributoestoque.domain.model.AtributoEstoqueId;
import com.totvs.sl.wms.estoque.atributoestoque.domain.model.SituacaoAtributoEstoqueValor;
import com.totvs.sl.wms.estoque.util.amqp.SubjectConfiguracao;
import com.totvs.sl.wms.estoque.util.amqp.SubjectDomainEvent;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
public final class AtributoEstoqueInativadoEvent extends SubjectDomainEvent implements SubjectConfiguracao {

	private final AtributoEstoqueId id;
	private final SituacaoAtributoEstoqueValor situacao;

	public static AtributoEstoqueInativadoEvent from(AtributoEstoque atributoEstoque) {
		return new AtributoEstoqueInativadoEvent(atributoEstoque.getId(), atributoEstoque.getSituacao().getValor());
	}
}
