package com.totvs.sl.wms.estoque.categoriaproduto.domain.model;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.totvs.tjf.core.common.domain.DomainObjectId;

import java.util.UUID;

public final class CategoriaProdutoId extends DomainObjectId<UUID> {

	private static final long serialVersionUID = 8972248904430470993L;

	protected CategoriaProdutoId(UUID id) {
		super(id);
	}

	public static CategoriaProdutoId generate() {
		return new CategoriaProdutoId(UUID.randomUUID());
	}

	@JsonCreator
	public static CategoriaProdutoId from(String uuid) {
		return uuid == null ? null : new CategoriaProdutoId(UUID.fromString(uuid));
	}
}
