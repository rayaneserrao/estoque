package com.totvs.sl.wms.estoque.config.amqp;

import org.springframework.cloud.stream.annotation.Input;
import org.springframework.cloud.stream.annotation.Output;
import org.springframework.messaging.MessageChannel;
import org.springframework.messaging.SubscribableChannel;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public final class WMSSyncChannel {

	public static final String WMS_SYNC_COMMAND_IN = "wms-sync-command-in";
	public static final String WMS_SYNC_RESULT_IN = "wms-sync-result-in";
	public static final String WMS_SYNC_OUT = "wms-sync-out";

	public interface WMSExchangeSyncCommandInput {
		@Input(WMSSyncChannel.WMS_SYNC_COMMAND_IN)
		SubscribableChannel input();
	}

	public interface WMSExchangeSyncResultInput {
		@Input(WMSSyncChannel.WMS_SYNC_RESULT_IN)
		SubscribableChannel input();
	}

	public interface WMSExchangeSyncOutput {
		@Output(WMSSyncChannel.WMS_SYNC_OUT)
		MessageChannel output();
	}
}
