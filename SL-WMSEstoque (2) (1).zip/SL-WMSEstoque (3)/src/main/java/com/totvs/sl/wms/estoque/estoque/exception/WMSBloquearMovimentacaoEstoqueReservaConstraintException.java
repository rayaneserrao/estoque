package com.totvs.sl.wms.estoque.estoque.exception;

import java.util.Set;

import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;

import com.totvs.tjf.api.context.stereotype.error.ApiBadRequest;

@ApiBadRequest
public class WMSBloquearMovimentacaoEstoqueReservaConstraintException extends ConstraintViolationException {

	public WMSBloquearMovimentacaoEstoqueReservaConstraintException(Set<? extends ConstraintViolation<?>> constraintViolations) {
		super(constraintViolations);
	}

	private static final long serialVersionUID = -3272274633535942389L;

}
