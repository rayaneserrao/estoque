package com.totvs.sl.wms.estoque.atributoestoque.exception;

import java.util.TreeSet;

import com.totvs.tjf.api.context.stereotype.ApiErrorParameter;
import com.totvs.tjf.api.context.stereotype.error.ApiBadRequest;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
@ApiBadRequest
public class WMSAtributoEstoqueControleQuantidadeUtilizadoException extends RuntimeException {

	private static final long serialVersionUID = 6101272488990669085L;

	@ApiErrorParameter
	private final TreeSet<String> utilizado;

}
