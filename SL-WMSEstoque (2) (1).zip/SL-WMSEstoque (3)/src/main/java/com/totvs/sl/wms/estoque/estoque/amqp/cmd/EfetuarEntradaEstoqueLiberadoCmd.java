package com.totvs.sl.wms.estoque.estoque.amqp.cmd;

import java.math.BigDecimal;
import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.Digits;
import javax.validation.constraints.NotNull;

import com.totvs.sl.wms.estoque.atributoestoquevalor.amqp.cmd.AtributoEstoqueValorCmd;
import com.totvs.sl.wms.estoque.atributoestoquevalor.domain.model.AtributoEstoqueValor;
import com.totvs.sl.wms.estoque.caracteristicavalor.amqp.cmd.CaracteristicaValorCmd;
import com.totvs.sl.wms.estoque.caracteristicavalor.domain.model.CaracteristicaValor;
import com.totvs.sl.wms.estoque.caracteristicavalor.domain.model.CaracteristicaValorTexto;
import com.totvs.sl.wms.estoque.caracteristicavalor.validator.UniqueListCaracteristicaCmdValor;
import com.totvs.sl.wms.estoque.endereco.domain.model.EnderecoId;
import com.totvs.sl.wms.estoque.estoque.domain.model.SeloEstoque;
import com.totvs.sl.wms.estoque.produto.domain.model.ProdutoId;
import com.totvs.sl.wms.estoque.selo.amqp.cmd.SeloEstoqueCmd;
import com.totvs.sl.wms.estoque.sku.domain.model.SKUId;
import com.totvs.sl.wms.estoque.tipoestoque.domain.model.TipoEstoqueId;
import com.totvs.sl.wms.estoque.unidade.domain.model.UnidadeId;
import com.totvs.sl.wms.estoque.unitizador.domain.model.UnitizadorId;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public final class EfetuarEntradaEstoqueLiberadoCmd {

	public static final String NAME = "EfetuarEntradaEstoqueLiberadoCmd";

	public static final String CONDITIONAL_EXPRESSION = "headers['type']=='" + NAME + "'";

	@NotNull(message = "{EfetuarEntradaEstoqueLiberadoCmd.unidadeId.NotNull}")
	private final UnidadeId unidadeId;

	@NotNull(message = "{EfetuarEntradaEstoqueLiberadoCmd.produtoId.NotNull}")
	private final ProdutoId produtoId;

	@NotNull(message = "{EfetuarEntradaEstoqueLiberadoCmd.skuId.NotNull}")
	private final SKUId skuId;

	private final UnitizadorId unitizadorId;

	@NotNull(message = "{EfetuarEntradaEstoqueLiberadoCmd.tipoEstoqueId.NotNull}")
	private final TipoEstoqueId tipoEstoqueId;

	@NotNull(message = "{EfetuarEntradaEstoqueLiberadoCmd.enderecoId.NotNull}")
	private final EnderecoId enderecoId;

	@NotNull(message = "{EfetuarEntradaEstoqueLiberadoCmd.avariado.NotNull}")
	private final Boolean avariado;

	@NotNull(message = "{EfetuarEntradaEstoqueLiberadoCmd.quantidade.NotNull}")
	@DecimalMin(value = "0.0001", message = "{EfetuarEntradaEstoqueLiberadoCmd.quantidade.DecimalMin}")
	@Digits(fraction = 4, integer = 11, message = "{EfetuarEntradaEstoqueLiberadoCmd.quantidade.Digits}")
	private final BigDecimal quantidade;

	@Valid
	@UniqueListCaracteristicaCmdValor(message = "{EfetuarEntradaEstoqueLiberadoCmd.caracteristicas.UniqueListCaracteristicaValor}")
	private final List<CaracteristicaValorCmd> caracteristicas;

	@Valid
	private final List<SeloEstoqueCmd> selos;

	@Valid
	private final List<AtributoEstoqueValorCmd> atributos;

	public final List<CaracteristicaValor<?>> getCaracteristicas() {
		return CaracteristicaValorCmd.from(this.caracteristicas);
	}

	@Deprecated
	public final List<CaracteristicaValorTexto> getCaracteristicasOld() {
		return CaracteristicaValorCmd.fromOld(this.caracteristicas);
	}

	public final List<SeloEstoque> getSelos() {
		return SeloEstoqueCmd.from(this.selos);
	}

	public final List<AtributoEstoqueValor<?>> getAtributos() {
		return AtributoEstoqueValorCmd.toAtributoEstoqueValor(this.atributos);
	}
}
