package com.totvs.sl.wms.estoque.estoque.domain.event;

import java.math.BigDecimal;
import java.util.List;

import com.totvs.sl.wms.estoque.estoque.domain.model.Estoque;
import com.totvs.sl.wms.estoque.estoque.domain.model.EstoqueId;
import com.totvs.sl.wms.estoque.movimentoestoque.domain.model.MovimentoEstoque;
import com.totvs.sl.wms.estoque.unidade.domain.model.UnidadeId;
import com.totvs.sl.wms.estoque.util.amqp.SubjectDomainEvent;

import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data(staticConstructor = "of")
@EqualsAndHashCode(callSuper = false)
public final class EstoqueLiberadoSaidaEfetuadaEvent extends SubjectDomainEvent implements SubjectSaidaEstoque {

	private final UnidadeId unidadeId;
	private final EstoqueOrigem origem;
	private final EstoqueSaida estoque;

	@Data(staticConstructor = "of")
	public static final class EstoqueOrigem {
		private final String id;
		private final String origem;
	}

	@Data
	@Builder
	public static final class EstoqueSaida {
		private final EstoqueId id;
		private final BigDecimal quantidadeSaida;
		private final BigDecimal saldo;
		private final BigDecimal saldoReservado;
		private final BigDecimal saldoDisponivel;
		private final BigDecimal quantidadeBloqueadaMovimentacaoNaoReservada;
		private final BigDecimal quantidadeBloqueadaMovimentacaoReservada;
		private final BigDecimal quantidadeBloqueadaMovimentacaoTotal;
		private final List<EstoqueAtributoSaldoEvent> atributosSaldo;

	}

	public static EstoqueLiberadoSaidaEfetuadaEvent from(Estoque estoque, MovimentoEstoque movimentoEstoque) {
		return EstoqueLiberadoSaidaEfetuadaEvent.of(estoque.getUnidadeId(),
													EstoqueOrigem.of(movimentoEstoque.getOrigem().getId().toString(),
																	 movimentoEstoque.getOrigem().getOrigem()),
													EstoqueSaida.builder()
																.id(estoque.getId())
																.quantidadeSaida(movimentoEstoque.getQuantidade())
																.saldo(estoque.getSaldo())
																.saldoReservado(estoque.getQuantidadeReservada())
																.saldoDisponivel(estoque.getSaldoDisponivel())
																.quantidadeBloqueadaMovimentacaoNaoReservada(estoque.getQuantidadeBloqueadaParaMovimentacaoEstoqueNaoReservada())
																.quantidadeBloqueadaMovimentacaoReservada(estoque.getQuantidadeBloqueadaParaMovimentacaoEstoqueReservada())
																.quantidadeBloqueadaMovimentacaoTotal(estoque.getQuantidadeBloqueadaParaMovimentacaoEstoqueTotal())
																.atributosSaldo(EstoqueAtributoSaldoEvent.from(estoque.getAtributosSaldo()))
																.build());

	}
}
