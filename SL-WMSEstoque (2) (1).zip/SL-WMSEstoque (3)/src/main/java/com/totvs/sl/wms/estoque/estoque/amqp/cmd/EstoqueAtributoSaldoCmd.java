package com.totvs.sl.wms.estoque.estoque.amqp.cmd;

import com.totvs.sl.wms.estoque.atributoestoquevalor.amqp.cmd.AtributoEstoqueValorCmd;
import com.totvs.sl.wms.estoque.estoque.domain.model.EstoqueAtributoSaldo;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.ToString;
import org.springframework.util.CollectionUtils;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import java.math.BigDecimal;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

@Getter
@ToString
@AllArgsConstructor(staticName = "of")
public final class EstoqueAtributoSaldoCmd {

	@NotNull(message = "{EstoqueAtributoSaldoCmd.saldo.NotNull}")
	private final BigDecimal saldo;

	@Valid
	private final List<AtributoEstoqueValorCmd> atributos;

	public static List<EstoqueAtributoSaldo> toEstoqueAtributoSaldo(List<EstoqueAtributoSaldoCmd> atributosSaldo) {

		if (CollectionUtils.isEmpty(atributosSaldo))
			return Collections.emptyList();

		return atributosSaldo.stream().map(atributoSaldo -> {
			return EstoqueAtributoSaldo.of(AtributoEstoqueValorCmd.toAtributoEstoqueValor(atributoSaldo.getAtributos()),
										   atributoSaldo.getSaldo());
		}).collect(Collectors.toList());
	}

}
