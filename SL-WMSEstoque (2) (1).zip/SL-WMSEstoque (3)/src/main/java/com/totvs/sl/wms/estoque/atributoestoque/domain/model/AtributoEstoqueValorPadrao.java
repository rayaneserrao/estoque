package com.totvs.sl.wms.estoque.atributoestoque.domain.model;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
@Getter
public enum AtributoEstoqueValorPadrao {

	ATRIBUTO_TEXTO("A definir"), ATRIBUTO_NUMERO("999999"), ATRIBUTO_DATA("1900-01-01");

	private final String valor;

}
