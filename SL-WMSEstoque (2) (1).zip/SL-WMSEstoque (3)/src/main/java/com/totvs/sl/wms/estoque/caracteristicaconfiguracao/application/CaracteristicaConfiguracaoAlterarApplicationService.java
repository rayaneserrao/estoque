package com.totvs.sl.wms.estoque.caracteristicaconfiguracao.application;

import static java.util.Objects.nonNull;

import javax.transaction.Transactional;

import org.springframework.stereotype.Service;

import com.totvs.sl.wms.estoque.caracteristicaconfiguracao.application.command.AlterarCaracteristicaConfiguracaoCommand;
import com.totvs.sl.wms.estoque.caracteristicaconfiguracao.domain.model.CaracteristicaConfiguracaoDomainRepository;
import com.totvs.sl.wms.estoque.caracteristicaconfiguracao.exception.WMSCaracteristicaConfiguracaoDuplicadaException;
import com.totvs.sl.wms.estoque.config.amqp.WMSPublisher;

import lombok.AllArgsConstructor;

@Service
@Transactional
@AllArgsConstructor
public class CaracteristicaConfiguracaoAlterarApplicationService {

	private static final String CARACTERISTICA_CONFIGURACAO_DESCRICAO_IDX = "caracteristica_configuracao_descricao_idx";

	private CaracteristicaConfiguracaoDomainRepository repository;
	private WMSPublisher publisher;

	public void handle(AlterarCaracteristicaConfiguracaoCommand cmd) {

		var caracteristicaConfiguracao = repository.findByIdOrThrowNotFound(cmd.getId());

		if (repository.existeCaracteristicaConfiguracaoComMesmaDescricao(cmd.getId(), cmd.getDescricao())) {
			throw new WMSCaracteristicaConfiguracaoDuplicadaException(cmd.getDescricao());
		}

		caracteristicaConfiguracao.alterar(cmd.getDescricao(), cmd.getFormato());

		try {
			repository.update(caracteristicaConfiguracao);
		} catch (Exception excecao) {
			var rootCause = excecao.getCause();
			var erro = nonNull(rootCause) ? rootCause.getMessage() : "";
			if (erro.contains(CARACTERISTICA_CONFIGURACAO_DESCRICAO_IDX))
				throw new WMSCaracteristicaConfiguracaoDuplicadaException(cmd.getDescricao());
			throw excecao;
		}

		caracteristicaConfiguracao.getEvents().forEach(publisher::dispatch);
	}

}
