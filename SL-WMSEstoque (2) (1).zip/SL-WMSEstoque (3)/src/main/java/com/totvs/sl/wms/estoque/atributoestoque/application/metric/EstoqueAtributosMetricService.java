package com.totvs.sl.wms.estoque.atributoestoque.application.metric;

import org.springframework.stereotype.Service;

import com.totvs.sl.wms.estoque.util.EstoqueMetrica;
import com.totvs.sl.wms.estoque.util.application.RegisterMetricService;

@Service
public class EstoqueAtributosMetricService {

	private RegisterMetricService metricService;

	public EstoqueAtributosMetricService(RegisterMetricService metricService) {
		this.metricService = metricService;
	}

	public void atributoCriado() {
		metricService.registerAndIncrementMetricCounter(EstoqueMetrica.ATRIBUTO_CRIADO);
	}

	public void atributoExcluido() {
		metricService.registerAndIncrementMetricCounter(EstoqueMetrica.ATRIBUTO_EXCLUIDO);
	}
}
