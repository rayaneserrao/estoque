package com.totvs.sl.wms.estoque.estoque.domain.event;

import com.totvs.sl.wms.estoque.estoque.domain.model.Estoque;
import com.totvs.sl.wms.estoque.estoque.domain.model.EstoqueId;
import com.totvs.sl.wms.estoque.estoque.domain.model.SeloEstoque;
import com.totvs.sl.wms.estoque.util.amqp.SubjectConfiguracao;
import com.totvs.sl.wms.estoque.util.amqp.SubjectDomainEvent;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data(staticConstructor = "of")
@EqualsAndHashCode(callSuper = false)
public final class EstoqueSeloAdicionadoEvent extends SubjectDomainEvent implements SubjectConfiguracao {

	private final EstoqueId id;
	private final SeloEstoqueEvent selo;

	@Data(staticConstructor = "of")
	public static final class SeloEstoqueEvent {
		private final String chave;
		private final String valor;
	}

	public static EstoqueSeloAdicionadoEvent from(Estoque estoque, SeloEstoque selo) {
		return EstoqueSeloAdicionadoEvent.of(estoque.getId(), SeloEstoqueEvent.of(selo.getChave(), selo.getValor()));
	}

}
