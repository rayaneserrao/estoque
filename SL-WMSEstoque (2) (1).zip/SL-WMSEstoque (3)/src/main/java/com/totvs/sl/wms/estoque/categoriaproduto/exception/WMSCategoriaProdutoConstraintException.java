package com.totvs.sl.wms.estoque.categoriaproduto.exception;

import com.totvs.tjf.api.context.stereotype.error.ApiBadRequest;

import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;
import java.util.Set;

@ApiBadRequest
public class WMSCategoriaProdutoConstraintException extends ConstraintViolationException {

	private static final long serialVersionUID = -279414524045312854L;

	public WMSCategoriaProdutoConstraintException(Set<? extends ConstraintViolation<?>> constraintViolations) {
		super(constraintViolations);
	}

}
