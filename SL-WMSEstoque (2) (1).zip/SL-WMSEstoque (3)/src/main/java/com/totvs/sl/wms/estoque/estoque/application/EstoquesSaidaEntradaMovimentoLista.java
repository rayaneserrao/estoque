package com.totvs.sl.wms.estoque.estoque.application;

import java.util.List;

import com.totvs.sl.wms.estoque.estoque.domain.model.Estoque;
import com.totvs.sl.wms.estoque.movimentoestoque.domain.model.MovimentoEstoque;

import lombok.Builder;
import lombok.Getter;

@Getter
@Builder
public final class EstoquesSaidaEntradaMovimentoLista {

	private List<EstoqueSaida> estoquesSaida;
	private List<Estoque> estoquesEntrada;
	private List<MovimentoEstoque> movimentosSaida;
	private List<MovimentoEstoque> movimentosEntrada;
}
