package com.totvs.sl.wms.estoque.estoque.application.command;

import java.math.BigDecimal;
import java.util.List;

import com.totvs.sl.wms.estoque.endereco.domain.model.EnderecoId;
import com.totvs.sl.wms.estoque.estoque.domain.model.EstoqueAtributoSaldo;
import com.totvs.sl.wms.estoque.estoque.domain.model.EstoqueId;
import com.totvs.sl.wms.estoque.origem.domain.model.Origem;
import com.totvs.sl.wms.estoque.unitizador.domain.model.UnitizadorId;

import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NonNull;

@Getter
@Builder
@EqualsAndHashCode
public final class BloquearMovimentacaoEstoqueCommand {

	@NonNull
	private final EstoqueId estoqueId;

	@NonNull
	private final BigDecimal quantidade;

	private final EnderecoId enderecoIdDestino;

	private final UnitizadorId unitizadorIdDestino;

	private final Origem origem;

	private final List<EstoqueAtributoSaldo> atributosSaldo;
}
