package com.totvs.sl.wms.estoque.atributoestoque.application.command;

import com.totvs.sl.wms.estoque.atributoestoque.domain.model.AtributoEstoqueId;
import com.totvs.sl.wms.estoque.atributoestoque.domain.model.ControleQuantidadeAtributoEstoqueValor;
import com.totvs.sl.wms.estoque.atributoestoque.domain.model.FormatoAtributoEstoqueValor;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public final class AlterarAtributoEstoqueCommand {

	private final AtributoEstoqueId id;
	private final String descricao;
	private final FormatoAtributoEstoqueValor formato;
	private final ControleQuantidadeAtributoEstoqueValor controleQuantidade;

}
