package com.totvs.sl.wms.estoque.estoque.exception;

import java.util.Set;

import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;

import com.totvs.tjf.api.context.stereotype.error.ApiBadRequest;

@ApiBadRequest("WMSGenericConstraintViolationException")
public class WMSEfetuarTransferenciaEnderecoEstoqueConstraintException extends ConstraintViolationException {

	private static final long serialVersionUID = -4118965076507035452L;

	public WMSEfetuarTransferenciaEnderecoEstoqueConstraintException(Set<? extends ConstraintViolation<?>> constraintViolations) {
		super(constraintViolations);
	}
}
