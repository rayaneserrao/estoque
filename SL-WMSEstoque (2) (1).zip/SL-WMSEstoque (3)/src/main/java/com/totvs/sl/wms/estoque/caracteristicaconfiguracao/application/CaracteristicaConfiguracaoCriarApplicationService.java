package com.totvs.sl.wms.estoque.caracteristicaconfiguracao.application;

import static java.util.Objects.nonNull;

import javax.transaction.Transactional;

import org.springframework.stereotype.Service;

import com.totvs.sl.wms.estoque.caracteristicaconfiguracao.application.command.CriarCaracteristicaConfiguracaoCommand;
import com.totvs.sl.wms.estoque.caracteristicaconfiguracao.domain.model.CaracteristicaConfiguracao;
import com.totvs.sl.wms.estoque.caracteristicaconfiguracao.domain.model.CaracteristicaConfiguracaoDomainRepository;
import com.totvs.sl.wms.estoque.caracteristicaconfiguracao.domain.model.CaracteristicaConfiguracaoId;
import com.totvs.sl.wms.estoque.caracteristicaconfiguracao.exception.WMSCaracteristicaConfiguracaoDuplicadaException;
import com.totvs.sl.wms.estoque.config.amqp.WMSPublisher;

import lombok.AllArgsConstructor;

@Service
@Transactional
@AllArgsConstructor
public class CaracteristicaConfiguracaoCriarApplicationService {

	private static final String CARACTERISTICA_CONFIGURACAO_DESCRICAO_IDX = "caracteristica_configuracao_descricao_idx";

	private CaracteristicaConfiguracaoDomainRepository repository;
	private WMSPublisher publisher;

	public CaracteristicaConfiguracaoId handle(CriarCaracteristicaConfiguracaoCommand cmd) {
		var caracteristicaConfiguracao = CaracteristicaConfiguracao.builder()
																   .id(CaracteristicaConfiguracaoId.generate())
																   .descricao(cmd.getDescricao().trim())
																   .formato(cmd.getFormato())
																   .origem(cmd.getOrigem())
																   .build();

		if (repository.existeCaracteristicaConfiguracaoComMesmaDescricao(cmd.getDescricao())) {
			throw new WMSCaracteristicaConfiguracaoDuplicadaException(cmd.getDescricao());
		}

		try {
			this.repository.insert(caracteristicaConfiguracao);
		} catch (Exception excecao) {
			var rootCause = excecao.getCause();
			var erro = nonNull(rootCause) ? rootCause.getMessage() : "";
			if (erro.contains(CARACTERISTICA_CONFIGURACAO_DESCRICAO_IDX))
				throw new WMSCaracteristicaConfiguracaoDuplicadaException(cmd.getDescricao());
			throw excecao;
		}

		caracteristicaConfiguracao.getEvents().forEach(publisher::dispatch);

		return caracteristicaConfiguracao.getId();
	}
}
