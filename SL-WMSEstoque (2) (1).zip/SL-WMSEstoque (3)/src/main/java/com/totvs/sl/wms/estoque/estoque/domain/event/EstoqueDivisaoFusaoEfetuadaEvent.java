package com.totvs.sl.wms.estoque.estoque.domain.event;

import java.math.BigDecimal;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.util.CollectionUtils;

import com.totvs.sl.wms.estoque.caracteristicaconfiguracao.domain.model.CaracteristicaConfiguracaoId;
import com.totvs.sl.wms.estoque.caracteristicaconfiguracao.domain.model.FormatoCaracteristicaValor;
import com.totvs.sl.wms.estoque.endereco.domain.model.EnderecoId;
import com.totvs.sl.wms.estoque.estoque.domain.model.Estoque;
import com.totvs.sl.wms.estoque.estoque.domain.model.EstoqueId;
import com.totvs.sl.wms.estoque.estoque.domain.model.SituacaoEstoque;
import com.totvs.sl.wms.estoque.estoque.domain.model.SituacaoEstoqueBloqueado;
import com.totvs.sl.wms.estoque.estoque.domain.model.SituacaoEstoqueLiberado;
import com.totvs.sl.wms.estoque.estoque.domain.model.SituacaoEstoqueValor;
import com.totvs.sl.wms.estoque.produto.domain.model.ProdutoId;
import com.totvs.sl.wms.estoque.rastreio.domain.model.RastreioId;
import com.totvs.sl.wms.estoque.sku.domain.model.SKUId;
import com.totvs.sl.wms.estoque.tipoestoque.domain.model.TipoEstoqueId;
import com.totvs.sl.wms.estoque.unidade.domain.model.UnidadeId;
import com.totvs.sl.wms.estoque.unitizador.domain.model.UnitizadorId;
import com.totvs.sl.wms.estoque.util.amqp.SubjectDomainEvent;

import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data(staticConstructor = "of")
@EqualsAndHashCode(callSuper = false)
public final class EstoqueDivisaoFusaoEfetuadaEvent extends SubjectDomainEvent implements SubjectBloqueioEstoque {

	private final UnidadeId unidadeId;
	private final EstoqueSaida estoqueSaida;
	private final EstoqueEntrada estoqueEntrada;

	@Data
	@Builder
	public static final class EstoqueSaida {
		private final EstoqueId id;
		private final BigDecimal saldo;
		private final BigDecimal saldoReservado;
		private final BigDecimal saldoDisponivel;
		private final BigDecimal quantidadeBloqueadaMovimentacaoNaoReservada;
		private final BigDecimal quantidadeBloqueadaMovimentacaoReservada;
		private final BigDecimal quantidadeBloqueadaMovimentacaoTotal;
		private final List<EstoqueAtributoSaldoEvent> atributosSaldo;
	}

	@Data
	@Builder
	public static final class EstoqueEntrada {
		private final EstoqueId id;
		private final ProdutoId produtoId;
		private final SKUId skuId;
		private final UnitizadorId unitizadorId;
		private final TipoEstoqueId tipoEstoqueId;
		private final EnderecoId enderecoId;
		private final Boolean avariado;
		private final RastreioId rastreioId;
		private final Set<SituacaoEstoqueEntrada> situacoes;
		private final List<CaracteristicaEstoqueEntrada> caracteristicas;
		private final List<EstoqueAtributoSaldoEvent> atributosSaldo;
		private final BigDecimal saldo;
		private final BigDecimal saldoReservado;
		private final BigDecimal saldoDisponivel;
		private final BigDecimal quantidadeBloqueadaMovimentacaoNaoReservada;
		private final BigDecimal quantidadeBloqueadaMovimentacaoReservada;
		private final BigDecimal quantidadeBloqueadaMovimentacaoTotal;
		private final List<SeloEstoqueEvent> selos;
		private final ZonedDateTime dataHoraEntrada;
	}

	@Data
	@Builder
	public static final class SituacaoEstoqueEntrada {
		private final SituacaoEstoqueValor situacao;
		private final ZonedDateTime quando;
		private final String chaveAcesso;
		private final String motivo;
	}

	@Data(staticConstructor = "of")
	public static final class CaracteristicaEstoqueEntrada {
		private final CaracteristicaConfiguracaoId caracteristicaConfiguracaoId;
		private final FormatoCaracteristicaValor formato;
		private final String valor;
	}

	@Data(staticConstructor = "of")
	public static final class SeloEstoqueEvent {
		private final String chave;
		private final String valor;
	}

	public static EstoqueDivisaoFusaoEfetuadaEvent from(Estoque estoqueSaida, Estoque estoqueEntrada) {

		return EstoqueDivisaoFusaoEfetuadaEvent.of(estoqueSaida.getUnidadeId(),
												   EstoqueSaida.builder()
															   .id(estoqueSaida.getId())
															   .saldo(estoqueSaida.getSaldo())
															   .saldoReservado(estoqueSaida.getQuantidadeReservada())
															   .saldoDisponivel(estoqueSaida.getSaldoDisponivel())
															   .quantidadeBloqueadaMovimentacaoNaoReservada(estoqueSaida.getQuantidadeBloqueadaParaMovimentacaoEstoqueNaoReservada())
															   .quantidadeBloqueadaMovimentacaoReservada(estoqueSaida.getQuantidadeBloqueadaParaMovimentacaoEstoqueReservada())
															   .quantidadeBloqueadaMovimentacaoTotal(estoqueSaida.getQuantidadeBloqueadaParaMovimentacaoEstoqueTotal())
															   .atributosSaldo(EstoqueAtributoSaldoEvent.from(estoqueSaida.getAtributosSaldo()))
															   .build(),
												   EstoqueEntrada.builder()
																 .id(estoqueEntrada.getId())
																 .produtoId(estoqueEntrada.getProdutoId())
																 .skuId(estoqueEntrada.getSkuId())
																 .unitizadorId(estoqueEntrada.getUnitizadorId())
																 .tipoEstoqueId(estoqueEntrada.getTipoEstoqueId())
																 .enderecoId(estoqueEntrada.getEnderecoId())
																 .situacoes(montarSituacoesEstoque(estoqueEntrada.getSituacoes()))
																 .avariado(estoqueEntrada.getAvariado())
																 .caracteristicas(montarCaracteristicas(estoqueEntrada))
																 .atributosSaldo(EstoqueAtributoSaldoEvent.from(estoqueEntrada.getAtributosSaldo()))
																 .rastreioId(estoqueEntrada.getRastreioId())
																 .saldo(estoqueEntrada.getSaldo())
																 .saldoReservado(estoqueEntrada.getQuantidadeReservada())
																 .saldoDisponivel(estoqueEntrada.getSaldoDisponivel())
																 .quantidadeBloqueadaMovimentacaoNaoReservada(estoqueEntrada.getQuantidadeBloqueadaParaMovimentacaoEstoqueNaoReservada())
																 .quantidadeBloqueadaMovimentacaoReservada(estoqueEntrada.getQuantidadeBloqueadaParaMovimentacaoEstoqueReservada())
																 .quantidadeBloqueadaMovimentacaoTotal(estoqueEntrada.getQuantidadeBloqueadaParaMovimentacaoEstoqueTotal())
																 .selos(estoqueEntrada.getSelos()
																					  .stream()
																					  .map(selo -> SeloEstoqueEvent.of(selo.getChave(),
																													   selo.getValor()))
																					  .collect(Collectors.toList()))
																 .dataHoraEntrada(estoqueEntrada.getDataHoraEntrada())
																 .build());

	}

	private static Set<SituacaoEstoqueEntrada> montarSituacoesEstoque(Set<SituacaoEstoque> situacoes) {
		return situacoes.stream()
						.map(EstoqueDivisaoFusaoEfetuadaEvent::criarSituacaoEstoqueEntrada)
						.collect(Collectors.toSet());
	}

	private static SituacaoEstoqueEntrada criarSituacaoEstoqueEntrada(SituacaoEstoque situacao) {
		return situacao.getSituacaoEstoque().equals(SituacaoEstoqueValor.LIBERADO) ? criarSituacaoLiberado(situacao)
				: criarSituacaoBloqueado(situacao);
	}

	private static SituacaoEstoqueEntrada criarSituacaoLiberado(SituacaoEstoque situacao) {
		var situacaoLiberado = (SituacaoEstoqueLiberado) situacao;

		return SituacaoEstoqueEntrada.builder()
									 .situacao(SituacaoEstoqueValor.LIBERADO)
									 .quando(situacaoLiberado.getQuando())
									 .build();
	}

	private static SituacaoEstoqueEntrada criarSituacaoBloqueado(SituacaoEstoque situacao) {
		var situacaoBloqueado = (SituacaoEstoqueBloqueado) situacao;

		return SituacaoEstoqueEntrada.builder()
									 .situacao(SituacaoEstoqueValor.BLOQUEADO)
									 .quando(situacaoBloqueado.getQuando())
									 .chaveAcesso(situacaoBloqueado.getChaveAcesso())
									 .motivo(situacaoBloqueado.getMotivo())
									 .build();
	}

	private static List<CaracteristicaEstoqueEntrada> montarCaracteristicas(Estoque estoque) {
		if (CollectionUtils.isEmpty(estoque.getCaracteristicas())) {
			return new ArrayList<>();
		}
		return estoque.getCaracteristicas()
					  .stream()
					  .map(caracteristica -> CaracteristicaEstoqueEntrada.of(caracteristica.getCaracteristicaConfiguracaoId(),
																			 caracteristica.getFormato(),
																			 caracteristica.getValor().toString()))
					  .collect(Collectors.toList());
	}
}
