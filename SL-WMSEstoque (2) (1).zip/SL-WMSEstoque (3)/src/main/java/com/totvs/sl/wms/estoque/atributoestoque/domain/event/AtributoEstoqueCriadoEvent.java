package com.totvs.sl.wms.estoque.atributoestoque.domain.event;

import com.totvs.sl.wms.estoque.atributoestoque.domain.model.AtributoEstoque;
import com.totvs.sl.wms.estoque.atributoestoque.domain.model.AtributoEstoqueId;
import com.totvs.sl.wms.estoque.atributoestoque.domain.model.ControleQuantidadeAtributoEstoqueValor;
import com.totvs.sl.wms.estoque.atributoestoque.domain.model.FormatoAtributoEstoqueValor;
import com.totvs.sl.wms.estoque.atributoestoque.domain.model.SituacaoAtributoEstoqueValor;
import com.totvs.sl.wms.estoque.util.amqp.SubjectConfiguracao;
import com.totvs.sl.wms.estoque.util.amqp.SubjectDomainEvent;

import lombok.AccessLevel;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
@Builder(access = AccessLevel.PRIVATE)
public final class AtributoEstoqueCriadoEvent extends SubjectDomainEvent implements SubjectConfiguracao {

	private final AtributoEstoqueId id;
	private final String descricao;
	private final ControleQuantidadeAtributoEstoqueValor controleQuantidade;
	private final FormatoAtributoEstoqueValor formato;
	private final SituacaoAtributoEstoqueValor situacao;

	public static final AtributoEstoqueCriadoEvent from(AtributoEstoque atributoEstoque) {
		return AtributoEstoqueCriadoEvent.builder()
										 .id(atributoEstoque.getId())
										 .descricao(atributoEstoque.getDescricao())
										 .formato(atributoEstoque.getFormato())
										 .controleQuantidade(atributoEstoque.getControleQuantidade())
										 .situacao(atributoEstoque.getSituacao().getValor())
										 .build();
	}
}
