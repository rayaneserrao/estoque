package com.totvs.sl.wms.estoque.categoriaproduto.exception;

import java.util.Set;

import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;

import com.totvs.tjf.api.context.stereotype.error.ApiBadRequest;

@ApiBadRequest
public class WMSCriarCategoriaProdutoConstraintException extends ConstraintViolationException { // NOSONAR

	private static final long serialVersionUID = 1L;

	public WMSCriarCategoriaProdutoConstraintException(Set<? extends ConstraintViolation<?>> constraintViolations) {
		super(constraintViolations);
	}
}
