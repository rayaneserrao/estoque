package com.totvs.sl.wms.estoque.estoque.amqp.event;

import java.util.List;

import com.totvs.sl.wms.estoque.caracteristicaconfiguracao.domain.model.CaracteristicaConfiguracaoId;
import com.totvs.sl.wms.estoque.config.amqp.ConsumeMessage;
import com.totvs.sl.wms.estoque.produto.domain.model.ProdutoId;
import com.totvs.sl.wms.estoque.util.amqp.RejectedEvent;
import com.totvs.sl.wms.estoque.util.amqp.SubjectConfiguracao;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data(staticConstructor = "of")
@EqualsAndHashCode(callSuper = false)
public final class EstoqueCaracteristicaConfiguracaoNaoAdicionadaEvent extends RejectedEvent
		implements SubjectConfiguracao, ConsumeMessage {

	public static final String NAME = "EstoqueCaracteristicaConfiguracaoNaoAdicionadaEvent";

	public static final String CONDITIONAL_EXPRESSION = "headers['type']=='" + NAME + "'";

	private final ProdutoId produtoId;
	private final CaracteristicaConfiguracaoId caracteristicaConfiguracaoId;
	private final List<Inconsistencia> inconsistencias;

	@Data(staticConstructor = "of")
	public static final class Inconsistencia {
		private final String id;
		private final String mensagem;
		private final String detalhe;
	}
}
