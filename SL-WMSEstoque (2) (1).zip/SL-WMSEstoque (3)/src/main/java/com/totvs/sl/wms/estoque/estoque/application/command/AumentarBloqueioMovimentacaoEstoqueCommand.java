package com.totvs.sl.wms.estoque.estoque.application.command;

import java.math.BigDecimal;

import com.totvs.sl.wms.estoque.bloqueiomovimentacaoestoque.domain.model.BloqueioMovimentacaoEstoqueId;
import com.totvs.sl.wms.estoque.estoque.domain.model.EstoqueId;

import lombok.Data;

@Data(staticConstructor = "of")
public final class AumentarBloqueioMovimentacaoEstoqueCommand {

	private final EstoqueId estoqueId;

	private final BloqueioMovimentacaoEstoqueId bloqueioMovimentacaoEstoqueId;

	private final BigDecimal quantidade;
}
