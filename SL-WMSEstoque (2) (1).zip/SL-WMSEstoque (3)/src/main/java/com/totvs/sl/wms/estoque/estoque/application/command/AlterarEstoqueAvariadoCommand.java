package com.totvs.sl.wms.estoque.estoque.application.command;

import com.totvs.sl.wms.estoque.estoque.domain.model.EstoqueId;

import lombok.Data;

@Data(staticConstructor = "of")
public final class AlterarEstoqueAvariadoCommand {
	private final EstoqueId id;
	private final boolean avariado;
}
