package com.totvs.sl.wms.estoque.estoque.amqp;

import java.util.ArrayList;

import org.springframework.cloud.stream.annotation.EnableBinding;
import org.springframework.cloud.stream.annotation.StreamListener;
import org.springframework.util.CollectionUtils;

import com.totvs.sl.wms.estoque.atributoestoquevalor.domain.model.AtributoEstoqueValor;
import com.totvs.sl.wms.estoque.config.amqp.WMSChannel;
import com.totvs.sl.wms.estoque.config.amqp.WMSPublisher;
import com.totvs.sl.wms.estoque.estoque.amqp.cmd.EfetuarSaidaEstoqueBloqueadoCmd;
import com.totvs.sl.wms.estoque.estoque.amqp.cmd.EfetuarSaidaEstoqueLiberadoCmd;
import com.totvs.sl.wms.estoque.estoque.amqp.cmd.EfetuarSaidaLoteEstoqueBloqueadoCmd;
import com.totvs.sl.wms.estoque.estoque.amqp.cmd.EfetuarSaidaLoteEstoqueLiberadoCmd;
import com.totvs.sl.wms.estoque.estoque.amqp.event.EstoqueBloqueadoSaidaLoteRejeitadaEvent;
import com.totvs.sl.wms.estoque.estoque.amqp.event.EstoqueBloqueadoSaidaRejeitadaEvent;
import com.totvs.sl.wms.estoque.estoque.amqp.event.EstoqueLiberadoSaidaLoteRejeitadaEvent;
import com.totvs.sl.wms.estoque.estoque.amqp.event.EstoqueLiberadoSaidaRejeitadaEvent;
import com.totvs.sl.wms.estoque.estoque.application.EstoqueEfetuarSaidaApplicationService;
import com.totvs.sl.wms.estoque.estoque.application.command.EfetuarSaidaEstoqueBloqueadoCommand;
import com.totvs.sl.wms.estoque.estoque.application.command.EfetuarSaidaEstoqueLiberadoCommand;
import com.totvs.sl.wms.estoque.estoque.application.command.EfetuarSaidaLoteEstoqueBloqueadoCommand;
import com.totvs.sl.wms.estoque.estoque.application.command.EfetuarSaidaLoteEstoqueLiberadoCommand;
import com.totvs.sl.wms.estoque.estoque.application.command.EfetuarSaidaLoteEstoqueLiberadoCommand.EstoqueSaida;
import com.totvs.sl.wms.estoque.estoque.exception.WMSEfetuarSaidaEstoqueBloqueadoConstraintException;
import com.totvs.sl.wms.estoque.estoque.exception.WMSEfetuarSaidaEstoqueLiberadoConstraintException;
import com.totvs.sl.wms.estoque.estoque.exception.WMSEfetuarSaidaLoteEstoqueBloqueadoConstraintException;
import com.totvs.sl.wms.estoque.estoque.exception.WMSEfetuarSaidaLoteEstoqueLiberadoConstraintException;
import com.totvs.sl.wms.estoque.origem.domain.model.Origem;
import com.totvs.sl.wms.estoque.origem.domain.model.OrigemId;
import com.totvs.sl.wms.estoque.util.amqp.AMQPUtil;
import com.totvs.tjf.api.response.error.converter.ErrorExceptionConverter;
import com.totvs.tjf.core.i18n.I18nService;
import com.totvs.tjf.core.validation.ValidatorService;
import com.totvs.tjf.messaging.context.TOTVSMessage;
import com.totvs.tjf.messaging.context.TransactionInfo;

import lombok.AllArgsConstructor;

@AllArgsConstructor
@EnableBinding({ WMSChannel.WMSSaidaEstoqueCommandsInput.class, WMSChannel.WMSSaidaEstoqueLoteCommandsInput.class })
public class EstoqueSaidaCommandsSubscriber {

	private EstoqueEfetuarSaidaApplicationService service;
	private ValidatorService validator;
	private WMSPublisher wmsPublisher;
	private I18nService i18nService;

	@StreamListener(target = WMSChannel.WMS_SAIDA_ESTOQUE_COMMANDS_IN, condition = EfetuarSaidaEstoqueLiberadoCmd.CONDITIONAL_EXPRESSION)
	public void efetuarSaidaEstoqueLiberado(final TOTVSMessage<EfetuarSaidaEstoqueLiberadoCmd> message) {

		AMQPUtil.gerarLog(this.getClass(), message, EfetuarSaidaEstoqueLiberadoCmd.CONDITIONAL_EXPRESSION);

		var cmd = message.getContent();

		validator.validate(cmd).ifPresent(violations -> {
			throw new WMSEfetuarSaidaEstoqueLiberadoConstraintException(violations);
		});

		var transactionInfo = message.getHeader().getTransactionInfo();

		var origem = Origem.of(OrigemId.from(transactionInfo.getTransactionId()), transactionInfo.getGeneratedBy());

		var command = EfetuarSaidaEstoqueLiberadoCommand.builder()
														.unidadeId(cmd.getUnidadeId())
														.origem(origem)
														.estoqueId(cmd.getEstoqueId())
														.quantidade(cmd.getQuantidade())
														.atributos(cmd.getAtributos())
														.build();

		try {
			service.handle(command);
		} catch (RuntimeException excecao) {
			rejeitarSaidaEstoqueLiberado(cmd, excecao);
		}
	}

	private void rejeitarSaidaEstoqueLiberado(EfetuarSaidaEstoqueLiberadoCmd cmd, RuntimeException excecao) {

		var id = excecao.getClass().getSimpleName();

		if (!id.startsWith("WMS"))
			throw excecao;

		var erroConverter = new ErrorExceptionConverter(i18nService);
		var erro = erroConverter.convert(excecao).getError();

		var eventoRejeicao = EstoqueLiberadoSaidaRejeitadaEvent.of(cmd.getUnidadeId(), erro);
		wmsPublisher.dispatch(eventoRejeicao);
	}

	@StreamListener(target = WMSChannel.WMS_SAIDA_ESTOQUE_COMMANDS_IN, condition = EfetuarSaidaLoteEstoqueLiberadoCmd.CONDITIONAL_EXPRESSION)
	public void efetuarSaidaLoteEstoqueLiberado(final TOTVSMessage<EfetuarSaidaLoteEstoqueLiberadoCmd> message) {

		AMQPUtil.gerarLog(this.getClass(), message, EfetuarSaidaLoteEstoqueLiberadoCmd.CONDITIONAL_EXPRESSION);

		var cmd = message.getContent();

		validator.validate(cmd).ifPresent(violations -> {
			throw new WMSEfetuarSaidaLoteEstoqueLiberadoConstraintException(violations);
		});

		var transactionInfo = message.getHeader().getTransactionInfo();

		var origem = Origem.of(OrigemId.from(transactionInfo.getTransactionId()), transactionInfo.getGeneratedBy());

		var estoques = new ArrayList<EstoqueSaida>();
		cmd.getEstoques().stream().forEach(estoque -> {
			var atributos = new ArrayList<AtributoEstoqueValor<?>>();
			if (!CollectionUtils.isEmpty(estoque.getAtributos()))
				estoque.getAtributos()
					   .forEach(atributo -> atributos.add(atributo.getFormato()
																  .getInstance(atributo.getId(),
																			   atributo.getValores(),
																			   atributo.getControleQuantidade())));
			estoques.add(EfetuarSaidaLoteEstoqueLiberadoCommand.EstoqueSaida.of(estoque.getId(),
																				estoque.getQuantidade(),
																				atributos));
		});

		var command = EfetuarSaidaLoteEstoqueLiberadoCommand.of(cmd.getUnidadeId(), estoques, origem);

		try {
			service.handle(command);
		} catch (RuntimeException excecao) {
			rejeitarSaidaLoteEstoqueLiberado(cmd, excecao);
		}
	}

	private void rejeitarSaidaLoteEstoqueLiberado(EfetuarSaidaLoteEstoqueLiberadoCmd cmd, RuntimeException excecao) {

		var id = excecao.getClass().getSimpleName();

		if (!id.startsWith("WMS"))
			throw excecao;

		var erroConverter = new ErrorExceptionConverter(i18nService);
		var erro = erroConverter.convert(excecao).getError();

		var eventoRejeicao = EstoqueLiberadoSaidaLoteRejeitadaEvent.builder()
																   .unidadeId(cmd.getUnidadeId())
																   .inconsistencia(erro)
																   .build();
		wmsPublisher.dispatch(eventoRejeicao);
	}

	@StreamListener(target = WMSChannel.WMS_SAIDA_ESTOQUE_LOTE_COMMANDS_IN, condition = EfetuarSaidaEstoqueBloqueadoCmd.CONDITIONAL_EXPRESSION)
	public void efetuarSaidaEstoqueBloqueadoLote(final TOTVSMessage<EfetuarSaidaEstoqueBloqueadoCmd> message) {

		AMQPUtil.gerarLog(this.getClass(), message, EfetuarSaidaEstoqueBloqueadoCmd.CONDITIONAL_EXPRESSION);

		processarEfetuarSaidaEstoqueBloqueadoCmd(message);
	}

	@StreamListener(target = WMSChannel.WMS_SAIDA_ESTOQUE_COMMANDS_IN, condition = EfetuarSaidaEstoqueBloqueadoCmd.CONDITIONAL_EXPRESSION)
	public void efetuarSaidaEstoqueBloqueado(final TOTVSMessage<EfetuarSaidaEstoqueBloqueadoCmd> message) {

		AMQPUtil.gerarLog(this.getClass(), message, EfetuarSaidaEstoqueBloqueadoCmd.CONDITIONAL_EXPRESSION);

		processarEfetuarSaidaEstoqueBloqueadoCmd(message);
	}

	private void processarEfetuarSaidaEstoqueBloqueadoCmd(final TOTVSMessage<EfetuarSaidaEstoqueBloqueadoCmd> message) {

		var cmd = message.getContent();

		validator.validate(cmd).ifPresent(violations -> {
			throw new WMSEfetuarSaidaEstoqueBloqueadoConstraintException(violations);
		});

		var origem = Origem.of(OrigemId.from(message.getHeader().getTransactionInfo().getTransactionId()),
							   message.getHeader().getTransactionInfo().getGeneratedBy());

		var command = EfetuarSaidaEstoqueBloqueadoCommand.builder()
														 .unidadeId(cmd.getUnidadeId())
														 .origem(origem)
														 .estoqueId(cmd.getEstoqueId())
														 .quantidade(cmd.getQuantidade())
														 .chaveAcesso(cmd.getChaveAcesso())
														 .atributos(cmd.getAtributos())
														 .build();

		try {
			service.handle(command);
		} catch (RuntimeException excecao) {
			rejeitarSaidaEstoqueBloqueado(cmd, excecao);
		}
	}

	private void rejeitarSaidaEstoqueBloqueado(EfetuarSaidaEstoqueBloqueadoCmd cmd, RuntimeException excecao) {
		var inconsistencias = new ArrayList<EstoqueBloqueadoSaidaRejeitadaEvent.Inconsistencia>();

		var id = excecao.getClass().getSimpleName();
		var mensagem = "";
		var detalhe = "";

		if (!id.startsWith("WMS"))
			throw excecao;

		var erroConverter = new ErrorExceptionConverter(i18nService);
		var erro = erroConverter.convert(excecao).getError();

		mensagem = erro.getMessage();
		detalhe = erro.getDetailedMessage();
		inconsistencias.add(EstoqueBloqueadoSaidaRejeitadaEvent.Inconsistencia.of(id, mensagem, detalhe));

		var eventoRejeicao = new EstoqueBloqueadoSaidaRejeitadaEvent();
		eventoRejeicao.setUnidadeId(cmd.getUnidadeId());
		eventoRejeicao.setInconsistencias(inconsistencias);

		wmsPublisher.dispatch(eventoRejeicao);
	}

	@StreamListener(target = WMSChannel.WMS_SAIDA_ESTOQUE_COMMANDS_IN, condition = EfetuarSaidaLoteEstoqueBloqueadoCmd.CONDITIONAL_EXPRESSION)
	public void efetuarSaidaLoteEstoqueBloqueado(final TOTVSMessage<EfetuarSaidaLoteEstoqueBloqueadoCmd> message) {

		AMQPUtil.gerarLog(this.getClass(), message, EfetuarSaidaLoteEstoqueBloqueadoCmd.CONDITIONAL_EXPRESSION);

		var cmd = message.getContent();

		validator.validate(cmd).ifPresent(violations -> {
			throw new WMSEfetuarSaidaLoteEstoqueBloqueadoConstraintException(violations);
		});

		var origem = Origem.of(OrigemId.from(message.getHeader().getTransactionInfo().getTransactionId()),
							   message.getHeader().getTransactionInfo().getGeneratedBy());

		var estoques = new ArrayList<EfetuarSaidaLoteEstoqueBloqueadoCommand.EstoqueSaida>();
		cmd.getEstoques().stream().forEach(estoque -> {
			estoques.add(EfetuarSaidaLoteEstoqueBloqueadoCommand.EstoqueSaida.builder()
																			 .id(estoque.getId())
																			 .quantidade(estoque.getQuantidade())
																			 .chaveAcesso(estoque.getChaveAcesso())
																			 .atributos(estoque.getAtributos())
																			 .build());
		});

		var command = EfetuarSaidaLoteEstoqueBloqueadoCommand.of(cmd.getUnidadeId(), estoques, origem);

		try {
			service.handle(command);
		} catch (RuntimeException excecao) {
			rejeitarSaidaLoteEstoqueBloqueado(cmd, excecao, message.getHeader().getTransactionInfo());
		}
	}

	private void rejeitarSaidaLoteEstoqueBloqueado(EfetuarSaidaLoteEstoqueBloqueadoCmd cmd,
												   RuntimeException excecao,
												   TransactionInfo transactionInfo) {

		var inconsistencias = new ArrayList<EstoqueBloqueadoSaidaLoteRejeitadaEvent.Inconsistencia>();

		var id = excecao.getClass().getSimpleName();
		var mensagem = "";
		var detalhe = "";

		if (!id.startsWith("WMS"))
			throw excecao;

		var erroConverter = new ErrorExceptionConverter(i18nService);
		var erro = erroConverter.convert(excecao).getError();

		mensagem = erro.getMessage();
		detalhe = erro.getDetailedMessage();
		inconsistencias.add(EstoqueBloqueadoSaidaLoteRejeitadaEvent.Inconsistencia.of(id, mensagem, detalhe));

		var eventoRejeicao = EstoqueBloqueadoSaidaLoteRejeitadaEvent.builder()
																	.unidadeId(cmd.getUnidadeId())
																	.generatedBy(transactionInfo.getGeneratedBy())
																	.transactionId(transactionInfo.getTransactionId())
																	.inconsistencias(inconsistencias)
																	.build();
		wmsPublisher.dispatch(eventoRejeicao);
	}

}
