package com.totvs.sl.wms.estoque.atributoestoque.repository;

import java.sql.Types;
import java.util.Optional;

import javax.persistence.EntityManager;
import javax.transaction.Transactional;

import org.springframework.jdbc.core.SqlParameterValue;
import org.springframework.stereotype.Repository;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.totvs.sl.wms.estoque.atributoestoque.domain.model.AtributoEstoque;
import com.totvs.sl.wms.estoque.atributoestoque.domain.model.AtributoEstoqueDomainRepository;
import com.totvs.sl.wms.estoque.atributoestoque.domain.model.AtributoEstoqueId;
import com.totvs.sl.wms.estoque.atributoestoque.exception.WMSAtributoEstoqueNaoEncontradoException;
import com.totvs.sl.wms.estoque.util.repository.SqlWhereBuilder;
import com.totvs.tjf.repository.aggregate.CrudAggregateRepository;

@Repository
@Transactional
public class AtributoEstoqueRepository extends CrudAggregateRepository<AtributoEstoque, AtributoEstoqueId>
		implements AtributoEstoqueDomainRepository {

	private static final String CONDICAO_ID = "id = ?";

	public AtributoEstoqueRepository(EntityManager em, ObjectMapper mapper) {
		super(em, mapper.copy());
	}

	@Override
	public Optional<AtributoEstoque> findById(AtributoEstoqueId id) {
		var clause = SqlWhereBuilder.builder().where(CONDICAO_ID).build();
		return this.findOne(clause, new SqlParameterValue(Types.VARCHAR, id));
	}

	@Override
	public AtributoEstoque findByIdOrThrowNotFound(AtributoEstoqueId id) {
		return findById(id).orElseThrow(WMSAtributoEstoqueNaoEncontradoException::new);
	}
}
