package com.totvs.sl.wms.estoque.atributoestoque.application.command;

import com.totvs.sl.wms.estoque.atributoestoque.domain.model.AtributoEstoqueId;

import lombok.Data;

@Data(staticConstructor = "of")
public final class ExcluirAtributoEstoqueCommand {

	private final AtributoEstoqueId id;

}
