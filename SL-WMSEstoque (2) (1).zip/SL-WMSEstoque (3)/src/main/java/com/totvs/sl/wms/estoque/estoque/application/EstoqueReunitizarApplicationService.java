package com.totvs.sl.wms.estoque.estoque.application;

import java.math.BigDecimal;
import java.util.List;
import java.util.UUID;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import com.totvs.sl.wms.estoque.atributoestoquevalor.domain.model.AtributoEstoqueValor;
import com.totvs.sl.wms.estoque.config.amqp.WMSPublisher;
import com.totvs.sl.wms.estoque.endereco.domain.model.Endereco;
import com.totvs.sl.wms.estoque.endereco.domain.model.EnderecoDomainRepository;
import com.totvs.sl.wms.estoque.endereco.domain.model.EnderecoId;
import com.totvs.sl.wms.estoque.estoque.application.command.EfetuarReunitizacaoEstoqueCommand;
import com.totvs.sl.wms.estoque.estoque.domain.event.EstoqueReunitizacaoEfetuadaEvent;
import com.totvs.sl.wms.estoque.estoque.domain.model.Estoque;
import com.totvs.sl.wms.estoque.estoque.domain.model.EstoqueAtributoSaldo;
import com.totvs.sl.wms.estoque.estoque.domain.model.EstoqueDomainRepository;
import com.totvs.sl.wms.estoque.estoque.domain.model.EstoqueHash;
import com.totvs.sl.wms.estoque.estoque.domain.model.EstoqueId;
import com.totvs.sl.wms.estoque.estoque.domain.model.FracionadoId;
import com.totvs.sl.wms.estoque.estoque.domain.service.AtualizaSaldoEstoqueEntradaDomainService;
import com.totvs.sl.wms.estoque.estoque.domain.service.AtualizaSaldoEstoqueSaidaDomainService;
import com.totvs.sl.wms.estoque.estoque.domain.service.ConfiguraEstoqueParaEntradaDomainService;
import com.totvs.sl.wms.estoque.estoque.domain.service.ValidaInformacoesBasicasEstoqueDomainService;
import com.totvs.sl.wms.estoque.estoque.domain.service.ValidaUnitizadorEstoqueDomainService;
import com.totvs.sl.wms.estoque.estoque.exception.WMSReunitizacaoUnidadeDiferenteUnidadeEstoqueException;
import com.totvs.sl.wms.estoque.estoque.exception.WMSSaldoInsuficienteReunitizacaoException;
import com.totvs.sl.wms.estoque.movimentoestoque.domain.model.MovimentoEstoqueDomainRepository;
import com.totvs.sl.wms.estoque.movimentoestoque.domain.model.MovimentoEstoqueId;
import com.totvs.sl.wms.estoque.origem.domain.model.Origem;
import com.totvs.sl.wms.estoque.origem.domain.model.OrigemId;
import com.totvs.sl.wms.estoque.produto.domain.model.ProdutoDomainRepository;
import com.totvs.sl.wms.estoque.sku.domain.model.SKU;
import com.totvs.sl.wms.estoque.sku.domain.model.SKUDomainRepository;
import com.totvs.sl.wms.estoque.tipoestoque.domain.model.TipoEstoqueId;
import com.totvs.sl.wms.estoque.unidade.domain.model.UnidadeId;
import com.totvs.sl.wms.estoque.unitizador.domain.model.UnitizadorId;

import lombok.AllArgsConstructor;

@Service
@Transactional
@AllArgsConstructor
public class EstoqueReunitizarApplicationService {

	private final MovimentoEstoqueDomainRepository movimentoEstoqueRepository;
	private final EstoqueDomainRepository estoqueRepository;
	private final ProdutoDomainRepository produtoRepository;
	private final SKUDomainRepository skuRepository;
	private final EnderecoDomainRepository enderecoRepository;
	private final ValidaInformacoesBasicasEstoqueDomainService validaInformacoesBasicasService;
	private final ValidaUnitizadorEstoqueDomainService validaEstoqueUnitizadorService;
	private final ConfiguraEstoqueParaEntradaDomainService configuraEstoqueEntradaService;
	private final AtualizaSaldoEstoqueEntradaDomainService atualizaSaldoEntradaService;
	private final AtualizaSaldoEstoqueSaidaDomainService atualizaSaldoSaidaService;
	private final WMSPublisher publisher;

	public EstoquesSaidaEntradaMovimentos handle(final EfetuarReunitizacaoEstoqueCommand cmd) {

		validaInformacoesBasicasService.existeEnderecoParaUnidade(cmd.getUnidadeId(), cmd.getDestino().getEnderecoId());
		validaInformacoesBasicasService.existeTipoEstoqueAtivoParaUnidade(cmd.getUnidadeId(),
																		  cmd.getDestino().getTipoEstoqueId());

		validaEstoqueUnitizadorService.existeParaUnidade(cmd.getUnidadeId(), cmd.getDestino().getUnitizadorId());
		validaEstoqueUnitizadorService.existeEmOutroEndereco(cmd.getUnidadeId(),
															 cmd.getDestino().getUnitizadorId(),
															 cmd.getDestino().getEnderecoId());

		var objRetorno = reunitizar(cmd.getUnidadeId(), cmd.getEstoqueId(), cmd.getDestino(), cmd.getAtributos());

		publisher.dispatch(objRetorno.getMovimentoSaida().getEvents());
		publisher.dispatch(objRetorno.getMovimentoEntrada().getEvents());
		publisher.dispatch(EstoqueReunitizacaoEfetuadaEvent.from(List.of(objRetorno.getEstoques().getEstoqueEntrada()),
																 List.of(objRetorno.getEstoques().getEstoqueSaida())));
		return objRetorno;
	}

	private EstoquesSaidaEntradaMovimentos reunitizar(final UnidadeId unidadeId,
													  final EstoqueId estoqueId,
													  final EfetuarReunitizacaoEstoqueCommand.Destino destino,
													  List<AtributoEstoqueValor<?>> atributos) {

		final var skuDestino = skuRepository.findByIdOrThrowNotFound(destino.getSkuId());

		BigDecimal quantidadeRestante = skuDestino.getQuantidadeUnidadesProduto().multiply(destino.getQuantidadeSku());

		BigDecimal quantidadeSkuProcessados = BigDecimal.ZERO;

		Estoque estoqueSaida = estoqueRepository.findWithLockById(estoqueId).orElse(null);

		validarSeUnidadeDestinoIgualUnidadeEstoque(unidadeId, estoqueSaida);

		var saldoATransferir = estoqueSaida.getSaldo().compareTo(quantidadeRestante) >= 0 ? quantidadeRestante
				: estoqueSaida.getSaldo();

		var atributosSaldo = this.obterListaEstoqueAtributoSaldo(atributos, saldoATransferir);

		var entradaSaidaMovimentos = this.realizarEntradaSaidaEstoquePorReunitizacao(skuDestino,
																					 estoqueSaida,
																					 saldoATransferir,
																					 destino.getUnitizadorId(),
																					 destino.getTipoEstoqueId(),
																					 destino.getEnderecoId(),
																					 destino.getAvariado(),
																					 atributosSaldo);

		var movimentoEntradaRetorno = entradaSaidaMovimentos.getMovimentoEntrada();

		var movimentoSaidaRetorno = entradaSaidaMovimentos.getMovimentoSaida();

		var estoqueSaidaRetorno = entradaSaidaMovimentos.getEstoques().getEstoqueSaida();

		var estoqueEntradaRetorno = entradaSaidaMovimentos.getEstoques().getEstoqueEntrada();

		quantidadeRestante = quantidadeRestante.subtract(saldoATransferir);
		quantidadeSkuProcessados = quantidadeSkuProcessados.add(saldoATransferir.divide(skuDestino.getQuantidadeUnidadesProduto()));

		if (quantidadeRestante.compareTo(BigDecimal.ZERO) > 0) {
			throw new WMSSaldoInsuficienteReunitizacaoException(destino.getQuantidadeSku().toString(),
																quantidadeSkuProcessados.toString());
		}

		return EstoquesSaidaEntradaMovimentos.of(EstoqueSaidaEntrada.of(unidadeId,
																		estoqueSaidaRetorno,
																		estoqueEntradaRetorno),
												 movimentoSaidaRetorno,
												 movimentoEntradaRetorno);
	}

	private List<EstoqueAtributoSaldo> obterListaEstoqueAtributoSaldo(List<AtributoEstoqueValor<?>> atributos,
																	  BigDecimal quantidade) {
		return CollectionUtils.isEmpty(atributos) ? null : List.of(EstoqueAtributoSaldo.of(atributos, quantidade));
	}

	private void validarSeUnidadeDestinoIgualUnidadeEstoque(final UnidadeId unidadeId, Estoque estoqueSaida) {
		if (!estoqueSaida.getUnidadeId().equals(unidadeId)) {
			throw new WMSReunitizacaoUnidadeDiferenteUnidadeEstoqueException();
		}
	}

	private EstoquesSaidaEntradaMovimentos realizarEntradaSaidaEstoquePorReunitizacao(SKU sku,
																					  Estoque estoqueSaida,
																					  BigDecimal saldoATransferir,
																					  UnitizadorId unitizadorIdDestino,
																					  TipoEstoqueId tipoEstoqueIdDestino,
																					  EnderecoId enderecoIdDestino,
																					  Boolean condicaoAvariaDestino,
																					  List<EstoqueAtributoSaldo> atributosSaldo) {

		var origem = Origem.of(OrigemId.from(UUID.randomUUID().toString()), "ReunitizacaoEstoque");

		var rastreioId = configuraEstoqueEntradaService.definirRastreio(saldoATransferir, estoqueSaida);

		var movimentoEstoqueIdSaida = MovimentoEstoqueId.generate();
		var movimentoEstoqueIdEntrada = MovimentoEstoqueId.generate();

		var estoqueHash = EstoqueHash.builder()
									 .unidadeId(estoqueSaida.getUnidadeId())
									 .produtoId(estoqueSaida.getProdutoId())
									 .skuId(sku.getId())
									 .unitizadorId(unitizadorIdDestino)
									 .tipoEstoqueId(tipoEstoqueIdDestino)
									 .enderecoId(enderecoIdDestino)
									 .fracionadoId(sku.isFracionado() ? FracionadoId.generate() : null)
									 .avariado(condicaoAvariaDestino)
									 .situacoes(estoqueSaida.getSituacoes())
									 .caracteristicas(estoqueSaida.getCaracteristicas())
									 .build();

		var produto = produtoRepository.findByIdOrThrowNotFound(estoqueSaida.getProdutoId());

		var estoqueEntrada = configuraEstoqueEntradaService.configurar(produto,
																	   sku,
																	   estoqueSaida.getSituacoes().iterator().next(),
																	   estoqueHash,
																	   rastreioId,
																	   estoqueSaida.getSelos(),
																	   estoqueSaida.getDataHoraEntrada());

		var enderecoDestino = enderecoRepository.findByIdOrThrowNotFound(enderecoIdDestino);

		var enderecosDiferentes = !estoqueSaida.getEnderecoId().equals(enderecoIdDestino);

		var alteraOcupacaoEnderecoOrigem = enderecosDiferentes
				&& this.determinarAlteraOcupacaoEndereco(enderecoRepository.findByIdOrThrowNotFound(estoqueSaida.getEnderecoId()));

		var alteraOcupacaoEnderecoDestino = enderecosDiferentes
				&& this.determinarAlteraOcupacaoEndereco(enderecoDestino);

		var movimentoEstoqueSaida = estoqueSaida.efetuarSaidaSaldoParcial(produto,
																		  sku,
																		  saldoATransferir,
																		  origem,
																		  movimentoEstoqueIdSaida,
																		  movimentoEstoqueIdEntrada,
																		  estoqueEntrada.getRastreioId(),
																		  alteraOcupacaoEnderecoOrigem,
																		  atributosSaldo);

		atualizaSaldoSaidaService.atualizar(estoqueSaida);

		movimentoEstoqueRepository.insert(movimentoEstoqueSaida);

		var movimentoEstoqueEntrada = estoqueEntrada.efetuarEntradaReunitizacao(produto,
																				sku,
																				saldoATransferir,
																				origem,
																				movimentoEstoqueIdEntrada,
																				movimentoEstoqueIdSaida,
																				estoqueSaida.getRastreioId(),
																				alteraOcupacaoEnderecoDestino,
																				enderecoDestino,
																				atributosSaldo);
		atualizaSaldoEntradaService.atualizar(estoqueEntrada);

		movimentoEstoqueRepository.insert(movimentoEstoqueEntrada);

		estoqueSaida.removeEvents();
		estoqueEntrada.removeEvents();

		return EstoquesSaidaEntradaMovimentos.of(EstoqueSaidaEntrada.of(estoqueSaida.getUnidadeId(),
																		EstoqueSaida.from(estoqueSaida),
																		estoqueEntrada),
												 movimentoEstoqueSaida,
												 movimentoEstoqueEntrada);
	}

	private boolean determinarAlteraOcupacaoEndereco(Endereco endereco) {
		return !endereco.isDoca() && !endereco.isStage();
	}
}
