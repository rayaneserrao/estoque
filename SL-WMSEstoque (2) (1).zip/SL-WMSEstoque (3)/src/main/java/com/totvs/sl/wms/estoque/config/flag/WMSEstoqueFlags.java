package com.totvs.sl.wms.estoque.config.flag;

import java.util.Collections;
import java.util.HashMap;
import java.util.Set;

import javax.annotation.PostConstruct;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.util.StringUtils;

import com.totvs.sl.wms.estoque.util.TenantUtils;
import com.totvs.sl.wms.estoque.util.flag.FlagUtils;

import lombok.Data;
import lombok.NonNull;

@Data
@Configuration
@ConfigurationProperties(prefix = "wms-estoque.feature-flags", ignoreInvalidFields = true)
public class WMSEstoqueFlags {

	private HashMap<String, Set<String>> flags;

	@PostConstruct
	private void init() {
		FlagUtils.init(this);
	}

	public boolean hasFlagTenant(@NonNull final String flag) {
		if (!StringUtils.hasText(flag))
			return false;

		final var tenant = TenantUtils.getTenant();

		return this.hasFlagTenant(flag, tenant);
	}

	public boolean hasFlagTenant(@NonNull final String flag, @NonNull final String tenant) {
		if (!StringUtils.hasText(flag) || !StringUtils.hasText(tenant))
			return false;

		final var flagTenants = flags.getOrDefault(flag.toUpperCase(), Collections.emptySet());
		return flagTenants.stream()
						  .map(TenantUtils::normalizeTenant)
						  .anyMatch(flagTenant -> flagTenant.equalsIgnoreCase(TenantUtils.normalizeTenant(tenant)));
	}
}
