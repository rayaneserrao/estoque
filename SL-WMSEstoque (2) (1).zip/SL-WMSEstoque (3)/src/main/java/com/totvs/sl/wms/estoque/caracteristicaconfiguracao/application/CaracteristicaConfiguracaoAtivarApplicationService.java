package com.totvs.sl.wms.estoque.caracteristicaconfiguracao.application;

import javax.transaction.Transactional;

import org.springframework.stereotype.Service;

import com.totvs.sl.wms.estoque.caracteristicaconfiguracao.application.command.AtivarCaracteristicaConfiguracaoCommand;
import com.totvs.sl.wms.estoque.caracteristicaconfiguracao.domain.model.CaracteristicaConfiguracaoDomainRepository;
import com.totvs.sl.wms.estoque.config.amqp.WMSPublisher;

import lombok.AllArgsConstructor;

@Service
@Transactional
@AllArgsConstructor
public class CaracteristicaConfiguracaoAtivarApplicationService {

	private CaracteristicaConfiguracaoDomainRepository repository;
	private WMSPublisher publisher;

	public void handle(AtivarCaracteristicaConfiguracaoCommand cmd) {

		var caracteristicaConfiguracao = repository.findByIdOrThrowNotFound(cmd.getId());

		if (caracteristicaConfiguracao.ativar()) {
			repository.update(caracteristicaConfiguracao);

			caracteristicaConfiguracao.getEvents().forEach(publisher::dispatch);
		}
	}
}
