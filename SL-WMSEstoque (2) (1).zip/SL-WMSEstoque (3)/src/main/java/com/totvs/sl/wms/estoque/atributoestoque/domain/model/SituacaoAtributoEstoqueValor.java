package com.totvs.sl.wms.estoque.atributoestoque.domain.model;

public enum SituacaoAtributoEstoqueValor {
	ATIVO, INATIVO
}
