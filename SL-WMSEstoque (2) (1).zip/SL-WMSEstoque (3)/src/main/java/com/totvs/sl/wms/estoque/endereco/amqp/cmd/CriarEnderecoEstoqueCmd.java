package com.totvs.sl.wms.estoque.endereco.amqp.cmd;

import static com.totvs.sl.wms.estoque.util.Constants.QUANTIDADE_MAXIMA_DECIMAIS;
import static com.totvs.sl.wms.estoque.util.Constants.QUANTIDADE_MAXIMA_DE_4_INTEIROS;

import java.math.BigDecimal;

import javax.validation.Valid;
import javax.validation.constraints.Digits;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Positive;

import com.totvs.sl.wms.estoque.endereco.domain.model.EnderecoId;
import com.totvs.sl.wms.estoque.unidade.domain.model.UnidadeId;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public final class CriarEnderecoEstoqueCmd {

	public static final String NAME = "CriarEnderecoEstoqueCmd";

	public static final String CONDITIONAL_EXPRESSION = "headers['type']=='" + NAME + "'";

	@NotNull(message = "{CriarEnderecoEstoqueCmd.id.NotNull}")
	private final EnderecoId id;
	@NotNull(message = "{CriarEnderecoEstoqueCmd.unidadeId.NotNull}")
	private final UnidadeId unidadeId;
	@NotNull(message = "{CriarEnderecoEstoqueCmd.funcao.NotNull}")
	private final String funcao;

	@Valid
	private final CriarEnderecoEstoqueCmdCapacidade capacidade;

	@Data(staticConstructor = "of")
	public static final class CriarEnderecoEstoqueCmdCapacidade {
		@Positive(message = "{CriarEnderecoEstoqueCmdCapacidade.unitizador.Positive}")
		private final Integer unitizador;

		@Positive(message = "{CriarEnderecoEstoqueCmdCapacidade.peso.Positive}")
		@Digits(fraction = 4, integer = 11, message = "{CriarEnderecoEstoqueCmdCapacidade.peso.Digits}")
		private final BigDecimal peso;

		@Valid
		private final CriarEnderecoEstoqueCmdDimensao dimensao;
	}

	@Data(staticConstructor = "of")
	public static final class CriarEnderecoEstoqueCmdDimensao {
		@Positive(message = "{CriarEnderecoEstoqueCmdDimensao.altura.Positive}")
		@Digits(fraction = QUANTIDADE_MAXIMA_DECIMAIS, integer = QUANTIDADE_MAXIMA_DE_4_INTEIROS, message = "{CriarEnderecoEstoqueCmdDimensao.altura.Digits}")
		private final BigDecimal altura;

		@Positive(message = "{CriarEnderecoEstoqueCmdDimensao.largura.Positive}")
		@Digits(fraction = QUANTIDADE_MAXIMA_DECIMAIS, integer = QUANTIDADE_MAXIMA_DE_4_INTEIROS, message = "{CriarEnderecoEstoqueCmdDimensao.largura.Digits}")
		private final BigDecimal largura;

		@Positive(message = "{CriarEnderecoEstoqueCmdDimensao.comprimento.Positive}")
		@Digits(fraction = QUANTIDADE_MAXIMA_DECIMAIS, integer = QUANTIDADE_MAXIMA_DE_4_INTEIROS, message = "{CriarEnderecoEstoqueCmdDimensao.comprimento.Digits}")
		private final BigDecimal comprimento;
	}

}
