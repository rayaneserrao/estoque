package com.totvs.sl.wms.estoque.endereco.api.dto;

import static com.totvs.sl.wms.estoque.util.Constants.QUANTIDADE_MAXIMA_DECIMAIS;
import static com.totvs.sl.wms.estoque.util.Constants.QUANTIDADE_MAXIMA_INTEIROS;

import java.math.BigDecimal;

import javax.validation.constraints.Digits;
import javax.validation.constraints.Positive;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Getter
@Builder
@AllArgsConstructor
@NoArgsConstructor(access = AccessLevel.PRIVATE, force = true)
@Schema(description = "Informações para capacidade de endereço")
public final class AlterarEnderecoCapacidadeDTO {

	@Positive(message = "{AlterarEnderecoCapacidadeDTO.capacidadeUnitizador.Positive}")
	@Schema(description = "Capacidade máxima de unitizadores pode conter no endereço")
	private final Integer capacidadeUnitizador;

	@Positive(message = "{AlterarEnderecoCapacidadeDTO.capacidadePeso.Positive}")
	@Digits(fraction = QUANTIDADE_MAXIMA_DECIMAIS, integer = QUANTIDADE_MAXIMA_INTEIROS, message = "{AlterarEnderecoCapacidadeDTO.capacidadePeso.Digits}")
	@Schema(description = "Capacidade máxima de peso pode conter no endereço")
	private final BigDecimal capacidadePeso;

	@Positive(message = "{AlterarEnderecoCapacidadeDTO.capacidadeAltura.Positive}")
	@Digits(fraction = QUANTIDADE_MAXIMA_DECIMAIS, integer = QUANTIDADE_MAXIMA_INTEIROS, message = "{AlterarEnderecoCapacidadeDTO.capacidadeAltura.Digits}")
	@Schema(description = "Capacidade máxima de altura pode conter no endereço")
	private final BigDecimal capacidadeAltura;

	@Positive(message = "{AlterarEnderecoCapacidadeDTO.capacidadeLargura.Positive}")
	@Digits(fraction = QUANTIDADE_MAXIMA_DECIMAIS, integer = QUANTIDADE_MAXIMA_INTEIROS, message = "{AlterarEnderecoCapacidadeDTO.capacidadeLargura.Digits}")
	@Schema(description = "Capacidade máxima de largura pode conter no endereço")
	private final BigDecimal capacidadeLargura;

	@Positive(message = "{AlterarEnderecoCapacidadeDTO.capacidadeComprimento.Positive}")
	@Digits(fraction = QUANTIDADE_MAXIMA_DECIMAIS, integer = QUANTIDADE_MAXIMA_INTEIROS, message = "{AlterarEnderecoCapacidadeDTO.capacidadeComprimento.Digits}")
	@Schema(description = "Capacidade máxima de comprimento pode conter no endereço")
	private final BigDecimal capacidadeComprimento;
}
