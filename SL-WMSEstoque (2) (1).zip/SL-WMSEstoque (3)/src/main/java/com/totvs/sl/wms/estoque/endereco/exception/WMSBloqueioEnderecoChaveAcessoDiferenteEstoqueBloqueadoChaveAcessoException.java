package com.totvs.sl.wms.estoque.endereco.exception;

import com.totvs.tjf.api.context.stereotype.error.ApiBadRequest;

@ApiBadRequest
public class WMSBloqueioEnderecoChaveAcessoDiferenteEstoqueBloqueadoChaveAcessoException extends RuntimeException {

	private static final long serialVersionUID = -5956380837141174552L;
}
