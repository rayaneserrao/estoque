package com.totvs.sl.wms.estoque.categoriaproduto.domain.event;

import com.totvs.sl.wms.estoque.categoriaproduto.domain.model.CategoriaProduto;
import com.totvs.sl.wms.estoque.categoriaproduto.domain.model.CategoriaProdutoId;
import com.totvs.sl.wms.estoque.util.amqp.SubjectConfiguracao;
import com.totvs.sl.wms.estoque.util.amqp.SubjectDomainEvent;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data(staticConstructor = "of")
@EqualsAndHashCode(callSuper = false)
public final class CategoriaProdutoAlteradoEvent extends SubjectDomainEvent implements SubjectConfiguracao {

	private final CategoriaProdutoId id;
	private final String descricao;

	public static CategoriaProdutoAlteradoEvent from(CategoriaProduto categoriaProduto) {
		return CategoriaProdutoAlteradoEvent.of(categoriaProduto.getId(), categoriaProduto.getDescricao());
	}

}
