package com.totvs.sl.wms.estoque.estoque.domain.event;

import java.math.BigDecimal;

import com.totvs.sl.wms.estoque.bloqueiomovimentacaoestoque.domain.model.BloqueioMovimentacaoEstoque;
import com.totvs.sl.wms.estoque.bloqueiomovimentacaoestoque.domain.model.BloqueioMovimentacaoEstoqueId;
import com.totvs.sl.wms.estoque.estoque.domain.model.Estoque;
import com.totvs.sl.wms.estoque.estoque.domain.model.EstoqueId;
import com.totvs.sl.wms.estoque.util.amqp.SubjectConfiguracao;
import com.totvs.sl.wms.estoque.util.amqp.SubjectDomainEvent;

import lombok.AccessLevel;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
@Builder(access = AccessLevel.PRIVATE)
public final class EstoqueAumentoBloqueioMovimentacaoEfetuadoEvent extends SubjectDomainEvent
		implements SubjectConfiguracao {

	private final BloqueioMovimentacaoEstoqueId bloqueioMovimentacaoEstoqueId;
	private final BigDecimal quantidadeBloqueioEfetuado;
	private final BloqueioMovimentacaoEstoqueAumentoQuantidade quantidadeBloqueada;
	private final BloqueioMovimentacaoEstoqueAumentoSaldo estoque;

	@Data(staticConstructor = "of")
	public static final class BloqueioMovimentacaoEstoqueAumentoQuantidade {
		private final BigDecimal naoReservada;
		private final BigDecimal reservada;
		private final BigDecimal total;
	}

	@Data(staticConstructor = "of")
	public static final class BloqueioMovimentacaoEstoqueAumentoSaldo {
		private final EstoqueId estoqueId;
		private final BloqueioMovimentacaoEstoqueAumentoQuantidade quantidadeBloqueada;
	}

	public static EstoqueAumentoBloqueioMovimentacaoEfetuadoEvent from(Estoque estoque,
																	   BloqueioMovimentacaoEstoque bloqueioMovimentacaoEstoque,
																	   BigDecimal quantidadeBloqueioEfetuado) {

		return EstoqueAumentoBloqueioMovimentacaoEfetuadoEvent.builder()
															  .bloqueioMovimentacaoEstoqueId(bloqueioMovimentacaoEstoque.getId())
															  .quantidadeBloqueioEfetuado(quantidadeBloqueioEfetuado)
															  .quantidadeBloqueada(BloqueioMovimentacaoEstoqueAumentoQuantidade.of(bloqueioMovimentacaoEstoque.getQuantidadeNaoReservada(),
																																   bloqueioMovimentacaoEstoque.getQuantidadeReservada(),
																																   bloqueioMovimentacaoEstoque.getQuantidade()))
															  .estoque(BloqueioMovimentacaoEstoqueAumentoSaldo.of(estoque.getId(),
																												  BloqueioMovimentacaoEstoqueAumentoQuantidade.of(estoque.getQuantidadeBloqueadaParaMovimentacaoEstoqueNaoReservada(),
																																								  estoque.getQuantidadeBloqueadaParaMovimentacaoEstoqueReservada(),
																																								  estoque.getQuantidadeBloqueadaParaMovimentacaoEstoqueTotal())))
															  .build();
	}

}
