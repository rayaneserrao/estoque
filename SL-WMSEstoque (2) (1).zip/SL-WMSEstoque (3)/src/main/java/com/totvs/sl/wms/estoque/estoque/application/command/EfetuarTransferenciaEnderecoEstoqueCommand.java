package com.totvs.sl.wms.estoque.estoque.application.command;

import java.math.BigDecimal;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import com.totvs.sl.wms.estoque.estoque.domain.model.EstoqueAtributoSaldo;
import org.springframework.util.CollectionUtils;

import com.totvs.sl.wms.estoque.atributoestoquevalor.domain.model.AtributoEstoqueValor;
import com.totvs.sl.wms.estoque.bloqueiomovimentacaoestoque.domain.model.BloqueioMovimentacaoEstoqueId;
import com.totvs.sl.wms.estoque.bloqueiomovimentacaounitizador.domain.model.BloqueioMovimentacaoUnitizadorId;
import com.totvs.sl.wms.estoque.endereco.domain.model.EnderecoId;
import com.totvs.sl.wms.estoque.estoque.domain.model.Estoque;
import com.totvs.sl.wms.estoque.estoque.domain.model.EstoqueId;
import com.totvs.sl.wms.estoque.estoque.domain.model.EstoqueReservaDefinitiva;
import com.totvs.sl.wms.estoque.origem.domain.model.Origem;
import com.totvs.sl.wms.estoque.reservadefinitivaestoque.domain.model.ReservaDefinitivaEstoqueId;
import com.totvs.sl.wms.estoque.unidade.domain.model.UnidadeId;
import com.totvs.sl.wms.estoque.unitizador.domain.model.UnitizadorId;

import lombok.Builder;
import lombok.Data;
import lombok.Getter;

@Data
public final class EfetuarTransferenciaEnderecoEstoqueCommand {

	private final UnidadeId unidadeId;

	private final Origem origem;

	private final EstoqueId estoqueId;

	private final EnderecoId enderecoId;

	private final Optional<BloqueioMovimentacaoEstoqueId> bloqueioMovimentacaoEstoqueId;

	private final Optional<BloqueioMovimentacaoUnitizadorId> bloqueioMovimentacaoUnitizadorId;

	private final Set<ReservaDefinitivaEstoqueId> reservasDefinitivas = new HashSet<>();

	private final BigDecimal quantidade;

	@Getter
	private final Optional<UnitizadorId> unitizadorId;

	private final Optional<String> chaveAcesso;

	private final List<AtributoEstoqueValor<?>> atributos;

	@Builder
	public EfetuarTransferenciaEnderecoEstoqueCommand(final UnidadeId unidadeId, // NOSONAR
													  final Origem origem,
													  final EstoqueId estoqueId,
													  final EnderecoId enderecoId,
													  final BloqueioMovimentacaoEstoqueId bloqueioMovimentacaoEstoqueId,
													  final BloqueioMovimentacaoUnitizadorId bloqueioMovimentacaoUnitizadorId,
													  final Set<ReservaDefinitivaEstoqueId> reservasDefinitivas,
													  final BigDecimal quantidade,
													  final UnitizadorId unitizadorId,
													  final String chaveAcesso,
													  final List<AtributoEstoqueValor<?>> atributos) {
		this.unidadeId = unidadeId;
		this.origem = origem;
		this.estoqueId = estoqueId;
		this.enderecoId = enderecoId;
		this.bloqueioMovimentacaoEstoqueId = Optional.ofNullable(bloqueioMovimentacaoEstoqueId);
		this.bloqueioMovimentacaoUnitizadorId = Optional.ofNullable(bloqueioMovimentacaoUnitizadorId);
		this.quantidade = quantidade;
		this.unitizadorId = Optional.ofNullable(unitizadorId);
		this.atributos = atributos;

		if (!CollectionUtils.isEmpty(reservasDefinitivas))
			this.reservasDefinitivas.addAll(reservasDefinitivas);

		this.chaveAcesso = Optional.ofNullable(chaveAcesso);
	}

	public BigDecimal getQuantidade(Estoque estoqueSaida) {

		if (this.bloqueioMovimentacaoEstoqueId.isPresent()) {
			return estoqueSaida.getBloqueiosMovimentacaoEstoque()
							   .stream()
							   .filter(bloqueio -> bloqueio.getBloqueioMovimentacaoEstoqueId()
														   .equals(this.bloqueioMovimentacaoEstoqueId.get()))
							   .findFirst()
							   .orElseThrow()
							   .getQuantidade();
		} else if (!CollectionUtils.isEmpty(this.reservasDefinitivas)) {
			return estoqueSaida.getReservasDefinitivas()
							   .stream()
							   .filter(reserva -> this.reservasDefinitivas.contains(reserva.getReservaDefinitivaEstoqueId()))
							   .map(EstoqueReservaDefinitiva::getQuantidade)
							   .reduce(BigDecimal.ZERO, BigDecimal::add);

		} else if (this.quantidade != null) {
			return this.quantidade;
		} else {
			return estoqueSaida.getSaldo();
		}
	}

	public Set<ReservaDefinitivaEstoqueId> getReservasDefinitivas(Estoque estoqueSaida) {
		if (this.bloqueioMovimentacaoEstoqueId.isPresent()) {
			return estoqueSaida.getBloqueiosMovimentacaoEstoque()
							   .stream()
							   .filter(bloqueio -> bloqueio.getBloqueioMovimentacaoEstoqueId()
														   .equals(this.bloqueioMovimentacaoEstoqueId.get()))
							   .flatMap(bloqueio -> bloqueio.getReservasDefinitivas().stream())
							   .map(EstoqueReservaDefinitiva::getReservaDefinitivaEstoqueId)
							   .collect(Collectors.toSet());
		} else if (!CollectionUtils.isEmpty(this.reservasDefinitivas)) {
			return this.reservasDefinitivas;
		} else {
			return Set.of();
		}
	}

	public List<EstoqueAtributoSaldo> getAtributosSaldo(Estoque estoqueSaida) {

		if (this.bloqueioMovimentacaoEstoqueId.isPresent()) {
			return estoqueSaida.getBloqueiosMovimentacaoEstoque()
							   .stream()
							   .filter(bloqueio -> bloqueio.getBloqueioMovimentacaoEstoqueId()
														   .equals(this.bloqueioMovimentacaoEstoqueId.get()))
							   .findFirst()
							   .orElseThrow()
							   .getAtributosSaldo();
		} else if (!CollectionUtils.isEmpty(this.atributos)) {
			return List.of(EstoqueAtributoSaldo.of(this.atributos, this.quantidade));
		} else {
			return estoqueSaida.getAtributosSaldo();
		}
	}
}
