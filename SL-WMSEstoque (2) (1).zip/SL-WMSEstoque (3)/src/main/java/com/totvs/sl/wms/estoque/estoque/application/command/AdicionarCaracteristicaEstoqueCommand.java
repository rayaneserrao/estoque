package com.totvs.sl.wms.estoque.estoque.application.command;

import com.totvs.sl.wms.estoque.caracteristicaconfiguracao.domain.model.CaracteristicaConfiguracaoId;
import com.totvs.sl.wms.estoque.produto.domain.model.ProdutoId;

import lombok.Data;

@Data(staticConstructor = "of")
public final class AdicionarCaracteristicaEstoqueCommand {
	private final ProdutoId produtoId;
	private final CaracteristicaConfiguracaoId caracteristicaConfiguracaoId;
	private final String valorPadrao;
}
