package com.totvs.sl.wms.estoque.atributoestoquevalor.api.dto;

import java.util.Collections;
import java.util.List;
import java.util.TreeSet;
import java.util.stream.Collectors;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.springframework.util.CollectionUtils;

import com.totvs.sl.wms.estoque.atributoestoque.domain.model.AtributoEstoqueId;
import com.totvs.sl.wms.estoque.atributoestoque.domain.model.ControleQuantidadeAtributoEstoqueValor;
import com.totvs.sl.wms.estoque.atributoestoque.domain.model.FormatoAtributoEstoqueValor;
import com.totvs.sl.wms.estoque.atributoestoquevalor.domain.model.AtributoEstoqueValor;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Builder;
import lombok.Getter;

@Getter
@Builder
public final class AtributoEstoqueValorDTO {

	@Schema(description = "Identificador do atributo de estoque.", required = true)
	@NotNull(message = "{AtributoEstoqueValorDTO.id.NotNull}")
	private final AtributoEstoqueId id;

	@Schema(description = "Formato do atributo de estoque.", required = true)
	@NotNull(message = "{AtributoEstoqueValorDTO.formato.NotNull}")
	private final FormatoAtributoEstoqueValor formato;

	@Schema(description = "Identificador do controle de quantidade do atributo de estoque.", required = true)
	@NotNull(message = "{AtributoEstoqueValorDTO.controleQuantidade.NotNull}")
	private final ControleQuantidadeAtributoEstoqueValor controleQuantidade;

	@Schema(description = "Valores do atributo de estoque.", required = true)
	@NotNull(message = "{AtributoEstoqueValorDTO.valores.NotNull}")
	@Size(min = 1, message = "{AtributoEstoqueValorDTO.valores.Size}")
	private final TreeSet<String> valores;

	public static List<AtributoEstoqueValor<?>> toAtributoEstoqueValor(List<AtributoEstoqueValorDTO> atributos) {

		if (CollectionUtils.isEmpty(atributos))
			return Collections.emptyList();

		return atributos.stream()
						.map(atributo -> atributo.getFormato()
												 .getInstance(atributo.getId(),
															  atributo.getValores(),
															  atributo.getControleQuantidade()))
						.collect(Collectors.toList());
	}
}
