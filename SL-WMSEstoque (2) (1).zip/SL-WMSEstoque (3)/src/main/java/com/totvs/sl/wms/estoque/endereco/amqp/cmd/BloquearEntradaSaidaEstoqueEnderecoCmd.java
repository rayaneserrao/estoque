package com.totvs.sl.wms.estoque.endereco.amqp.cmd;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import com.totvs.sl.wms.estoque.endereco.domain.model.EnderecoId;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public final class BloquearEntradaSaidaEstoqueEnderecoCmd {

	public static final String NAME = "BloquearEntradaSaidaEstoqueEnderecoCmd";

	public static final String CONDITIONAL_EXPRESSION = "headers['type']=='" + NAME + "'";

	@NotNull(message = "{BloquearEntradaSaidaEstoqueEnderecoCmd.id.NotNull}")
	private final EnderecoId id;

	@NotBlank(message = "{BloquearEntradaSaidaEstoqueEnderecoCmd.chaveAcesso.NotBlank}")
	private final String chaveAcesso;

	private final boolean bloquearEstoques;

	private final String motivo;

	private final boolean permiteSkuFracionado;

}
