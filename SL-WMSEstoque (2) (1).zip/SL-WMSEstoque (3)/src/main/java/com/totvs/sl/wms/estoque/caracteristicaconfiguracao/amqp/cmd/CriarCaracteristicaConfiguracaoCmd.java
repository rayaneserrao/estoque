package com.totvs.sl.wms.estoque.caracteristicaconfiguracao.amqp.cmd;

import javax.validation.constraints.NotBlank;

import com.totvs.sl.wms.estoque.caracteristicaconfiguracao.domain.model.CaracteristicaConfiguracaoOrigem;
import com.totvs.sl.wms.estoque.caracteristicaconfiguracao.domain.model.FormatoCaracteristicaValor;
import com.totvs.tjf.core.validation.ValueOfEnum;

import lombok.Data;

@Data(staticConstructor = "of")
public final class CriarCaracteristicaConfiguracaoCmd {

	public static final String NAME = "CriarCaracteristicaConfiguracaoCmd";

	public static final String CONDITIONAL_EXPRESSION = "headers['type']=='" + NAME + "'";

	@NotBlank(message = "{CriarCaracteristicaConfiguracaoCmd.descricao.NotBlank}")
	private final String descricao;

	@NotBlank(message = "{CriarCaracteristicaConfiguracaoCmd.formato.NotBlank}")
	@ValueOfEnum(enumClass = FormatoCaracteristicaValor.class, message = "{CriarCaracteristicaConfiguracaoCmd.formato.ValueOfENum}")
	private final String formato;

	@NotBlank(message = "{CriarCaracteristicaConfiguracaoCmd.origem.NotBlank}")
	@ValueOfEnum(enumClass = CaracteristicaConfiguracaoOrigem.class, message = "{CriarCaracteristicaConfiguracaoCmd.origem.ValueOfENum}")
	private final String origem;

}
