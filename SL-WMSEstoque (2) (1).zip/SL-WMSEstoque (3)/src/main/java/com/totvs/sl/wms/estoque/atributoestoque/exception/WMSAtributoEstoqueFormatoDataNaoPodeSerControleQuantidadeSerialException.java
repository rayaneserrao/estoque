package com.totvs.sl.wms.estoque.atributoestoque.exception;

import com.totvs.tjf.api.context.stereotype.error.ApiBadRequest;

@ApiBadRequest
public class WMSAtributoEstoqueFormatoDataNaoPodeSerControleQuantidadeSerialException extends RuntimeException {

	private static final long serialVersionUID = -6352008408020127149L;

}
