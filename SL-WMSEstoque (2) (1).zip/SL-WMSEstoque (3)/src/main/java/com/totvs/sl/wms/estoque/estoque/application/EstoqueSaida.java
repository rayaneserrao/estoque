package com.totvs.sl.wms.estoque.estoque.application;

import java.math.BigDecimal;
import java.util.List;

import com.totvs.sl.wms.estoque.estoque.domain.model.Estoque;
import com.totvs.sl.wms.estoque.estoque.domain.model.EstoqueAtributoSaldo;
import com.totvs.sl.wms.estoque.estoque.domain.model.EstoqueId;
import com.totvs.sl.wms.estoque.unidade.domain.model.UnidadeId;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public final class EstoqueSaida {

	private UnidadeId unidadeId;
	private EstoqueId estoqueId;
	private BigDecimal saldo;
	private BigDecimal saldoReservado;
	private BigDecimal saldoDisponivel;
	private BigDecimal quantidadeBloqueadaMovimentacaoNaoReservada;
	private BigDecimal quantidadeBloqueadaMovimentacaoReservada;
	private BigDecimal quantidadeBloqueadaMovimentacaoTotal;
	private List<EstoqueAtributoSaldo> atributosSaldo;

	public static EstoqueSaida from(Estoque estoque) {
		return new EstoqueSaida(estoque.getUnidadeId(),
								estoque.getId(),
								estoque.getSaldo(),
								estoque.getQuantidadeReservada(),
								estoque.getSaldoDisponivel(),
								estoque.getQuantidadeBloqueadaParaMovimentacaoEstoqueNaoReservada(),
								estoque.getQuantidadeBloqueadaParaMovimentacaoEstoqueReservada(),
								estoque.getQuantidadeBloqueadaParaMovimentacaoEstoqueTotal(),
								estoque.getAtributosSaldo());
	}
}
