package com.totvs.sl.wms.estoque.endereco.domain.model;

import static com.totvs.sl.wms.estoque.util.Constants.QUANTIDADE_MAXIMA_DECIMAIS;
import static com.totvs.sl.wms.estoque.util.Constants.QUANTIDADE_MAXIMA_DE_4_INTEIROS;
import static com.totvs.tjf.autoconfigure.ValidationUtils.validateIntegrity;

import java.math.BigDecimal;
import java.math.RoundingMode;

import javax.validation.constraints.Digits;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Positive;

import com.totvs.sl.wms.estoque.endereco.exception.WMSDimensaoEnderecoConstraintException;
import com.totvs.sl.wms.estoque.util.Constants;

import lombok.AccessLevel;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor(access = AccessLevel.PRIVATE, force = true)
public final class DimensaoEndereco {

	@NotNull(message = "{DimensaoEndereco.altura.NotNull}")
	@Positive(message = "{DimensaoEndereco.altura.Positive}")
	@Digits(fraction = QUANTIDADE_MAXIMA_DECIMAIS, integer = QUANTIDADE_MAXIMA_DE_4_INTEIROS, message = "{DimensaoEndereco.altura.Digits}")
	private final BigDecimal altura;

	@NotNull(message = "{DimensaoEndereco.largura.NotNull}")
	@Positive(message = "{DimensaoEndereco.largura.Positive}")
	@Digits(fraction = QUANTIDADE_MAXIMA_DECIMAIS, integer = QUANTIDADE_MAXIMA_DE_4_INTEIROS, message = "{DimensaoEndereco.largura.Digits}")
	private final BigDecimal largura;

	@NotNull(message = "{DimensaoEndereco.comprimento.NotNull}")
	@Positive(message = "{DimensaoEndereco.comprimento.Positive}")
	@Digits(fraction = QUANTIDADE_MAXIMA_DECIMAIS, integer = QUANTIDADE_MAXIMA_DE_4_INTEIROS, message = "{DimensaoEndereco.comprimento.Digits}")
	private final BigDecimal comprimento;

	private DimensaoEndereco(BigDecimal altura, BigDecimal largura, BigDecimal comprimento) {

		this.altura = altura;
		this.largura = largura;
		this.comprimento = comprimento;

		validateIntegrity(this).ifPresent(violations -> {
			throw new WMSDimensaoEnderecoConstraintException(violations);
		});
	}

	public static DimensaoEndereco of(BigDecimal altura, BigDecimal largura, BigDecimal comprimento) {
		return new DimensaoEndereco(altura, largura, comprimento);
	}

	public BigDecimal getCubagem() {
		return this.altura.multiply(this.largura)
						  .multiply(this.comprimento)
						  .setScale(Constants.QUANTIDADE_MAXIMA_DECIMAIS, RoundingMode.HALF_EVEN);
	}
}
