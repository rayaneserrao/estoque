package com.totvs.sl.wms.estoque.endereco.exception;

import java.math.BigDecimal;

import com.totvs.tjf.api.context.stereotype.ApiErrorParameter;
import com.totvs.tjf.api.context.stereotype.error.ApiBadRequest;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
@ApiBadRequest
public class WMSEnderecoOcupacaoCubagemNaoPodeSerSuperiorCapacidadeException extends RuntimeException {

	private static final long serialVersionUID = 1210178469247291781L;

	@ApiErrorParameter
	private final BigDecimal capacidade;

	@ApiErrorParameter
	private final BigDecimal ocupacao;
}
