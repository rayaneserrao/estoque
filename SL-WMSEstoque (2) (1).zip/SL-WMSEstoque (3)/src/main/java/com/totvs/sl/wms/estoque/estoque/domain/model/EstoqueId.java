package com.totvs.sl.wms.estoque.estoque.domain.model;

import java.util.UUID;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.totvs.tjf.core.common.domain.DomainObjectId;

public final class EstoqueId extends DomainObjectId<UUID> {

	private static final long serialVersionUID = 5900662630341581483L;

	protected EstoqueId(UUID id) {
		super(id);
	}

	public static EstoqueId generate() {
		return new EstoqueId(UUID.randomUUID());
	}

	@JsonCreator
	public static EstoqueId from(String uuid) {
		return uuid == null ? null : new EstoqueId(UUID.fromString(uuid));
	}
}