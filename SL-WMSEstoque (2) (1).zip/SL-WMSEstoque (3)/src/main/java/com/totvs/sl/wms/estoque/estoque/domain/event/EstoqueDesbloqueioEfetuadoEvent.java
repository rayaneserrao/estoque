package com.totvs.sl.wms.estoque.estoque.domain.event;

import java.math.BigDecimal;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.util.CollectionUtils;

import com.totvs.sl.wms.estoque.caracteristicaconfiguracao.domain.model.CaracteristicaConfiguracaoId;
import com.totvs.sl.wms.estoque.caracteristicaconfiguracao.domain.model.FormatoCaracteristicaValor;
import com.totvs.sl.wms.estoque.endereco.domain.model.EnderecoId;
import com.totvs.sl.wms.estoque.estoque.domain.model.Estoque;
import com.totvs.sl.wms.estoque.estoque.domain.model.EstoqueId;
import com.totvs.sl.wms.estoque.estoque.domain.model.SituacaoEstoque;
import com.totvs.sl.wms.estoque.estoque.domain.model.SituacaoEstoqueLiberado;
import com.totvs.sl.wms.estoque.origem.domain.model.Origem;
import com.totvs.sl.wms.estoque.produto.domain.model.ProdutoId;
import com.totvs.sl.wms.estoque.rastreio.domain.model.RastreioId;
import com.totvs.sl.wms.estoque.sku.domain.model.SKUId;
import com.totvs.sl.wms.estoque.tipoestoque.domain.model.TipoEstoqueId;
import com.totvs.sl.wms.estoque.unidade.domain.model.UnidadeId;
import com.totvs.sl.wms.estoque.unitizador.domain.model.UnitizadorId;
import com.totvs.sl.wms.estoque.util.amqp.SubjectDomainEvent;

import lombok.Builder;
import lombok.Data;
import lombok.Getter;
import lombok.ToString;

@Getter
@ToString
@Builder
public final class EstoqueDesbloqueioEfetuadoEvent extends SubjectDomainEvent implements SubjectBloqueioEstoque {

	private final UnidadeId unidadeId;

	@Deprecated(since = "Aguardar inventário remover dependência")
	private final EstoqueOrigem origem;
	private final EstoqueSaida estoqueSaida;
	private final EstoqueEntrada estoqueEntrada;
	private final BigDecimal quantidade;

	@Deprecated(since = "Aguardar inventário remover dependência")
	@Data(staticConstructor = "of")
	public static final class EstoqueOrigem {
		private final String id;
		private final String origem;
	}

	@Data
	@Builder
	public static final class EstoqueSaida {
		private final EstoqueId id;
		private final BigDecimal saldo;
		private final BigDecimal saldoReservado;
		private final BigDecimal saldoDisponivel;
		private final BigDecimal quantidadeBloqueadaMovimentacaoNaoReservada;
		private final BigDecimal quantidadeBloqueadaMovimentacaoReservada;
		private final BigDecimal quantidadeBloqueadaMovimentacaoTotal;
		private final List<EstoqueAtributoSaldoEvent> atributosSaldo;
	}

	@Data(staticConstructor = "of")
	public static final class CaracteristicaEstoqueEntrada {
		private final CaracteristicaConfiguracaoId caracteristicaConfiguracaoId;
		private final FormatoCaracteristicaValor formato;
		private final String valor;
	}

	@Data
	@Builder
	public static final class EstoqueEntrada {
		private final EstoqueId id;
		private final ProdutoId produtoId;
		private final SKUId skuId;
		private final UnitizadorId unitizadorId;
		private final TipoEstoqueId tipoEstoqueId;
		private final EnderecoId enderecoId;
		private final Set<SituacaoEstoqueEntrada> situacoes;
		private final Boolean avariado;
		private final List<CaracteristicaEstoqueEntrada> caracteristicas;
		private final List<EstoqueAtributoSaldoEvent> atributosSaldo;
		private final RastreioId rastreioId;
		private final BigDecimal saldo;
		private final BigDecimal saldoReservado;
		private final BigDecimal saldoDisponivel;
		private final BigDecimal quantidadeBloqueadaMovimentacaoNaoReservada;
		private final BigDecimal quantidadeBloqueadaMovimentacaoReservada;
		private final BigDecimal quantidadeBloqueadaMovimentacaoTotal;
		private final List<SeloEstoqueEvent> selos;
		private final ZonedDateTime dataHoraEntrada;
	}

	@Data(staticConstructor = "of")
	public static final class SituacaoEstoqueEntrada {
		private final ZonedDateTime quando;
	}

	@Data(staticConstructor = "of")
	public static final class SeloEstoqueEvent {
		private final String chave;
		private final String valor;
	}

	public static EstoqueDesbloqueioEfetuadoEvent from(Estoque estoqueOrigem,
													   BigDecimal quantidadeDesbloqueada,
													   Estoque estoqueDestino,
													   Origem origem) {

		return EstoqueDesbloqueioEfetuadoEvent.builder()
											  .unidadeId(estoqueDestino.getUnidadeId())
											  .quantidade(quantidadeDesbloqueada)
											  .origem(EstoqueOrigem.of(origem.getId().toString(), origem.getOrigem()))
											  .estoqueSaida(EstoqueSaida.builder()
																		.id(estoqueOrigem.getId())
																		.saldo(estoqueOrigem.getSaldo())
																		.saldoReservado(estoqueOrigem.getQuantidadeReservada())
																		.saldoDisponivel(estoqueOrigem.getSaldoDisponivel())
																		.quantidadeBloqueadaMovimentacaoNaoReservada(estoqueOrigem.getQuantidadeBloqueadaParaMovimentacaoEstoqueNaoReservada())
																		.quantidadeBloqueadaMovimentacaoReservada(estoqueOrigem.getQuantidadeBloqueadaParaMovimentacaoEstoqueReservada())
																		.quantidadeBloqueadaMovimentacaoTotal(estoqueOrigem.getQuantidadeBloqueadaParaMovimentacaoEstoqueTotal())
																		.atributosSaldo(EstoqueAtributoSaldoEvent.from(estoqueOrigem.getAtributosSaldo()))
																		.build())
											  .estoqueEntrada(EstoqueEntrada.builder()
																			.id(estoqueDestino.getId())
																			.produtoId(estoqueDestino.getProdutoId())
																			.skuId(estoqueDestino.getSkuId())
																			.unitizadorId(estoqueDestino.getUnitizadorId())
																			.tipoEstoqueId(estoqueDestino.getTipoEstoqueId())
																			.enderecoId(estoqueDestino.getEnderecoId())
																			.situacoes(montarSituacoesEstoque(estoqueDestino.getSituacoes()))
																			.avariado(estoqueDestino.getAvariado())
																			.caracteristicas(montarCaracteristicas(estoqueDestino))
																			.atributosSaldo(EstoqueAtributoSaldoEvent.from(estoqueDestino.getAtributosSaldo()))
																			.rastreioId(estoqueDestino.getRastreioId())
																			.saldo(estoqueDestino.getSaldo())
																			.saldoReservado(estoqueDestino.getQuantidadeReservada())
																			.saldoDisponivel(estoqueDestino.getSaldoDisponivel())
																			.quantidadeBloqueadaMovimentacaoNaoReservada(estoqueDestino.getQuantidadeBloqueadaParaMovimentacaoEstoqueNaoReservada())
																			.quantidadeBloqueadaMovimentacaoReservada(estoqueDestino.getQuantidadeBloqueadaParaMovimentacaoEstoqueReservada())
																			.quantidadeBloqueadaMovimentacaoTotal(estoqueDestino.getQuantidadeBloqueadaParaMovimentacaoEstoqueTotal())
																			.selos(estoqueDestino.getSelos()
																								 .stream()
																								 .map(selo -> SeloEstoqueEvent.of(selo.getChave(),
																																  selo.getValor()))
																								 .collect(Collectors.toList()))
																			.dataHoraEntrada(estoqueDestino.getDataHoraEntrada())
																			.build())
											  .build();

	}

	private static Set<SituacaoEstoqueEntrada> montarSituacoesEstoque(Set<SituacaoEstoque> situacoes) {
		return situacoes.stream()
						.map(EstoqueDesbloqueioEfetuadoEvent::criarSituacaoEstoqueEntrada)
						.collect(Collectors.toSet());
	}

	private static SituacaoEstoqueEntrada criarSituacaoEstoqueEntrada(SituacaoEstoque situacao) {
		var situacaoEstoque = (SituacaoEstoqueLiberado) situacao;
		return SituacaoEstoqueEntrada.of(situacaoEstoque.getQuando());
	}

	private static List<CaracteristicaEstoqueEntrada> montarCaracteristicas(Estoque estoque) {
		if (CollectionUtils.isEmpty(estoque.getCaracteristicas())) {
			return new ArrayList<>();
		}
		return estoque.getCaracteristicas()
					  .stream()
					  .map(caracteristica -> CaracteristicaEstoqueEntrada.of(caracteristica.getCaracteristicaConfiguracaoId(),
																			 caracteristica.getFormato(),
																			 caracteristica.getValor().toString()))
					  .collect(Collectors.toList());
	}
}
