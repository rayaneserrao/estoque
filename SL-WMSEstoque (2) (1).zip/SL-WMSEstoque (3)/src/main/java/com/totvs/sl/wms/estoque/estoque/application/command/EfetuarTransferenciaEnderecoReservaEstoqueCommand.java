package com.totvs.sl.wms.estoque.estoque.application.command;

import java.util.List;
import java.util.Optional;

import org.springframework.util.CollectionUtils;

import com.totvs.sl.wms.estoque.atributoestoquevalor.domain.model.AtributoEstoqueValor;
import com.totvs.sl.wms.estoque.bloqueiomovimentacaoestoque.domain.model.BloqueioMovimentacaoEstoqueId;
import com.totvs.sl.wms.estoque.endereco.domain.model.EnderecoId;
import com.totvs.sl.wms.estoque.estoque.domain.model.Estoque;
import com.totvs.sl.wms.estoque.estoque.domain.model.EstoqueAtributoSaldo;
import com.totvs.sl.wms.estoque.origem.domain.model.Origem;
import com.totvs.sl.wms.estoque.reservadefinitivaestoque.domain.model.ReservaDefinitivaEstoque;
import com.totvs.sl.wms.estoque.reservadefinitivaestoque.domain.model.ReservaDefinitivaEstoqueId;
import com.totvs.sl.wms.estoque.unidade.domain.model.UnidadeId;
import com.totvs.sl.wms.estoque.unitizador.domain.model.UnitizadorId;

import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;

@Getter
@EqualsAndHashCode
public final class EfetuarTransferenciaEnderecoReservaEstoqueCommand {
	private final UnidadeId unidadeId;
	private final Origem origem;
	private final ReservaDefinitivaEstoqueId reservaDefinitivaEstoqueId;
	private final EnderecoId enderecoId;
	private final Optional<BloqueioMovimentacaoEstoqueId> bloqueioMovimentacaoEstoqueId;
	private final Optional<UnitizadorId> unitizadorId;
	private final List<AtributoEstoqueValor<?>> atributos;

	@Builder
	private EfetuarTransferenciaEnderecoReservaEstoqueCommand(final UnidadeId unidadeId,
															  final Origem origem,
															  final ReservaDefinitivaEstoqueId reservaDefinitivaEstoqueId,
															  final EnderecoId enderecoId,
															  final BloqueioMovimentacaoEstoqueId bloqueioMovimentacaoEstoqueId,
															  final UnitizadorId unitizadorId,
															  final List<AtributoEstoqueValor<?>> atributos) {
		this.unidadeId = unidadeId;
		this.origem = origem;
		this.reservaDefinitivaEstoqueId = reservaDefinitivaEstoqueId;
		this.enderecoId = enderecoId;
		this.bloqueioMovimentacaoEstoqueId = Optional.ofNullable(bloqueioMovimentacaoEstoqueId);
		this.unitizadorId = Optional.ofNullable(unitizadorId);
		this.atributos = atributos;
	}

	public List<EstoqueAtributoSaldo> getAtributosSaldo(Estoque estoqueSaida, ReservaDefinitivaEstoque reserva) {

		if (this.bloqueioMovimentacaoEstoqueId.isPresent()) {
			return estoqueSaida.getBloqueiosMovimentacaoEstoque()
							   .stream()
							   .filter(bloqueio -> bloqueio.getBloqueioMovimentacaoEstoqueId()
														   .equals(this.bloqueioMovimentacaoEstoqueId.get()))
							   .findFirst()
							   .orElseThrow()
							   .getAtributosSaldo();
		} else if (!CollectionUtils.isEmpty(this.atributos)) {
			return List.of(EstoqueAtributoSaldo.of(this.atributos, reserva.getQuantidade()));
		} else {
			return estoqueSaida.getReservasDefinitivas()
							   .stream()
							   .filter(reservaDefinitiva -> reservaDefinitiva.getReservaDefinitivaEstoqueId()
																			 .equals(reserva.getId()))
							   .findFirst()
							   .orElseThrow()
							   .getAtributosSaldo();
		}
	}
}
