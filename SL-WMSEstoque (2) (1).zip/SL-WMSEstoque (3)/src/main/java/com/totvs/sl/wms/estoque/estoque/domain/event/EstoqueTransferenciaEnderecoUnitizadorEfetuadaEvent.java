package com.totvs.sl.wms.estoque.estoque.domain.event;

import java.math.BigDecimal;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.util.CollectionUtils;

import com.totvs.sl.wms.estoque.bloqueiomovimentacaounitizador.domain.model.BloqueioMovimentacaoUnitizadorId;
import com.totvs.sl.wms.estoque.caracteristicaconfiguracao.domain.model.CaracteristicaConfiguracaoId;
import com.totvs.sl.wms.estoque.caracteristicaconfiguracao.domain.model.FormatoCaracteristicaValor;
import com.totvs.sl.wms.estoque.caracteristicavalor.domain.model.CaracteristicaValor;
import com.totvs.sl.wms.estoque.endereco.domain.model.Endereco;
import com.totvs.sl.wms.estoque.endereco.domain.model.EnderecoId;
import com.totvs.sl.wms.estoque.endereco.domain.model.FuncaoEndereco;
import com.totvs.sl.wms.estoque.estoque.application.EstoqueSaidaEntrada;
import com.totvs.sl.wms.estoque.estoque.domain.model.EstoqueId;
import com.totvs.sl.wms.estoque.estoque.domain.model.SituacaoEstoque;
import com.totvs.sl.wms.estoque.estoque.domain.model.SituacaoEstoqueBloqueado;
import com.totvs.sl.wms.estoque.estoque.domain.model.SituacaoEstoqueLiberado;
import com.totvs.sl.wms.estoque.estoque.domain.model.SituacaoEstoqueValor;
import com.totvs.sl.wms.estoque.produto.domain.model.ProdutoId;
import com.totvs.sl.wms.estoque.rastreio.domain.model.RastreioId;
import com.totvs.sl.wms.estoque.sku.domain.model.SKUId;
import com.totvs.sl.wms.estoque.tipoestoque.domain.model.TipoEstoqueId;
import com.totvs.sl.wms.estoque.unidade.domain.model.UnidadeId;
import com.totvs.sl.wms.estoque.unitizador.domain.model.UnitizadorId;
import com.totvs.sl.wms.estoque.util.amqp.SubjectDomainEvent;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.Getter;
import lombok.ToString;

@ToString
@Getter
@AllArgsConstructor(staticName = "of")
public final class EstoqueTransferenciaEnderecoUnitizadorEfetuadaEvent extends SubjectDomainEvent
		implements SubjectMovimentacaoEstoque {

	public static final String NAME = "EstoqueTransferenciaEnderecoUnitizadorEfetuadaEvent";
	public static final String CONDITIONAL_EXPRESSION = "headers['type']=='" + NAME + "'";

	private final UnidadeId unidadeId;
	private final EnderecoDestino enderecoDestino;
	private final BloqueioMovimentacaoUnitizadorId bloqueioMovimentacaoUnitizadorId;
	private final List<EstoqueTransferencia> estoques;

	@Data(staticConstructor = "of")
	public static final class EnderecoDestino {
		private final EnderecoId id;
		private final FuncaoEndereco funcao;
	}

	@Data(staticConstructor = "of")
	public static final class EstoqueTransferencia {
		private final EstoqueTransferenciaSaida saida;
		private final EstoqueTransferenciaEntrada entrada;
	}

	@Data
	@Builder
	public static final class EstoqueTransferenciaSaida {
		private final EstoqueId id;
		private final BigDecimal saldo;
		private final BigDecimal saldoReservado;
		private final BigDecimal saldoDisponivel;
		private final BigDecimal quantidadeBloqueadaMovimentacaoNaoReservada;
		private final BigDecimal quantidadeBloqueadaMovimentacaoReservada;
		private final BigDecimal quantidadeBloqueadaMovimentacaoTotal;
		private final List<EstoqueAtributoSaldoEvent> atributosSaldo;
	}

	@Data
	@Builder
	public static final class EstoqueTransferenciaEntrada {
		private final EstoqueId id;
		private final ProdutoId produtoId;
		private final SKUId skuId;
		private final UnitizadorId unitizadorId;
		private final TipoEstoqueId tipoEstoqueId;
		private final EnderecoId enderecoId;
		private final Set<SituacaoEstoqueTransferenciaUnitizador> situacoes;
		private final Boolean avariado;
		private final RastreioId rastreioId;
		private final List<CaracteristicaEstoqueEntrada> caracteristicas;
		private final List<EstoqueAtributoSaldoEvent> atributosSaldo;
		private final BigDecimal saldo;
		private final BigDecimal saldoReservado;
		private final BigDecimal saldoDisponivel;
		private final BigDecimal quantidadeBloqueadaMovimentacaoNaoReservada;
		private final BigDecimal quantidadeBloqueadaMovimentacaoReservada;
		private final BigDecimal quantidadeBloqueadaMovimentacaoTotal;
		private final List<SeloEstoqueEvent> selos;
		private final ZonedDateTime dataHoraEntrada;
	}

	@Data
	@Builder
	public static final class SituacaoEstoqueTransferenciaUnitizador {
		private final SituacaoEstoqueValor situacao;
		private final ZonedDateTime quando;
		private final String chaveAcesso;
		private final String motivo;
	}

	@Data(staticConstructor = "of")
	public static final class CaracteristicaEstoqueEntrada {
		private final CaracteristicaConfiguracaoId caracteristicaConfiguracaoId;
		private final FormatoCaracteristicaValor formato;
		private final String valor;
	}

	@Data(staticConstructor = "of")
	public static final class SeloEstoqueEvent {
		private final String chave;
		private final String valor;
	}

	public static EstoqueTransferenciaEnderecoUnitizadorEfetuadaEvent from(UnidadeId unidadeId,
																		   Endereco endereco,
																		   Iterable<EstoqueSaidaEntrada> listaEstoques,
																		   BloqueioMovimentacaoUnitizadorId bloqueioMovimentacaoUnitizadorId) {

		var listaEstoquesEvent = new ArrayList<EstoqueTransferencia>();

		for (var estoque : listaEstoques) {

			var estoqueSaida = estoque.getEstoqueSaida();
			var estoqueEntrada = estoque.getEstoqueEntrada();

			listaEstoquesEvent.add(EstoqueTransferencia.of(EstoqueTransferenciaSaida.builder()
																					.id(estoqueSaida.getEstoqueId())
																					.saldo(estoqueSaida.getSaldo())
																					.saldoReservado(estoqueSaida.getSaldoReservado())
																					.saldoDisponivel(estoqueSaida.getSaldoDisponivel())
																					.quantidadeBloqueadaMovimentacaoNaoReservada(estoqueSaida.getQuantidadeBloqueadaMovimentacaoNaoReservada())
																					.quantidadeBloqueadaMovimentacaoReservada(estoqueSaida.getQuantidadeBloqueadaMovimentacaoReservada())
																					.quantidadeBloqueadaMovimentacaoTotal(estoqueSaida.getQuantidadeBloqueadaMovimentacaoTotal())
																					.atributosSaldo(EstoqueAtributoSaldoEvent.from(estoqueSaida.getAtributosSaldo()))
																					.build(),
														   EstoqueTransferenciaEntrada.builder()
																					  .id(estoqueEntrada.getId())
																					  .produtoId(estoqueEntrada.getProdutoId())
																					  .skuId(estoqueEntrada.getSkuId())
																					  .unitizadorId(estoqueEntrada.getUnitizadorId())
																					  .tipoEstoqueId(estoqueEntrada.getTipoEstoqueId())
																					  .enderecoId(estoqueEntrada.getEnderecoId())
																					  .situacoes(montarSituacoesEstoqueDestino(estoqueEntrada.getSituacoes()))
																					  .avariado(estoqueEntrada.getAvariado())
																					  .saldo(estoqueEntrada.getSaldo())
																					  .saldoReservado(estoqueEntrada.getQuantidadeReservada())
																					  .saldoDisponivel(estoqueEntrada.getSaldoDisponivel())
																					  .quantidadeBloqueadaMovimentacaoNaoReservada(estoqueEntrada.getQuantidadeBloqueadaParaMovimentacaoEstoqueNaoReservada())
																					  .quantidadeBloqueadaMovimentacaoReservada(estoqueEntrada.getQuantidadeBloqueadaParaMovimentacaoEstoqueReservada())
																					  .quantidadeBloqueadaMovimentacaoTotal(estoqueEntrada.getQuantidadeBloqueadaParaMovimentacaoEstoqueTotal())
																					  .caracteristicas(montarCaracteristicasEstoqueDestino(estoqueEntrada.getCaracteristicas()))
																					  .atributosSaldo(EstoqueAtributoSaldoEvent.from(estoqueEntrada.getAtributosSaldo()))
																					  .rastreioId(estoqueEntrada.getRastreioId())
																					  .selos(estoqueEntrada.getSelos()
																										   .stream()
																										   .map(selo -> SeloEstoqueEvent.of(selo.getChave(),
																																			selo.getValor()))
																										   .collect(Collectors.toList()))
																					  .dataHoraEntrada(estoqueEntrada.getDataHoraEntrada())
																					  .build()));
		}

		return EstoqueTransferenciaEnderecoUnitizadorEfetuadaEvent.of(unidadeId,
																	  montarEnderecoDestino(endereco),
																	  bloqueioMovimentacaoUnitizadorId,
																	  listaEstoquesEvent);
	}

	private static EnderecoDestino montarEnderecoDestino(Endereco endereco) {
		return EnderecoDestino.of(endereco.getId(), endereco.getFuncao());
	}

	private static Set<SituacaoEstoqueTransferenciaUnitizador> montarSituacoesEstoqueDestino(Set<SituacaoEstoque> situacoes) {
		return situacoes.stream()
						.map(EstoqueTransferenciaEnderecoUnitizadorEfetuadaEvent::criar)
						.collect(Collectors.toSet());
	}

	private static SituacaoEstoqueTransferenciaUnitizador criar(SituacaoEstoque situacao) {
		return situacao.getSituacaoEstoque().equals(SituacaoEstoqueValor.LIBERADO) ? criarSituacaoLiberado(situacao)
				: criarSituacaoBloqueado(situacao);
	}

	private static SituacaoEstoqueTransferenciaUnitizador criarSituacaoLiberado(SituacaoEstoque situacao) {
		var situacaoLiberado = (SituacaoEstoqueLiberado) situacao;

		return SituacaoEstoqueTransferenciaUnitizador.builder()
													 .situacao(SituacaoEstoqueValor.LIBERADO)
													 .quando(situacaoLiberado.getQuando())
													 .build();
	}

	private static SituacaoEstoqueTransferenciaUnitizador criarSituacaoBloqueado(SituacaoEstoque situacao) {
		var situacaoBloqueado = (SituacaoEstoqueBloqueado) situacao;

		return SituacaoEstoqueTransferenciaUnitizador.builder()
													 .situacao(SituacaoEstoqueValor.BLOQUEADO)
													 .quando(situacaoBloqueado.getQuando())
													 .chaveAcesso(situacaoBloqueado.getChaveAcesso())
													 .motivo(situacaoBloqueado.getMotivo())
													 .build();
	}

	private static List<CaracteristicaEstoqueEntrada> montarCaracteristicasEstoqueDestino(List<CaracteristicaValor<?>> caracteristicas) {
		if (CollectionUtils.isEmpty(caracteristicas)) {
			return new ArrayList<>();
		}
		return caracteristicas.stream()
							  .map(caracteristica -> CaracteristicaEstoqueEntrada.of(caracteristica.getCaracteristicaConfiguracaoId(),
																					 caracteristica.getFormato(),
																					 caracteristica.getValor()
																								   .toString()))
							  .collect(Collectors.toList());
	}
}
