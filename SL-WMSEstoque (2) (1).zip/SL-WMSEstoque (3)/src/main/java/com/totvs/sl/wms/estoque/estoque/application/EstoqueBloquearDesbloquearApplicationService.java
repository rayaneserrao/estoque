package com.totvs.sl.wms.estoque.estoque.application;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.totvs.sl.wms.estoque.bloqueiomovimentacaounitizador.domain.model.BloqueioMovimentacaoUnitizadorId;
import com.totvs.sl.wms.estoque.config.amqp.WMSPublisher;
import com.totvs.sl.wms.estoque.endereco.domain.model.EnderecoDomainRepository;
import com.totvs.sl.wms.estoque.estoque.application.command.BloquearEstoqueCommand;
import com.totvs.sl.wms.estoque.estoque.application.command.DesbloquearEstoqueCommand;
import com.totvs.sl.wms.estoque.estoque.application.command.DesbloquearEstoquesUnitizadorCommand;
import com.totvs.sl.wms.estoque.estoque.domain.event.DesbloqueioEstoquesUnitizadorEfetuadoEvent;
import com.totvs.sl.wms.estoque.estoque.domain.event.EstoqueBloqueioEfetuadoEvent;
import com.totvs.sl.wms.estoque.estoque.domain.event.EstoqueDesbloqueioEfetuadoEvent;
import com.totvs.sl.wms.estoque.estoque.domain.model.Estoque;
import com.totvs.sl.wms.estoque.estoque.domain.model.EstoqueAtributoSaldo;
import com.totvs.sl.wms.estoque.estoque.domain.model.EstoqueDomainRepository;
import com.totvs.sl.wms.estoque.estoque.domain.model.EstoqueHash;
import com.totvs.sl.wms.estoque.estoque.domain.model.EstoqueId;
import com.totvs.sl.wms.estoque.estoque.domain.model.FracionadoId;
import com.totvs.sl.wms.estoque.estoque.domain.model.SituacaoEstoque;
import com.totvs.sl.wms.estoque.estoque.domain.model.SituacaoEstoqueBloqueado;
import com.totvs.sl.wms.estoque.estoque.domain.model.SituacaoEstoqueLiberado;
import com.totvs.sl.wms.estoque.estoque.domain.service.AtualizaSaldoEstoqueEntradaDomainService;
import com.totvs.sl.wms.estoque.estoque.domain.service.AtualizaSaldoEstoqueSaidaDomainService;
import com.totvs.sl.wms.estoque.estoque.domain.service.ConfiguraEstoqueParaEntradaDomainService;
import com.totvs.sl.wms.estoque.estoque.domain.service.ValidaUnitizadorEstoqueDomainService;
import com.totvs.sl.wms.estoque.movimentoestoque.domain.model.MovimentoEstoque;
import com.totvs.sl.wms.estoque.movimentoestoque.domain.model.MovimentoEstoqueDomainRepository;
import com.totvs.sl.wms.estoque.movimentoestoque.domain.model.MovimentoEstoqueId;
import com.totvs.sl.wms.estoque.origem.domain.model.Origem;
import com.totvs.sl.wms.estoque.produto.domain.model.ProdutoDomainRepository;
import com.totvs.sl.wms.estoque.sku.domain.model.SKUDomainRepository;
import com.totvs.sl.wms.estoque.unitizador.domain.model.UnitizadorDomainRepository;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Service
@Transactional
@AllArgsConstructor
public class EstoqueBloquearDesbloquearApplicationService {

	private final MovimentoEstoqueDomainRepository movimentoEstoqueRepository;
	private final EstoqueDomainRepository estoqueRepository;
	private final ProdutoDomainRepository produtoRepository;
	private final SKUDomainRepository skuRepository;
	private final EnderecoDomainRepository enderecoRepository;
	private final UnitizadorDomainRepository unitizadorRepository;
	private final ValidaUnitizadorEstoqueDomainService validaEstoqueUnitizadorService;
	private final ConfiguraEstoqueParaEntradaDomainService configuraEstoqueEntradaService;
	private final AtualizaSaldoEstoqueEntradaDomainService atualizaSaldoEntradaService;
	private final AtualizaSaldoEstoqueSaidaDomainService atualizaSaldoSaidaService;
	private final WMSPublisher publisher;

	@Getter
	@AllArgsConstructor(staticName = "of")
	public static final class BloqueioEfetuadoEventEstoquesMovimentos {
		private EstoqueBloqueioEfetuadoEvent evento;
		private MovimentoEstoque movimentoSaida;
		private MovimentoEstoque movimentoEntrada;
	}

	@Getter
	@AllArgsConstructor(staticName = "of")
	public static final class DesbloqueioEfetuadoEventEstoquesMovimentos {
		private EstoqueDesbloqueioEfetuadoEvent evento;
		private MovimentoEstoque movimentoSaida;
		private MovimentoEstoque movimentoEntrada;
	}

	public EstoqueId handle(final BloquearEstoqueCommand cmd) {

		var estoqueSaida = estoqueRepository.findWithLockByIdAndUnidadeIdOrThrowNotFound(cmd.getEstoqueId(),
																						 cmd.getUnidadeId());

		var situacao = SituacaoEstoqueBloqueado.of(cmd.getChaveAcesso(), cmd.getMotivo());

		var eventoMovimentos = this.efetuarBloqueioEstoque(estoqueSaida,
														   cmd.getQuantidade(),
														   situacao,
														   cmd.getOrigem(),
														   cmd.getAtributosSaldo(estoqueSaida));

		eventoMovimentos.getMovimentoSaida().getEvents().forEach(publisher::dispatch);
		eventoMovimentos.getMovimentoEntrada().getEvents().forEach(publisher::dispatch);

		publisher.dispatch(eventoMovimentos.getEvento());

		return eventoMovimentos.getMovimentoEntrada().getEstoqueId();

	}

	public EstoqueId handle(final DesbloquearEstoqueCommand cmd) {

		var estoqueSaida = estoqueRepository.findWithLockByIdAndUnidadeIdOrThrowNotFound(cmd.getEstoqueId(),
																						 cmd.getUnidadeId());

		var eventoMovimentos = this.efetuarDesbloqueioEstoque(estoqueSaida,
															  cmd.getQuantidade(),
															  cmd.getChaveAcesso(),
															  SituacaoEstoqueLiberado.of(),
															  cmd.getOrigem(),
															  cmd.getBloqueioMovimentacaoUnitizadorId().orElse(null),
															  cmd.getAtributosSaldo(estoqueSaida));

		eventoMovimentos.getMovimentoSaida().getEvents().forEach(publisher::dispatch);
		eventoMovimentos.getMovimentoEntrada().getEvents().forEach(publisher::dispatch);

		publisher.dispatch(eventoMovimentos.getEvento());

		return eventoMovimentos.getMovimentoEntrada().getEstoqueId();

	}

	public void handle(final DesbloquearEstoquesUnitizadorCommand cmd) {

		var unitizador = unitizadorRepository.findWithLockByIdOrThrowNotFound(cmd.getUnitizadorId());

		validaEstoqueUnitizadorService.idDiferenteBloqueioMovimentacaoUnitizador(cmd.getBloqueioMovimentacaoUnitizadorId()
																					.orElse(null),
																				 cmd.getUnitizadorId());

		var estoquesSaldos = estoqueRepository.findWithLockByUnitizadorIdAndUnidadeId(unitizador.getId(),
																					  unitizador.getUnidadeId());

		validaEstoqueUnitizadorService.existeNaListaEstoques(estoquesSaldos);

		estoquesSaldos.forEach(estoque -> {
			var eventoMovimentos = this.efetuarDesbloqueioEstoque(estoque,
																  estoque.getSaldo(),
																  cmd.getChaveAcesso(),
																  SituacaoEstoqueLiberado.of(),
																  cmd.getOrigem(),
																  cmd.getBloqueioMovimentacaoUnitizadorId()
																	 .orElse(null),
																  estoque.getAtributosSaldo());

			eventoMovimentos.getMovimentoSaida().getEvents().forEach(publisher::dispatch);
			eventoMovimentos.getMovimentoEntrada().getEvents().forEach(publisher::dispatch);
			publisher.dispatch(eventoMovimentos.getEvento());
		});

		publisher.dispatch(DesbloqueioEstoquesUnitizadorEfetuadoEvent.of(cmd.getUnitizadorId()));

	}

	private BloqueioEfetuadoEventEstoquesMovimentos efetuarBloqueioEstoque(Estoque estoqueSaida,
																		   BigDecimal quantidade,
																		   SituacaoEstoque situacao,
																		   Origem origem,
																		   List<EstoqueAtributoSaldo> atributosSaldo) {
		return efetuarBloqueioEstoque(estoqueSaida, quantidade, situacao, origem, false, atributosSaldo);
	}

	public BloqueioEfetuadoEventEstoquesMovimentos efetuarBloqueioEstoque(Estoque estoqueSaida,
																		  BigDecimal quantidade,
																		  SituacaoEstoque situacao,
																		  Origem origem,
																		  boolean removerUnitizador,
																		  List<EstoqueAtributoSaldo> atributosSaldo) {

		var produto = produtoRepository.findByIdOrThrowNotFound(estoqueSaida.getProdutoId());

		var sku = skuRepository.findByIdAndProdutoIdThrowNotFound(estoqueSaida.getSkuId(), estoqueSaida.getProdutoId());

		var endereco = enderecoRepository.findByIdOrThrowNotFound(estoqueSaida.getEnderecoId());

		var rastreioId = configuraEstoqueEntradaService.definirRastreio(quantidade, estoqueSaida);

		var movimentoEstoqueIdSaida = MovimentoEstoqueId.generate();
		var movimentoEstoqueIdEntrada = MovimentoEstoqueId.generate();

		var estoqueHash = EstoqueHash.builder()
									 .unidadeId(estoqueSaida.getUnidadeId())
									 .produtoId(estoqueSaida.getProdutoId())
									 .skuId(estoqueSaida.getSkuId())
									 .unitizadorId(removerUnitizador ? null : estoqueSaida.getUnitizadorId())
									 .tipoEstoqueId(estoqueSaida.getTipoEstoqueId())
									 .enderecoId(estoqueSaida.getEnderecoId())
									 .fracionadoId(sku.isFracionado() ? FracionadoId.generate() : null)
									 .situacoes(Set.of(situacao))
									 .avariado(estoqueSaida.getAvariado())
									 .caracteristicas(estoqueSaida.getCaracteristicas())
									 .build();

		var estoqueEntrada = configuraEstoqueEntradaService.configurar(produto,
																	   sku,
																	   situacao,
																	   estoqueHash,
																	   rastreioId,
																	   estoqueSaida.getSelos(),
																	   estoqueSaida.getDataHoraEntrada());

		var atributosSaldoEntrada = new ArrayList<>(List.copyOf(atributosSaldo));
		var movimentoEstoqueSaida = estoqueSaida.efetuarSaidaBloqueio(produto,
																	  sku,
																	  quantidade,
																	  origem,
																	  movimentoEstoqueIdSaida,
																	  movimentoEstoqueIdEntrada,
																	  estoqueEntrada.getRastreioId(),
																	  false,
																	  atributosSaldo);

		atualizaSaldoSaidaService.atualizar(estoqueSaida);
		movimentoEstoqueRepository.insert(movimentoEstoqueSaida);

		var movimentoEstoqueEntrada = estoqueEntrada.efetuarEntradaBloqueio(endereco,
																			produto,
																			sku,
																			quantidade,
																			origem,
																			movimentoEstoqueIdEntrada,
																			movimentoEstoqueIdSaida,
																			estoqueSaida.getRastreioId(),
																			false,
																			atributosSaldoEntrada);

		atualizaSaldoEntradaService.atualizar(estoqueEntrada);

		movimentoEstoqueRepository.insert(movimentoEstoqueEntrada);

		estoqueSaida.removeEvents();
		estoqueEntrada.removeEvents();

		var event = EstoqueBloqueioEfetuadoEvent.from(estoqueSaida, quantidade, estoqueEntrada, origem);

		return BloqueioEfetuadoEventEstoquesMovimentos.of(event, movimentoEstoqueSaida, movimentoEstoqueEntrada);

	}

	public DesbloqueioEfetuadoEventEstoquesMovimentos efetuarDesbloqueioEstoque(Estoque estoqueSaida,
																				BigDecimal quantidade,
																				String chaveAcesso,
																				SituacaoEstoque situacao,
																				Origem origem,
																				List<EstoqueAtributoSaldo> atributosSaldo) {
		return efetuarDesbloqueioEstoque(estoqueSaida, quantidade, chaveAcesso, situacao, origem, null, atributosSaldo);
	}

	private DesbloqueioEfetuadoEventEstoquesMovimentos efetuarDesbloqueioEstoque(Estoque estoqueSaida,
																				 BigDecimal quantidade,
																				 String chaveAcesso,
																				 SituacaoEstoque situacao,
																				 Origem origem,
																				 BloqueioMovimentacaoUnitizadorId bloqueioMovimentacaoUnitizadorId,
																				 List<EstoqueAtributoSaldo> atributosSaldo) {

		var produto = produtoRepository.findByIdOrThrowNotFound(estoqueSaida.getProdutoId());

		var sku = skuRepository.findByIdAndProdutoIdThrowNotFound(estoqueSaida.getSkuId(), estoqueSaida.getProdutoId());

		var rastreioId = configuraEstoqueEntradaService.definirRastreio(quantidade, estoqueSaida);

		var movimentoEstoqueIdSaida = MovimentoEstoqueId.generate();
		var movimentoEstoqueIdEntrada = MovimentoEstoqueId.generate();

		var estoqueHash = EstoqueHash.builder()
									 .unidadeId(estoqueSaida.getUnidadeId())
									 .produtoId(estoqueSaida.getProdutoId())
									 .skuId(estoqueSaida.getSkuId())
									 .unitizadorId(estoqueSaida.getUnitizadorId())
									 .tipoEstoqueId(estoqueSaida.getTipoEstoqueId())
									 .enderecoId(estoqueSaida.getEnderecoId())
									 .fracionadoId(sku.isFracionado() ? FracionadoId.generate() : null)
									 .situacoes(Set.of(situacao))
									 .avariado(estoqueSaida.getAvariado())
									 .caracteristicas(estoqueSaida.getCaracteristicas())
									 .build();

		var estoqueEntrada = configuraEstoqueEntradaService.configurar(produto,
																	   sku,
																	   situacao,
																	   estoqueHash,
																	   bloqueioMovimentacaoUnitizadorId,
																	   rastreioId,
																	   estoqueSaida.getSelos(),
																	   estoqueSaida.getDataHoraEntrada());

		var atributosSaldoEntrada = new ArrayList<>(atributosSaldo);

		var movimentoEstoqueSaida = estoqueSaida.efetuarSaidaDesbloqueio(produto,
																		 sku,
																		 quantidade,
																		 chaveAcesso,
																		 origem,
																		 movimentoEstoqueIdSaida,
																		 movimentoEstoqueIdEntrada,
																		 estoqueEntrada.getRastreioId(),
																		 false,
																		 bloqueioMovimentacaoUnitizadorId,
																		 atributosSaldo);

		atualizaSaldoSaidaService.atualizar(estoqueSaida);

		movimentoEstoqueRepository.insert(movimentoEstoqueSaida);

		var movimentoEstoqueEntrada = estoqueEntrada.efetuarEntradaDesbloqueio(produto,
																			   sku,
																			   quantidade,
																			   origem,
																			   movimentoEstoqueIdEntrada,
																			   movimentoEstoqueIdSaida,
																			   estoqueSaida.getRastreioId(),
																			   false,
																			   atributosSaldoEntrada);

		atualizaSaldoEntradaService.atualizar(estoqueEntrada);

		movimentoEstoqueRepository.insert(movimentoEstoqueEntrada);

		estoqueSaida.removeEvents();
		estoqueEntrada.removeEvents();

		var event = EstoqueDesbloqueioEfetuadoEvent.from(estoqueSaida, quantidade, estoqueEntrada, origem);

		return DesbloqueioEfetuadoEventEstoquesMovimentos.of(event, movimentoEstoqueSaida, movimentoEstoqueEntrada);

	}
}
