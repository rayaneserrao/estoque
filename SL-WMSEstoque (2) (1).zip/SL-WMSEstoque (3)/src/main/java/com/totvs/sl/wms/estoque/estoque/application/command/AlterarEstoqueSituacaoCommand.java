package com.totvs.sl.wms.estoque.estoque.application.command;

import com.totvs.sl.wms.estoque.estoque.domain.model.EstoqueId;
import com.totvs.sl.wms.estoque.estoque.domain.model.SituacaoEstoqueValor;

import lombok.Data;

@Data(staticConstructor = "of")
public final class AlterarEstoqueSituacaoCommand {
	private final EstoqueId id;
	private final SituacaoEstoqueValor situacao;
}
