package com.totvs.sl.wms.estoque.depositante.domain.model;

import java.util.UUID;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.totvs.tjf.core.common.domain.DomainObjectId;

public final class DepositanteId extends DomainObjectId<UUID> {

	private static final long serialVersionUID = 2832132242407029767L;

	protected DepositanteId(UUID id) {
		super(id);
	}
	
	@JsonCreator
	public static DepositanteId from(String uuid) {
		return uuid == null ? null : new DepositanteId(UUID.fromString(uuid));
	}
}