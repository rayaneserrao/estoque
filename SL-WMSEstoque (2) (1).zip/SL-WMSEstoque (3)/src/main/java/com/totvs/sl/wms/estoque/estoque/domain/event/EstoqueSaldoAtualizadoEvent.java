package com.totvs.sl.wms.estoque.estoque.domain.event;

import java.math.BigDecimal;
import java.time.ZonedDateTime;
import java.util.Collection;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import com.totvs.sl.wms.estoque.caracteristicaconfiguracao.domain.model.CaracteristicaConfiguracaoId;
import com.totvs.sl.wms.estoque.caracteristicaconfiguracao.domain.model.FormatoCaracteristicaValor;
import com.totvs.sl.wms.estoque.caracteristicavalor.domain.model.CaracteristicaValor;
import com.totvs.sl.wms.estoque.config.amqp.ConsumeMessage;
import com.totvs.sl.wms.estoque.endereco.domain.model.EnderecoId;
import com.totvs.sl.wms.estoque.estoque.application.EstoqueSaida;
import com.totvs.sl.wms.estoque.estoque.domain.model.Estoque;
import com.totvs.sl.wms.estoque.estoque.domain.model.EstoqueId;
import com.totvs.sl.wms.estoque.estoque.domain.model.SituacaoEstoque;
import com.totvs.sl.wms.estoque.estoque.domain.model.SituacaoEstoqueBloqueado;
import com.totvs.sl.wms.estoque.estoque.domain.model.SituacaoEstoqueLiberado;
import com.totvs.sl.wms.estoque.estoque.domain.model.SituacaoEstoqueValor;
import com.totvs.sl.wms.estoque.produto.domain.model.ProdutoId;
import com.totvs.sl.wms.estoque.rastreio.domain.model.RastreioId;
import com.totvs.sl.wms.estoque.sku.domain.model.SKUId;
import com.totvs.sl.wms.estoque.tipoestoque.domain.model.TipoEstoqueId;
import com.totvs.sl.wms.estoque.unidade.domain.model.UnidadeId;
import com.totvs.sl.wms.estoque.unitizador.domain.model.UnitizadorId;
import com.totvs.sl.wms.estoque.util.amqp.SubjectConfiguracao;
import com.totvs.sl.wms.estoque.util.amqp.SubjectDomainEvent;

import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data(staticConstructor = "of")
@EqualsAndHashCode(callSuper = false)
public final class EstoqueSaldoAtualizadoEvent extends SubjectDomainEvent
		implements SubjectConfiguracao, ConsumeMessage {

	public static final String NAME = "EstoqueSaldoAtualizadoEvent";

	public static final String CONDITIONAL_EXPRESSION = "headers['type']=='" + NAME + "'";

	private final ProdutoId produtoId;
	private final List<EstoqueAtualizacaoSaida> estoquesSaida;
	private final List<EstoqueAtualizacaoEntrada> estoquesEntrada;

	@Data
	@Builder
	public static final class EstoqueAtualizacaoSaida {
		private final UnidadeId unidadeId;
		private final EstoqueId id;
		private final BigDecimal saldo;
		private final BigDecimal saldoReservado;
		private final BigDecimal saldoDisponivel;
		private final BigDecimal quantidadeBloqueadaMovimentacaoNaoReservada;
		private final BigDecimal quantidadeBloqueadaMovimentacaoReservada;
		private final BigDecimal quantidadeBloqueadaMovimentacaoTotal;
		private final List<EstoqueAtributoSaldoEvent> atributosSaldo;
	}

	@Data
	@Builder
	public static final class EstoqueAtualizacaoEntrada {
		private final UnidadeId unidadeId;
		private final EstoqueId id;
		private final SKUId skuId;
		private final UnitizadorId unitizadorId;
		private final TipoEstoqueId tipoEstoqueId;
		private final EnderecoId enderecoId;
		private final Set<SituacaoEstoqueAtualizacao> situacoes;
		private final Boolean avariado;
		private final RastreioId rastreioId;
		private final List<CaracteristicaEstoqueEntrada> caracteristicas;
		private final List<EstoqueAtributoSaldoEvent> atributosSaldo;
		private final BigDecimal saldo;
		private final BigDecimal saldoReservado;
		private final BigDecimal saldoDisponivel;
		private final BigDecimal quantidadeBloqueadaMovimentacaoNaoReservada;
		private final BigDecimal quantidadeBloqueadaMovimentacaoReservada;
		private final BigDecimal quantidadeBloqueadaMovimentacaoTotal;
		private final List<SeloEstoqueEvent> selos;
		private final ZonedDateTime dataHoraEntrada;
	}

	@Data
	@Builder
	public static final class SituacaoEstoqueAtualizacao {
		private final SituacaoEstoqueValor situacao;
		private final ZonedDateTime quando;
		private final String chaveAcesso;
		private final String motivo;
	}

	@Data(staticConstructor = "of")
	public static final class CaracteristicaEstoqueEntrada {
		private final CaracteristicaConfiguracaoId caracteristicaConfiguracaoId;
		private final FormatoCaracteristicaValor formato;
		private final String valor;
	}

	@Data(staticConstructor = "of")
	public static final class SeloEstoqueEvent {
		private final String chave;
		private final String valor;
	}

	public static EstoqueSaldoAtualizadoEvent from(ProdutoId produtoId,
												   Collection<Estoque> estoquesEntrada,
												   Collection<EstoqueSaida> estoquesSaida) {

		return EstoqueSaldoAtualizadoEvent.of(produtoId,
											  estoquesSaida.stream()
														   .map(estoque -> EstoqueAtualizacaoSaida.builder()
																								  .id(estoque.getEstoqueId())
																								  .unidadeId(estoque.getUnidadeId())
																								  .saldo(estoque.getSaldo())
																								  .saldoReservado(estoque.getSaldoReservado())
																								  .saldoDisponivel(estoque.getSaldoDisponivel())
																								  .quantidadeBloqueadaMovimentacaoNaoReservada(estoque.getQuantidadeBloqueadaMovimentacaoNaoReservada())
																								  .quantidadeBloqueadaMovimentacaoReservada(estoque.getQuantidadeBloqueadaMovimentacaoReservada())
																								  .quantidadeBloqueadaMovimentacaoTotal(estoque.getQuantidadeBloqueadaMovimentacaoTotal())
																								  .atributosSaldo(EstoqueAtributoSaldoEvent.from(estoque.getAtributosSaldo()))
																								  .build())
														   .collect(Collectors.toList()),
											  estoquesEntrada.stream()
															 .map(estoque -> EstoqueAtualizacaoEntrada.builder()
																									  .unidadeId(estoque.getUnidadeId())
																									  .id(estoque.getId())
																									  .skuId(estoque.getSkuId())
																									  .unitizadorId(estoque.getUnitizadorId())
																									  .tipoEstoqueId(estoque.getTipoEstoqueId())
																									  .enderecoId(estoque.getEnderecoId())
																									  .situacoes(montarSituacoesEstoqueDestino(estoque.getSituacoes()))
																									  .avariado(estoque.getAvariado())
																									  .caracteristicas(montarCaracteristicas(estoque.getCaracteristicas()))
																									  .atributosSaldo(EstoqueAtributoSaldoEvent.from(estoque.getAtributosSaldo()))
																									  .rastreioId(estoque.getRastreioId())
																									  .saldo(estoque.getSaldo())
																									  .saldoReservado(estoque.getQuantidadeReservada())
																									  .saldoDisponivel(estoque.getSaldoDisponivel())
																									  .quantidadeBloqueadaMovimentacaoNaoReservada(estoque.getQuantidadeBloqueadaParaMovimentacaoEstoqueNaoReservada())
																									  .quantidadeBloqueadaMovimentacaoReservada(estoque.getQuantidadeBloqueadaParaMovimentacaoEstoqueReservada())
																									  .quantidadeBloqueadaMovimentacaoTotal(estoque.getQuantidadeBloqueadaParaMovimentacaoEstoqueTotal())
																									  .selos(estoque.getSelos()
																													.stream()
																													.map(selo -> SeloEstoqueEvent.of(selo.getChave(),
																																					 selo.getValor()))
																													.collect(Collectors.toList()))
																									  .dataHoraEntrada(estoque.getDataHoraEntrada())
																									  .build())
															 .collect(Collectors.toList()));

	}

	private static Set<SituacaoEstoqueAtualizacao> montarSituacoesEstoqueDestino(Set<SituacaoEstoque> situacoes) {
		return situacoes.stream().map(EstoqueSaldoAtualizadoEvent::criar).collect(Collectors.toSet());
	}

	private static SituacaoEstoqueAtualizacao criar(SituacaoEstoque situacao) {
		return situacao.getSituacaoEstoque().equals(SituacaoEstoqueValor.LIBERADO) ? criarSituacaoLiberado(situacao)
				: criarSituacaoBloqueado(situacao);
	}

	private static SituacaoEstoqueAtualizacao criarSituacaoLiberado(SituacaoEstoque situacao) {
		var situacaoLiberado = (SituacaoEstoqueLiberado) situacao;

		return SituacaoEstoqueAtualizacao.builder()
										 .situacao(SituacaoEstoqueValor.LIBERADO)
										 .quando(situacaoLiberado.getQuando())
										 .build();
	}

	private static SituacaoEstoqueAtualizacao criarSituacaoBloqueado(SituacaoEstoque situacao) {
		var situacaoBloqueado = (SituacaoEstoqueBloqueado) situacao;

		return SituacaoEstoqueAtualizacao.builder()
										 .situacao(SituacaoEstoqueValor.BLOQUEADO)
										 .quando(situacaoBloqueado.getQuando())
										 .chaveAcesso(situacaoBloqueado.getChaveAcesso())
										 .motivo(situacaoBloqueado.getMotivo())
										 .build();
	}

	private static List<CaracteristicaEstoqueEntrada> montarCaracteristicas(List<CaracteristicaValor<?>> caracteristicas) {
		return caracteristicas.stream()
							  .map(caracteristica -> CaracteristicaEstoqueEntrada.of(caracteristica.getCaracteristicaConfiguracaoId(),
																					 caracteristica.getFormato(),
																					 caracteristica.getValor()
																								   .toString()))
							  .collect(Collectors.toList());
	}
}
