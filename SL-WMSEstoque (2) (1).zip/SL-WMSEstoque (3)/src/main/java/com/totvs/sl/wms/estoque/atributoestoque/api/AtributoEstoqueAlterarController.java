package com.totvs.sl.wms.estoque.atributoestoque.api;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

import javax.annotation.security.RolesAllowed;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.totvs.sl.wms.estoque.atributoestoque.api.dto.AlterarAtributoEstoqueDTO;
import com.totvs.sl.wms.estoque.atributoestoque.application.AtributoEstoqueAlterarApplicationService;
import com.totvs.sl.wms.estoque.atributoestoque.application.command.AlterarAtributoEstoqueCommand;
import com.totvs.sl.wms.estoque.atributoestoque.domain.model.AtributoEstoqueId;
import com.totvs.sl.wms.estoque.atributoestoque.domain.model.ControleQuantidadeAtributoEstoqueValor;
import com.totvs.sl.wms.estoque.atributoestoque.domain.model.FormatoAtributoEstoqueValor;
import com.totvs.sl.wms.estoque.atributoestoque.exception.WMSAtributoEstoqueConstraintException;
import com.totvs.sl.wms.estoque.usuario.domain.model.UsuarioPerfil;
import com.totvs.tjf.api.context.stereotype.ApiGuideline;
import com.totvs.tjf.api.context.stereotype.ApiGuideline.ApiGuidelineVersion;
import com.totvs.tjf.core.validation.ValidatorService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.AllArgsConstructor;

@Tag(name = "atributo-estoque")

@AllArgsConstructor
@RestController
@ApiGuideline(ApiGuidelineVersion.V2)
@RequestMapping(path = AtributoEstoqueAlterarController.PATH, produces = APPLICATION_JSON_VALUE, consumes = APPLICATION_JSON_VALUE)
@RolesAllowed({ UsuarioPerfil.Perfil.PLANEJADOR_WMS, UsuarioPerfil.Perfil.PLANEJADOR_WMS_SENIOR })
public class AtributoEstoqueAlterarController {

	public static final String PATH = "/api/v1/atributosEstoque"; // NOSONAR

	private final AtributoEstoqueAlterarApplicationService service;
	private final ValidatorService validator;

	@Operation(description = "Alterar um atributo de estoque.", method = "POST")
	@ApiResponses(value = { @ApiResponse(responseCode = "204", description = "Atributo estoque alterado com sucesso."),
			@ApiResponse(responseCode = "400", description = "O atributo estoque não pôde ser alterado pois possui alguma informação inválida."),
			@ApiResponse(responseCode = "404", description = "O atributo estoque não foi encontrado."), })
	@PostMapping(path = "/{id}/alterar")
	public ResponseEntity<Void> alterar(@PathVariable AtributoEstoqueId id,
										@RequestBody AlterarAtributoEstoqueDTO dto) {

		validator.validate(dto).ifPresent(violations -> {
			throw new WMSAtributoEstoqueConstraintException(violations);
		});

		var cmd = AlterarAtributoEstoqueCommand.builder()
											   .id(id)
											   .descricao(dto.getDescricao())
											   .formato(FormatoAtributoEstoqueValor.valueOf(dto.getFormato()))
											   .controleQuantidade(ControleQuantidadeAtributoEstoqueValor.valueOf(dto.getControleQuantidade()))
											   .build();
		service.handle(cmd);
		return ResponseEntity.ok().build();
	}

}
