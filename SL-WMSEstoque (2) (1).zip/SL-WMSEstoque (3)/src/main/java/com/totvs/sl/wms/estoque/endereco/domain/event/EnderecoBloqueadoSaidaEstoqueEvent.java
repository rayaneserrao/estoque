package com.totvs.sl.wms.estoque.endereco.domain.event;

import com.totvs.sl.wms.estoque.endereco.domain.model.Endereco;
import com.totvs.sl.wms.estoque.endereco.domain.model.EnderecoId;
import com.totvs.sl.wms.estoque.endereco.domain.model.TipoBloqueioEndereco;
import com.totvs.sl.wms.estoque.estoque.domain.event.SubjectSaidaEstoque;
import com.totvs.sl.wms.estoque.util.amqp.SubjectDomainEvent;

import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
@Builder
public final class EnderecoBloqueadoSaidaEstoqueEvent extends SubjectDomainEvent implements SubjectSaidaEstoque {

	private final EnderecoId id;
	private final EnderecoBloqueadoOrigem origem;
	private final TipoBloqueioEndereco tipoBloqueioEfetuado;
	private final TipoBloqueioEndereco tipoBloqueioAtual;

	@Data(staticConstructor = "of")
	public static final class EnderecoBloqueadoOrigem {
		private final String id;
		private final String origem;
	}

	public static EnderecoBloqueadoSaidaEstoqueEvent from(Endereco endereco) {

		var bloqueio = endereco.getBloqueio().orElseThrow();

		var origemEvento = EnderecoBloqueadoOrigem.of(bloqueio.getOrigem().getId().toString(),
													  bloqueio.getOrigem().getOrigem());

		return EnderecoBloqueadoSaidaEstoqueEvent.builder()
												 .id(endereco.getId())
												 .origem(origemEvento)
												 .tipoBloqueioEfetuado(TipoBloqueioEndereco.SAIDA)
												 .tipoBloqueioAtual(bloqueio.getTipo())
												 .build();
	}
}
