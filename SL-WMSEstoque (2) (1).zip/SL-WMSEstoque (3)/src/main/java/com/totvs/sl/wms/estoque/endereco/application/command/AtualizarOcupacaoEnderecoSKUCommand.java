package com.totvs.sl.wms.estoque.endereco.application.command;

import com.totvs.sl.wms.estoque.sku.domain.model.SKUId;

import lombok.Data;

@Data(staticConstructor = "of")
public final class AtualizarOcupacaoEnderecoSKUCommand {
	private final SKUId id;
}
