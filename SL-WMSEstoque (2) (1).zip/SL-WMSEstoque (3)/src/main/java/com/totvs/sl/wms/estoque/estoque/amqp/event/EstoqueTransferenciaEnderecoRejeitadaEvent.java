package com.totvs.sl.wms.estoque.estoque.amqp.event;

import com.totvs.sl.wms.estoque.estoque.domain.event.SubjectMovimentacaoEstoque;
import com.totvs.sl.wms.estoque.estoque.domain.model.EstoqueId;
import com.totvs.sl.wms.estoque.unidade.domain.model.UnidadeId;
import com.totvs.sl.wms.estoque.util.amqp.RejectedEvent;
import com.totvs.tjf.api.context.response.ApiErrorResponse;
import lombok.Builder;
import lombok.Getter;
import lombok.ToString;

@ToString
@Getter
@Builder
public final class EstoqueTransferenciaEnderecoRejeitadaEvent extends RejectedEvent
		implements SubjectMovimentacaoEstoque {

	private final UnidadeId unidadeId;
	private final EstoqueId estoqueId;
	private ApiErrorResponse inconsistencia;
	private String mensagemCodigo;
	private String mensagemDetalhe;
}
