package com.totvs.sl.wms.estoque.estoque.application.command;

import java.math.BigDecimal;
import java.util.List;

import com.totvs.sl.wms.estoque.atributoestoquevalor.domain.model.AtributoEstoqueValor;
import com.totvs.sl.wms.estoque.caracteristicavalor.domain.model.CaracteristicaValor;
import com.totvs.sl.wms.estoque.caracteristicavalor.domain.model.CaracteristicaValorTexto;
import com.totvs.sl.wms.estoque.endereco.domain.model.EnderecoId;
import com.totvs.sl.wms.estoque.estoque.domain.model.FracionadoId;
import com.totvs.sl.wms.estoque.estoque.domain.model.SeloEstoque;
import com.totvs.sl.wms.estoque.origem.domain.model.Origem;
import com.totvs.sl.wms.estoque.produto.domain.model.ProdutoId;
import com.totvs.sl.wms.estoque.sku.domain.model.SKUId;
import com.totvs.sl.wms.estoque.tipoestoque.domain.model.TipoEstoqueId;
import com.totvs.sl.wms.estoque.unidade.domain.model.UnidadeId;
import com.totvs.sl.wms.estoque.unitizador.domain.model.UnitizadorId;

import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;

@Getter
@Builder
@EqualsAndHashCode
public final class EfetuarEntradaEstoqueLiberadoCommand implements EfetuarEntradaEstoqueCommand {
	private final UnidadeId unidadeId;
	private final Origem origem;
	private final ProdutoId produtoId;
	private final SKUId skuId;
	private final UnitizadorId unitizadorId;
	private final TipoEstoqueId tipoEstoqueId;
	private final EnderecoId enderecoId;
	private final Boolean avariado;
	private final BigDecimal quantidade;
	@Deprecated
	private final List<CaracteristicaValorTexto> caracteristicasOld;
	private final List<SeloEstoque> selos;
	private final FracionadoId fracionadoId;
	private final List<AtributoEstoqueValor<?>> atributos;
	private final List<CaracteristicaValor<?>> caracteristicas;
}
