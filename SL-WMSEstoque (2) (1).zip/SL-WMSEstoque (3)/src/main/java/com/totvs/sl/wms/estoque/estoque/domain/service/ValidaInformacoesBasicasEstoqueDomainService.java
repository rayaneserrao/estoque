package com.totvs.sl.wms.estoque.estoque.domain.service;

import org.springframework.stereotype.Service;

import com.totvs.sl.wms.estoque.caracteristicaconfiguracao.domain.model.CaracteristicaConfiguracaoDomainRepository;
import com.totvs.sl.wms.estoque.caracteristicaconfiguracao.domain.model.CaracteristicaConfiguracaoId;
import com.totvs.sl.wms.estoque.caracteristicaconfiguracao.exception.WMSCaracteristicaConfiguracaoNaoEncontradaException;
import com.totvs.sl.wms.estoque.endereco.domain.model.EnderecoDomainRepository;
import com.totvs.sl.wms.estoque.endereco.domain.model.EnderecoId;
import com.totvs.sl.wms.estoque.endereco.exception.WMSEnderecoNaoEncontradoException;
import com.totvs.sl.wms.estoque.estoque.exception.WMSProdutoComSituacaoInativoException;
import com.totvs.sl.wms.estoque.estoque.exception.WMSSkuComSituacaoInativoException;
import com.totvs.sl.wms.estoque.estoque.exception.WMSTipoEstoqueComSituacaoInativoException;
import com.totvs.sl.wms.estoque.produto.domain.model.ProdutoDomainRepository;
import com.totvs.sl.wms.estoque.produto.domain.model.ProdutoId;
import com.totvs.sl.wms.estoque.produto.exception.WMSProdutoNaoEncontradoException;
import com.totvs.sl.wms.estoque.sku.domain.model.SKUDomainRepository;
import com.totvs.sl.wms.estoque.sku.domain.model.SKUId;
import com.totvs.sl.wms.estoque.tipoestoque.domain.model.TipoEstoqueDomainRepository;
import com.totvs.sl.wms.estoque.tipoestoque.domain.model.TipoEstoqueId;
import com.totvs.sl.wms.estoque.unidade.domain.model.UnidadeDomainRepository;
import com.totvs.sl.wms.estoque.unidade.domain.model.UnidadeId;
import com.totvs.sl.wms.estoque.unidade.exception.WMSUnidadeNaoEncontradaException;

import lombok.AllArgsConstructor;

@Service
@AllArgsConstructor
public class ValidaInformacoesBasicasEstoqueDomainService {

	private final UnidadeDomainRepository unidadeRepository;
	private final EnderecoDomainRepository enderecoRepository;
	private final ProdutoDomainRepository produtoRepository;
	private final TipoEstoqueDomainRepository tipoEstoqueRepository;
	private final CaracteristicaConfiguracaoDomainRepository caracteristicaRepository;
	private final SKUDomainRepository skuDomainRepository;

	public void existeUnidade(UnidadeId unidadeId) {
		if (!unidadeRepository.existeUnidadeComId(unidadeId)) {
			throw new WMSUnidadeNaoEncontradaException();
		}
	}

	public void existeEnderecoParaUnidade(UnidadeId unidadeId, EnderecoId enderecoId) {
		if (!enderecoRepository.existeEnderecoComIdEUnidadeId(enderecoId, unidadeId)) {
			throw new WMSEnderecoNaoEncontradoException();
		}
	}

	public void existeProdutoAtivo(ProdutoId produtoId) {
		if (!produtoRepository.existeProdutoComIdEAtivo(produtoId)) {
			throw new WMSProdutoNaoEncontradoException();
		}
	}

	public void existeProdutoAtivoParaUnidade(UnidadeId unidadeId, ProdutoId produtoId) {
		var produto = produtoRepository.findByIdAndUnidadeIdOrThrowNotFound(produtoId, unidadeId);
		if (produto.getSituacao().isInativo()) {
			throw new WMSProdutoComSituacaoInativoException(produto.getCodigo(), produto.getDescricaoInterna());
		}
	}

	public void existeTipoEstoqueAtivoParaUnidade(UnidadeId unidadeId, TipoEstoqueId tipoEstoqueId) {
		var tipoEstoque = tipoEstoqueRepository.findByIdAndUnidadeIdOrThrowNotFound(tipoEstoqueId, unidadeId);
		if (tipoEstoque.getSituacao().isInativo()) {
			throw new WMSTipoEstoqueComSituacaoInativoException(tipoEstoque.getDescricao());
		}
	}

	public void existeCaracteristicaConfiguracao(CaracteristicaConfiguracaoId caracteristicaConfiguracaoId) {
		if (!caracteristicaRepository.findById(caracteristicaConfiguracaoId).isPresent()) {
			throw new WMSCaracteristicaConfiguracaoNaoEncontradaException();
		}
	}

	public void existeSkuAtivo(SKUId skuId, ProdutoId produtoId) {
		var sku = skuDomainRepository.findByIdAndProdutoIdThrowNotFound(skuId, produtoId);
		if (sku.getSituacao().isInativo()) {
			throw new WMSSkuComSituacaoInativoException(sku.getDescricao());
		}
	}

}
