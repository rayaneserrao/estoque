package com.totvs.sl.wms.estoque.estoque.domain.model;

import java.time.ZonedDateTime;

import com.totvs.sl.wms.estoque.util.DateTimeUtils;

import lombok.EqualsAndHashCode;
import lombok.Getter;

@Getter
@EqualsAndHashCode
public class SituacaoEstoqueLiberado implements SituacaoEstoque {

	private ZonedDateTime quando;

	private SituacaoEstoqueLiberado() {
		this.quando = DateTimeUtils.format(DateTimeUtils.getNow());
	}

	public static SituacaoEstoqueLiberado of() {
		return new SituacaoEstoqueLiberado();
	}

	@Override
	public SituacaoEstoqueValor getSituacaoEstoque() {
		return SituacaoEstoqueValor.LIBERADO;
	}

	@Override
	public String toString() {
		return SituacaoEstoqueValor.LIBERADO.toString();
	}
}
