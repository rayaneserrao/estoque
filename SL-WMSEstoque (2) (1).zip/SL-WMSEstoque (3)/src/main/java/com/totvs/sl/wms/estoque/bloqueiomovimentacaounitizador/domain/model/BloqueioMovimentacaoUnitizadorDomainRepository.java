package com.totvs.sl.wms.estoque.bloqueiomovimentacaounitizador.domain.model;

import java.util.Collection;
import java.util.Optional;

import com.totvs.sl.wms.estoque.endereco.domain.model.EnderecoId;
import com.totvs.sl.wms.estoque.unitizador.domain.model.UnitizadorId;
import com.totvs.tjf.repository.aggregate.AggregateRepository;

public interface BloqueioMovimentacaoUnitizadorDomainRepository
        extends AggregateRepository<BloqueioMovimentacaoUnitizador, BloqueioMovimentacaoUnitizadorId> {

	public Optional<BloqueioMovimentacaoUnitizador> findById(BloqueioMovimentacaoUnitizadorId id);

	public BloqueioMovimentacaoUnitizador findWithLockByIdOrThrowNotFound(BloqueioMovimentacaoUnitizadorId id);

	public boolean existsByUnitizadorId(UnitizadorId unitizadorId);

	Collection<BloqueioMovimentacaoUnitizador> findWithLockByEnderecoIdDestino(EnderecoId enderecoIdDestino);

	Collection<BloqueioMovimentacaoUnitizador> findByEnderecoIdDestino(EnderecoId enderecoIdDestino);

}
