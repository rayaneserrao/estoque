package com.totvs.sl.wms.estoque.estoque.amqp.cmd;

import javax.validation.constraints.NotNull;

import com.totvs.sl.wms.estoque.atributoestoque.domain.model.AtributoEstoqueId;
import com.totvs.sl.wms.estoque.produto.domain.model.ProdutoId;
import com.totvs.sl.wms.estoque.util.amqp.EstoqueOutput;
import com.totvs.sl.wms.estoque.util.amqp.SubjectConfiguracao;
import com.totvs.sl.wms.estoque.util.amqp.TransactionalCmd;

import lombok.Getter;
import lombok.ToString;

@Getter
@ToString
public final class RemoverAtributoEstoqueSaldoCmd extends TransactionalCmd
		implements SubjectConfiguracao, EstoqueOutput {

	public static final String NAME = "RemoverAtributoEstoqueSaldoCmd";

	public static final String CONDITIONAL_EXPRESSION = "headers['type']=='" + NAME + "'";

	@NotNull(message = "{RemoverAtributoEstoqueSaldoCmd.atributoEstoqueId.NotNull}")
	private final AtributoEstoqueId atributoEstoqueId;

	@NotNull(message = "{RemoverAtributoEstoqueSaldoCmd.produtoId.NotNull}")
	private final ProdutoId produtoId;

	private RemoverAtributoEstoqueSaldoCmd(AtributoEstoqueId atributoEstoqueId, ProdutoId produtoId) {
		super(null, null);
		this.atributoEstoqueId = atributoEstoqueId;
		this.produtoId = produtoId;
	}

	public static RemoverAtributoEstoqueSaldoCmd of(AtributoEstoqueId atributoEstoqueId, ProdutoId produtoId) {
		return new RemoverAtributoEstoqueSaldoCmd(atributoEstoqueId, produtoId);
	}
}
