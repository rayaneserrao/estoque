package com.totvs.sl.wms.estoque.estoque.domain.service;

import javax.persistence.EntityManager;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.totvs.sl.wms.estoque.endereco.domain.model.EnderecoId;

import lombok.AllArgsConstructor;

@Service
@AllArgsConstructor
@Transactional(readOnly = true)
public class EstoqueUnitizadorService {

	private final EntityManager em;

	@SuppressWarnings("unchecked")
	public Long contarUnitizadoresEstoqueByEnderecoId(EnderecoId enderecoId) {

		var sql = """
				SELECT COUNT(DISTINCT data->>'unitizadorId')
				FROM estoque
				WHERE data->>'enderecoId' = :enderecoId
				AND data->>'unitizadorId' IS NOT NULL
				""";

		var query = em.createNativeQuery(sql).setParameter("enderecoId", enderecoId.toString());

		return ((Number) query.getSingleResult()).longValue();
	}

}
