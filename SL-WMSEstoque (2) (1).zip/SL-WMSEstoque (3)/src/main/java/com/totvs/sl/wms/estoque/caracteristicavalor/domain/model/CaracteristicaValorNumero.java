package com.totvs.sl.wms.estoque.caracteristicavalor.domain.model;

import static com.totvs.tjf.autoconfigure.ValidationUtils.validateIntegrity;

import java.math.BigDecimal;
import java.util.Comparator;

import javax.validation.constraints.Digits;
import javax.validation.constraints.NotNull;

import com.totvs.sl.wms.estoque.caracteristicaconfiguracao.domain.model.CaracteristicaConfiguracaoId;
import com.totvs.sl.wms.estoque.caracteristicaconfiguracao.domain.model.FormatoCaracteristicaValor;
import com.totvs.sl.wms.estoque.caracteristicavalor.exception.WMSCaracteristicaValorNumeroConstraintException;

import lombok.AccessLevel;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Getter
@ToString
@EqualsAndHashCode
@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class CaracteristicaValorNumero implements CaracteristicaValor<BigDecimal> {

	@NotNull(message = "{CaracteristicaValorNumero.caracteristicaConfiguracaoId.NotNull}")
	private CaracteristicaConfiguracaoId caracteristicaConfiguracaoId;

	@NotNull(message = "{CaracteristicaValorNumero.valor.NotNull}")
	@Digits(fraction = 4, integer = 11, message = "{CaracteristicaValorNumero.valor.Digits}")
	private BigDecimal valor;

	@Builder
	private CaracteristicaValorNumero(CaracteristicaConfiguracaoId caracteristicaConfiguracaoId, BigDecimal valor) {

		this.caracteristicaConfiguracaoId = caracteristicaConfiguracaoId;
		this.valor = valor;

		validateIntegrity(this).ifPresent(violations -> {
			throw new WMSCaracteristicaValorNumeroConstraintException(violations);
		});
	}

	@Override
	public FormatoCaracteristicaValor getFormato() {
		return FormatoCaracteristicaValor.NUMERO;
	}

	@Override
	public int compareTo(CaracteristicaValor<BigDecimal> caracteristica) {

		return caracteristica instanceof CaracteristicaValorNumero caracteristicaNumero

				? Comparator.comparing(CaracteristicaValorNumero::getCaracteristicaConfiguracaoId)
							.thenComparing(CaracteristicaValorNumero::getValor)
							.compare(this, caracteristicaNumero)

				: this.getCaracteristicaConfiguracaoId().compareTo(caracteristica.getCaracteristicaConfiguracaoId());
	}
}
