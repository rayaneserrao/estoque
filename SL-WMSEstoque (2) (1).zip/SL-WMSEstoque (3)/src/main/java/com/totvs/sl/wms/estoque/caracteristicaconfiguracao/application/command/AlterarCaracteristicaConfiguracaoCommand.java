package com.totvs.sl.wms.estoque.caracteristicaconfiguracao.application.command;

import com.totvs.sl.wms.estoque.caracteristicaconfiguracao.domain.model.CaracteristicaConfiguracaoId;
import com.totvs.sl.wms.estoque.caracteristicaconfiguracao.domain.model.FormatoCaracteristicaValor;

import lombok.Data;

@Data(staticConstructor = "of")
public final class AlterarCaracteristicaConfiguracaoCommand {

	private final CaracteristicaConfiguracaoId id;
	private final String descricao;

	private final FormatoCaracteristicaValor formato;
}
