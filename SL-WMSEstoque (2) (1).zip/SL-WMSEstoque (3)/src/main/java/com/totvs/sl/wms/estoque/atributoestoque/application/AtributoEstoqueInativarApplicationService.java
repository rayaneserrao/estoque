package com.totvs.sl.wms.estoque.atributoestoque.application;

import javax.transaction.Transactional;

import org.springframework.stereotype.Service;

import com.totvs.sl.wms.estoque.atributoestoque.application.command.InativarAtributoEstoqueCommand;
import com.totvs.sl.wms.estoque.atributoestoque.domain.model.AtributoEstoqueDomainRepository;
import com.totvs.sl.wms.estoque.config.amqp.WMSPublisher;

import lombok.AllArgsConstructor;

@Service
@Transactional
@AllArgsConstructor
public class AtributoEstoqueInativarApplicationService {

	private AtributoEstoqueDomainRepository repository;
	private WMSPublisher publisher;

	public void handle(InativarAtributoEstoqueCommand cmd) {

		var atributoEstoque = repository.findByIdOrThrowNotFound(cmd.getId());

		if (atributoEstoque.inativar()) {
			repository.update(atributoEstoque);
			atributoEstoque.getEvents().forEach(publisher::dispatch);
		}
	}

}
