package com.totvs.sl.wms.estoque.estoque.application.command;

import java.util.Optional;

import com.totvs.sl.wms.estoque.bloqueiomovimentacaounitizador.domain.model.BloqueioMovimentacaoUnitizadorId;
import com.totvs.sl.wms.estoque.endereco.domain.model.EnderecoId;
import com.totvs.sl.wms.estoque.origem.domain.model.Origem;
import com.totvs.sl.wms.estoque.unidade.domain.model.UnidadeId;
import com.totvs.sl.wms.estoque.unitizador.domain.model.UnitizadorId;

import lombok.Builder;
import lombok.Data;

@Data
public final class EfetuarTransferenciaEnderecoUnitizadorEstoqueCommand {
	private final UnidadeId unidadeId;
	private final Origem origem;
	private final UnitizadorId unitizadorId;
	private final EnderecoId enderecoId;
	private final Optional<BloqueioMovimentacaoUnitizadorId> bloqueioMovimentacaoUnitizadorId;
	private final String chaveAcesso;

	@Builder
	public EfetuarTransferenciaEnderecoUnitizadorEstoqueCommand(final UnidadeId unidadeId,
																final Origem origem,
																final UnitizadorId unitizadorId,
																final EnderecoId enderecoId,
																final BloqueioMovimentacaoUnitizadorId bloqueioMovimentacaoUnitizadorId,
																final String chaveAcesso) {
		this.unidadeId = unidadeId;
		this.origem = origem;
		this.unitizadorId = unitizadorId;
		this.enderecoId = enderecoId;
		this.bloqueioMovimentacaoUnitizadorId = Optional.ofNullable(bloqueioMovimentacaoUnitizadorId);
		this.chaveAcesso = chaveAcesso;
	}

}
