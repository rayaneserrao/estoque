package com.totvs.sl.wms.estoque.atributoestoque.domain.model;

import java.util.Optional;

import com.totvs.tjf.repository.aggregate.AggregateRepository;

public interface AtributoEstoqueDomainRepository extends AggregateRepository<AtributoEstoque, AtributoEstoqueId> {

	Optional<AtributoEstoque> findById(AtributoEstoqueId id);

	AtributoEstoque findByIdOrThrowNotFound(AtributoEstoqueId id);
}
