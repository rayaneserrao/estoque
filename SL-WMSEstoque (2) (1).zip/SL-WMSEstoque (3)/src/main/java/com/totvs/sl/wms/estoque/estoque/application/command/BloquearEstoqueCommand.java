package com.totvs.sl.wms.estoque.estoque.application.command;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.util.CollectionUtils;

import com.totvs.sl.wms.estoque.atributoestoquevalor.domain.model.AtributoEstoqueValor;
import com.totvs.sl.wms.estoque.estoque.domain.model.Estoque;
import com.totvs.sl.wms.estoque.estoque.domain.model.EstoqueAtributoSaldo;
import com.totvs.sl.wms.estoque.estoque.domain.model.EstoqueId;
import com.totvs.sl.wms.estoque.origem.domain.model.Origem;
import com.totvs.sl.wms.estoque.unidade.domain.model.UnidadeId;

import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;

@Getter
@Builder
@EqualsAndHashCode
public final class BloquearEstoqueCommand {
	private final UnidadeId unidadeId;
	private final EstoqueId estoqueId;
	private final BigDecimal quantidade;
	private final String chaveAcesso;
	private final String motivo;
	private final Origem origem;
	private final List<AtributoEstoqueValor<?>> atributos;

	public List<EstoqueAtributoSaldo> getAtributosSaldo(Estoque estoque) {
		return CollectionUtils.isEmpty(atributos) ? estoque.getAtributosSaldo()
				: List.of(EstoqueAtributoSaldo.of(atributos, quantidade));
	}
}
