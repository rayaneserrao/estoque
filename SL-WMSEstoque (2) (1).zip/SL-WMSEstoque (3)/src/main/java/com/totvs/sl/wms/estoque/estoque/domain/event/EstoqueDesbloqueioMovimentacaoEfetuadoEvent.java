package com.totvs.sl.wms.estoque.estoque.domain.event;

import java.math.BigDecimal;

import com.totvs.sl.wms.estoque.bloqueiomovimentacaoestoque.domain.model.BloqueioMovimentacaoEstoqueId;
import com.totvs.sl.wms.estoque.estoque.domain.model.Estoque;
import com.totvs.sl.wms.estoque.estoque.domain.model.EstoqueId;
import com.totvs.sl.wms.estoque.util.amqp.SubjectConfiguracao;
import com.totvs.sl.wms.estoque.util.amqp.SubjectDomainEvent;

import lombok.AccessLevel;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
@Builder(access = AccessLevel.PRIVATE)
public final class EstoqueDesbloqueioMovimentacaoEfetuadoEvent extends SubjectDomainEvent
		implements SubjectConfiguracao {

	private final EstoqueId estoqueId;
	private final BloqueioMovimentacaoEstoqueId bloqueioMovimentacaoEstoqueId;
	private final BigDecimal quantidadeBloqueadaMovimentacaoNaoReservada;
	private final BigDecimal quantidadeBloqueadaMovimentacaoReservada;
	private final BigDecimal quantidadeBloqueadaMovimentacaoTotal;

	public static EstoqueDesbloqueioMovimentacaoEfetuadoEvent of(Estoque estoque,
																 BloqueioMovimentacaoEstoqueId bloqueioMovimentacaoEstoqueId) {

		return EstoqueDesbloqueioMovimentacaoEfetuadoEvent.builder()
														  .estoqueId(estoque.getId())
														  .bloqueioMovimentacaoEstoqueId(bloqueioMovimentacaoEstoqueId)
														  .quantidadeBloqueadaMovimentacaoNaoReservada(estoque.getQuantidadeBloqueadaParaMovimentacaoEstoqueNaoReservada())
														  .quantidadeBloqueadaMovimentacaoReservada(estoque.getQuantidadeBloqueadaParaMovimentacaoEstoqueReservada())
														  .quantidadeBloqueadaMovimentacaoTotal(estoque.getQuantidadeBloqueadaParaMovimentacaoEstoqueTotal())
														  .build();
	}

}
