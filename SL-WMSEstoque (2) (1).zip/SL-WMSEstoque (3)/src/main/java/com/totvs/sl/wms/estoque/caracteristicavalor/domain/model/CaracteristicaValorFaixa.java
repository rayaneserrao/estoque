package com.totvs.sl.wms.estoque.caracteristicavalor.domain.model;

import com.totvs.sl.wms.estoque.caracteristicaconfiguracao.domain.model.CaracteristicaConfiguracaoId;
import com.totvs.sl.wms.estoque.caracteristicaconfiguracao.domain.model.FormatoCaracteristicaValor;

public interface CaracteristicaValorFaixa<T> extends Comparable<CaracteristicaValorFaixa<T>> {

	CaracteristicaConfiguracaoId getCaracteristicaConfiguracaoId();

	FormatoCaracteristicaValor getFormato();

	T getValorInicial();

	T getValorFinal();

}