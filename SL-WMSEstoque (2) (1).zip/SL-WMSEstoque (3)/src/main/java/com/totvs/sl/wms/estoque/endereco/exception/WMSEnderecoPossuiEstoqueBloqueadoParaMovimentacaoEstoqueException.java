package com.totvs.sl.wms.estoque.endereco.exception;

import com.totvs.tjf.api.context.stereotype.error.ApiBadRequest;

@ApiBadRequest
public class WMSEnderecoPossuiEstoqueBloqueadoParaMovimentacaoEstoqueException extends RuntimeException {

	private static final long serialVersionUID = -9063920466732345756L;
}
