package com.totvs.sl.wms.estoque.caracteristicaconfiguracao.domain.event;

import com.totvs.sl.wms.estoque.caracteristicaconfiguracao.domain.model.CaracteristicaConfiguracao;
import com.totvs.sl.wms.estoque.caracteristicaconfiguracao.domain.model.CaracteristicaConfiguracaoId;
import com.totvs.sl.wms.estoque.caracteristicaconfiguracao.domain.model.CaracteristicaConfiguracaoOrigem;
import com.totvs.sl.wms.estoque.caracteristicaconfiguracao.domain.model.FormatoCaracteristicaValor;
import com.totvs.sl.wms.estoque.util.amqp.SubjectConfiguracao;
import com.totvs.sl.wms.estoque.util.amqp.SubjectDomainEvent;

import lombok.Builder;
import lombok.Getter;
import lombok.ToString;

@ToString
@Getter
@Builder
public final class CaracteristicaConfiguracaoCriadaEvent extends SubjectDomainEvent implements SubjectConfiguracao {

	private final CaracteristicaConfiguracaoId id;
	private final String descricao;
	private final FormatoCaracteristicaValor formato;
	private final CaracteristicaConfiguracaoOrigem origem;

	public static CaracteristicaConfiguracaoCriadaEvent from(CaracteristicaConfiguracao caracteristicaConfiguracao) {
		return CaracteristicaConfiguracaoCriadaEvent.builder()
													.id(caracteristicaConfiguracao.getId())
													.descricao(caracteristicaConfiguracao.getDescricao())
													.formato(caracteristicaConfiguracao.getFormato())
													.origem(caracteristicaConfiguracao.getOrigem())
													.build();

	}
}
