package com.totvs.sl.wms.estoque.caracteristicavalor.domain.model;

import static com.totvs.tjf.autoconfigure.ValidationUtils.validateIntegrity;

import java.util.Comparator;

import javax.validation.constraints.NotNull;

import com.totvs.sl.wms.estoque.caracteristicaconfiguracao.domain.model.CaracteristicaConfiguracaoId;
import com.totvs.sl.wms.estoque.caracteristicaconfiguracao.domain.model.FormatoCaracteristicaValor;
import com.totvs.sl.wms.estoque.caracteristicavalor.exception.WMSCaracteristicaValorFaixaTextoConstraintException;
import com.totvs.sl.wms.estoque.caracteristicavalor.validator.ValidCaracteristicaValorInicialFinal;

import lombok.AccessLevel;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Getter
@EqualsAndHashCode
@NoArgsConstructor(access = AccessLevel.PRIVATE)
@ValidCaracteristicaValorInicialFinal(message = "{CaracteristicaValorFaixaTexto.valorInicialOuValorFinal.NotNull}")
public class CaracteristicaValorFaixaTexto implements CaracteristicaValorFaixa<String> {

	@Getter
	@NotNull(message = "{CaracteristicaValorFaixaTexto.caracteristicaConfiguracaoId.NotNull}")
	private CaracteristicaConfiguracaoId caracteristicaConfiguracaoId;

	private String valorInicial;

	private String valorFinal;

	@Builder
	private CaracteristicaValorFaixaTexto(CaracteristicaConfiguracaoId caracteristicaConfiguracaoId,
										  String valorInicial,
										  String valorFinal) {

		this.caracteristicaConfiguracaoId = caracteristicaConfiguracaoId;
		this.valorInicial = valorInicial;
		this.valorFinal = valorFinal;

		validateIntegrity(this).ifPresent(violations -> {
			throw new WMSCaracteristicaValorFaixaTextoConstraintException(violations);
		});

	}

	@Override
	public FormatoCaracteristicaValor getFormato() {
		return FormatoCaracteristicaValor.TEXTO;
	}

	@Override
	public int compareTo(CaracteristicaValorFaixa<String> caracteristica) {
		return caracteristica instanceof CaracteristicaValorFaixaTexto caracteristicaValorFaixaTexto
				? Comparator.comparing(CaracteristicaValorFaixaTexto::getCaracteristicaConfiguracaoId)
							.thenComparing(CaracteristicaValorFaixaTexto::getValorInicial,
										   Comparator.nullsFirst(String::compareTo))
							.thenComparing(CaracteristicaValorFaixaTexto::getValorFinal,
										   Comparator.nullsFirst(String::compareTo))
							.compare(this, caracteristicaValorFaixaTexto)
				: this.getCaracteristicaConfiguracaoId().compareTo(caracteristica.getCaracteristicaConfiguracaoId());
	}
}
