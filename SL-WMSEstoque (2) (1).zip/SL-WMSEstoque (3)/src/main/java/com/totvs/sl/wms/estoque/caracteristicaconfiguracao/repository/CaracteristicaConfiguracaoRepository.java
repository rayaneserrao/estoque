package com.totvs.sl.wms.estoque.caracteristicaconfiguracao.repository;

import java.sql.Types;
import java.util.Optional;

import javax.persistence.EntityManager;
import javax.transaction.Transactional;

import org.springframework.jdbc.core.SqlParameterValue;
import org.springframework.stereotype.Repository;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.totvs.sl.wms.estoque.caracteristicaconfiguracao.domain.model.CaracteristicaConfiguracao;
import com.totvs.sl.wms.estoque.caracteristicaconfiguracao.domain.model.CaracteristicaConfiguracaoDomainRepository;
import com.totvs.sl.wms.estoque.caracteristicaconfiguracao.domain.model.CaracteristicaConfiguracaoId;
import com.totvs.sl.wms.estoque.caracteristicaconfiguracao.exception.WMSCaracteristicaConfiguracaoNaoEncontradaException;
import com.totvs.sl.wms.estoque.util.repository.SqlWhereBuilder;
import com.totvs.tjf.repository.aggregate.CrudAggregateRepository;

@Repository
@Transactional
public class CaracteristicaConfiguracaoRepository
		extends CrudAggregateRepository<CaracteristicaConfiguracao, CaracteristicaConfiguracaoId>
		implements CaracteristicaConfiguracaoDomainRepository {

	private static final String CONDICAO_ID = "id = ?";

	private static final String CONDICAO_ID_DIFERENTE = "id != ?";

	private static final String CONDICAO_DESCRICAO = "lower(data ->> 'descricao') = ?";

	public CaracteristicaConfiguracaoRepository(EntityManager em, ObjectMapper mapper) {
		super(em, mapper.copy());
	}

	@Override
	public Optional<CaracteristicaConfiguracao> findById(CaracteristicaConfiguracaoId id) {
		var clause = SqlWhereBuilder.builder().where(CONDICAO_ID).build();
		return this.findOne(clause, new SqlParameterValue(Types.VARCHAR, id));
	}

	@Override
	public CaracteristicaConfiguracao findByIdOrThrowNotFound(CaracteristicaConfiguracaoId id) {
		return findById(id).orElseThrow(WMSCaracteristicaConfiguracaoNaoEncontradaException::new);
	}

	@Override
	public boolean existeCaracteristicaConfiguracaoComMesmaDescricao(String descricao) {
		var clause = SqlWhereBuilder.builder().where(CONDICAO_DESCRICAO).build();
		return this.exists(clause, new SqlParameterValue(Types.VARCHAR, descricao.trim().toLowerCase()));
	}

	@Override
	public boolean existeCaracteristicaConfiguracaoComMesmaDescricao(CaracteristicaConfiguracaoId id,
																	 String descricao) {
		var clause = SqlWhereBuilder.builder().where(CONDICAO_DESCRICAO).and(CONDICAO_ID_DIFERENTE).build();
		return this.exists(clause,
						   new SqlParameterValue(Types.VARCHAR, descricao.trim().toLowerCase()),
						   new SqlParameterValue(Types.VARCHAR, id));
	}
}
