package com.totvs.sl.wms.estoque.bloqueiomovimentacaounitizador.exception;

import java.util.Set;

import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;

import com.totvs.tjf.api.context.stereotype.error.ApiBadRequest;

@ApiBadRequest("WMSBloqueioMovimentacaoUnitizadorConstraintException")
public class WMSBloqueioMovimentacaoUnitizadorConstraintException extends ConstraintViolationException {

	private static final long serialVersionUID = -2189570176444592363L;

	public WMSBloqueioMovimentacaoUnitizadorConstraintException(Set<? extends ConstraintViolation<?>> constraintViolations) {
		super(constraintViolations);
	}
}