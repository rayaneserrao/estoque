package com.totvs.sl.wms.estoque.estoque.amqp.cmd;

import java.math.BigDecimal;
import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.Digits;
import javax.validation.constraints.NotNull;

import com.totvs.sl.wms.estoque.atributoestoquevalor.amqp.cmd.AtributoEstoqueValorCmd;
import com.totvs.sl.wms.estoque.atributoestoquevalor.domain.model.AtributoEstoqueValor;
import com.totvs.sl.wms.estoque.estoque.domain.model.EstoqueId;
import com.totvs.sl.wms.estoque.unidade.domain.model.UnidadeId;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public final class BloquearEstoqueCmd {

	public static final String NAME = "BloquearEstoqueCmd";
	public static final String CONDITIONAL_EXPRESSION = "headers['type']=='" + NAME + "'";

	@NotNull(message = "{BloquearEstoqueCmd.unidadeId.NotNull}")
	private final UnidadeId unidadeId;

	@NotNull(message = "{BloquearEstoqueCmd.estoqueId.NotNull}")
	private final EstoqueId estoqueId;

	@NotNull(message = "{BloquearEstoqueCmd.quantidade.NotNull}")
	@DecimalMin(value = "0.0001", message = "{BloquearEstoqueCmd.quantidade.DecimalMin}")
	@Digits(fraction = 4, integer = 11, message = "{BloquearEstoqueCmd.quantidade.Digits}")
	private final BigDecimal quantidade;

	private final String chaveAcesso;

	private final String motivo;

	@Valid
	private final List<AtributoEstoqueValorCmd> atributos;

	public final List<AtributoEstoqueValor<?>> getAtributos() {
		return AtributoEstoqueValorCmd.toAtributoEstoqueValor(this.atributos);
	}
}
