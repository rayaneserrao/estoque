package com.totvs.sl.wms.estoque.deposito.domain.model;

import java.util.UUID;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.totvs.tjf.core.common.domain.DomainObjectId;

public final class DepositoId extends DomainObjectId<UUID> {

	private static final long serialVersionUID = -4690563719570959030L;

	protected DepositoId(UUID id) {
		super(id);
	}

	@JsonCreator
	public static DepositoId from(String uuid) {
		return uuid == null ? null : new DepositoId(UUID.fromString(uuid));
	}
}