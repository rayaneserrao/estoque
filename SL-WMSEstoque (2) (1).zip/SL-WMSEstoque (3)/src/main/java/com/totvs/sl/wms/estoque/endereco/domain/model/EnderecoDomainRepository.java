package com.totvs.sl.wms.estoque.endereco.domain.model;

import java.util.Optional;

import com.totvs.sl.wms.estoque.unidade.domain.model.UnidadeId;
import com.totvs.tjf.repository.aggregate.AggregateRepository;

public interface EnderecoDomainRepository extends AggregateRepository<Endereco, EnderecoId> {

	Optional<Endereco> findById(EnderecoId id);

	Endereco findByIdAndUnidadeIdOrThrowNotFound(EnderecoId id, UnidadeId unidadeId);

	Endereco findByIdOrThrowNotFound(EnderecoId id);

	boolean existeEnderecoComIdEUnidadeId(EnderecoId id, UnidadeId unidadeId);

	Endereco findWithLockByIdOrThrowNotFound(EnderecoId id);

}
