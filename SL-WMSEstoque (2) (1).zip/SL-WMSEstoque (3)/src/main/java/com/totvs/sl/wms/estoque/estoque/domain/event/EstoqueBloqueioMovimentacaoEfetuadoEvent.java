package com.totvs.sl.wms.estoque.estoque.domain.event;

import java.math.BigDecimal;

import com.totvs.sl.wms.estoque.bloqueiomovimentacaoestoque.domain.model.BloqueioMovimentacaoEstoque;
import com.totvs.sl.wms.estoque.bloqueiomovimentacaoestoque.domain.model.BloqueioMovimentacaoEstoqueId;
import com.totvs.sl.wms.estoque.endereco.domain.model.EnderecoId;
import com.totvs.sl.wms.estoque.estoque.domain.model.Estoque;
import com.totvs.sl.wms.estoque.estoque.domain.model.EstoqueId;
import com.totvs.sl.wms.estoque.unitizador.domain.model.UnitizadorId;
import com.totvs.sl.wms.estoque.util.amqp.SubjectDomainEvent;

import lombok.AccessLevel;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
@Builder(access = AccessLevel.PRIVATE)
public final class EstoqueBloqueioMovimentacaoEfetuadoEvent extends SubjectDomainEvent
		implements SubjectBloqueioEstoque {

	private final BloqueioMovimentacaoEstoqueId bloqueioMovimentacaoEstoqueId;
	private final BloqueioMovimentacaoEstoqueQuantidade quantidadeBloqueada;
	private final BloqueioMovimentacaoEstoqueOrigem origem;
	private final BloqueioMovimentacaoEstoqueSaldo estoque;
	private final BloqueioMovimentacaoEstoqueInformacoes informacoesOrigem;
	private final BloqueioMovimentacaoEstoqueInformacoes informacoesDestino;

	@Data(staticConstructor = "of")
	public static final class BloqueioMovimentacaoEstoqueQuantidade {
		private final BigDecimal naoReservada;
		private final BigDecimal reservada;
		private final BigDecimal total;
	}

	@Data(staticConstructor = "of")
	public static final class BloqueioMovimentacaoEstoqueOrigem {
		private final String id;
		private final String origem;
	}

	@Data(staticConstructor = "of")
	public static final class BloqueioMovimentacaoEstoqueSaldo {
		private final EstoqueId estoqueId;
		private final BloqueioMovimentacaoEstoqueQuantidade quantidadeBloqueada;
	}

	@Data(staticConstructor = "of")
	public static final class BloqueioMovimentacaoEstoqueInformacoes {
		private final EnderecoId enderecoId;
		private final UnitizadorId unitizadorId;
	}

	public static EstoqueBloqueioMovimentacaoEfetuadoEvent of(Estoque estoque,
															  BloqueioMovimentacaoEstoque bloqueioMovimentacaoEstoque) {

		return EstoqueBloqueioMovimentacaoEfetuadoEvent.builder()
													   .bloqueioMovimentacaoEstoqueId(bloqueioMovimentacaoEstoque.getId())
													   .quantidadeBloqueada(BloqueioMovimentacaoEstoqueQuantidade.of(bloqueioMovimentacaoEstoque.getQuantidadeNaoReservada(),
																													 bloqueioMovimentacaoEstoque.getQuantidadeReservada(),
																													 bloqueioMovimentacaoEstoque.getQuantidade()))
													   .origem(BloqueioMovimentacaoEstoqueOrigem.of(bloqueioMovimentacaoEstoque.getOrigem()
																															   .getId()
																															   .toString(),
																									bloqueioMovimentacaoEstoque.getOrigem()
																															   .getOrigem()))
													   .estoque(BloqueioMovimentacaoEstoqueSaldo.of(estoque.getId(),
																									BloqueioMovimentacaoEstoqueQuantidade.of(estoque.getQuantidadeBloqueadaParaMovimentacaoEstoqueNaoReservada(),
																																			 estoque.getQuantidadeBloqueadaParaMovimentacaoEstoqueReservada(),
																																			 estoque.getQuantidadeBloqueadaParaMovimentacaoEstoqueTotal())))
													   .informacoesOrigem(BloqueioMovimentacaoEstoqueInformacoes.of(estoque.getEnderecoId(),
																													estoque.getUnitizadorId()))
													   .informacoesDestino(BloqueioMovimentacaoEstoqueInformacoes.of(bloqueioMovimentacaoEstoque.getEnderecoIdDestino()
																																				.orElse(null),
																													 bloqueioMovimentacaoEstoque.getUnitizadorIdDestino()
																																				.orElse(null)))
													   .build();
	}

}
