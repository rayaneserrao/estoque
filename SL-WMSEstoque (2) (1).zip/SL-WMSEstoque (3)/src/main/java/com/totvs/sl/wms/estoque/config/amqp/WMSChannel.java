package com.totvs.sl.wms.estoque.config.amqp;

import org.springframework.cloud.stream.annotation.Input;
import org.springframework.cloud.stream.annotation.Output;
import org.springframework.messaging.MessageChannel;
import org.springframework.messaging.SubscribableChannel;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public final class WMSChannel {

	public static final String WMS_ESTOQUE_CONFIGURACAO_COMMANDS_IN = "wms-estoque-configuracao-commands-in";

	public static final String WMS_ESTOQUE_ENDERECO_COMMANDS_IN = "wms-estoque-endereco-commands-in";

	public static final String WMS_DIVISAO_FUSAO_ESTOQUE_COMMANDS_IN = "wms-divisao-fusao-estoque-commands-in";

	public static final String WMS_ENTRADA_ESTOQUE_COMMANDS_IN = "wms-entrada-estoque-commands-in";
	public static final String WMS_ENTRADA_ESTOQUE_LOTE_COMMANDS_IN = "wms-entrada-estoque-lote-commands-in";

	public static final String WMS_SAIDA_ESTOQUE_COMMANDS_IN = "wms-saida-estoque-commands-in";
	public static final String WMS_SAIDA_ESTOQUE_LOTE_COMMANDS_IN = "wms-saida-estoque-lote-commands-in";

	public static final String WMS_BLOQUEIO_ESTOQUE_COMMANDS_IN = "wms-bloqueio-estoque-commands-in";
	public static final String WMS_BLOQUEIO_ESTOQUE_LOTE_COMMANDS_IN = "wms-bloqueio-estoque-lote-commands-in";

	public static final String WMS_BLOQUEIO_ENDERECO_COMMANDS_IN = "wms-bloqueio-endereco-commands-in";
	public static final String WMS_BLOQUEIO_ENDERECO_LOTE_COMMANDS_IN = "wms-bloqueio-endereco-lote-commands-in";

	public static final String WMS_RESERVA_ESTOQUE_COMMANDS_IN = "wms-reserva-estoque-commands-in";

	public static final String WMS_MOVIMENTACAO_ESTOQUE_COMMANDS_IN = "wms-movimentacao-estoque-commands-in";

	public static final String WMS_ALTERACAO_ESTOQUE_COMMANDS_IN = "wms-alteracao-estoque-commands-in";

	public static final String WMS_ENDERECO_EVENTS_IN = "wms-endereco-events-in";

	public static final String WMS_ESTOQUE_RESPONSE_IN = "wms-estoque-response-in";
	public static final String WMS_ESTOQUE_EVENTS_IN = "wms-estoque-events-in";
	public static final String WMS_ESTOQUE_OUT = "wms-estoque-out";

	public static final String WMS_OUTPUT = "wms-output-events";
	public static final String FOUNDATION_INPUT = "foundation-input-events";
	public static final String WMS_INTEGRACAO_OUT = "wms-integracao-out";

	public interface WMSEstoqueConfiguracaoCommandsInput {
		@Input(WMSChannel.WMS_ESTOQUE_CONFIGURACAO_COMMANDS_IN)
		SubscribableChannel input();
	}

	public interface WMSEstoqueEnderecoCommandsInput {
		@Input(WMSChannel.WMS_ESTOQUE_ENDERECO_COMMANDS_IN)
		SubscribableChannel input();
	}

	public interface WMSDivisaoFusaoEstoqueCommandsInput {
		@Input(WMSChannel.WMS_DIVISAO_FUSAO_ESTOQUE_COMMANDS_IN)
		SubscribableChannel input();
	}

	public interface WMSEntradaEstoqueCommandsInput {
		@Input(WMSChannel.WMS_ENTRADA_ESTOQUE_COMMANDS_IN)
		SubscribableChannel input();
	}

	public interface WMSEntradaEstoqueLoteCommandsInput {
		@Input(WMSChannel.WMS_ENTRADA_ESTOQUE_LOTE_COMMANDS_IN)
		SubscribableChannel input();
	}

	public interface WMSSaidaEstoqueCommandsInput {
		@Input(WMSChannel.WMS_SAIDA_ESTOQUE_COMMANDS_IN)
		SubscribableChannel input();
	}

	public interface WMSSaidaEstoqueLoteCommandsInput {
		@Input(WMSChannel.WMS_SAIDA_ESTOQUE_LOTE_COMMANDS_IN)
		SubscribableChannel input();
	}

	public interface WMSAlteracaoEstoqueCommandsInput {
		@Input(WMSChannel.WMS_ALTERACAO_ESTOQUE_COMMANDS_IN)
		SubscribableChannel input();
	}

	public interface WMSReservaEstoqueCommandsInput {
		@Input(WMSChannel.WMS_RESERVA_ESTOQUE_COMMANDS_IN)
		SubscribableChannel input();
	}

	public interface WMSBloqueioEnderecoCommandsInput {
		@Input(WMSChannel.WMS_BLOQUEIO_ENDERECO_COMMANDS_IN)
		SubscribableChannel input();
	}

	public interface WMSBloqueioEnderecoLoteCommandsInput {
		@Input(WMSChannel.WMS_BLOQUEIO_ENDERECO_LOTE_COMMANDS_IN)
		SubscribableChannel input();
	}

	public interface WMSBloqueioEstoqueCommandsInput {
		@Input(WMSChannel.WMS_BLOQUEIO_ESTOQUE_COMMANDS_IN)
		SubscribableChannel input();
	}

	public interface WMSBloqueioEstoqueLoteCommandsInput {
		@Input(WMSChannel.WMS_BLOQUEIO_ESTOQUE_LOTE_COMMANDS_IN)
		SubscribableChannel input();
	}

	public interface WMSMovimentacaoEstoqueCommandsInput {
		@Input(WMSChannel.WMS_MOVIMENTACAO_ESTOQUE_COMMANDS_IN)
		SubscribableChannel input();
	}

	public interface WMSEstoqueResponseInput {
		@Input(WMSChannel.WMS_ESTOQUE_RESPONSE_IN)
		SubscribableChannel input();
	}

	public interface WMSEstoqueEventsInput {
		@Input(WMSChannel.WMS_ESTOQUE_EVENTS_IN)
		SubscribableChannel input();
	}

	public interface WMSEstoqueOutput {
		@Output(WMSChannel.WMS_ESTOQUE_OUT)
		MessageChannel output();
	}

	public interface WMSEnderecoEventsInput {
		@Input(WMSChannel.WMS_ENDERECO_EVENTS_IN)
		SubscribableChannel input();
	}

	public interface WMSExchangeOutput {
		@Output(WMSChannel.WMS_OUTPUT)
		MessageChannel output();
	}

	public interface FoundationExchangeInput {
		@Input(WMSChannel.FOUNDATION_INPUT)
		SubscribableChannel input();
	}

	public interface WMSIntegracaoOut {
		@Output(WMSChannel.WMS_INTEGRACAO_OUT)
		MessageChannel output();
	}
}
