package com.totvs.sl.wms.estoque.estoque.exception;

import com.totvs.tjf.api.context.stereotype.error.ApiBadRequest;

import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;
import java.util.Set;

@ApiBadRequest("WMSEfetuarSaidaLoteEstoqueBloqueadoConstraintException")
public class WMSEfetuarSaidaLoteEstoqueBloqueadoConstraintException extends ConstraintViolationException {

	private static final long serialVersionUID = -742578524132418291L;

	public WMSEfetuarSaidaLoteEstoqueBloqueadoConstraintException(Set<? extends ConstraintViolation<?>> constraintViolations) {
		super(constraintViolations);
	}
}
