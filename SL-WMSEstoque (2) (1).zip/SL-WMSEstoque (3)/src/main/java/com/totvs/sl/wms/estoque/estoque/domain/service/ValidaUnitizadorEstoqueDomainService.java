package com.totvs.sl.wms.estoque.estoque.domain.service;

import java.util.Collection;
import java.util.Objects;

import org.springframework.stereotype.Service;

import com.totvs.sl.wms.estoque.bloqueiomovimentacaounitizador.domain.model.BloqueioMovimentacaoUnitizadorDomainRepository;
import com.totvs.sl.wms.estoque.bloqueiomovimentacaounitizador.domain.model.BloqueioMovimentacaoUnitizadorId;
import com.totvs.sl.wms.estoque.bloqueiomovimentacaounitizador.exception.WMSUnitizadorIdDiferenteBloqueioMovimentacaoUnitizadorIdException;
import com.totvs.sl.wms.estoque.endereco.domain.model.Endereco;
import com.totvs.sl.wms.estoque.endereco.domain.model.EnderecoId;
import com.totvs.sl.wms.estoque.estoque.domain.model.Estoque;
import com.totvs.sl.wms.estoque.estoque.domain.model.EstoqueDomainRepository;
import com.totvs.sl.wms.estoque.estoque.domain.model.EstoqueId;
import com.totvs.sl.wms.estoque.estoque.exception.WMSEstoqueUnitizadorNaoEncontradoException;
import com.totvs.sl.wms.estoque.estoque.exception.WMSExisteSaldoUnitizadorOutroEnderecoException;
import com.totvs.sl.wms.estoque.unidade.domain.model.UnidadeId;
import com.totvs.sl.wms.estoque.unitizador.domain.model.UnitizadorDomainRepository;
import com.totvs.sl.wms.estoque.unitizador.domain.model.UnitizadorId;
import com.totvs.sl.wms.estoque.unitizador.exception.WMSUnitizadorNaoEncontradoException;

import lombok.AllArgsConstructor;

@Service
@AllArgsConstructor
public class ValidaUnitizadorEstoqueDomainService {

	private final EstoqueDomainRepository estoqueRepository;
	private final BloqueioMovimentacaoUnitizadorDomainRepository bloqueioMovimentacaoUnitizadorRepository;
	private final UnitizadorDomainRepository unitizadorRepository;

	public void existeParaUnidade(UnidadeId unidadeId, UnitizadorId unitizadorId) {
		if (Objects.nonNull(unitizadorId)
				&& !unitizadorRepository.existeUnitizadorComIdEUnidadeId(unitizadorId, unidadeId)) {
			throw new WMSUnitizadorNaoEncontradoException();
		}
	}

	public void existeEmOutroEndereco(UnidadeId unidadeId, UnitizadorId unitizadorId, EnderecoId enderecoId) {

		if (Objects.nonNull(unitizadorId)
				&& estoqueRepository.existeEstoqueComSaldoEUnitizadorEmOutroEndereco(unidadeId,
																					 unitizadorId,
																					 enderecoId)) {
			throw new WMSExisteSaldoUnitizadorOutroEnderecoException();
		}
	}

	public void existeEmOutroEstoqueEOutroEndereco(EstoqueId estoqueId,
												   UnidadeId unidadeId,
												   UnitizadorId unitizadorId,
												   EnderecoId enderecoId) {

		if (estoqueRepository.existeOutroEstoqueComUnitizadorEmOutroEndereco(estoqueId,
																			 unidadeId,
																			 unitizadorId,
																			 enderecoId)) {
			throw new WMSExisteSaldoUnitizadorOutroEnderecoException();
		}
	}

	public void existeEmOutroEndereco(UnidadeId unidadeId,
									  UnitizadorId unitizadorId,
									  EnderecoId enderecoIdOrigem,
									  EnderecoId enderecoIdDestino) {

		if (Objects.nonNull(unitizadorId)
				&& estoqueRepository.existeEstoqueComSaldoEUnitizadorEmOutroEndereco(unidadeId,
																					 unitizadorId,
																					 enderecoIdOrigem,
																					 enderecoIdDestino)) {
			throw new WMSExisteSaldoUnitizadorOutroEnderecoException();
		}

	}

	public void ocupacaoUnitizadorEndereco(UnitizadorId unitizadorId, Endereco endereco) {

		if (Objects.nonNull(unitizadorId)) {
			if (!estoqueRepository.existsByUnitizadorIdAndEnderecoId(unitizadorId, endereco.getId()))
				endereco.validarSePermiteAumentarOcupacaoUnitizador();
		}
	}

	public void existeNaListaEstoques(Collection<Estoque> listaEstoques) {

		if (listaEstoques.isEmpty())
			throw new WMSEstoqueUnitizadorNaoEncontradoException();
	}

	public void idDiferenteBloqueioMovimentacaoUnitizador(BloqueioMovimentacaoUnitizadorId bloqueioMovimentacaoUnitizadorId,
														  UnitizadorId unitizadorId) {

		if (bloqueioMovimentacaoUnitizadorId != null) {

			var bloqueioMovimentacaoUnitizador = bloqueioMovimentacaoUnitizadorRepository.findWithLockByIdOrThrowNotFound(bloqueioMovimentacaoUnitizadorId);

			if (!unitizadorId.equals(bloqueioMovimentacaoUnitizador.getUnitizadorId())) {
				throw new WMSUnitizadorIdDiferenteBloqueioMovimentacaoUnitizadorIdException();
			}
		}
	}

}
