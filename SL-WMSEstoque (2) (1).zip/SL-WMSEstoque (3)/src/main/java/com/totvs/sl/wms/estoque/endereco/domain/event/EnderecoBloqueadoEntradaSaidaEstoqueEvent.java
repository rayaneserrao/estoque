package com.totvs.sl.wms.estoque.endereco.domain.event;

import java.math.BigDecimal;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.util.CollectionUtils;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.totvs.sl.wms.estoque.caracteristicaconfiguracao.domain.model.CaracteristicaConfiguracaoId;
import com.totvs.sl.wms.estoque.caracteristicaconfiguracao.domain.model.FormatoCaracteristicaValor;
import com.totvs.sl.wms.estoque.endereco.domain.model.Endereco;
import com.totvs.sl.wms.estoque.endereco.domain.model.EnderecoId;
import com.totvs.sl.wms.estoque.endereco.domain.model.TipoBloqueioEndereco;
import com.totvs.sl.wms.estoque.estoque.domain.model.Estoque;
import com.totvs.sl.wms.estoque.estoque.domain.model.EstoqueId;
import com.totvs.sl.wms.estoque.estoque.domain.model.FracionadoId;
import com.totvs.sl.wms.estoque.estoque.domain.model.SituacaoEstoque;
import com.totvs.sl.wms.estoque.estoque.domain.model.SituacaoEstoqueBloqueado;
import com.totvs.sl.wms.estoque.produto.domain.model.ProdutoId;
import com.totvs.sl.wms.estoque.rastreio.domain.model.RastreioId;
import com.totvs.sl.wms.estoque.sku.domain.model.SKU;
import com.totvs.sl.wms.estoque.sku.domain.model.SKUId;
import com.totvs.sl.wms.estoque.tipoestoque.domain.model.TipoEstoqueId;
import com.totvs.sl.wms.estoque.unitizador.domain.model.Unitizador;
import com.totvs.sl.wms.estoque.unitizador.domain.model.UnitizadorId;
import com.totvs.sl.wms.estoque.util.amqp.SubjectDomainEvent;

import lombok.Builder;
import lombok.Data;
import lombok.Getter;
import lombok.ToString;

@Getter
@ToString
@Builder
public final class EnderecoBloqueadoEntradaSaidaEstoqueEvent extends SubjectDomainEvent
		implements SubjectBloqueioEndereco {

	private final EnderecoId id;
	private final EnderecoBloqueadoOrigem origem;
	private final TipoBloqueioEndereco tipoBloqueioEfetuado;
	private final TipoBloqueioEndereco tipoBloqueioAtual;
	private final List<EstoqueBloqueado> estoquesBloqueados;

	@Data(staticConstructor = "of")
	public static final class EnderecoBloqueadoOrigem {
		private final String id;
		private final String origem;
	}

	@Data
	@Builder
	public static final class EstoqueBloqueado {
		private final EstoqueId id;
		private final ProdutoId produtoId;
		@Deprecated(since = "WMSIS-1356")
		private final SKUId skuId;
		@Deprecated(since = "WMSIS-1356")
		private final UnitizadorId unitizadorId;
		private final TipoEstoqueId tipoEstoqueId;
		private final EnderecoId enderecoId;
		private final Set<SituacaoEstoqueBloqueadoEvent> situacoes;
		private final Boolean avariado;
		private final RastreioId rastreioId;
		private final List<CaracteristicaEstoqueBloqueado> caracteristicas;
		private final BigDecimal saldo;
		private final BigDecimal saldoReservado;
		private final BigDecimal saldoDisponivel;
		private final BigDecimal quantidadeBloqueadaMovimentacaoNaoReservada;
		private final BigDecimal quantidadeBloqueadaMovimentacaoReservada;
		private final BigDecimal quantidadeBloqueadaMovimentacaoTotal;
		private final FracionadoId fracionadoId;
		private final SKUEstoque sku;
		private final UnitizadorEstoque unitizador;
	}

	@Data(staticConstructor = "of")
	public static final class SituacaoEstoqueBloqueadoEvent {
		private final ZonedDateTime quando;
		private final String chaveAcesso;
		private final String motivo;
	}

	@Data(staticConstructor = "of")
	public static final class SKUEstoque {
		private final SKUId skuId;
		private final BigDecimal quantidadeUnidadesProduto;
	}

	@Data(staticConstructor = "of")
	public static final class CaracteristicaEstoqueBloqueado {
		private final CaracteristicaConfiguracaoId caracteristicaConfiguracaoId;
		private final FormatoCaracteristicaValor formato;
		private final String valor;

	}

	@Data(staticConstructor = "of")
	public static final class UnitizadorEstoque {
		private final UnitizadorId unitizadorId;
		private final String codigoBarras;

		@JsonCreator
		public static UnitizadorEstoque from(Unitizador unitizador) {
			return unitizador == null ? null : new UnitizadorEstoque(unitizador.getId(), unitizador.getCodigoBarras());
		}
	}

	public static EnderecoBloqueadoEntradaSaidaEstoqueEvent from(Endereco endereco,
																 Collection<Estoque> estoquesEndereco,
																 Set<SKU> skus,
																 Set<Unitizador> unitizadores) {

		var bloqueio = endereco.getBloqueio().orElseThrow();

		var origemEvento = EnderecoBloqueadoOrigem.of(bloqueio.getOrigem().getId().toString(),
													  bloqueio.getOrigem().getOrigem());

		return EnderecoBloqueadoEntradaSaidaEstoqueEvent.builder()
														.id(endereco.getId())
														.origem(origemEvento)
														.tipoBloqueioEfetuado(TipoBloqueioEndereco.ENTRADA_SAIDA)
														.tipoBloqueioAtual(bloqueio.getTipo())
														.estoquesBloqueados(montarEstoquesBloqueados(estoquesEndereco,
																									 skus,
																									 unitizadores))
														.build();
	}

	private static List<EstoqueBloqueado> montarEstoquesBloqueados(Collection<Estoque> estoquesEndereco,
																   Set<SKU> skus,
																   Set<Unitizador> unitizadores) {

		List<Estoque> estoques = estoquesEndereco.stream().filter(Estoque::isBloqueado).toList();

		var estoquesBloqueados = new ArrayList<EstoqueBloqueado>();

		estoques.forEach(estoque -> {
			var sku = skus.stream().filter(s -> s.getId().equals(estoque.getSkuId())).findFirst().orElseThrow();

			Unitizador unitizador = null;

			if (estoque.getUnitizadorId() != null) {
				unitizador = unitizadores.stream()
										 .filter(u -> u.getId().equals(estoque.getUnitizadorId()))
										 .findFirst()
										 .orElse(null);
			}

			estoquesBloqueados.add(EstoqueBloqueado.builder()
												   .id(estoque.getId())
												   .produtoId(estoque.getProdutoId())
												   .skuId(estoque.getSkuId())
												   .unitizadorId(estoque.getUnitizadorId())
												   .tipoEstoqueId(estoque.getTipoEstoqueId())
												   .enderecoId(estoque.getEnderecoId())
												   .situacoes(montarSituacoesEstoque(estoque.getSituacoes()))
												   .avariado(estoque.getAvariado())
												   .rastreioId(estoque.getRastreioId())
												   .caracteristicas(montarCaracteristicas(estoque))
												   .saldo(estoque.getSaldo())
												   .saldoReservado(estoque.getQuantidadeReservada())
												   .saldoDisponivel(estoque.getSaldoDisponivel())
												   .quantidadeBloqueadaMovimentacaoNaoReservada(estoque.getQuantidadeBloqueadaParaMovimentacaoEstoqueNaoReservada())
												   .quantidadeBloqueadaMovimentacaoReservada(estoque.getQuantidadeBloqueadaParaMovimentacaoEstoqueReservada())
												   .quantidadeBloqueadaMovimentacaoTotal(estoque.getQuantidadeBloqueadaParaMovimentacaoEstoqueTotal())
												   .fracionadoId(estoque.getFracionadoId())
												   .sku(SKUEstoque.of(estoque.getSkuId(),
																	  sku.getQuantidadeUnidadesProduto()))
												   .unitizador(UnitizadorEstoque.from(unitizador))
												   .build());
		});

		return estoquesBloqueados;

	}

	private static Set<SituacaoEstoqueBloqueadoEvent> montarSituacoesEstoque(Set<SituacaoEstoque> situacoes) {
		return situacoes.stream()
						.map(EnderecoBloqueadoEntradaSaidaEstoqueEvent::criarSituacaoEstoqueBloqueio)
						.collect(Collectors.toSet());
	}

	private static SituacaoEstoqueBloqueadoEvent criarSituacaoEstoqueBloqueio(SituacaoEstoque situacao) {
		var situacaoEstoque = (SituacaoEstoqueBloqueado) situacao;
		return SituacaoEstoqueBloqueadoEvent.of(situacaoEstoque.getQuando(),
												situacaoEstoque.getChaveAcesso(),
												situacaoEstoque.getMotivo());
	}

	private static List<CaracteristicaEstoqueBloqueado> montarCaracteristicas(Estoque estoque) {

		if (CollectionUtils.isEmpty(estoque.getCaracteristicas())) {
			return new ArrayList<>();
		}

		return estoque.getCaracteristicas()
					  .stream()
					  .map(caracteristica -> CaracteristicaEstoqueBloqueado.of(caracteristica.getCaracteristicaConfiguracaoId(),
																			   caracteristica.getFormato(),
																			   caracteristica.getValor().toString()))
					  .collect(Collectors.toList());
	}

}
