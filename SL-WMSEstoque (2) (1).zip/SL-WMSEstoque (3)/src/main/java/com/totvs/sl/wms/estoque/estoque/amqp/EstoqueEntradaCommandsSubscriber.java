package com.totvs.sl.wms.estoque.estoque.amqp;

import java.util.ArrayList;

import org.springframework.cloud.stream.annotation.EnableBinding;
import org.springframework.cloud.stream.annotation.StreamListener;

import com.totvs.sl.wms.estoque.config.amqp.WMSChannel;
import com.totvs.sl.wms.estoque.config.amqp.WMSPublisher;
import com.totvs.sl.wms.estoque.estoque.amqp.cmd.EfetuarEntradaEstoqueBloqueadoCmd;
import com.totvs.sl.wms.estoque.estoque.amqp.cmd.EfetuarEntradaEstoqueLiberadoCmd;
import com.totvs.sl.wms.estoque.estoque.amqp.event.EstoqueBloqueadoEntradaRejeitadaEvent;
import com.totvs.sl.wms.estoque.estoque.amqp.event.EstoqueLiberadoEntradaRejeitadaEvent;
import com.totvs.sl.wms.estoque.estoque.application.EstoqueEfetuarEntradaApplicationService;
import com.totvs.sl.wms.estoque.estoque.application.command.EfetuarEntradaEstoqueBloqueadoCommand;
import com.totvs.sl.wms.estoque.estoque.application.command.EfetuarEntradaEstoqueLiberadoCommand;
import com.totvs.sl.wms.estoque.estoque.exception.WMSEfetuarEntradaEstoqueBloqueadoConstraintException;
import com.totvs.sl.wms.estoque.estoque.exception.WMSEfetuarEntradaEstoqueLiberadoConstraintException;
import com.totvs.sl.wms.estoque.estoque.exception.WMSExisteEstoqueComMesmoHashException;
import com.totvs.sl.wms.estoque.origem.domain.model.Origem;
import com.totvs.sl.wms.estoque.origem.domain.model.OrigemId;
import com.totvs.sl.wms.estoque.util.amqp.AMQPUtil;
import com.totvs.tjf.api.response.error.converter.ErrorExceptionConverter;
import com.totvs.tjf.core.i18n.I18nService;
import com.totvs.tjf.core.validation.ValidatorService;
import com.totvs.tjf.messaging.context.TOTVSMessage;

import lombok.AllArgsConstructor;

@AllArgsConstructor
@EnableBinding({ WMSChannel.WMSEntradaEstoqueCommandsInput.class, WMSChannel.WMSEntradaEstoqueLoteCommandsInput.class })
public class EstoqueEntradaCommandsSubscriber {

	private EstoqueEfetuarEntradaApplicationService service;

	private ValidatorService validator;

	private WMSPublisher wmsPublisher;

	private I18nService i18nService;

	@StreamListener(target = WMSChannel.WMS_ENTRADA_ESTOQUE_COMMANDS_IN, condition = EfetuarEntradaEstoqueLiberadoCmd.CONDITIONAL_EXPRESSION)
	public void efetuarEntradaEstoqueLiberado(final TOTVSMessage<EfetuarEntradaEstoqueLiberadoCmd> message) {

		AMQPUtil.gerarLog(this.getClass(), message, EfetuarEntradaEstoqueLiberadoCmd.CONDITIONAL_EXPRESSION);

		var cmd = message.getContent();

		validator.validate(cmd).ifPresent(violations -> {
			throw new WMSEfetuarEntradaEstoqueLiberadoConstraintException(violations);
		});

		var transactionInfo = message.getHeader().getTransactionInfo();
		var origem = Origem.of(OrigemId.from(transactionInfo.getTransactionId()), transactionInfo.getGeneratedBy());

		var command = EfetuarEntradaEstoqueLiberadoCommand.builder()
														  .unidadeId(cmd.getUnidadeId())
														  .origem(origem)
														  .produtoId(cmd.getProdutoId())
														  .skuId(cmd.getSkuId())
														  .unitizadorId(cmd.getUnitizadorId())
														  .tipoEstoqueId(cmd.getTipoEstoqueId())
														  .enderecoId(cmd.getEnderecoId())
														  .avariado(cmd.getAvariado())
														  .quantidade(cmd.getQuantidade())
														  .caracteristicasOld(cmd.getCaracteristicasOld())
														  .caracteristicas(cmd.getCaracteristicas())
														  .atributos(cmd.getAtributos())
														  .selos(cmd.getSelos())
														  .build();

		try {
			service.handle(command);
		} catch (WMSExisteEstoqueComMesmoHashException excecao) {
			throw excecao;
		} catch (RuntimeException excecao) {
			rejeitarEntradaEstoqueLiberadoCmd(cmd, excecao);
		}
	}

	private void rejeitarEntradaEstoqueLiberadoCmd(EfetuarEntradaEstoqueLiberadoCmd cmd, RuntimeException excecao) {

		var inconsistencias = new ArrayList<EstoqueLiberadoEntradaRejeitadaEvent.Inconsistencia>();

		var id = excecao.getClass().getSimpleName();
		var mensagem = "";
		var detalhe = "";

		if (!id.startsWith("WMS")) {
			throw excecao;
		}

		var erroConverter = new ErrorExceptionConverter(i18nService);
		var erro = erroConverter.convert(excecao).getError();

		mensagem = erro.getMessage();
		detalhe = erro.getDetailedMessage();
		inconsistencias.add(EstoqueLiberadoEntradaRejeitadaEvent.Inconsistencia.of(id, mensagem, detalhe));

		var eventoRejeicao = EstoqueLiberadoEntradaRejeitadaEvent.builder()
																 .unidadeId(cmd.getUnidadeId())
																 .inconsistencias(inconsistencias)
																 .build();

		wmsPublisher.dispatch(eventoRejeicao);
	}

	@StreamListener(target = WMSChannel.WMS_ENTRADA_ESTOQUE_COMMANDS_IN, condition = EfetuarEntradaEstoqueBloqueadoCmd.CONDITIONAL_EXPRESSION)
	public void efetuarEntradaEstoqueBloqueado(final TOTVSMessage<EfetuarEntradaEstoqueBloqueadoCmd> message) {
		this.processarEfetuarEntradaEstoqueBloqueado(message);
	}

	@StreamListener(target = WMSChannel.WMS_ENTRADA_ESTOQUE_LOTE_COMMANDS_IN, condition = EfetuarEntradaEstoqueBloqueadoCmd.CONDITIONAL_EXPRESSION)
	public void efetuarEntradaEstoqueBloqueadoLote(final TOTVSMessage<EfetuarEntradaEstoqueBloqueadoCmd> message) {
		this.processarEfetuarEntradaEstoqueBloqueado(message);
	}

	private void processarEfetuarEntradaEstoqueBloqueado(final TOTVSMessage<EfetuarEntradaEstoqueBloqueadoCmd> message) {

		AMQPUtil.gerarLog(this.getClass(), message, EfetuarEntradaEstoqueBloqueadoCmd.CONDITIONAL_EXPRESSION);

		var cmd = message.getContent();

		validator.validate(cmd).ifPresent(violations -> {
			throw new WMSEfetuarEntradaEstoqueBloqueadoConstraintException(violations);
		});

		var transactionInfo = message.getHeader().getTransactionInfo();
		var origem = Origem.of(OrigemId.from(transactionInfo.getTransactionId()), transactionInfo.getGeneratedBy());

		var command = EfetuarEntradaEstoqueBloqueadoCommand.builder()
														   .unidadeId(cmd.getUnidadeId())
														   .origem(origem)
														   .produtoId(cmd.getProdutoId())
														   .skuId(cmd.getSkuId())
														   .unitizadorId(cmd.getUnitizadorId())
														   .tipoEstoqueId(cmd.getTipoEstoqueId())
														   .enderecoId(cmd.getEnderecoId())
														   .avariado(cmd.getAvariado())
														   .quantidade(cmd.getQuantidade())
														   .chaveAcesso(cmd.getChaveAcesso())
														   .motivo(cmd.getMotivo())
														   .fracionadoId(cmd.getFracionadoId())
														   .caracteristicasOld(cmd.getCaracteristicasOld())
														   .caracteristicas(cmd.getCaracteristicas())
														   .atributos(cmd.getAtributos())
														   .selos(cmd.getSelos())
														   .build();

		try {
			service.handle(command);
		} catch (WMSExisteEstoqueComMesmoHashException excecao) {
			throw excecao;
		} catch (RuntimeException excecao) {
			rejeitarEntradaEstoqueBloqueadoCmd(cmd, excecao);
		}
	}

	private void rejeitarEntradaEstoqueBloqueadoCmd(EfetuarEntradaEstoqueBloqueadoCmd cmd, RuntimeException excecao) {

		var inconsistencias = new ArrayList<EstoqueBloqueadoEntradaRejeitadaEvent.Inconsistencia>();

		var id = excecao.getClass().getSimpleName();
		var mensagem = "";
		var detalhe = "";

		if (!id.startsWith("WMS")) {
			throw excecao;
		}

		var erroConverter = new ErrorExceptionConverter(i18nService);
		var erro = erroConverter.convert(excecao).getError();

		mensagem = erro.getMessage();
		detalhe = erro.getDetailedMessage();
		inconsistencias.add(EstoqueBloqueadoEntradaRejeitadaEvent.Inconsistencia.of(id, mensagem, detalhe));

		var eventoRejeicao = new EstoqueBloqueadoEntradaRejeitadaEvent();
		eventoRejeicao.setUnidadeId(cmd.getUnidadeId());
		eventoRejeicao.setInconsistencias(inconsistencias);

		eventoRejeicao.setInconsistencia(erro);

		wmsPublisher.dispatch(eventoRejeicao);
	}

}
