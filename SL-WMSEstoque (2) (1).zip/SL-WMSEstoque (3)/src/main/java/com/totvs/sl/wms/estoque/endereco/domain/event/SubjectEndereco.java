package com.totvs.sl.wms.estoque.endereco.domain.event;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.totvs.sl.wms.estoque.util.amqp.SubjectMessage;

public interface SubjectEndereco extends SubjectMessage {

	@JsonIgnore
	@Override
	default String getSubject() {
		return "endereco";
	}
}