package com.totvs.sl.wms.estoque.endereco.domain.event;

import com.totvs.sl.wms.estoque.endereco.domain.model.Endereco;
import com.totvs.sl.wms.estoque.endereco.domain.model.EnderecoId;
import com.totvs.sl.wms.estoque.endereco.domain.model.TipoBloqueioEndereco;
import com.totvs.sl.wms.estoque.estoque.domain.event.SubjectEntradaEstoque;
import com.totvs.sl.wms.estoque.util.amqp.SubjectDomainEvent;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
@AllArgsConstructor(access = AccessLevel.PRIVATE)
public final class EnderecoDesbloqueadoEntradaEstoqueEvent extends SubjectDomainEvent implements SubjectEntradaEstoque {

	private final EnderecoId id;
	private final TipoBloqueioEndereco tipoDesbloqueioEfetuado;
	private final TipoBloqueioEndereco tipoBloqueioAtual;

	public static EnderecoDesbloqueadoEntradaEstoqueEvent from(Endereco endereco) {

		return new EnderecoDesbloqueadoEntradaEstoqueEvent(endereco.getId(),
														   TipoBloqueioEndereco.ENTRADA,
														   endereco.getBloqueio()
																   .map(bloqueio -> bloqueio.getTipo())
																   .orElse(null));
	}
}
