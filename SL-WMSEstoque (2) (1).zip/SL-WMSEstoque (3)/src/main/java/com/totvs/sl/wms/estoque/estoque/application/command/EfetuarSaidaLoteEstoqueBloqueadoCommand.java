package com.totvs.sl.wms.estoque.estoque.application.command;

import java.math.BigDecimal;
import java.util.List;

import com.totvs.sl.wms.estoque.atributoestoquevalor.domain.model.AtributoEstoqueValor;
import com.totvs.sl.wms.estoque.estoque.domain.model.EstoqueId;
import com.totvs.sl.wms.estoque.origem.domain.model.Origem;
import com.totvs.sl.wms.estoque.unidade.domain.model.UnidadeId;

import lombok.Builder;
import lombok.Data;

@Data(staticConstructor = "of")
public final class EfetuarSaidaLoteEstoqueBloqueadoCommand {

	private final UnidadeId unidadeId;
	private final List<EstoqueSaida> estoques;
	private final Origem origem;

	@Data
	@Builder
	public static final class EstoqueSaida {
		private final EstoqueId id;
		private final BigDecimal quantidade;
		private final String chaveAcesso;
		private final List<AtributoEstoqueValor<?>> atributos;
	}
}
