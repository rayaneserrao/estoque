package com.totvs.sl.wms.estoque.endereco.domain.event;

import com.totvs.sl.wms.estoque.endereco.domain.model.Endereco;
import com.totvs.sl.wms.estoque.endereco.domain.model.EnderecoId;
import com.totvs.sl.wms.estoque.endereco.domain.model.TipoBloqueioEndereco;
import com.totvs.sl.wms.estoque.estoque.domain.event.SubjectSaidaEstoque;
import com.totvs.sl.wms.estoque.util.amqp.SubjectDomainEvent;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
@AllArgsConstructor(access = AccessLevel.PRIVATE)
public final class EnderecoDesbloqueadoSaidaEstoqueEvent extends SubjectDomainEvent implements SubjectSaidaEstoque {

	private final EnderecoId id;
	private final TipoBloqueioEndereco tipoDesbloqueioEfetuado;
	private final TipoBloqueioEndereco tipoBloqueioAtual;

	public static EnderecoDesbloqueadoSaidaEstoqueEvent from(Endereco endereco) {

		return new EnderecoDesbloqueadoSaidaEstoqueEvent(endereco.getId(),
														 TipoBloqueioEndereco.SAIDA,
														 endereco.getBloqueio()
																 .map(bloqueio -> bloqueio.getTipo())
																 .orElse(null));
	}
}
