package com.totvs.sl.wms.estoque.estoque.api.dto;

import javax.validation.constraints.NotBlank;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor(force = true)
@AllArgsConstructor(staticName = "of")
@Schema(description = "Informações para remover selo no estoque")
public final class RemoverSeloEstoqueDTO {

	@NotBlank(message = "{RemoverSeloEstoqueDTO.chave.NotBlank}")
	@Schema(description = "Chave do selo", required = true)
	private final String chave;

	@NotBlank(message = "{RemoverSeloEstoqueDTO.valor.NotBlank}")
	@Schema(description = "Valor do selo", required = true)
	private final String valor;
}
