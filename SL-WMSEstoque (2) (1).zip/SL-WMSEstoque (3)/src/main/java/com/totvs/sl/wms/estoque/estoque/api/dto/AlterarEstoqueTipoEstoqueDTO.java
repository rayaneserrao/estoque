package com.totvs.sl.wms.estoque.estoque.api.dto;

import javax.validation.constraints.NotNull;

import com.totvs.sl.wms.estoque.tipoestoque.domain.model.TipoEstoqueId;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

@AllArgsConstructor(staticName = "of")
@NoArgsConstructor(force = true)
@Getter
@Schema(description = "Informações para alteração do tipo de estoque no saldo")
public final class AlterarEstoqueTipoEstoqueDTO {

	@NotNull(message = "{AlterarEstoqueTipoEstoqueDTO.tipoEstoqueId.NotNull}")
	@Schema(description = "Identificador do tipo de estoque a ser alterado no saldo")
	private final TipoEstoqueId tipoEstoqueId;

}
