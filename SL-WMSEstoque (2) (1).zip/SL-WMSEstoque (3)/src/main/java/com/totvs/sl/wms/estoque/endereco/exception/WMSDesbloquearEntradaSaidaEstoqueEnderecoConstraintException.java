package com.totvs.sl.wms.estoque.endereco.exception;

import java.util.Set;

import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;

import com.totvs.tjf.api.context.stereotype.error.ApiBadRequest;

@ApiBadRequest("WMSGenericConstraintViolationException")
public class WMSDesbloquearEntradaSaidaEstoqueEnderecoConstraintException extends ConstraintViolationException {

	private static final long serialVersionUID = 4614820322222362065L;

	public WMSDesbloquearEntradaSaidaEstoqueEnderecoConstraintException(Set<? extends ConstraintViolation<?>> constraintViolations) {
		super(constraintViolations);
	}
}
