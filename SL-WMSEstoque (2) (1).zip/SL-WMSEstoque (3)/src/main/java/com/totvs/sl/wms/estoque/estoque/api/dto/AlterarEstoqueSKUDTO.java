package com.totvs.sl.wms.estoque.estoque.api.dto;

import javax.validation.constraints.NotNull;

import com.totvs.sl.wms.estoque.sku.domain.model.SKUId;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

@AllArgsConstructor(staticName = "of")
@NoArgsConstructor(force = true)
@Getter
@Schema(description = "Informações para alteração de SKU no estoque")
public final class AlterarEstoqueSKUDTO {

	@NotNull(message = "{AlterarEstoqueSKUDTO.skuId.NotNull}")
	@Schema(description = "Identificador do SKU a ser alterado no estoque")
	private final SKUId skuId;

}
