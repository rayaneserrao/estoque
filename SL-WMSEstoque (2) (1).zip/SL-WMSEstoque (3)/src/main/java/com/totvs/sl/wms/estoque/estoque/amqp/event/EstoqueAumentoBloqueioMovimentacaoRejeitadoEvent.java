package com.totvs.sl.wms.estoque.estoque.amqp.event;

import java.util.Collection;

import com.totvs.sl.wms.estoque.bloqueiomovimentacaoestoque.domain.model.BloqueioMovimentacaoEstoqueId;
import com.totvs.sl.wms.estoque.estoque.domain.event.SubjectBloqueioEstoque;
import com.totvs.sl.wms.estoque.estoque.domain.model.EstoqueId;
import com.totvs.sl.wms.estoque.util.amqp.RejectedEvent;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data(staticConstructor = "of")
@EqualsAndHashCode(callSuper = false)
public final class EstoqueAumentoBloqueioMovimentacaoRejeitadoEvent extends RejectedEvent
		implements SubjectBloqueioEstoque {

	private final EstoqueId estoqueId;

	private final BloqueioMovimentacaoEstoqueId bloqueioMovimentacaoEstoqueId;

	private final Collection<Inconsistencia> inconsistencias;

	@Data(staticConstructor = "of")
	public static final class Inconsistencia {
		private final String id;
		private final String mensagem;
		private final String detalhe;
	}

}
