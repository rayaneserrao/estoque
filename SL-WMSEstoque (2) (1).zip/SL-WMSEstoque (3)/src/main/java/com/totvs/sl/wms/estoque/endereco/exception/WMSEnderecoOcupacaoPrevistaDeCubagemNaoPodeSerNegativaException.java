package com.totvs.sl.wms.estoque.endereco.exception;

import java.math.BigDecimal;

import com.totvs.tjf.api.context.stereotype.ApiErrorParameter;
import com.totvs.tjf.api.context.stereotype.error.ApiBadRequest;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
@ApiBadRequest
public class WMSEnderecoOcupacaoPrevistaDeCubagemNaoPodeSerNegativaException extends RuntimeException {

	private static final long serialVersionUID = -3700556910835389123L;

	@ApiErrorParameter
	private final BigDecimal cubagem;

	@ApiErrorParameter
	private final BigDecimal novaOcupacaoPrevistaCubagem;
	
}
