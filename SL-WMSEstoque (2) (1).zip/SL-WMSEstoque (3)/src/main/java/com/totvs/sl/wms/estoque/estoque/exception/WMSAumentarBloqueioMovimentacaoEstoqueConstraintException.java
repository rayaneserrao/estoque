package com.totvs.sl.wms.estoque.estoque.exception;

import java.util.Set;

import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;

import com.totvs.tjf.api.context.stereotype.error.ApiBadRequest;

@ApiBadRequest
public class WMSAumentarBloqueioMovimentacaoEstoqueConstraintException extends ConstraintViolationException {

	private static final long serialVersionUID = 1L;

	public WMSAumentarBloqueioMovimentacaoEstoqueConstraintException(Set<? extends ConstraintViolation<?>> constraintViolations) {
		super(constraintViolations);
	}

}
