package com.totvs.sl.wms.estoque.estoque.api.dto;

import static com.totvs.sl.wms.estoque.util.Constants.QUANTIDADE_MAXIMA_DECIMAIS;
import static com.totvs.sl.wms.estoque.util.Constants.QUANTIDADE_MAXIMA_INTEIROS;

import java.math.BigDecimal;
import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.Digits;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Positive;

import com.totvs.sl.wms.estoque.atributoestoquevalor.api.dto.AtributoEstoqueValorDTO;
import com.totvs.sl.wms.estoque.endereco.domain.model.EnderecoId;
import com.totvs.sl.wms.estoque.estoque.domain.model.EstoqueId;
import com.totvs.sl.wms.estoque.unitizador.domain.model.UnitizadorId;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;

@AllArgsConstructor(staticName = "of")
@NoArgsConstructor(force = true)
@Getter
@Schema(description = "Informações para divisão/fusão de estoque")
public final class DividirFundirDTO {

	@Valid
	@NotNull(message = "{DividirFundirDTO.estoqueSaida.NotNull}")
	@Schema(description = "Dados do estoque saída divisão/fusão")
	private final EstoqueSaida estoqueSaida;

	@Valid
	@NotNull(message = "{DividirFundirDTO.estoqueEntrada.NotNull}")
	@Schema(description = "Dados do estoque entrada divisão/fusão")
	private final EstoqueEntrada estoqueEntrada;

	@Valid
	private final List<AtributoEstoqueValorDTO> atributos;

	@Data
	@NoArgsConstructor(access = AccessLevel.PRIVATE, force = true)
	@AllArgsConstructor(staticName = "of")
	@Schema(description = "Informações dos dados estoque saída divisão/fusão")
	public static final class EstoqueSaida {

		@NotNull(message = "{DividirFundirDTO.EstoqueSaida.id.NotNull}")
		@Schema(description = "Identificador do estoque saída")
		private final EstoqueId id;

		@NotNull(message = "{DividirFundirDTO.EstoqueSaida.quantidade.NotNull}")
		@Positive(message = "{DividirFundirDTO.EstoqueSaida.quantidade.Positive}")
		@Digits(fraction = QUANTIDADE_MAXIMA_DECIMAIS, integer = QUANTIDADE_MAXIMA_INTEIROS, message = "{DividirFundirDTO.EstoqueSaida.quantidade.Digits}")
		@Schema(description = "Quantidade para divisão/fusão")
		private final BigDecimal quantidade;
	}

	@Data
	@NoArgsConstructor(access = AccessLevel.PRIVATE, force = true)
	@AllArgsConstructor(staticName = "of")
	@Schema(description = "Informações dos dados estoque entrada divisão/fusão")
	public static final class EstoqueEntrada {

		@NotNull(message = "{DividirFundirDTO.EstoqueEntrada.unitizadorId.NotNull}")
		@Schema(description = "Identificador do unitizador")
		private final UnitizadorId unitizadorId;

		@Schema(description = "Identificador do endereço de destino")
		private final EnderecoId enderecoId;
	}
}
