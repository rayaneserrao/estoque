package com.totvs.sl.wms.estoque.estoque.amqp.cmd;

import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import com.totvs.sl.wms.estoque.atributoestoquevalor.amqp.cmd.AtributoEstoqueValorCmd;
import com.totvs.sl.wms.estoque.atributoestoquevalor.domain.model.AtributoEstoqueValor;
import com.totvs.sl.wms.estoque.estoque.domain.model.EstoqueId;
import com.totvs.sl.wms.estoque.reservadefinitivaestoque.domain.model.ReservaDefinitivaEstoqueId;
import com.totvs.sl.wms.estoque.sku.domain.model.SKUId;
import com.totvs.tjf.core.common.CollectionUtils;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
public final class AlterarEstoqueSKUCmd {

	public static final String NAME = "AlterarEstoqueSKUCmd";
	public static final String CONDITIONAL_EXPRESSION = "headers['type']=='" + NAME + "'";

	@NotNull(message = "{AlterarEstoqueSKUCmd.id.NotNull}")
	private final EstoqueId id;

	@NotNull(message = "{AlterarEstoqueSKUCmd.skuId.NotNull}")
	private final SKUId skuId;

	private final boolean aceitarParcialConvertendoSaldoDisponivel;

	private final Integer quantidadeSKU;

	private final List<ReservaDefinitivaCmd> reservasDefinitivas;

	@Valid
	private final List<AtributoEstoqueValorCmd> atributos;

	private final boolean manterAtributosReserva;

	@Data
	@NoArgsConstructor(force = true)
	@AllArgsConstructor(staticName = "of")
	public static final class ReservaDefinitivaCmd {
		private final ReservaDefinitivaEstoqueId id;
	}

	public List<ReservaDefinitivaCmd> getReservasDefinitivas() {
		return CollectionUtils.unmodifiable(this.reservasDefinitivas);
	}

	public final List<AtributoEstoqueValor<?>> getAtributos() {
		return AtributoEstoqueValorCmd.toAtributoEstoqueValor(this.atributos);
	}
}
