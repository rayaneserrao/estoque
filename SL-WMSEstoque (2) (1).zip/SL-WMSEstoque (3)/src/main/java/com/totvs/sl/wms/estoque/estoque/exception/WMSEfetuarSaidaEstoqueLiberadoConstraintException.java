package com.totvs.sl.wms.estoque.estoque.exception;

import java.util.Set;

import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;

import com.totvs.tjf.api.context.stereotype.error.ApiBadRequest;

@ApiBadRequest("WMSEfetuarSaidaEstoqueLiberadoConstraintException")
public class WMSEfetuarSaidaEstoqueLiberadoConstraintException extends ConstraintViolationException {

	private static final long serialVersionUID = -408488342320176422L;

	public WMSEfetuarSaidaEstoqueLiberadoConstraintException(Set<? extends ConstraintViolation<?>> constraintViolations) {
		super(constraintViolations);
	}
}
