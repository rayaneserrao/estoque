package com.totvs.sl.wms.estoque.estoque.exception;

import com.totvs.tjf.api.context.stereotype.error.ApiBadRequest;

@ApiBadRequest
public class WMSBloqueioMovimentacaoUnitizadorEstoqueNaoEncontradoException extends RuntimeException {

	private static final long serialVersionUID = -9005307396070285364L;

}
