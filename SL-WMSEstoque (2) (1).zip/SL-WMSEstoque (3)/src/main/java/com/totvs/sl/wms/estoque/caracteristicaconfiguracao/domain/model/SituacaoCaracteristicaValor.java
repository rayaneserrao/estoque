package com.totvs.sl.wms.estoque.caracteristicaconfiguracao.domain.model;

public enum SituacaoCaracteristicaValor {
	ATIVO, INATIVO
}
