package com.totvs.sl.wms.estoque.estoque.exception;

import java.util.Set;

import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;

import com.totvs.tjf.api.context.stereotype.error.ApiBadRequest;

@ApiBadRequest("WMSEfetuarBloqueioMovimentacaoEstoqueUnitizadorConstraintException")
public class WMSBloquearMovimentacaoEstoqueUnitizadorConstraintException extends ConstraintViolationException {
	
	private static final long serialVersionUID = -6174460179455870897L;

	public WMSBloquearMovimentacaoEstoqueUnitizadorConstraintException(Set<? extends ConstraintViolation<?>> constraintViolations) {
		super(constraintViolations);
	}
}
