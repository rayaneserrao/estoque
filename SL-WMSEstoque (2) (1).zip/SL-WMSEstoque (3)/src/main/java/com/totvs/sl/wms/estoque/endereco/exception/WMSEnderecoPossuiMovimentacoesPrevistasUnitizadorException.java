package com.totvs.sl.wms.estoque.endereco.exception;

import com.totvs.tjf.api.context.stereotype.error.ApiBadRequest;

@ApiBadRequest
public class WMSEnderecoPossuiMovimentacoesPrevistasUnitizadorException extends RuntimeException {

	private static final long serialVersionUID = -7716613404855157311L;
}
