package com.totvs.sl.wms.estoque.caracteristicaconfiguracao.domain.model;

import static com.totvs.tjf.autoconfigure.ValidationUtils.validateIntegrity;

import java.util.ArrayList;
import java.util.List;
import java.util.TreeSet;

import javax.persistence.Table;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.totvs.sl.wms.estoque.caracteristicaconfiguracao.domain.event.CaracteristicaConfiguracaoAlteradaEvent;
import com.totvs.sl.wms.estoque.caracteristicaconfiguracao.domain.event.CaracteristicaConfiguracaoAtivadaEvent;
import com.totvs.sl.wms.estoque.caracteristicaconfiguracao.domain.event.CaracteristicaConfiguracaoCriadaEvent;
import com.totvs.sl.wms.estoque.caracteristicaconfiguracao.domain.event.CaracteristicaConfiguracaoExcluidaEvent;
import com.totvs.sl.wms.estoque.caracteristicaconfiguracao.domain.event.CaracteristicaConfiguracaoInativadaEvent;
import com.totvs.sl.wms.estoque.caracteristicaconfiguracao.exception.WMSCaracteristicaConfiguracaoConstraintException;
import com.totvs.sl.wms.estoque.caracteristicaconfiguracao.exception.WMSCaracteristicaConfiguracaoFormatoNaoPodeSerAlteradoException;
import com.totvs.sl.wms.estoque.caracteristicaconfiguracao.exception.WMSCaracteristicaConfiguracaoNaoPermiteAlterarOrigemPadraoException;
import com.totvs.sl.wms.estoque.caracteristicaconfiguracao.exception.WMSCaracteristicaConfiguracaoNaoPermiteExcluirOrigemPadraoException;
import com.totvs.sl.wms.estoque.caracteristicaconfiguracao.exception.WMSCaracteristicaConfiguracaoNaoPodeSerExcluidaException;
import com.totvs.sl.wms.estoque.caracteristicavalor.domain.model.CaracteristicaValorPadrao;
import com.totvs.tjf.core.stereotype.Aggregate;
import com.totvs.tjf.repository.aggregate.metadata.AggregateDomainMetadataInfo;

import lombok.AccessLevel;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;

@ToString
@Getter
@Aggregate
@Table(name = "caracteristica_configuracao")
@EqualsAndHashCode(callSuper = true)
@NoArgsConstructor(access = AccessLevel.PROTECTED, force = true)
public class CaracteristicaConfiguracao extends AggregateDomainMetadataInfo<CaracteristicaConfiguracaoId> {

	@NotBlank(message = "{CaracteristicaConfiguracao.descricao.NotBlank}")
	@Size(min = 1, max = 60, message = "{CaracteristicaConfiguracao.descricao.Size}")
	private String descricao;

	@NotNull(message = "{CaracteristicaConfiguracao.formato.NotNull}")
	private FormatoCaracteristicaValor formato;

	@NotNull(message = "{CaracteristicaConfiguracao.origem.NotNull}")
	private CaracteristicaConfiguracaoOrigem origem;

	private SituacaoCaracteristica situacao;

	private List<SituacaoCaracteristica> historicoSituacoes = new ArrayList<>();

	private final TreeSet<String> utilizado = new TreeSet<>();

	@Builder
	public CaracteristicaConfiguracao(CaracteristicaConfiguracaoId id,
									  String descricao,
									  FormatoCaracteristicaValor formato,
									  CaracteristicaConfiguracaoOrigem origem) {

		super(id);
		this.descricao = descricao;
		this.formato = formato;
		this.origem = origem;
		this.situacao = SituacaoCaracteristica.ofAtivo();

		validateIntegrity(this).ifPresent(violations -> {
			throw new WMSCaracteristicaConfiguracaoConstraintException(violations);
		});

		this.registerEvent(CaracteristicaConfiguracaoCriadaEvent.from(this));

	}

	public void alterar(String descricao, FormatoCaracteristicaValor formato) {

		if (this.origem.equals(CaracteristicaConfiguracaoOrigem.PADRAO)) {
			throw new WMSCaracteristicaConfiguracaoNaoPermiteAlterarOrigemPadraoException();
		}

		if (!this.formato.equals(formato) && !this.utilizado.isEmpty()) {
			throw new WMSCaracteristicaConfiguracaoFormatoNaoPodeSerAlteradoException(this.utilizado);
		}

		this.formato = formato;
		this.descricao = descricao;

		validateIntegrity(this).ifPresent(violations -> {
			throw new WMSCaracteristicaConfiguracaoConstraintException(violations);
		});

		this.registerEvent(CaracteristicaConfiguracaoAlteradaEvent.from(this));
	}

	public boolean ativar() {

		if (this.situacao.isAtivo())
			return false;

		this.historicoSituacoes.add(this.situacao);
		this.situacao = SituacaoCaracteristica.ofAtivo();

		this.registerEvent(CaracteristicaConfiguracaoAtivadaEvent.from(this));

		return true;
	}

	public boolean inativar() {

		if (this.situacao.isInativo())
			return false;

		this.historicoSituacoes.add(this.situacao);
		this.situacao = SituacaoCaracteristica.ofInativo();

		this.registerEvent(CaracteristicaConfiguracaoInativadaEvent.from(this));

		return true;
	}

	public String getValorPadrao() {
		switch (this.formato) {
		case DATA:
			return CaracteristicaValorPadrao.CARACTERISTICA_DATA.getValor();
		case NUMERO:
			return CaracteristicaValorPadrao.CARACTERISTICA_NUMERO.getValor();
		default:
			return CaracteristicaValorPadrao.CARACTERISTICA_TEXTO.getValor();
		}
	}

	public void marcarUtilizado(String funcionalidade) {
		this.utilizado.add(funcionalidade);
	}

	public void desmarcarUtilizado(String funcionalidade) {
		this.utilizado.remove(funcionalidade);
	}

	public void excluir() {

		if (this.origem.equals(CaracteristicaConfiguracaoOrigem.PADRAO)) {
			throw new WMSCaracteristicaConfiguracaoNaoPermiteExcluirOrigemPadraoException();
		}

		if (!this.utilizado.isEmpty()) {
			throw new WMSCaracteristicaConfiguracaoNaoPodeSerExcluidaException(this.utilizado);
		}

		this.registerEvent(CaracteristicaConfiguracaoExcluidaEvent.from(this));
	}
}
