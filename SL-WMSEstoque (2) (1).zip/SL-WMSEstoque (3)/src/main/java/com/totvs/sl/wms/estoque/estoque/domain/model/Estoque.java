package com.totvs.sl.wms.estoque.estoque.domain.model;

import static com.totvs.sl.wms.estoque.util.Constants.QUANTIDADE_MAXIMA_DECIMAIS;
import static com.totvs.sl.wms.estoque.util.Constants.QUANTIDADE_MAXIMA_INTEIROS;
import static com.totvs.sl.wms.estoque.util.Constants.QUANTIDADE_MINIMA;
import static com.totvs.sl.wms.estoque.util.Constants.QUANTIDADE_MINIMA_SALDO_INICIAL;
import static com.totvs.tjf.autoconfigure.ValidationUtils.validateIntegrity;
import static java.util.Objects.isNull;

import java.math.BigDecimal;
import java.math.MathContext;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.springframework.util.CollectionUtils;

import com.totvs.sl.wms.estoque.bloqueiomovimentacaoestoque.domain.model.BloqueioMovimentacaoEstoque;
import com.totvs.sl.wms.estoque.bloqueiomovimentacaoestoque.domain.model.BloqueioMovimentacaoEstoqueId;
import com.totvs.sl.wms.estoque.bloqueiomovimentacaounitizador.domain.model.BloqueioMovimentacaoUnitizadorId;
import com.totvs.sl.wms.estoque.caracteristicavalor.domain.model.CaracteristicaValor;
import com.totvs.sl.wms.estoque.endereco.domain.model.Endereco;
import com.totvs.sl.wms.estoque.endereco.domain.model.EnderecoId;
import com.totvs.sl.wms.estoque.endereco.exception.WMSEnderecoBloqueadoParaSaidaEstoqueException;
import com.totvs.sl.wms.estoque.estoque.domain.event.EstoqueAumentoBloqueioMovimentacaoEfetuadoEvent;
import com.totvs.sl.wms.estoque.estoque.domain.event.EstoqueBloqueadoEntradaEfetuadaEvent;
import com.totvs.sl.wms.estoque.estoque.domain.event.EstoqueBloqueadoSaidaEfetuadaEvent;
import com.totvs.sl.wms.estoque.estoque.domain.event.EstoqueBloqueioMovimentacaoAssociacaoAtributosEfetuadaEvent;
import com.totvs.sl.wms.estoque.estoque.domain.event.EstoqueBloqueioMovimentacaoEfetuadoEvent;
import com.totvs.sl.wms.estoque.estoque.domain.event.EstoqueDesbloqueioMovimentacaoEfetuadoEvent;
import com.totvs.sl.wms.estoque.estoque.domain.event.EstoqueLiberadoEntradaEfetuadaEvent;
import com.totvs.sl.wms.estoque.estoque.domain.event.EstoqueLiberadoSaidaEfetuadaEvent;
import com.totvs.sl.wms.estoque.estoque.domain.event.EstoqueSeloAdicionadoEvent;
import com.totvs.sl.wms.estoque.estoque.domain.event.EstoqueSeloRemovidoEvent;
import com.totvs.sl.wms.estoque.estoque.exception.WMSBloqueioMovimentacaoEstoqueNaoRelacionadoAReservaDefinitivaEstoqueException;
import com.totvs.sl.wms.estoque.estoque.exception.WMSBloqueioMovimentacaoUnitizadorIdDiferenteDoEstoqueException;
import com.totvs.sl.wms.estoque.estoque.exception.WMSChaveAcessoBloqueioEstoqueDiferenteDoEnderecoException;
import com.totvs.sl.wms.estoque.estoque.exception.WMSChaveAcessoSaidaEstoqueInvalidaException;
import com.totvs.sl.wms.estoque.estoque.exception.WMSEnderecoBloqueadoParaEntradaEstoqueException;
import com.totvs.sl.wms.estoque.estoque.exception.WMSEstoqueAtributoSaldoNaoPertenceAoEstoqueException;
import com.totvs.sl.wms.estoque.estoque.exception.WMSEstoqueAtributoSaldoValorSerialNaoEncontradoNoEstoqueException;
import com.totvs.sl.wms.estoque.estoque.exception.WMSEstoqueAtributosNaoIndicadosNaMovimentacaoException;
import com.totvs.sl.wms.estoque.estoque.exception.WMSEstoqueBloqueadoComChaveAcessoEChaveAcessoInformadaDiferenteException;
import com.totvs.sl.wms.estoque.estoque.exception.WMSEstoqueBloqueadoParaMovimentacaoPorEstoqueException;
import com.totvs.sl.wms.estoque.estoque.exception.WMSEstoqueBloqueadoPorUnitizadorException;
import com.totvs.sl.wms.estoque.estoque.exception.WMSEstoqueBloqueioMovimentacaoEstoqueNaoEncontradoException;
import com.totvs.sl.wms.estoque.estoque.exception.WMSEstoqueBloqueioMovimentacaoEstoqueNaoRealizadoQuantidadeNaoDeveSerSuperiorSaldoDisponivelParaBloqueioException;
import com.totvs.sl.wms.estoque.estoque.exception.WMSEstoqueBloqueioMovimentacaoEstoqueNaoRealizadoQuantidadeReservaInvalidaException;
import com.totvs.sl.wms.estoque.estoque.exception.WMSEstoqueBloqueioMovimentacaoEstoqueNaoRealizadoReservaJaRegistradaException;
import com.totvs.sl.wms.estoque.estoque.exception.WMSEstoqueBloqueioMovimentacaoEstoqueNaoRealizadoReservaNaoEncontradaException;
import com.totvs.sl.wms.estoque.estoque.exception.WMSEstoqueBloqueioMovimentacaoRelacionadoAReservaDefinitivaEstoqueException;
import com.totvs.sl.wms.estoque.estoque.exception.WMSEstoqueConstraintException;
import com.totvs.sl.wms.estoque.estoque.exception.WMSEstoqueDesbloquearMovimentacaoEstoqueRegistroNaoEncontradaException;
import com.totvs.sl.wms.estoque.estoque.exception.WMSEstoqueHashNaoInformadoException;
import com.totvs.sl.wms.estoque.estoque.exception.WMSEstoqueQuantidadeAtributosNaoInformadaParaSaldoComAtributosException;
import com.totvs.sl.wms.estoque.estoque.exception.WMSEstoqueQuantidadeDecimaisException;
import com.totvs.sl.wms.estoque.estoque.exception.WMSEstoqueQuantidadeInteirosException;
import com.totvs.sl.wms.estoque.estoque.exception.WMSEstoqueQuantidadeInvalidaException;
import com.totvs.sl.wms.estoque.estoque.exception.WMSEstoqueQuantidadeNaoInformadaException;
import com.totvs.sl.wms.estoque.estoque.exception.WMSEstoqueQuantidadeSaldoAtributoInsuficienteException;
import com.totvs.sl.wms.estoque.estoque.exception.WMSEstoqueQuantidadeSaldoInsuficienteException;
import com.totvs.sl.wms.estoque.estoque.exception.WMSEstoqueQuantidadeTotalAtributosDeveSerIgualQuantidadeMovimentadaException;
import com.totvs.sl.wms.estoque.estoque.exception.WMSEstoqueReservaDefinitivaBloqueioMovimentacaoEstoqueNaoInformadoException;
import com.totvs.sl.wms.estoque.estoque.exception.WMSEstoqueReservaNaoEncontradaException;
import com.totvs.sl.wms.estoque.estoque.exception.WMSEstoqueSaldoAtributoTotalmenteReservadoException;
import com.totvs.sl.wms.estoque.estoque.exception.WMSEstoqueSaldoInformadoParaProcessamentoMaiorOuMenorQueOSuficienteException;
import com.totvs.sl.wms.estoque.estoque.exception.WMSEstoqueSaldoTotalmenteReservadoException;
import com.totvs.sl.wms.estoque.estoque.exception.WMSEstoqueValorAtributoSerialJaPossuiBloqueioMovimentacaoException;
import com.totvs.sl.wms.estoque.estoque.exception.WMSFuncaoEnderecoInvalidaParaEstornoException;
import com.totvs.sl.wms.estoque.estoque.exception.WMSProdutoInformadoNaoCorrespondeAoEstoqueException;
import com.totvs.sl.wms.estoque.estoque.exception.WMSQuantidadeAReservarSuperiorAoSaldoDisponivelException;
import com.totvs.sl.wms.estoque.estoque.exception.WMSQuantidadeAReservarSuperiorAoSaldoDisponivelSKUFracionadoException;
import com.totvs.sl.wms.estoque.estoque.exception.WMSQuantidadeMaximaAumentoBloqueioMovimentacaoZeroException;
import com.totvs.sl.wms.estoque.estoque.exception.WMSReservaInformadaNaoCorrespondeAoEstoqueException;
import com.totvs.sl.wms.estoque.estoque.exception.WMSSKUInformadoNaoCorrespondeAoEstoqueException;
import com.totvs.sl.wms.estoque.estoque.exception.WMSSaidaEstoqueBloqueadoComChaveAcessoException;
import com.totvs.sl.wms.estoque.estoque.exception.WMSSaidaEstoqueReservasPertecemBloqueioMovimentacaoEstoqueException;
import com.totvs.sl.wms.estoque.estoque.exception.WMSSaidaEstoqueTransferenciaReservasDiferentesBloqueioMovimentacaoEstoqueException;
import com.totvs.sl.wms.estoque.estoque.exception.WMSSeloExistenteException;
import com.totvs.sl.wms.estoque.estoque.exception.WMSSeloNaoExistenteException;
import com.totvs.sl.wms.estoque.estoque.exception.WMSSituacaoEstoqueNaoPermiteBloqueioException;
import com.totvs.sl.wms.estoque.estoque.exception.WMSSituacaoEstoqueNaoPermiteDesbloqueioException;
import com.totvs.sl.wms.estoque.estoque.exception.WMSSituacaoEstoqueNaoPermiteSaidaException;
import com.totvs.sl.wms.estoque.movimentoestoque.domain.model.MovimentoEstoque;
import com.totvs.sl.wms.estoque.movimentoestoque.domain.model.MovimentoEstoqueId;
import com.totvs.sl.wms.estoque.movimentoestoque.domain.model.TipoMovimentoEstoque;
import com.totvs.sl.wms.estoque.movimentoestoque.exception.WMSMovimentoEstoqueParaRelacionamentoDeveTerIdInformadoException;
import com.totvs.sl.wms.estoque.movimentoestoque.exception.WMSMovimentoEstoqueParaRelacionamentoDeveTerMovimentoRelacionadoIdInformadoException;
import com.totvs.sl.wms.estoque.movimentoestoque.exception.WMSMovimentoEstoqueParaRelacionamentoDeveTerRastreioRelacionadoIdInformadoException;
import com.totvs.sl.wms.estoque.origem.domain.model.Origem;
import com.totvs.sl.wms.estoque.produto.domain.model.Produto;
import com.totvs.sl.wms.estoque.produto.domain.model.ProdutoId;
import com.totvs.sl.wms.estoque.produto.exception.WMSEstoqueValorAtributoSerialJaPossuiReservaException;
import com.totvs.sl.wms.estoque.rastreio.domain.model.RastreioId;
import com.totvs.sl.wms.estoque.reservadefinitivaestoque.domain.event.EstornoLiquidacaoReservaDefinitivaEstoqueEfetuadaEvent;
import com.totvs.sl.wms.estoque.reservadefinitivaestoque.domain.event.ExclusaoReservaDefinitivaEstoqueEfetuadaEvent;
import com.totvs.sl.wms.estoque.reservadefinitivaestoque.domain.event.GeracaoReservaDefinitivaEstoqueEfetuadaEvent;
import com.totvs.sl.wms.estoque.reservadefinitivaestoque.domain.event.LiquidacaoReservaDefinitivaEstoqueEfetuadaEvent;
import com.totvs.sl.wms.estoque.reservadefinitivaestoque.domain.event.SubtracaoReservaDefinitivaEstoqueEfetuadaEvent;
import com.totvs.sl.wms.estoque.reservadefinitivaestoque.domain.model.ReservaDefinitivaEstoque;
import com.totvs.sl.wms.estoque.reservadefinitivaestoque.domain.model.ReservaDefinitivaEstoqueId;
import com.totvs.sl.wms.estoque.reservadefinitivaestoque.exception.WMSEstoqueBloqueadoNaoPodeGerarReservaException;
import com.totvs.sl.wms.estoque.reservadefinitivaestoque.exception.WMSReservaDefinitivaEstoqueNaoPodeSerExcluidaException;
import com.totvs.sl.wms.estoque.reservadefinitivaestoque.exception.WMSReservaDefinitivaEstoqueQuantidadeNaoPodeSerSubtraidaException;
import com.totvs.sl.wms.estoque.reservadefinitivaestoque.exception.WMSSituacaoReservaDefinitivaEstoqueNaoPermiteTransferenciaEnderecoException;
import com.totvs.sl.wms.estoque.sku.domain.model.SKU;
import com.totvs.sl.wms.estoque.sku.domain.model.SKUId;
import com.totvs.sl.wms.estoque.sku.exception.WMSEstoqueQuantidadeDeveSerMultiplaSKUException;
import com.totvs.sl.wms.estoque.tipoestoque.domain.model.TipoEstoqueId;
import com.totvs.sl.wms.estoque.unidade.domain.model.UnidadeId;
import com.totvs.sl.wms.estoque.unitizador.domain.model.UnitizadorId;
import com.totvs.sl.wms.estoque.util.CompareUtils;
import com.totvs.tjf.core.stereotype.Aggregate;
import com.totvs.tjf.repository.aggregate.metadata.AggregateDomainMetadataInfo;

import lombok.AccessLevel;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.NonNull;
import lombok.ToString;

@ToString
@Getter
@Aggregate
@Table(name = "estoque")
@EqualsAndHashCode(callSuper = true)
@NoArgsConstructor(access = AccessLevel.PROTECTED, force = true)
public class Estoque extends AggregateDomainMetadataInfo<EstoqueId> {

	@NotNull(message = "{Estoque.rastreioId.NotNull}")
	private RastreioId rastreioId;

	private UnidadeId unidadeId;

	private ProdutoId produtoId;

	private SKUId skuId;

	private UnitizadorId unitizadorId;

	private TipoEstoqueId tipoEstoqueId;

	private EnderecoId enderecoId;

	private FracionadoId fracionadoId;

	private BloqueioMovimentacaoUnitizadorId bloqueioMovimentacaoUnitizadorId;

	@NotNull(message = "{Estoque.saldo.NotNull}")
	private BigDecimal saldo;

	private Set<SituacaoEstoque> situacoes;

	private Boolean avariado;

	private String hash;

	private Set<EstoqueReservaDefinitiva> reservasDefinitivas = new HashSet<>();

	private List<CaracteristicaValor<?>> caracteristicas = new ArrayList<>();

	private List<EstoqueAtributoSaldo> atributosSaldo = new ArrayList<>();

	private Collection<EstoqueBloqueioMovimentacao> bloqueiosMovimentacaoEstoque = new HashSet<>();

	private List<SeloEstoque> selos = new ArrayList<>();

	private ZonedDateTime dataHoraEntrada;

	@Builder
	private Estoque(EstoqueId id, // NOSONAR
					Produto produto,
					SKU sku,
					BigDecimal saldo,
					EstoqueHash estoqueHash,
					RastreioId rastreioId,
					List<EstoqueAtributoSaldo> atributosSaldo,
					List<SeloEstoque> selos,
					ZonedDateTime dataHoraEntrada) {

		super(id);

		if (estoqueHash == null)
			throw new WMSEstoqueHashNaoInformadoException();

		this.saldo = saldo;
		this.unidadeId = estoqueHash.getUnidadeId();
		this.produtoId = estoqueHash.getProdutoId();
		this.skuId = estoqueHash.getSkuId();
		this.unitizadorId = estoqueHash.getUnitizadorId();
		this.tipoEstoqueId = estoqueHash.getTipoEstoqueId();
		this.enderecoId = estoqueHash.getEnderecoId();
		this.fracionadoId = estoqueHash.getFracionadoId();
		this.situacoes = estoqueHash.getSituacoes();
		this.avariado = estoqueHash.getAvariado();
		this.hash = estoqueHash.getHash();
		this.caracteristicas = estoqueHash.getCaracteristicas();
		this.rastreioId = rastreioId != null ? rastreioId : RastreioId.generate();

		if (!CollectionUtils.isEmpty(atributosSaldo)) {
			this.atributosSaldo.addAll(atributosSaldo);
		}

		if (!CollectionUtils.isEmpty(selos)) {
			this.selos.addAll(selos);
		}

		this.dataHoraEntrada = dataHoraEntrada;

		validateIntegrity(this).ifPresent(violations -> {
			throw new WMSEstoqueConstraintException(violations);
		});

		validarInformacoesBasicas(produto, sku, saldo, true, atributosSaldo);

	}

	public Optional<BloqueioMovimentacaoUnitizadorId> getBloqueioMovimentacaoUnitizadorId() {
		return Optional.ofNullable(this.bloqueioMovimentacaoUnitizadorId);
	}

	protected MovimentoEstoque efetuarEntrada(Produto produto, // NOSONAR
											  SKU sku,
											  BigDecimal quantidade,
											  Origem origem,
											  MovimentoEstoqueId movimentoEstoqueId,
											  MovimentoEstoqueId movimentoEstoqueRelacionadoId,
											  RastreioId rastreioRelacionadoId,
											  boolean alteraOcupacaoEndereco,
											  List<EstoqueAtributoSaldo> estoqueAtributos) {

		if (movimentoEstoqueId != null || movimentoEstoqueRelacionadoId != null || rastreioRelacionadoId != null)
			validarInformacoesParaRelacionamento(movimentoEstoqueId,
												 movimentoEstoqueRelacionadoId,
												 rastreioRelacionadoId);

		validarInformacoesBasicas(produto, sku, quantidade, false, estoqueAtributos);

		var movimentoEstoque = processarEntrada(quantidade,
												origem,
												null,
												movimentoEstoqueId,
												movimentoEstoqueRelacionadoId,
												rastreioRelacionadoId,
												alteraOcupacaoEndereco,
												estoqueAtributos);

		registrarEstoqueEntradaEfetuadaEvent(movimentoEstoque);

		return movimentoEstoque;
	}

	public MovimentoEstoque efetuarEntradaAlteracaoEstoque(Produto produto, // NOSONAR
														   SKU sku,
														   BigDecimal quantidade,
														   Iterable<ReservaDefinitivaEstoque> reservasDefinitivas,
														   Origem origem,
														   MovimentoEstoqueId movimentoEstoqueId,
														   MovimentoEstoqueId movimentoEstoqueRelacionadoId,
														   RastreioId rastreioRelacionadoId,
														   boolean alteraOcupacaoEndereco,
														   List<EstoqueAtributoSaldo> estoqueAtributos,
														   boolean manterAtributosReserva) {

		if (movimentoEstoqueId != null || movimentoEstoqueRelacionadoId != null || rastreioRelacionadoId != null)
			validarInformacoesParaRelacionamento(movimentoEstoqueId,
												 movimentoEstoqueRelacionadoId,
												 rastreioRelacionadoId);

		validarInformacoesBasicas(produto, sku, quantidade, false, estoqueAtributos);

		var movimentoEstoque = processarEntrada(quantidade,
												origem,
												null,
												movimentoEstoqueId,
												movimentoEstoqueRelacionadoId,
												rastreioRelacionadoId,
												alteraOcupacaoEndereco,
												estoqueAtributos);

		reservasDefinitivas.forEach(reservaDefinitiva -> adicionarReservaNoSaldo(reservaDefinitiva,
																				 manterAtributosReserva
																						 ? estoqueAtributos
																						 : null));

		registrarEstoqueEntradaEfetuadaEvent(movimentoEstoque);

		return movimentoEstoque;
	}

	public MovimentoEstoque efetuarSaidaLiberado(Produto produto,
												 SKU sku,
												 BigDecimal quantidade,
												 Origem origem,
												 Endereco endereco,
												 boolean alteraOcupacaoEndereco,
												 List<EstoqueAtributoSaldo> estoqueAtributos) {

		if (isBloqueado())
			throw new WMSSituacaoEstoqueNaoPermiteSaidaException(SituacaoEstoqueValor.BLOQUEADO.name());

		validarSeEnderecoBloqueadoParaSaidaOuEntradaSaida(endereco);

		validarInformacoesParaSaida(produto, sku, quantidade, estoqueAtributos);

		var movimento = processarSaida(quantidade,
									   origem,
									   null,
									   null,
									   null,
									   null,
									   alteraOcupacaoEndereco,
									   estoqueAtributos);

		this.registerEvent(EstoqueLiberadoSaidaEfetuadaEvent.from(this, movimento));

		return movimento;

	}

	public MovimentoEstoque efetuarSaidaBloqueado(Produto produto, // NOSONAR
												  SKU sku,
												  BigDecimal quantidade,
												  Origem origem,
												  String chave,
												  Endereco endereco,
												  boolean alteraOcupacaoEndereco,
												  List<EstoqueAtributoSaldo> estoqueAtributos) {

		if (isLiberado())
			throw new WMSSituacaoEstoqueNaoPermiteSaidaException(SituacaoEstoqueValor.LIBERADO.name());

		validarSeEnderecoBloqueadoParaSaidaOuEntradaSaida(endereco);

		validarChaveAcesso(chave);

		validarInformacoesParaSaida(produto, sku, quantidade, estoqueAtributos);

		var movimento = processarSaida(quantidade,
									   origem,
									   null,
									   null,
									   null,
									   null,
									   alteraOcupacaoEndereco,
									   estoqueAtributos);

		this.registerEvent(EstoqueBloqueadoSaidaEfetuadaEvent.from(this, movimento));

		return movimento;

	}

	public MovimentoEstoque efetuarSaidaSaldoParcial(Produto produto, // NOSONAR
													 SKU sku,
													 BigDecimal quantidade,
													 Origem origem,
													 MovimentoEstoqueId movimentoEstoqueId,
													 MovimentoEstoqueId movimentoEstoqueRelacionadoId,
													 RastreioId rastreioRelacionadoId,
													 boolean alteraOcupacaoEndereco,
													 List<EstoqueAtributoSaldo> estoqueAtributos) {
		return this.efetuarSaidaSaldoParcial(produto,
											 sku,
											 quantidade,
											 origem,
											 movimentoEstoqueId,
											 movimentoEstoqueRelacionadoId,
											 rastreioRelacionadoId,
											 alteraOcupacaoEndereco,
											 null,
											 false,
											 estoqueAtributos);
	}

	public MovimentoEstoque efetuarSaidaSaldoParcial(Produto produto, // NOSONAR
													 SKU sku,
													 BigDecimal quantidade,
													 Origem origem,
													 MovimentoEstoqueId movimentoEstoqueId,
													 MovimentoEstoqueId movimentoEstoqueRelacionadoId,
													 RastreioId rastreioRelacionadoId,
													 boolean alteraOcupacaoEndereco,
													 BloqueioMovimentacaoEstoqueId bloqueioMovimentacaoEstoqueId,
													 boolean desvincularBloqueioMovimentacao,
													 List<EstoqueAtributoSaldo> estoqueAtributos) {

		validarInformacoesParaSaida(produto, sku, quantidade, bloqueioMovimentacaoEstoqueId, estoqueAtributos);

		validarEstoqueBloqueadoComChaveAcesso();

		var movimentoEstoque = processarSaida(quantidade,
											  origem,
											  null,
											  movimentoEstoqueId,
											  movimentoEstoqueRelacionadoId,
											  rastreioRelacionadoId,
											  alteraOcupacaoEndereco,
											  estoqueAtributos);

		if (bloqueioMovimentacaoEstoqueId != null && desvincularBloqueioMovimentacao)
			this.bloqueiosMovimentacaoEstoque.removeIf(bloqueio -> bloqueio.getBloqueioMovimentacaoEstoqueId()
																		   .equals(bloqueioMovimentacaoEstoqueId));

		return movimentoEstoque;

	}

	public MovimentoEstoque efetuarSaidaSaldoParcialDesvinculandoReserva(ReservaDefinitivaEstoque reserva, // NOSONAR
																		 Produto produto,
																		 SKU sku,
																		 BigDecimal quantidade,
																		 Origem origem,
																		 MovimentoEstoqueId movimentoEstoqueId,
																		 MovimentoEstoqueId movimentoEstoqueRelacionadoId,
																		 RastreioId rastreioRelacionadoId,
																		 boolean alteraOcupacaoEndereco,
																		 BloqueioMovimentacaoEstoque bloqueioMovimentacaoEstoque,
																		 boolean desvincularBloqueioMovimentacao,
																		 List<EstoqueAtributoSaldo> estoqueAtributos) {

		excluirReservaDoSaldo(reserva, bloqueioMovimentacaoEstoque);

		return efetuarSaidaSaldoParcial(produto,
										sku,
										quantidade,
										origem,
										movimentoEstoqueId,
										movimentoEstoqueRelacionadoId,
										rastreioRelacionadoId,
										alteraOcupacaoEndereco,
										bloqueioMovimentacaoEstoque != null ? bloqueioMovimentacaoEstoque.getId()
												: null,
										desvincularBloqueioMovimentacao,
										estoqueAtributos);

	}

	public MovimentoEstoque efetuarSaidaSaldoTotal(Origem origem,
												   MovimentoEstoqueId movimentoEstoqueId,
												   MovimentoEstoqueId movimentoEstoqueRelacionadoId,
												   RastreioId rastreioRelacionadoId,
												   boolean alteraOcupacaoEndereco) {

		validarInformacoesParaRelacionamento(movimentoEstoqueId, movimentoEstoqueRelacionadoId, rastreioRelacionadoId);

		validarSaldoSuficienteParaSaida(this.getSaldo(), this.getAtributosSaldo());

		validarEstoqueBloqueadoComChaveAcesso();

		validarBloqueioMovimentacaoEstoque(null, this.getSaldo());

		validarBloqueioMovimentacaoUnitizador();

		return processarSaida(this.getSaldo(),
							  origem,
							  null,
							  movimentoEstoqueId,
							  movimentoEstoqueRelacionadoId,
							  rastreioRelacionadoId,
							  alteraOcupacaoEndereco,
							  this.getAtributosSaldo());

	}

	public MovimentoEstoque efetuarSaidaAlteracaoEstoque(Origem origem, // NOSONAR
														 Produto produto,
														 SKU sku,
														 BigDecimal quantidade,
														 @NonNull List<ReservaDefinitivaEstoque> reservasDefinitivas,
														 MovimentoEstoqueId movimentoEstoqueId,
														 MovimentoEstoqueId movimentoEstoqueRelacionadoId,
														 RastreioId rastreioRelacionadoId,
														 boolean alteraOcupacaoEndereco,
														 List<EstoqueAtributoSaldo> estoqueAtributos) {

		validarInformacoesBasicas(produto, sku, quantidade, false, estoqueAtributos);

		validarInformacoesParaRelacionamento(movimentoEstoqueId, movimentoEstoqueRelacionadoId, rastreioRelacionadoId);

		validarEstoqueBloqueadoComChaveAcesso();

		validarReservasPertencemBloqueioMovimentacaoEstoque(reservasDefinitivas, null);

		validarSaldoSuficienteParaSaidaDescontandoReservas(quantidade, reservasDefinitivas, estoqueAtributos, null);

		var movimentoEstoque = processarSaida(quantidade,
											  origem,
											  null,
											  movimentoEstoqueId,
											  movimentoEstoqueRelacionadoId,
											  rastreioRelacionadoId,
											  alteraOcupacaoEndereco,
											  estoqueAtributos);

		reservasDefinitivas.forEach(this::exclusaoReservaDefinitivaDoSaldo);

		return movimentoEstoque;
	}

	public MovimentoEstoque efetuarSaidaTransferencia(Produto produto, // NOSONAR
													  SKU sku,
													  Origem origem,
													  BigDecimal quantidade,
													  BloqueioMovimentacaoEstoqueId bloqueioMovimentacaoEstoqueId,
													  BloqueioMovimentacaoUnitizadorId bloqueioMovimentacaoUnitizadorId,
													  @NonNull List<ReservaDefinitivaEstoque> reservasDefinitivas,
													  MovimentoEstoqueId movimentoEstoqueId,
													  MovimentoEstoqueId movimentoEstoqueRelacionadoId,
													  RastreioId rastreioRelacionadoId,
													  Endereco endereco,
													  boolean alteraOcupacaoEndereco,
													  List<EstoqueAtributoSaldo> estoqueAtributos) {
		return this.efetuarSaidaTransferencia(produto,
											  sku,
											  origem,
											  quantidade,
											  bloqueioMovimentacaoEstoqueId,
											  bloqueioMovimentacaoUnitizadorId,
											  reservasDefinitivas,
											  movimentoEstoqueId,
											  movimentoEstoqueRelacionadoId,
											  rastreioRelacionadoId,
											  endereco,
											  alteraOcupacaoEndereco,
											  null,
											  estoqueAtributos);
	}

	public MovimentoEstoque efetuarSaidaTransferencia(Produto produto, // NOSONAR
													  SKU sku,
													  Origem origem,
													  BigDecimal quantidade,
													  BloqueioMovimentacaoEstoqueId bloqueioMovimentacaoEstoqueId,
													  BloqueioMovimentacaoUnitizadorId bloqueioMovimentacaoUnitizadorId,
													  @NonNull List<ReservaDefinitivaEstoque> reservasDefinitivas,
													  MovimentoEstoqueId movimentoEstoqueId,
													  MovimentoEstoqueId movimentoEstoqueRelacionadoId,
													  RastreioId rastreioRelacionadoId,
													  Endereco endereco,
													  boolean alteraOcupacaoEndereco,
													  String chaveAcesso,
													  List<EstoqueAtributoSaldo> estoqueAtributos) {

		validarInformacoesBasicas(produto, sku, quantidade, false, estoqueAtributos);

		validarInformacoesParaRelacionamento(movimentoEstoqueId, movimentoEstoqueRelacionadoId, rastreioRelacionadoId);

		validarSaldoSuficienteParaSaidaDescontandoReservas(quantidade,
														   reservasDefinitivas,
														   estoqueAtributos,
														   bloqueioMovimentacaoEstoqueId);

		validarSeEnderecoBloqueadoParaSaidaOuEntradaSaida(endereco);

		validarEstoqueBloqueadoComChaveAcesso(chaveAcesso);

		validarTransferenciaComReserva(reservasDefinitivas);

		validarBloqueioMovimentacaoEstoque(bloqueioMovimentacaoEstoqueId, quantidade);

		validarBloqueioMovimentacaoUnitizadorDiferente(bloqueioMovimentacaoUnitizadorId);

		validarReservasPertencemBloqueioMovimentacaoEstoque(reservasDefinitivas, bloqueioMovimentacaoEstoqueId);

		var movimentoEstoque = processarSaida(quantidade,
											  origem,
											  null,
											  movimentoEstoqueId,
											  movimentoEstoqueRelacionadoId,
											  rastreioRelacionadoId,
											  alteraOcupacaoEndereco,
											  estoqueAtributos);

		reservasDefinitivas.forEach(this::exclusaoReservaDefinitivaDoSaldo);

		this.bloqueiosMovimentacaoEstoque.removeIf(bloqueio -> bloqueio.getBloqueioMovimentacaoEstoqueId()
																	   .equals(bloqueioMovimentacaoEstoqueId));

		return movimentoEstoque;
	}

	public MovimentoEstoque efetuarEntradaTransferencia(Origem origem, // NOSONAR
														Endereco endereco,
														BigDecimal quantidade,
														@NonNull Iterable<ReservaDefinitivaEstoque> reservasDefinitivas,
														MovimentoEstoqueId movimentoEstoqueId,
														MovimentoEstoqueId movimentoEstoqueRelacionadoId,
														RastreioId rastreioRelacionadoId,
														boolean alteraOcupacaoEndereco,
														Produto produto,
														SKU sku,
														List<EstoqueAtributoSaldo> estoqueAtributos,
														boolean manterAtributosReserva) {

		validarInformacoesParaRelacionamento(movimentoEstoqueId, movimentoEstoqueRelacionadoId, rastreioRelacionadoId);

		validarInformacoesBasicas(produto, sku, quantidade, false, estoqueAtributos);

		validarSeEnderecoBloqueadoParaEntradaOuEntradaSaida(endereco);

		validarSeOcupacaoEnderecoPermiteEntrada(sku, quantidade, endereco, alteraOcupacaoEndereco);

		var movimentoEstoque = processarEntrada(quantidade,
												origem,
												null,
												movimentoEstoqueId,
												movimentoEstoqueRelacionadoId,
												rastreioRelacionadoId,
												alteraOcupacaoEndereco,
												estoqueAtributos);

		reservasDefinitivas.forEach(reservaDefinitiva -> adicionarReservaNoSaldo(reservaDefinitiva,
																				 manterAtributosReserva
																						 ? estoqueAtributos
																						 : null));

		return movimentoEstoque;
	}

	public MovimentoEstoque efetuarSaidaBloqueio(Produto produto, // NOSONAR
												 SKU sku,
												 BigDecimal quantidade,
												 Origem origem,
												 MovimentoEstoqueId movimentoEstoqueId,
												 MovimentoEstoqueId movimentoEstoqueRelacionadoId,
												 RastreioId rastreioRelacionadoId,
												 boolean alteraOcupacaoEndereco,
												 List<EstoqueAtributoSaldo> estoqueAtributos) {

		if (!isLiberado())
			throw new WMSSituacaoEstoqueNaoPermiteBloqueioException(getSituacaoCorrente().toString());

		validarInformacoesParaRelacionamento(movimentoEstoqueId, movimentoEstoqueRelacionadoId, rastreioRelacionadoId);

		validarInformacoesParaSaida(produto, sku, quantidade, estoqueAtributos);

		return processarSaida(quantidade,
							  origem,
							  null,
							  movimentoEstoqueId,
							  movimentoEstoqueRelacionadoId,
							  rastreioRelacionadoId,
							  alteraOcupacaoEndereco,
							  estoqueAtributos);

	}

	public MovimentoEstoque efetuarSaidaDesbloqueio(Produto produto, // NOSONAR
													SKU sku,
													BigDecimal quantidade,
													String chave,
													Origem origem,
													MovimentoEstoqueId movimentoEstoqueId,
													MovimentoEstoqueId movimentoEstoqueRelacionadoId,
													RastreioId rastreioRelacionadoId,
													boolean alteraOcupacaoEndereco,
													BloqueioMovimentacaoUnitizadorId bloqueioMovimentacaoUnitizadorId,
													List<EstoqueAtributoSaldo> estoqueAtributos) {

		if (!isBloqueado())
			throw new WMSSituacaoEstoqueNaoPermiteDesbloqueioException(getSituacaoCorrente().toString());

		validarInformacoesParaRelacionamento(movimentoEstoqueId, movimentoEstoqueRelacionadoId, rastreioRelacionadoId);

		validarChaveAcesso(chave);

		validarInformacoesParaSaida(produto, sku, quantidade, bloqueioMovimentacaoUnitizadorId, estoqueAtributos);

		return processarSaida(quantidade,
							  origem,
							  null,
							  movimentoEstoqueId,
							  movimentoEstoqueRelacionadoId,
							  rastreioRelacionadoId,
							  alteraOcupacaoEndereco,
							  estoqueAtributos);

	}

	public ReservaDefinitivaEstoque adicionarReservaDefinitiva(SKU sku, // NOSONAR
															   BigDecimal quantidade,
															   Origem origem,
															   BloqueioMovimentacaoEstoque bloqueioMovimentacaoEstoque,
															   boolean permitirParcialSku,
															   Endereco endereco,
															   List<EstoqueAtributoSaldo> estoqueAtributos,
															   Produto produto) {
		return this.adicionarReservaDefinitiva(ReservaDefinitivaEstoqueId.generate(),
											   sku,
											   quantidade,
											   origem,
											   bloqueioMovimentacaoEstoque,
											   permitirParcialSku,
											   endereco,
											   false,
											   true,
											   estoqueAtributos,
											   produto);

	}

	public ReservaDefinitivaEstoque adicionarReservaDefinitiva(ReservaDefinitivaEstoqueId reservaDefinitivaEstoqueId, // NOSONAR
															   SKU sku,
															   BigDecimal quantidade,
															   Origem origem,
															   BloqueioMovimentacaoEstoque bloqueioMovimentacaoEstoque,
															   boolean permitirParcialSku,
															   Endereco endereco,
															   boolean vincularBloqueioMovimentacao,
															   boolean registrarEvento,
															   List<EstoqueAtributoSaldo> estoqueAtributos,
															   Produto produto) {

		if (this.isBloqueado())
			throw new WMSEstoqueBloqueadoNaoPodeGerarReservaException();

		validarSeEnderecoBloqueadoParaSaidaOuEntradaSaida(endereco);

		validarSku(sku);

		validarQuantidade(sku, quantidade, permitirParcialSku, false, true, estoqueAtributos);

		validarBloqueioMovimentacaoUnitizador();

		validarSaldoTotalmenteReservado(estoqueAtributos);

		validarSaldoSuficienteParaAdicionarReserva(sku, quantidade, bloqueioMovimentacaoEstoque, estoqueAtributos);

		var reserva = ReservaDefinitivaEstoque.builder()
											  .id(reservaDefinitivaEstoqueId)
											  .origem(origem)
											  .quantidade(quantidade)
											  .estoqueId(this.id)
											  .build();

		adicionarReservaNoSaldo(reserva, estoqueAtributos);

		if (bloqueioMovimentacaoEstoque != null) {
			if (vincularBloqueioMovimentacao) {
				atualizarEstoqueReservaDefinitivaNoBloqueioMovimentacaoEstoque(bloqueioMovimentacaoEstoque,
																			   reserva,
																			   estoqueAtributos,
																			   produto);
			} else {
				adicionarReservaDefinitivaNoBloqueioMovimentacaoEstoque(bloqueioMovimentacaoEstoque,
																		reserva,
																		estoqueAtributos);
			}
		}

		if (registrarEvento)
			this.registerEvent(GeracaoReservaDefinitivaEstoqueEfetuadaEvent.from(reserva, this));

		return reserva;
	}

	private void atualizarEstoqueReservaDefinitivaNoBloqueioMovimentacaoEstoque(BloqueioMovimentacaoEstoque bloqueioMovimentacaoEstoque,
																				ReservaDefinitivaEstoque reserva,
																				List<EstoqueAtributoSaldo> estoqueAtributos,
																				Produto produto) {
		bloqueioMovimentacaoEstoque.atualizar(id, reserva.getQuantidade(), reserva, estoqueAtributos);

		this.executarBloqueioMovimentacaoEstoque(bloqueioMovimentacaoEstoque, produto, estoqueAtributos);

		this.getBloqueioMovimentacaoEstoqueById(bloqueioMovimentacaoEstoque.getId())
			.adicionarReservaDefinitivaEstoque(reserva, estoqueAtributos);
	}

	private void adicionarReservaDefinitivaNoBloqueioMovimentacaoEstoque(BloqueioMovimentacaoEstoque bloqueioMovimentacaoEstoque,
																		 ReservaDefinitivaEstoque reserva,
																		 List<EstoqueAtributoSaldo> estoqueAtributos) {
		bloqueioMovimentacaoEstoque.adicionarReservaDefinitivaEstoque(reserva, estoqueAtributos);

		this.getBloqueioMovimentacaoEstoqueById(bloqueioMovimentacaoEstoque.getId())
			.adicionarReservaDefinitivaEstoque(reserva, estoqueAtributos);
	}

	private EstoqueBloqueioMovimentacao getBloqueioMovimentacaoEstoqueById(BloqueioMovimentacaoEstoqueId id) {
		return this.bloqueiosMovimentacaoEstoque.stream()
												.filter(bloqueio -> bloqueio.getBloqueioMovimentacaoEstoqueId()
																			.equals(id))
												.findFirst()
												.orElseThrow();
	}

	public Optional<EstoqueBloqueioMovimentacao> getBloqueioMovimentacaoEstoqueByReservaDefinitivaEstoqueId(ReservaDefinitivaEstoqueId id) {
		return this.bloqueiosMovimentacaoEstoque.stream()
												.filter(bloqueio -> bloqueio.getReservasDefinitivas()
																			.stream()
																			.anyMatch(reserva -> reserva.getReservaDefinitivaEstoqueId()
																										.equals(id)))
												.findFirst();

	}

	public void removerReservaDefinitiva(ReservaDefinitivaEstoque reserva,
										 BloqueioMovimentacaoEstoque bloqueioMovimentacaoEstoque) {
		this.removerReservaDefinitiva(reserva, bloqueioMovimentacaoEstoque, false, true);
	}

	public void removerReservaDefinitiva(ReservaDefinitivaEstoque reserva,
										 BloqueioMovimentacaoEstoque bloqueioMovimentacaoEstoque,
										 boolean desvincularBloqueioMovimentacao,
										 boolean registrarEvento) {

		var estoqueReserva = this.excluirReservaDoSaldo(reserva, bloqueioMovimentacaoEstoque);

		if (bloqueioMovimentacaoEstoque != null && desvincularBloqueioMovimentacao) {
			this.bloqueiosMovimentacaoEstoque.removeIf(bloqueio -> bloqueio.getBloqueioMovimentacaoEstoqueId()
																		   .equals(bloqueioMovimentacaoEstoque.getId()));
		}

		if (registrarEvento)
			this.registerEvent(ExclusaoReservaDefinitivaEstoqueEfetuadaEvent.from(reserva, this, estoqueReserva));

	}

	private EstoqueReservaDefinitiva excluirReservaDoSaldo(ReservaDefinitivaEstoque reservaDefinitiva,
														   BloqueioMovimentacaoEstoque bloqueioMovimentacaoEstoque) {

		if (!reservaDefinitiva.podeSerExcluidaOuAlterada())
			throw new WMSReservaDefinitivaEstoqueNaoPodeSerExcluidaException();

		validarReserva(reservaDefinitiva);

		validarRelacionamentoReservaDefinitivaEstoqueBloqueioMovimentacaoEstoque(reservaDefinitiva,
																				 bloqueioMovimentacaoEstoque);

		var estoqueReserva = this.getReserva(reservaDefinitiva.getId());

		exclusaoReservaDefinitivaDoSaldo(reservaDefinitiva);

		if (bloqueioMovimentacaoEstoque != null) {
			excluirReservaDefinitivaDoBloqueioMovimentacaoEstoque(bloqueioMovimentacaoEstoque, reservaDefinitiva);
		}

		return estoqueReserva;

	}

	private void excluirReservaDefinitivaDoBloqueioMovimentacaoEstoque(BloqueioMovimentacaoEstoque bloqueioMovimentacaoEstoque,
																	   ReservaDefinitivaEstoque reserva) {

		bloqueioMovimentacaoEstoque.removerReservaDefinitivaEstoque(reserva);

		this.getBloqueioMovimentacaoEstoqueById(bloqueioMovimentacaoEstoque.getId())
			.removerReservaDefinitivaEstoque(reserva.getId());

	}

	private void validarRelacionamentoReservaDefinitivaEstoqueBloqueioMovimentacaoEstoque(ReservaDefinitivaEstoque reserva,
																						  BloqueioMovimentacaoEstoque bloqueioMovimentacaoEstoque) {
		if (bloqueioMovimentacaoEstoque != null) {
			if (!bloqueioMovimentacaoEstoque.possuiReservaDefinitivaEstoque(reserva.getId()))
				throw new WMSBloqueioMovimentacaoEstoqueNaoRelacionadoAReservaDefinitivaEstoqueException();
		} else {
			if (this.getBloqueioMovimentacaoEstoqueByReservaDefinitivaEstoqueId(reserva.getId()).isPresent())
				throw new WMSEstoqueReservaDefinitivaBloqueioMovimentacaoEstoqueNaoInformadoException();
		}
	}

	public MovimentoEstoque liquidarReservaDefinitiva(ReservaDefinitivaEstoque reserva,
													  Origem origem,
													  Endereco endereco,
													  boolean alteraOcupacaoEndereco,
													  boolean permiteDeterminarAtributos) {

		validarReserva(reserva);

		validarSeEnderecoBloqueadoParaSaidaOuEntradaSaida(endereco);

		validarBloqueioMovimentacaoEstoqueAssociadoAReserva(reserva);

		validarBloqueioMovimentacaoEstoque(null, reserva.getQuantidade());

		validarBloqueioMovimentacaoUnitizador();

		reserva.liquidar();

		var estoqueAtributos = this.getAtributosReserva(reserva.getId());

		if (!CollectionUtils.isEmpty(this.atributosSaldo) && CollectionUtils.isEmpty(estoqueAtributos)) {
			if (permiteDeterminarAtributos)
				estoqueAtributos = determinarAtributosSaldo(reserva.getQuantidade());
			else
				throw new WMSEstoqueAtributosNaoIndicadosNaMovimentacaoException();

		}

		var movimentoEstoque = this.processarSaida(reserva.getQuantidade(),
												   origem,
												   reserva.getId(),
												   null,
												   null,
												   null,
												   alteraOcupacaoEndereco,
												   estoqueAtributos);

		exclusaoReservaDefinitivaDoSaldo(reserva);

		this.registerEvent(LiquidacaoReservaDefinitivaEstoqueEfetuadaEvent.from(reserva,
																				this,
																				origem,
																				estoqueAtributos));

		return movimentoEstoque;

	}

	private void validarBloqueioMovimentacaoEstoqueAssociadoAReserva(ReservaDefinitivaEstoque reserva) {
		if (this.getBloqueioMovimentacaoEstoqueByReservaDefinitivaEstoqueId(reserva.getId()).isPresent())
			throw new WMSEstoqueBloqueioMovimentacaoRelacionadoAReservaDefinitivaEstoqueException();

	}

	public MovimentoEstoque estornarLiquidacaoReservaDefinitiva(ReservaDefinitivaEstoque reserva,
																Origem origem,
																Endereco endereco,
																boolean alteraOcupacaoEndereco,
																List<EstoqueAtributoSaldo> estoqueAtributos) {

		validarSeEnderecoBloqueadoParaEntradaOuEntradaSaida(endereco);

		validarSeFuncaoDocaStage(endereco);

		reserva.estornarLiquidacao(this.getId());

		var movimentoEstoque = processarEntrada(reserva.getQuantidade(),
												origem,
												reserva.getId(),
												null,
												null,
												null,
												alteraOcupacaoEndereco,
												estoqueAtributos);

		adicionarReservaNoSaldo(reserva, estoqueAtributos);

		this.registerEvent(EstornoLiquidacaoReservaDefinitivaEstoqueEfetuadaEvent.from(reserva, this, origem));

		return movimentoEstoque;

	}

	public void subtrairQuantidadeReservada(ReservaDefinitivaEstoque reserva, // NOSONAR
											SKU sku,
											BigDecimal quantidade,
											BloqueioMovimentacaoEstoque bloqueioMovimentacaoEstoque,
											boolean permitirParcialSku,
											boolean manterQuantidadeBloqueada,
											List<EstoqueAtributoSaldo> estoqueAtributosSubtrair,
											Produto produto) {

		if (!reserva.podeSerExcluidaOuAlterada())
			throw new WMSReservaDefinitivaEstoqueQuantidadeNaoPodeSerSubtraidaException();

		validarSku(sku);

		validarQuantidade(sku, quantidade, permitirParcialSku, false, false, estoqueAtributosSubtrair);

		var estoqueReservaExcluida = excluirReservaDoSaldo(reserva, bloqueioMovimentacaoEstoque);

		List<EstoqueAtributoSaldo> atributosBloqueio = new ArrayList<>();

		if (bloqueioMovimentacaoEstoque != null) {

			atributosBloqueio = new ArrayList<>(this.getBloqueioMovimentacaoEstoqueById(bloqueioMovimentacaoEstoque.getId())
													.getAtributosSaldo());

			excluirBloqueioMovimentacaoEstoqueDoSaldo(bloqueioMovimentacaoEstoque.getId());
		}

		reserva.subtrair(quantidade);

		var estoqueAtributosRestantes = estoqueReservaExcluida.atualizarAtributos(reserva.getQuantidade(),
																				  estoqueAtributosSubtrair);

		adicionarReservaNoSaldo(reserva, estoqueAtributosRestantes);

		if (bloqueioMovimentacaoEstoque != null) {
			bloqueioMovimentacaoEstoque.atualizar(this.id,
												  manterQuantidadeBloqueada
														  ? bloqueioMovimentacaoEstoque.getQuantidade()
														  : reserva.getQuantidade(),
												  reserva,
												  estoqueAtributosRestantes);
			executarBloqueioMovimentacaoEstoque(bloqueioMovimentacaoEstoque,
												produto,
												manterQuantidadeBloqueada ? atributosBloqueio
														: estoqueAtributosRestantes);
		}

		this.registerEvent(SubtracaoReservaDefinitivaEstoqueEfetuadaEvent.from(reserva,
																			   this,
																			   this,
																			   bloqueioMovimentacaoEstoque));

	}

	private void validarSeFuncaoDocaStage(Endereco endereco) {
		if (!endereco.isDoca() && !endereco.isStage())
			throw new WMSFuncaoEnderecoInvalidaParaEstornoException();

	}

	private MovimentoEstoque processarEntrada(BigDecimal quantidade, // NOSONAR
											  Origem origem,
											  ReservaDefinitivaEstoqueId reservaDefinitivaId,
											  MovimentoEstoqueId movimentoEstoqueId,
											  MovimentoEstoqueId movimentoEstoqueRelacionadoId,
											  RastreioId rastreioRelacionadoId,
											  boolean alteraOcupacaoEndereco,
											  List<EstoqueAtributoSaldo> estoqueAtributos) {

		somarQuantidade(quantidade);

		var estoqueAtributosMovimento = somarQuantidadeAtributos(estoqueAtributos);

		return MovimentoEstoque.builder()
							   .id(movimentoEstoqueId != null ? movimentoEstoqueId : MovimentoEstoqueId.generate())
							   .movimentoEstoqueRelacionadoId(movimentoEstoqueRelacionadoId)
							   .rastreioRelacionadoId(rastreioRelacionadoId)
							   .origem(origem)
							   .tipo(TipoMovimentoEstoque.ENTRADA)
							   .reservaDefinitivaId(reservaDefinitivaId)
							   .quantidade(quantidade)
							   .estoque(this)
							   .alteraOcupacaoEndereco(alteraOcupacaoEndereco)
							   .atributosSaldo(estoqueAtributosMovimento)
							   .build();
	}

	private MovimentoEstoque processarSaida(BigDecimal quantidade, // NOSONAR
											Origem origem,
											ReservaDefinitivaEstoqueId reservaDefinitivaId,
											MovimentoEstoqueId movimentoEstoqueId,
											MovimentoEstoqueId movimentoEstoqueRelacionadoId,
											RastreioId rastreioRelacionadoId,
											boolean alteraOcupacaoEndereco,
											List<EstoqueAtributoSaldo> estoqueAtributos) {

		subtrairQuantidade(quantidade);

		var estoqueAtributosMovimento = subtrairQuantidadeAtributos(estoqueAtributos);

		return MovimentoEstoque.builder()
							   .id(movimentoEstoqueId != null ? movimentoEstoqueId : MovimentoEstoqueId.generate())
							   .movimentoEstoqueRelacionadoId(movimentoEstoqueRelacionadoId)
							   .rastreioRelacionadoId(rastreioRelacionadoId)
							   .origem(origem)
							   .tipo(TipoMovimentoEstoque.SAIDA)
							   .reservaDefinitivaId(reservaDefinitivaId)
							   .quantidade(quantidade)
							   .estoque(this)
							   .alteraOcupacaoEndereco(alteraOcupacaoEndereco)
							   .atributosSaldo(estoqueAtributosMovimento)
							   .build();

	}

	private void somarQuantidade(BigDecimal quantidade) {
		this.saldo = this.saldo.add(quantidade);
	}

	private List<EstoqueAtributoSaldo> somarQuantidadeAtributos(List<EstoqueAtributoSaldo> estoqueAtributosSomar) {

		List<EstoqueAtributoSaldo> atributosSaldoMovimento = new ArrayList<>();

		if (!CollectionUtils.isEmpty(estoqueAtributosSomar)) {

			estoqueAtributosSomar.forEach(estoqueAtributoSomar -> { // NOSONAR
				this.atributosSaldo.stream()
								   .filter(estoqueAtributo -> estoqueAtributo.equals(estoqueAtributoSomar))
								   .findAny()
								   .ifPresentOrElse(estoqueAtributo -> {
									   var estoqueAtributoAtualizado = estoqueAtributo.somandoQuantidade(estoqueAtributoSomar.getAtributos(),
																										 estoqueAtributoSomar.getSaldo());
									   this.atributosSaldo.remove(estoqueAtributo);
									   this.atributosSaldo.add(estoqueAtributoAtualizado);

									   this.atualizarAtributoSaldoMovimento(atributosSaldoMovimento,
																			estoqueAtributoSomar);
								   }, () -> {
									   var novoAtributoSaldo = EstoqueAtributoSaldo.of(estoqueAtributoSomar.getAtributos(),
																					   estoqueAtributoSomar.getSaldo());
									   this.atributosSaldo.add(novoAtributoSaldo);
									   atributosSaldoMovimento.add(novoAtributoSaldo);
								   });
			});

		}

		return atributosSaldoMovimento;
	}

	private void atualizarAtributoSaldoMovimento(List<EstoqueAtributoSaldo> atributosSaldoMovimento,
												 EstoqueAtributoSaldo estoqueAtributoSomar) {

		atributosSaldoMovimento.stream()
							   .filter(movimentoAtributo -> movimentoAtributo.equals(estoqueAtributoSomar))
							   .findAny()
							   .ifPresentOrElse(movimentoAtributo -> {
								   atributosSaldoMovimento.remove(movimentoAtributo);
								   atributosSaldoMovimento.add(movimentoAtributo.somandoQuantidade(estoqueAtributoSomar.getAtributos(),
																								   estoqueAtributoSomar.getSaldo()));
							   }, () -> { // NOSONAR
								   atributosSaldoMovimento.add(EstoqueAtributoSaldo.of(estoqueAtributoSomar.getAtributos(),
																					   estoqueAtributoSomar.getSaldo()));
							   });

	}

	private void subtrairQuantidade(BigDecimal quantidade) {
		this.saldo = this.saldo.subtract(quantidade);
	}

	private List<EstoqueAtributoSaldo> subtrairQuantidadeAtributos(List<EstoqueAtributoSaldo> estoqueAtributosSubtrair) {

		List<EstoqueAtributoSaldo> atributosSaldoMovimento = new ArrayList<>();

		if (!CollectionUtils.isEmpty(estoqueAtributosSubtrair))
			estoqueAtributosSubtrair.forEach(estoqueAtributoSubtrair -> { // NOSONAR
				atributosSaldoMovimento.add(EstoqueAtributoSaldo.of(estoqueAtributoSubtrair.getAtributos(),
																	estoqueAtributoSubtrair.getSaldo()));
			});

		List<EstoqueAtributoSaldo> estoqueAtributosRestantes = new ArrayList<>();
		estoqueAtributosRestantes.addAll(this.atributosSaldo);

		if (!CollectionUtils.isEmpty(estoqueAtributosSubtrair)) {

			estoqueAtributosSubtrair.forEach(estoqueAtributoSubtrair -> { // NOSONAR
				this.atributosSaldo.stream()
								   .filter(estoqueAtributo -> estoqueAtributo.equals(estoqueAtributoSubtrair))
								   .findAny()
								   .ifPresent(estoqueAtributo -> {
									   if (CompareUtils.lessThan(estoqueAtributoSubtrair.getSaldo(),
																 estoqueAtributo.getSaldo())) {
										   estoqueAtributosRestantes.remove(estoqueAtributo);
										   estoqueAtributosRestantes.add(estoqueAtributo.subtraindoQuantidade(estoqueAtributoSubtrair.getAtributos(),
																											  estoqueAtributoSubtrair.getSaldo()));
									   } else {
										   estoqueAtributosRestantes.remove(estoqueAtributoSubtrair);
									   }
								   });
			});

		}

		this.atributosSaldo.clear();
		this.atributosSaldo.addAll(estoqueAtributosRestantes);

		return atributosSaldoMovimento;
	}

	public BigDecimal getQuantidadeReservada() {
		return reservasDefinitivas.stream()
								  .map(EstoqueReservaDefinitiva::getQuantidade)
								  .reduce(BigDecimal.ZERO, BigDecimal::add);
	}

	private BigDecimal getQuantidadeReservada(EstoqueAtributoSaldo estoqueAtributo) {
		return reservasDefinitivas.stream()
								  .map(reservaDefinitiva -> reservaDefinitiva.getQuantidadeReservadaAtributo(estoqueAtributo))
								  .reduce(BigDecimal.ZERO, BigDecimal::add);
	}

	public BigDecimal getSaldoDisponivel() {
		return this.saldo.subtract(this.getQuantidadeReservada());
	}

	public SituacaoEstoqueValor getSituacaoCorrente() {
		return situacoes.iterator().next().getSituacaoEstoque();
	}

	public boolean isBloqueado() {
		return getSituacaoCorrente().equals(SituacaoEstoqueValor.BLOQUEADO);
	}

	private boolean isLiberado() {
		return getSituacaoCorrente().equals(SituacaoEstoqueValor.LIBERADO);
	}

	public Set<EstoqueReservaDefinitiva> getReservasDefinitivas() {
		return com.totvs.tjf.core.common.CollectionUtils.unmodifiable(this.reservasDefinitivas);
	}

	public List<CaracteristicaValor<?>> getCaracteristicas() { // NOSONAR
		return com.totvs.tjf.core.common.CollectionUtils.unmodifiable(this.caracteristicas);
	}

	public BloqueioMovimentacaoEstoque bloquearMovimentacaoEstoque(SKU sku, // NOSONAR
																   @NonNull Origem origem,
																   @NonNull BigDecimal quantidade,
																   ReservaDefinitivaEstoqueId reservaDefinitivaEstoqueId,
																   Endereco enderecoDestino,
																   UnitizadorId unitizadorIdDestino,
																   Produto produto,
																   List<EstoqueAtributoSaldo> atributosSaldo) {

		if (Objects.nonNull(enderecoDestino))
			validarSeEnderecoBloqueadoParaEntradaOuEntradaSaida(enderecoDestino);

		validarSku(sku);

		validarQuantidade(sku, quantidade, false, false, true, atributosSaldo);

		validarInformacoesBloqueioMovimentacaoEstoque(quantidade, reservaDefinitivaEstoqueId, atributosSaldo);

		validarEstoqueBloqueadoComChaveAcesso();

		Collection<EstoqueReservaDefinitiva> reservasDefinitivasBloqueio = (reservaDefinitivaEstoqueId != null)
				? Set.of(EstoqueReservaDefinitiva.builder()
												 .reservaDefinitivaEstoqueId(reservaDefinitivaEstoqueId)
												 .quantidade(quantidade)
												 .atributos(atributosSaldo)
												 .build())
				: Set.of();

		var bloqueioMovimentacaoEstoque = BloqueioMovimentacaoEstoque.builder()
																	 .id(BloqueioMovimentacaoEstoqueId.generate())
																	 .enderecoIdDestino(Objects.nonNull(enderecoDestino)
																			 ? enderecoDestino.getId()
																			 : null)
																	 .unitizadorIdDestino(unitizadorIdDestino)
																	 .quantidade(quantidade)
																	 .origem(origem)
																	 .reservasDefinitivas(reservasDefinitivasBloqueio)
																	 .estoque(this)
																	 .produto(produto)
																	 .build();

		executarBloqueioMovimentacaoEstoque(bloqueioMovimentacaoEstoque, produto, atributosSaldo);

		this.registerEvent(EstoqueBloqueioMovimentacaoEfetuadoEvent.of(this, bloqueioMovimentacaoEstoque));

		return bloqueioMovimentacaoEstoque;

	}

	private void executarBloqueioMovimentacaoEstoque(BloqueioMovimentacaoEstoque bloqueioMovimentacaoEstoque,
													 Produto produto,
													 List<EstoqueAtributoSaldo> atributosSaldo) {

		var estoqueBloqueioMovimentacao = EstoqueBloqueioMovimentacao.of(bloqueioMovimentacaoEstoque.getId(),
																		 bloqueioMovimentacaoEstoque.getQuantidade(),
																		 bloqueioMovimentacaoEstoque.getReservasDefinitivas(),
																		 produto,
																		 atributosSaldo);

		this.bloqueiosMovimentacaoEstoque.add(estoqueBloqueioMovimentacao);

	}

	private void validarInformacoesBloqueioMovimentacaoEstoque(BigDecimal quantidade,
															   ReservaDefinitivaEstoqueId reservaDefinitivaEstoqueId,
															   List<EstoqueAtributoSaldo> atributosSaldo) {

		if (reservaDefinitivaEstoqueId != null) {
			validarPresencaReservaDefinitiva(reservaDefinitivaEstoqueId, quantidade);

			validarPresencaBloqueioJaRealizado(reservaDefinitivaEstoqueId);
		}

		validarBloqueioMovimentacaoUnitizador();

		validarSaldoDisponivelParaBloqueioMovimentacaoEstoque(quantidade, reservaDefinitivaEstoqueId);

		validarAtributosBloqueioMovimentacao(atributosSaldo);
	}

	private void validarSaldoDisponivelParaBloqueioMovimentacaoEstoque(BigDecimal quantidade,
																	   ReservaDefinitivaEstoqueId reservaDefinitivaEstoqueId) {

		var saldoDisponivelParaBloqueio = this.getSaldo()
											  .subtract(this.getQuantidadeBloqueadaParaMovimentacaoEstoqueNaoReservada()
															.add(this.getQuantidadeTotalReservadaDescontandoAReserva(reservaDefinitivaEstoqueId)));

		if (CompareUtils.lessThan(saldoDisponivelParaBloqueio, quantidade)) {
			throw new WMSEstoqueBloqueioMovimentacaoEstoqueNaoRealizadoQuantidadeNaoDeveSerSuperiorSaldoDisponivelParaBloqueioException(saldoDisponivelParaBloqueio.toString());
		}
	}

	private BigDecimal getQuantidadeTotalReservadaDescontandoAReserva(ReservaDefinitivaEstoqueId reservaDefinitivaEstoqueId) {
		return this.reservasDefinitivas.stream()
									   .filter(reserva -> !reserva.getReservaDefinitivaEstoqueId()
																  .equals(reservaDefinitivaEstoqueId))
									   .map(EstoqueReservaDefinitiva::getQuantidade)
									   .reduce(BigDecimal.ZERO, BigDecimal::add);
	}

	public BigDecimal getQuantidadeBloqueadaParaMovimentacaoEstoqueReservada() {
		return this.getBloqueioMovimentacaoUnitizadorId().isEmpty()
				? this.bloqueiosMovimentacaoEstoque.stream()
												   .map(EstoqueBloqueioMovimentacao::getQuantidadeReservada)
												   .reduce(BigDecimal.ZERO, BigDecimal::add)
				: this.getQuantidadeReservada();
	}

	public BigDecimal getQuantidadeBloqueadaParaMovimentacaoEstoqueNaoReservada() {
		return this.getBloqueioMovimentacaoUnitizadorId().isEmpty()
				? this.bloqueiosMovimentacaoEstoque.stream()
												   .map(EstoqueBloqueioMovimentacao::getQuantidadeNaoReservada)
												   .reduce(BigDecimal.ZERO, BigDecimal::add)
				: this.getSaldoDisponivel();
	}

	public BigDecimal getQuantidadeBloqueadaParaMovimentacaoEstoqueTotal() {
		return this.getBloqueioMovimentacaoUnitizadorId().isEmpty()
				? this.bloqueiosMovimentacaoEstoque.stream()
												   .map(EstoqueBloqueioMovimentacao::getQuantidade)
												   .reduce(BigDecimal.ZERO, BigDecimal::add)
				: this.getSaldo();
	}

	public BigDecimal getSaldoDisponivelDescontandoBloqueioMovimentacaoNaoReservado() {
		return this.getSaldoDisponivel().subtract(this.getQuantidadeBloqueadaParaMovimentacaoEstoqueNaoReservada());
	}

	private void validarPresencaBloqueioJaRealizado(ReservaDefinitivaEstoqueId reservaDefinitivaEstoqueId) {
		if (this.bloqueiosMovimentacaoEstoque.stream()
											 .flatMap(bloqueio -> bloqueio.getReservasDefinitivas().stream())
											 .anyMatch(reserva -> reserva.getReservaDefinitivaEstoqueId()
																		 .equals(reservaDefinitivaEstoqueId))) {
			throw new WMSEstoqueBloqueioMovimentacaoEstoqueNaoRealizadoReservaJaRegistradaException();
		}
	}

	private void validarPresencaReservaDefinitiva(ReservaDefinitivaEstoqueId reservaDefinitivaEstoqueId,
												  BigDecimal quantidade) {

		var reservaDefinitiva = this.reservasDefinitivas.stream()
														.filter(reserva -> reserva.getReservaDefinitivaEstoqueId()
																				  .equals(reservaDefinitivaEstoqueId))
														.findFirst();
		if (reservaDefinitiva.isEmpty()) {
			throw new WMSEstoqueBloqueioMovimentacaoEstoqueNaoRealizadoReservaNaoEncontradaException();
		} else {
			if (!CompareUtils.equalTo(reservaDefinitiva.get().getQuantidade(), quantidade)) {
				throw new WMSEstoqueBloqueioMovimentacaoEstoqueNaoRealizadoQuantidadeReservaInvalidaException();
			}
		}
	}

	public void desbloquearMovimentacaoEstoque(BloqueioMovimentacaoEstoqueId bloqueioMovimentacaoEstoqueId) {

		excluirBloqueioMovimentacaoEstoqueDoSaldo(bloqueioMovimentacaoEstoqueId);

		this.registerEvent(EstoqueDesbloqueioMovimentacaoEfetuadoEvent.of(this, bloqueioMovimentacaoEstoqueId));

	}

	private void excluirBloqueioMovimentacaoEstoqueDoSaldo(BloqueioMovimentacaoEstoqueId bloqueioMovimentacaoEstoqueId) {

		if (this.bloqueiosMovimentacaoEstoque.stream()
											 .noneMatch(bloqueio -> bloqueio.getBloqueioMovimentacaoEstoqueId()
																			.equals(bloqueioMovimentacaoEstoqueId))) {
			throw new WMSEstoqueDesbloquearMovimentacaoEstoqueRegistroNaoEncontradaException();
		}

		this.bloqueiosMovimentacaoEstoque.removeIf(bloqueio -> bloqueio.getBloqueioMovimentacaoEstoqueId()
																	   .equals(bloqueioMovimentacaoEstoqueId));

	}

	public void bloquearMovimentacaoUnitizador(BloqueioMovimentacaoUnitizadorId bloqueioMovimentacaoUnitizadorId) {
		bloquearMovimentacaoUnitizador(bloqueioMovimentacaoUnitizadorId, null);
	}

	public void bloquearMovimentacaoUnitizador(BloqueioMovimentacaoUnitizadorId bloqueioMovimentacaoUnitizadorId,
											   String chaveAcesso) {

		this.validarBloqueioMovimentacaoUnitizadorDiferente(bloqueioMovimentacaoUnitizadorId);

		this.validarBloqueioMovimentacaoEstoque(null, this.saldo);

		if (Objects.isNull(chaveAcesso))
			validarEstoqueBloqueadoComChaveAcesso();
		else
			validarEstoqueBloqueadoComChaveAcesso(chaveAcesso);

		this.bloqueioMovimentacaoUnitizadorId = bloqueioMovimentacaoUnitizadorId;
	}

	public void desbloquearMovimentacaoUnitizador(BloqueioMovimentacaoUnitizadorId bloqueioMovimentacaoUnitizadorId) {

		if (!this.bloqueioMovimentacaoUnitizadorId.equals(bloqueioMovimentacaoUnitizadorId))
			throw new WMSBloqueioMovimentacaoUnitizadorIdDiferenteDoEstoqueException();

		this.bloqueioMovimentacaoUnitizadorId = null;
	}

	private void validarBloqueioMovimentacaoUnitizador() {
		if (!this.getBloqueioMovimentacaoUnitizadorId().isEmpty())
			throw new WMSEstoqueBloqueadoPorUnitizadorException();
	}

	private void validarBloqueioMovimentacaoUnitizadorDiferente(BloqueioMovimentacaoUnitizadorId bloqueioMovimentacaoUnitizadorId) {
		if (this.getBloqueioMovimentacaoUnitizadorId().isPresent()
				&& !this.bloqueioMovimentacaoUnitizadorId.equals(bloqueioMovimentacaoUnitizadorId)) {
			throw new WMSEstoqueBloqueadoPorUnitizadorException();
		}
	}

	private void validarBloqueioMovimentacaoEstoque(BloqueioMovimentacaoEstoqueId bloqueioMovimentacaoEstoqueId,
													BigDecimal quantidade) {

		if ((bloqueioMovimentacaoEstoqueId != null)
				&& this.bloqueiosMovimentacaoEstoque.stream()
													.noneMatch(bloqueio -> bloqueio.getBloqueioMovimentacaoEstoqueId()
																				   .equals(bloqueioMovimentacaoEstoqueId)))
			throw new WMSEstoqueBloqueioMovimentacaoEstoqueNaoEncontradoException();

		var saldoBloqueado = bloqueiosMovimentacaoEstoque.stream()
														 .filter(bloqueio -> !bloqueio.getBloqueioMovimentacaoEstoqueId()
																					  .equals(bloqueioMovimentacaoEstoqueId))
														 .map(EstoqueBloqueioMovimentacao::getQuantidade)
														 .reduce(BigDecimal.ZERO, BigDecimal::add);

		var disponivelSaida = this.saldo.subtract(saldoBloqueado);
		var resultado = disponivelSaida.subtract(quantidade);

		if (CompareUtils.lessThan(resultado, BigDecimal.ZERO))
			throw new WMSEstoqueBloqueadoParaMovimentacaoPorEstoqueException(this.saldo,
																			 saldoBloqueado,
																			 disponivelSaida,
																			 quantidade);

	}

	private void registrarEstoqueEntradaEfetuadaEvent(MovimentoEstoque movimentoEstoque) {
		if (this.getSituacaoCorrente().equals(SituacaoEstoqueValor.LIBERADO))
			this.registerEvent(EstoqueLiberadoEntradaEfetuadaEvent.from(this, movimentoEstoque));
		else
			this.registerEvent(EstoqueBloqueadoEntradaEfetuadaEvent.from(this, movimentoEstoque));
	}

	private void validarInformacoesBasicas(Produto produto,
										   SKU sku,
										   BigDecimal quantidade,
										   boolean ehSaldoInicial,
										   List<EstoqueAtributoSaldo> estoqueAtributos) {

		validarProduto(produto);

		validarSku(sku);

		validarQuantidade(sku, quantidade, false, ehSaldoInicial, false, estoqueAtributos);

		produto.validarIntegridadeCaracteristicas(this.caracteristicas);

		if (!CompareUtils.equalTo(quantidade, BigDecimal.ZERO))
			produto.validarIntegridadeAtributos(estoqueAtributos);

	}

	private void validarInformacoesParaSaida(Produto produto,
											 SKU sku,
											 BigDecimal quantidade,
											 List<EstoqueAtributoSaldo> estoqueAtributos) {
		validarInformacoesParaSaida(produto, sku, quantidade, null, null, estoqueAtributos);
	}

	private void validarInformacoesParaSaida(Produto produto,
											 SKU sku,
											 BigDecimal quantidade,
											 BloqueioMovimentacaoUnitizadorId bloqueioMovimentacaoUnitizadorId,
											 List<EstoqueAtributoSaldo> estoqueAtributos) {
		validarInformacoesParaSaida(produto, sku, quantidade, null, bloqueioMovimentacaoUnitizadorId, estoqueAtributos);
	}

	private void validarInformacoesParaSaida(Produto produto,
											 SKU sku,
											 BigDecimal quantidade,
											 BloqueioMovimentacaoEstoqueId bloqueioMovimentacaoEstoqueId,
											 List<EstoqueAtributoSaldo> estoqueAtributos) {
		validarInformacoesParaSaida(produto, sku, quantidade, bloqueioMovimentacaoEstoqueId, null, estoqueAtributos);
	}

	private void validarInformacoesParaSaida(Produto produto,
											 SKU sku,
											 BigDecimal quantidade,
											 BloqueioMovimentacaoEstoqueId bloqueioMovimentacaoEstoqueId,
											 BloqueioMovimentacaoUnitizadorId bloqueioMovimentacaoUnitizadorId,
											 List<EstoqueAtributoSaldo> estoqueAtributos) {

		validarInformacoesBasicas(produto, sku, quantidade, false, estoqueAtributos);

		validarSaldoSuficienteParaSaida(quantidade, estoqueAtributos);

		validarBloqueioMovimentacaoEstoque(bloqueioMovimentacaoEstoqueId, quantidade);

		if (bloqueioMovimentacaoUnitizadorId == null)
			validarBloqueioMovimentacaoUnitizador();
		else
			validarBloqueioMovimentacaoUnitizadorDiferente(bloqueioMovimentacaoUnitizadorId);
	}

	private void validarProduto(Produto produto) {
		if (!produto.getId().equals(this.getProdutoId()))
			throw new WMSProdutoInformadoNaoCorrespondeAoEstoqueException();
	}

	private void validarSku(SKU sku) {
		if (!sku.getId().equals(this.getSkuId()))
			throw new WMSSKUInformadoNaoCorrespondeAoEstoqueException();
	}

	private void validarReserva(ReservaDefinitivaEstoque reservaDefinitiva) {
		if (!reservaDefinitiva.getEstoqueId().equals(this.getId()))
			throw new WMSReservaInformadaNaoCorrespondeAoEstoqueException();
	}

	private void validarAtributos(List<EstoqueAtributoSaldo> atributosSaldo) {

		var atributoSaldoInexistente = atributosSaldo.stream()
													 .filter(atributoSaldo -> !this.atributosSaldo.contains(atributoSaldo))
													 .findAny();

		if (atributoSaldoInexistente.isPresent())
			throw new WMSEstoqueAtributoSaldoNaoPertenceAoEstoqueException(atributoSaldoInexistente.get().toString());
	}

	private void validarInformacoesParaRelacionamento(MovimentoEstoqueId movimentoEstoqueId,
													  MovimentoEstoqueId movimentoEstoqueRelacionadoId,
													  RastreioId rastreioRelacionadoId) {

		if (movimentoEstoqueId == null)
			throw new WMSMovimentoEstoqueParaRelacionamentoDeveTerIdInformadoException();

		if (movimentoEstoqueRelacionadoId == null)
			throw new WMSMovimentoEstoqueParaRelacionamentoDeveTerMovimentoRelacionadoIdInformadoException();

		if (rastreioRelacionadoId == null)
			throw new WMSMovimentoEstoqueParaRelacionamentoDeveTerRastreioRelacionadoIdInformadoException();

	}

	private void validarQuantidade(SKU sku,
								   BigDecimal quantidade,
								   boolean permitirParcialSku,
								   boolean ehSaldoInicial,
								   boolean permiteSemAtributos,
								   List<EstoqueAtributoSaldo> estoqueAtributos) {

		validarQuantidadeInformada(quantidade);

		validarQuantidadeMinima(quantidade, ehSaldoInicial);

		validarNumeroInteirosQuantidade(quantidade);

		validarNumeroDecimaisQuantidade(quantidade);

		if (!permitirParcialSku)
			validarQuantidadeMultiplaSKU(quantidade, sku, estoqueAtributos);

		validarQuantidadeAtributos(quantidade, permiteSemAtributos, estoqueAtributos);

	}

	private void validarQuantidadeInformada(BigDecimal quantidade) {

		if (Objects.isNull(quantidade))
			throw new WMSEstoqueQuantidadeNaoInformadaException();
	}

	private void validarQuantidadeMinima(BigDecimal quantidade, boolean ehSaldoInicial) {

		var quantidadeMinima = ehSaldoInicial ? QUANTIDADE_MINIMA_SALDO_INICIAL : QUANTIDADE_MINIMA;

		if (CompareUtils.lessThan(quantidade, quantidadeMinima))
			throw new WMSEstoqueQuantidadeInvalidaException(quantidade);
	}

	private void validarNumeroInteirosQuantidade(BigDecimal quantidade) {

		if ((quantidade.precision() - quantidade.scale()) > QUANTIDADE_MAXIMA_INTEIROS)
			throw new WMSEstoqueQuantidadeInteirosException(quantidade.toString(),
															String.valueOf(QUANTIDADE_MAXIMA_INTEIROS));
	}

	private void validarNumeroDecimaisQuantidade(BigDecimal quantidade) {

		if (quantidade.scale() > QUANTIDADE_MAXIMA_DECIMAIS)
			throw new WMSEstoqueQuantidadeDecimaisException(quantidade.toString(),
															String.valueOf(QUANTIDADE_MAXIMA_DECIMAIS));
	}

	private void validarQuantidadeMultiplaSKU(BigDecimal quantidade,
											  SKU sku,
											  List<EstoqueAtributoSaldo> estoqueAtributos) {

		if (!sku.isFracionado()) {

			if (!sku.isQuantidadeMultipla(quantidade))
				throw new WMSEstoqueQuantidadeDeveSerMultiplaSKUException(sku.getQuantidadeUnidadesProduto(),
																		  quantidade);

			if (!CollectionUtils.isEmpty(estoqueAtributos)) {
				estoqueAtributos.forEach(atributo -> {
					if (!sku.isQuantidadeMultipla(atributo.getSaldo()))
						throw new WMSEstoqueQuantidadeDeveSerMultiplaSKUException(sku.getQuantidadeUnidadesProduto(),
																				  atributo.getSaldo());
				});
			}
		}
	}

	private void validarQuantidadeAtributos(BigDecimal quantidade,
											boolean permiteSemAtributos,
											List<EstoqueAtributoSaldo> estoqueAtributos) {

		if (!CollectionUtils.isEmpty(estoqueAtributos)) {

			var quantidadeTotalAtributos = estoqueAtributos.stream()
														   .map(EstoqueAtributoSaldo::getSaldo)
														   .reduce(BigDecimal.ZERO, BigDecimal::add);

			if (!CompareUtils.equalTo(quantidade, quantidadeTotalAtributos))
				throw new WMSEstoqueQuantidadeTotalAtributosDeveSerIgualQuantidadeMovimentadaException(quantidade,
																									   quantidadeTotalAtributos);
		} else if (!permiteSemAtributos && !CollectionUtils.isEmpty(this.atributosSaldo)) {
			throw new WMSEstoqueQuantidadeAtributosNaoInformadaParaSaldoComAtributosException();
		}

	}

	private void validarSaldoSuficienteParaSaida(BigDecimal quantidadeSaida,
												 List<EstoqueAtributoSaldo> estoqueAtributosSaida) {

		if (CompareUtils.greatherThan(quantidadeSaida, this.saldo.subtract(this.getQuantidadeReservada())))
			throw new WMSEstoqueQuantidadeSaldoInsuficienteException(quantidadeSaida,
																	 this.getSaldo(),
																	 this.getQuantidadeReservada(),
																	 this.getSaldoDisponivel());

		this.validarSaldoSuficienteAtributos(estoqueAtributosSaida);
	}

	private void validarSaldoSuficienteParaSaidaDescontandoReservas(BigDecimal quantidade,
																	List<ReservaDefinitivaEstoque> reservasDefinitivas,
																	List<EstoqueAtributoSaldo> estoqueAtributosSaida,
																	BloqueioMovimentacaoEstoqueId bloqueioMovimentacaoEstoqueId) {
		var somaReservas = reservasDefinitivas.stream()
											  .map(ReservaDefinitivaEstoque::getQuantidade)
											  .reduce(BigDecimal.ZERO, BigDecimal::add);

		if (CompareUtils.greatherThan(quantidade,
									  this.saldo.subtract(this.getQuantidadeReservada().subtract(somaReservas)))) {
			throw new WMSEstoqueQuantidadeSaldoInsuficienteException(quantidade,
																	 this.getSaldo(),
																	 this.getQuantidadeReservada(),
																	 this.getSaldoDisponivel());
		}

		this.validarSaldoSuficienteAtributosDescontandoReservasEBloqueioMovimentacao(reservasDefinitivas,
																					 estoqueAtributosSaida,
																					 bloqueioMovimentacaoEstoqueId);
	}

	private void validarSaldoSuficienteParaAdicionarReserva(SKU sku,
															BigDecimal quantidadeAReservar,
															BloqueioMovimentacaoEstoque bloqueioMovimentacaoEstoque,
															List<EstoqueAtributoSaldo> estoqueAtributosReservar) {

		var disponivelParaReserva = bloqueioMovimentacaoEstoque == null
				? this.saldo.subtract(this.getQuantidadeReservada())
							.subtract(this.getQuantidadeBloqueadaParaMovimentacaoEstoqueNaoReservada())
				: this.saldo.subtract(this.getQuantidadeReservada());

		if (CompareUtils.lessThan(disponivelParaReserva.subtract(quantidadeAReservar), BigDecimal.ZERO)) {
			if (sku.isFracionado()) {
				throw new WMSQuantidadeAReservarSuperiorAoSaldoDisponivelSKUFracionadoException(quantidadeAReservar,
																								this.saldo.subtract(this.getQuantidadeReservada()));
			} else {
				throw new WMSQuantidadeAReservarSuperiorAoSaldoDisponivelException(quantidadeAReservar,
																				   quantidadeAReservar.divide(sku.getQuantidadeUnidadesProduto(),
																											  MathContext.DECIMAL128),
																				   disponivelParaReserva,
																				   disponivelParaReserva.divide(sku.getQuantidadeUnidadesProduto(),
																												MathContext.DECIMAL128));
			}
		}

		this.validarSaldoSuficienteAtributos(estoqueAtributosReservar);

	}

	private void validarSaldoSuficienteAtributos(List<EstoqueAtributoSaldo> atributosSaldoValidar) {

		if (!CollectionUtils.isEmpty(this.atributosSaldo) && !CollectionUtils.isEmpty(atributosSaldoValidar)) {

			atributosSaldoValidar.forEach(atributoSaldoValidar -> { // NOSONAR

				this.atributosSaldo.stream()
								   .filter(atributo -> atributo.equals(atributoSaldoValidar))
								   .findAny()
								   .ifPresentOrElse(atributoSaldo -> {

									   var quantidadeReservadaAtributo = this.getQuantidadeReservada(atributoSaldoValidar);

									   var quantidadeDisponivel = atributoSaldo.getSaldo()
																			   .subtract(quantidadeReservadaAtributo);

									   if (CompareUtils.greatherThan(atributoSaldoValidar.getSaldo(),
																	 quantidadeDisponivel))
										   throw new WMSEstoqueQuantidadeSaldoAtributoInsuficienteException(atributoSaldoValidar.toString(),
																											atributoSaldoValidar.getSaldo(),
																											atributoSaldo.getSaldo(),
																											quantidadeReservadaAtributo,
																											quantidadeDisponivel);

									   this.validarExistenciaAtributosSeriais(atributoSaldo, atributoSaldoValidar);

								   }, () -> {
									   throw new WMSEstoqueAtributoSaldoNaoPertenceAoEstoqueException(atributoSaldoValidar.toString());
								   });

			});
		}
	}

	private void validarSaldoSuficienteAtributosDescontandoReservasEBloqueioMovimentacao(List<ReservaDefinitivaEstoque> reservasDefinitivas,
																						 List<EstoqueAtributoSaldo> atributosSaldoValidar,
																						 BloqueioMovimentacaoEstoqueId bloqueioMovimentacaoEstoqueId) {

		if (!CollectionUtils.isEmpty(this.atributosSaldo)) {

			var reservasFiltradas = this.reservasDefinitivas.stream()
															.filter(estoqueReserva -> reservasDefinitivas.stream()
																										 .anyMatch(reservaDef -> reservaDef.getId()
																																		   .equals(estoqueReserva.getReservaDefinitivaEstoqueId())))
															.toList();

			atributosSaldoValidar.forEach(atributoSaldoValidar -> { // NOSONAR

				this.atributosSaldo.stream()
								   .filter(atributo -> atributo.equals(atributoSaldoValidar))
								   .findAny()
								   .ifPresentOrElse(atributoSaldo -> {

									   var somaReservasAtributo = reservasFiltradas.stream()
																				   .map(reservaFiltrada -> reservaFiltrada.getQuantidadeReservadaAtributo(atributoSaldoValidar))
																				   .reduce(BigDecimal.ZERO,
																						   BigDecimal::add);

									   var quantidadeReservadaAtributo = this.getQuantidadeReservada(atributoSaldoValidar)
																			 .subtract(somaReservasAtributo);

									   var quantidadeBloqueadaAtributo = BigDecimal.ZERO;

									   if (Objects.nonNull(bloqueioMovimentacaoEstoqueId)) {
										   var bloqueioFiltrado = this.getBloqueioMovimentacaoEstoqueById(bloqueioMovimentacaoEstoqueId);
										   var quantidadeBloqueioAtributo = bloqueioFiltrado.getQuantidadeBloqueadaAtributo(atributoSaldoValidar);

										   quantidadeBloqueadaAtributo = quantidadeBloqueadaAtributo.add(bloqueioFiltrado.getQuantidadeBloqueadaNaoReservada(atributoSaldoValidar)
																														 .subtract(quantidadeBloqueioAtributo));
									   }

									   var quantidadeDisponivel = atributoSaldo.getSaldo()
																			   .subtract(quantidadeReservadaAtributo)
																			   .subtract(quantidadeBloqueadaAtributo);

									   if (CompareUtils.greatherThan(atributoSaldoValidar.getSaldo(),
																	 quantidadeDisponivel))
										   throw new WMSEstoqueQuantidadeSaldoAtributoInsuficienteException(atributoSaldoValidar.toString(),
																											atributoSaldoValidar.getSaldo(),
																											atributoSaldo.getSaldo(),
																											quantidadeReservadaAtributo,
																											quantidadeDisponivel);

									   this.validarExistenciaAtributosSeriais(atributoSaldo, atributoSaldoValidar);

								   }, () -> {
									   throw new WMSEstoqueAtributoSaldoNaoPertenceAoEstoqueException(atributoSaldoValidar.toString());
								   });

			});
		}
	}

	private void validarExistenciaAtributosSeriais(EstoqueAtributoSaldo atributoSaldo,
												   EstoqueAtributoSaldo atributoSaldoValidar) {

		List<String> valoresInexistentes = new ArrayList<>();

		atributoSaldoValidar.getAtributos()
							.stream()
							.filter(atributoValidar -> atributoValidar.getControleQuantidade().isSerial())
							.forEach(atributoValidar -> {

								var atributo = atributoSaldo.getAtributos()
															.stream()
															.filter(atributoFiltrar -> atributoFiltrar.getId()
																									  .equals(atributoValidar.getId()))
															.findAny()
															.orElseThrow();

								atributoValidar.getValores().stream().forEach(valorValidar -> {

									if (atributo.getValores()
												.stream()
												.noneMatch(valor -> valor.toString().equals(valorValidar.toString())))
										valoresInexistentes.add(valorValidar.toString());
								});
							});

		if (!valoresInexistentes.isEmpty())
			throw new WMSEstoqueAtributoSaldoValorSerialNaoEncontradoNoEstoqueException(valoresInexistentes);

	}

	private void validarChaveAcesso(String chave) {
		SituacaoEstoqueBloqueado situacaoCorrente = (SituacaoEstoqueBloqueado) situacoes.iterator().next();

		if (situacaoCorrente.getChaveAcesso() == null || chave == null) {
			if (Objects.equals(chave, situacaoCorrente.getChaveAcesso())) {
				return;
			} else {
				throw new WMSChaveAcessoSaidaEstoqueInvalidaException();
			}
		}

		if (!situacaoCorrente.getChaveAcesso().equals(chave))
			throw new WMSChaveAcessoSaidaEstoqueInvalidaException();
	}

	private void validarSaldoTotalmenteReservado(List<EstoqueAtributoSaldo> estoqueAtributosReservar) {

		if (CompareUtils.equalTo(this.getQuantidadeReservada(), this.saldo))
			throw new WMSEstoqueSaldoTotalmenteReservadoException();

		if (!CollectionUtils.isEmpty(this.atributosSaldo) && !CollectionUtils.isEmpty(estoqueAtributosReservar)) {

			estoqueAtributosReservar.forEach(estoqueAtributoReservar -> {
				if (CompareUtils.equalTo(this.getQuantidadeReservada(estoqueAtributoReservar),
										 estoqueAtributoReservar.getSaldo()))
					throw new WMSEstoqueSaldoAtributoTotalmenteReservadoException(estoqueAtributoReservar.toString());
			});
		}

	}

	private void validarEstoqueBloqueadoComChaveAcesso() {
		validarEstoqueBloqueadoComChaveAcesso(null);
	}

	private void validarEstoqueBloqueadoComChaveAcesso(String chaveAcesso) {
		if (isBloqueado()) {
			var situacao = (SituacaoEstoqueBloqueado) this.getSituacoes().iterator().next();

			if (situacao.getChaveAcesso() != null && chaveAcesso == null)
				throw new WMSSaidaEstoqueBloqueadoComChaveAcessoException();

			if (chaveAcesso != null && !situacao.getChaveAcesso().equals(chaveAcesso))
				throw new WMSEstoqueBloqueadoComChaveAcessoEChaveAcessoInformadaDiferenteException();
		}
	}

	private void validarTransferenciaComReserva(List<ReservaDefinitivaEstoque> reservas) {
		reservas.forEach(reservaDefinitiva -> {
			this.validarReserva(reservaDefinitiva);
			if (!reservaDefinitiva.podeSerTransferida())
				throw new WMSSituacaoReservaDefinitivaEstoqueNaoPermiteTransferenciaEnderecoException();
		});
	}

	private void validarReservasPertencemBloqueioMovimentacaoEstoque(List<ReservaDefinitivaEstoque> reservasDefinitivas,
																	 BloqueioMovimentacaoEstoqueId bloqueioMovimentacaoEstoqueId) {
		if (bloqueioMovimentacaoEstoqueId == null && CollectionUtils.isEmpty(reservasDefinitivas))
			return;

		var bloqueioMovimentacao = this.bloqueiosMovimentacaoEstoque.stream()
																	.filter(bloqueio -> bloqueio.getBloqueioMovimentacaoEstoqueId()
																								.equals(bloqueioMovimentacaoEstoqueId))
																	.findFirst();
		var reservasEstoque = reservasDefinitivas.stream()
												 .map(ReservaDefinitivaEstoque::getId)
												 .collect(Collectors.toSet());

		bloqueioMovimentacao.ifPresentOrElse(bloqueio -> {

			var reservasBloqueio = bloqueio.getReservasDefinitivas()
										   .stream()
										   .map(EstoqueReservaDefinitiva::getReservaDefinitivaEstoqueId)
										   .collect(Collectors.toSet());
			if (!reservasEstoque.containsAll(reservasBloqueio) || !reservasBloqueio.containsAll(reservasEstoque)) {
				throw new WMSSaidaEstoqueTransferenciaReservasDiferentesBloqueioMovimentacaoEstoqueException();
			}
		}, () -> {
			if (this.bloqueiosMovimentacaoEstoque.stream()
												 .flatMap(bloqueio -> bloqueio.getReservasDefinitivas().stream())
												 .map(EstoqueReservaDefinitiva::getReservaDefinitivaEstoqueId)
												 .anyMatch(reservasEstoque::contains)) {
				throw new WMSSaidaEstoqueReservasPertecemBloqueioMovimentacaoEstoqueException();
			}
		});
	}

	private EstoqueReservaDefinitiva adicionarReservaNoSaldo(ReservaDefinitivaEstoque reserva,
															 List<EstoqueAtributoSaldo> estoqueAtributos) {

		var estoqueReserva = EstoqueReservaDefinitiva.builder()
													 .reservaDefinitivaEstoqueId(reserva.getId())
													 .quantidade(reserva.getQuantidade())
													 .atributos(estoqueAtributos)
													 .build();

		this.reservasDefinitivas.add(estoqueReserva);

		reserva.registrarEstoque(this.id);

		return estoqueReserva;
	}

	private void exclusaoReservaDefinitivaDoSaldo(ReservaDefinitivaEstoque reserva) {
		this.reservasDefinitivas.removeIf(reservaEstoque -> reservaEstoque.getReservaDefinitivaEstoqueId()
																		  .equals(reserva.getId()));
	}

	public BloqueioMovimentacaoEstoque aumentarQuantidadeBloqueioMovimentacao(BloqueioMovimentacaoEstoque bloqueioMovimentacaoEstoque,
																			  BigDecimal quantidadeSolicitada,
																			  SKU sku) {

		var estoqueBloqueioMovimentacaoAssociado = this.getBloqueioMovimentacaoEstoqueById(bloqueioMovimentacaoEstoque.getId());

		var quantidadeMaximaAumento = this.getSaldoDisponivelDescontandoBloqueioMovimentacaoNaoReservado();

		if (CompareUtils.equalTo(quantidadeMaximaAumento, BigDecimal.ZERO)) {
			throw new WMSQuantidadeMaximaAumentoBloqueioMovimentacaoZeroException(bloqueioMovimentacaoEstoque.getId()
																											 .toString());
		}

		if (CompareUtils.greatherThanOrEqualTo(quantidadeSolicitada, quantidadeMaximaAumento)) {
			bloqueioMovimentacaoEstoque.aumentarQuantidadeBloqueada(quantidadeMaximaAumento);
			estoqueBloqueioMovimentacaoAssociado.aumentarQuantidadeBloqueada(quantidadeMaximaAumento);
			this.registerEvent(EstoqueAumentoBloqueioMovimentacaoEfetuadoEvent.from(this,
																					bloqueioMovimentacaoEstoque,
																					quantidadeMaximaAumento));
		}

		if (CompareUtils.lessThan(quantidadeSolicitada, quantidadeMaximaAumento)) {
			validarQuantidadeMultiplaSKU(quantidadeSolicitada, sku, this.atributosSaldo);
			bloqueioMovimentacaoEstoque.aumentarQuantidadeBloqueada(quantidadeSolicitada);
			estoqueBloqueioMovimentacaoAssociado.aumentarQuantidadeBloqueada(quantidadeSolicitada);
			this.registerEvent(EstoqueAumentoBloqueioMovimentacaoEfetuadoEvent.from(this,
																					bloqueioMovimentacaoEstoque,
																					quantidadeSolicitada));
		}

		return bloqueioMovimentacaoEstoque;
	}

	private void validarSeEnderecoBloqueadoParaSaidaOuEntradaSaida(Endereco endereco) {

		if (endereco.isBloqueadoSaida() || endereco.isBloqueadoEntradaSaida()) {

			if (!(this.getSituacoes().iterator().next() instanceof SituacaoEstoqueBloqueado))
				throw new WMSEnderecoBloqueadoParaSaidaEstoqueException();

			var situacao = (SituacaoEstoqueBloqueado) this.getSituacoes().iterator().next();

			if (!situacao.getChaveAcesso().equals(endereco.getBloqueio().orElseThrow().getChaveAcesso()))
				throw new WMSChaveAcessoBloqueioEstoqueDiferenteDoEnderecoException();
		}
	}

	public MovimentoEstoque efetuarEntradaEstoque(Endereco endereco,
												  Produto produto,
												  SKU sku,
												  BigDecimal quantidade,
												  Origem origem,
												  boolean alteraOcupacaoEndereco,
												  List<EstoqueAtributoSaldo> estoqueAtributos) {

		return efetuarEntradaEstoque(endereco,
									 produto,
									 sku,
									 quantidade,
									 origem,
									 null,
									 null,
									 null,
									 alteraOcupacaoEndereco,
									 estoqueAtributos);
	}

	public MovimentoEstoque efetuarEntradaEstoque(Endereco endereco, // NOSONAR
												  Produto produto,
												  SKU sku,
												  BigDecimal quantidade,
												  Origem origem,
												  MovimentoEstoqueId movimentoEstoqueIdEntrada,
												  MovimentoEstoqueId movimentoEstoqueIdSaida,
												  RastreioId rastreioId,
												  boolean alteraOcupacaoEndereco,
												  List<EstoqueAtributoSaldo> estoqueAtributos) {

		validarSeEnderecoBloqueadoParaEntradaOuEntradaSaida(endereco);

		validarSeOcupacaoEnderecoPermiteEntrada(sku, quantidade, endereco, alteraOcupacaoEndereco);

		return efetuarEntrada(produto,
							  sku,
							  quantidade,
							  origem,
							  movimentoEstoqueIdEntrada,
							  movimentoEstoqueIdSaida,
							  rastreioId,
							  alteraOcupacaoEndereco,
							  estoqueAtributos);
	}

	public MovimentoEstoque efetuarEntradaEstoqueAssociandoReservaSubtraindoQuantidadeReservada(Endereco endereco, // NOSONAR
																								Produto produto,
																								SKU sku,
																								BigDecimal quantidade,
																								Origem origem,
																								MovimentoEstoqueId movimentoEstoqueIdEntrada,
																								MovimentoEstoqueId movimentoEstoqueIdSaida,
																								RastreioId rastreioId,
																								boolean alteraOcupacaoEndereco,
																								ReservaDefinitivaEstoque reserva,
																								BigDecimal quantidadeSubtrairReserva,
																								BloqueioMovimentacaoEstoque bloqueioMovimentacaoEstoque,
																								List<EstoqueAtributoSaldo> atributosSaldoEntrada,
																								List<EstoqueAtributoSaldo> atributosSaldoReserva) {

		validarSeEnderecoBloqueadoParaEntradaOuEntradaSaida(endereco);

		validarQuantidade(sku, quantidade, false, false, false, atributosSaldoEntrada);

		validarQuantidadeInformada(quantidadeSubtrairReserva);

		validarQuantidade(sku,
						  quantidade.subtract(quantidadeSubtrairReserva),
						  false,
						  false,
						  true,
						  atributosSaldoReserva);

		validarSeOcupacaoEnderecoPermiteEntrada(sku, quantidade, endereco, alteraOcupacaoEndereco);

		exclusaoReservaDefinitivaDoSaldo(reserva);

		if (bloqueioMovimentacaoEstoque != null)
			this.bloqueiosMovimentacaoEstoque.removeIf(bloqueio -> bloqueio.getBloqueioMovimentacaoEstoqueId()
																		   .equals(bloqueioMovimentacaoEstoque.getId()));

		reserva.subtrair(quantidadeSubtrairReserva);

		var movimento = efetuarEntrada(produto,
									   sku,
									   quantidade,
									   origem,
									   movimentoEstoqueIdEntrada,
									   movimentoEstoqueIdSaida,
									   rastreioId,
									   alteraOcupacaoEndereco,
									   atributosSaldoEntrada);

		adicionarReservaNoSaldo(reserva, atributosSaldoReserva);

		if (bloqueioMovimentacaoEstoque != null) {
			bloqueioMovimentacaoEstoque.atualizar(this.id, reserva.getQuantidade(), reserva, atributosSaldoReserva);
			executarBloqueioMovimentacaoEstoque(bloqueioMovimentacaoEstoque, produto, List.of());
		}

		return movimento;

	}

	private void validarSeOcupacaoEnderecoPermiteEntrada(SKU sku,
														 BigDecimal quantidade,
														 Endereco endereco,
														 boolean alteraOcupacaoEndereco) {

		if (alteraOcupacaoEndereco)
			endereco.getCapacidade()
					.ifPresent(capacidade -> endereco.validarSePermiteAumentarOcupacao(sku.getPesoParaQuantidade(quantidade),
																					   sku.getCubagemParaQuantidade(quantidade)));
	}

	public MovimentoEstoque efetuarEntradaReunitizacao(Produto produto, // NOSONAR
													   SKU sku,
													   BigDecimal saldoATransferir,
													   Origem origem,
													   MovimentoEstoqueId movimentoEstoqueIdEntrada,
													   MovimentoEstoqueId movimentoEstoqueIdSaida,
													   RastreioId rastreioId,
													   boolean alteraOcupacaoEndereco,
													   Endereco endereco,
													   List<EstoqueAtributoSaldo> estoqueAtributos) {

		validarSeOcupacaoEnderecoPermiteEntrada(sku, saldoATransferir, endereco, alteraOcupacaoEndereco);

		return efetuarEntrada(produto,
							  sku,
							  saldoATransferir,
							  origem,
							  movimentoEstoqueIdEntrada,
							  movimentoEstoqueIdSaida,
							  rastreioId,
							  alteraOcupacaoEndereco,
							  estoqueAtributos);
	}

	public MovimentoEstoque efetuarEntradaBloqueio(Endereco endereco, // NOSONAR
												   Produto produto,
												   SKU sku,
												   BigDecimal quantidade,
												   Origem origem,
												   MovimentoEstoqueId movimentoEstoqueIdEntrada,
												   MovimentoEstoqueId movimentoEstoqueIdSaida,
												   RastreioId rastreioId,
												   boolean alteraOcupacaoEndereco,
												   List<EstoqueAtributoSaldo> estoqueAtributos) {
		return efetuarEntradaEstoque(endereco,
									 produto,
									 sku,
									 quantidade,
									 origem,
									 movimentoEstoqueIdEntrada,
									 movimentoEstoqueIdSaida,
									 rastreioId,
									 alteraOcupacaoEndereco,
									 estoqueAtributos);
	}

	public MovimentoEstoque efetuarEntradaDesbloqueio(Produto produto, // NOSONAR
													  SKU sku,
													  BigDecimal quantidade,
													  Origem origem,
													  MovimentoEstoqueId movimentoEstoqueIdEntrada,
													  MovimentoEstoqueId movimentoEstoqueIdSaida,
													  RastreioId rastreioId,
													  boolean alteraOcupacaoEndereco,
													  List<EstoqueAtributoSaldo> estoqueAtributos) {
		return efetuarEntrada(produto,
							  sku,
							  quantidade,
							  origem,
							  movimentoEstoqueIdEntrada,
							  movimentoEstoqueIdSaida,
							  rastreioId,
							  alteraOcupacaoEndereco,
							  estoqueAtributos);
	}

	public MovimentoEstoque efetuarEntradaAdicaoCaracteristica(Produto produto, // NOSONAR
															   SKU sku,
															   BigDecimal saldoAMovimentar,
															   Origem origem,
															   MovimentoEstoqueId movimentoEstoqueIdEntrada,
															   MovimentoEstoqueId movimentoEstoqueIdSaida,
															   RastreioId rastreioId,
															   boolean alteraOcupacaoEndereco,
															   List<EstoqueAtributoSaldo> estoqueAtributos) {
		return efetuarEntrada(produto,
							  sku,
							  saldoAMovimentar,
							  origem,
							  movimentoEstoqueIdEntrada,
							  movimentoEstoqueIdSaida,
							  rastreioId,
							  alteraOcupacaoEndereco,
							  estoqueAtributos);
	}

	public MovimentoEstoque efetuarEntradaRemocaoCaracteristica(Produto produto, // NOSONAR
																SKU sku,
																BigDecimal saldoAMovimentar,
																Origem origem,
																MovimentoEstoqueId movimentoEstoqueIdEntrada,
																MovimentoEstoqueId movimentoEstoqueIdSaida,
																RastreioId rastreioId,
																boolean alteraOcupacaoEndereco,
																List<EstoqueAtributoSaldo> estoqueAtributos) {
		return efetuarEntrada(produto,
							  sku,
							  saldoAMovimentar,
							  origem,
							  movimentoEstoqueIdEntrada,
							  movimentoEstoqueIdSaida,
							  rastreioId,
							  alteraOcupacaoEndereco,
							  estoqueAtributos);
	}

	public MovimentoEstoque efetuarEntradaAdicaoAtributo(Produto produto, // NOSONAR
														 SKU sku,
														 BigDecimal saldoAMovimentar,
														 Origem origem,
														 MovimentoEstoqueId movimentoEstoqueIdEntrada,
														 MovimentoEstoqueId movimentoEstoqueIdSaida,
														 RastreioId rastreioId,
														 boolean alteraOcupacaoEndereco,
														 List<EstoqueAtributoSaldo> estoqueAtributos) {
		return efetuarEntrada(produto,
							  sku,
							  saldoAMovimentar,
							  origem,
							  movimentoEstoqueIdEntrada,
							  movimentoEstoqueIdSaida,
							  rastreioId,
							  alteraOcupacaoEndereco,
							  estoqueAtributos);
	}

	public MovimentoEstoque efetuarEntradaRemocaoAtributo(Produto produto, // NOSONAR
														  SKU sku,
														  BigDecimal saldoAMovimentar,
														  Origem origem,
														  MovimentoEstoqueId movimentoEstoqueIdEntrada,
														  MovimentoEstoqueId movimentoEstoqueIdSaida,
														  RastreioId rastreioId,
														  boolean alteraOcupacaoEndereco,
														  List<EstoqueAtributoSaldo> estoqueAtributos) {
		return efetuarEntrada(produto,
							  sku,
							  saldoAMovimentar,
							  origem,
							  movimentoEstoqueIdEntrada,
							  movimentoEstoqueIdSaida,
							  rastreioId,
							  alteraOcupacaoEndereco,
							  estoqueAtributos);
	}

	public MovimentoEstoque efetuarEntradaDivisaoFusao(Endereco endereco, // NOSONAR
													   Produto produto,
													   SKU sku,
													   BigDecimal quantidade,
													   Origem origem,
													   MovimentoEstoqueId movimentoEstoqueIdEntrada,
													   MovimentoEstoqueId movimentoEstoqueIdSaida,
													   RastreioId rastreioId,
													   boolean alteraOcupacaoEndereco,
													   List<EstoqueAtributoSaldo> estoqueAtributos) {
		return efetuarEntradaEstoque(endereco,
									 produto,
									 sku,
									 quantidade,
									 origem,
									 movimentoEstoqueIdEntrada,
									 movimentoEstoqueIdSaida,
									 rastreioId,
									 alteraOcupacaoEndereco,
									 estoqueAtributos);
	}

	private void validarSeEnderecoBloqueadoParaEntradaOuEntradaSaida(Endereco endereco) {

		if (endereco.isBloqueadoEntrada() || endereco.isBloqueadoEntradaSaida()) {

			if (!(this.getSituacoes().iterator().next() instanceof SituacaoEstoqueBloqueado)) {
				throw new WMSEnderecoBloqueadoParaEntradaEstoqueException();
			}

			var situacao = (SituacaoEstoqueBloqueado) this.getSituacoes().iterator().next();

			if (!situacao.getChaveAcesso().equals(endereco.getBloqueio().orElseThrow().getChaveAcesso())) {
				throw new WMSChaveAcessoBloqueioEstoqueDiferenteDoEnderecoException();
			}
		}
	}

	public void adicionarSelo(SeloEstoque selo) {
		if (this.selos.stream().anyMatch(selo::equals)) {
			throw new WMSSeloExistenteException();
		} else {
			this.selos.add(selo);
			this.registerEvent(EstoqueSeloAdicionadoEvent.from(this, selo));
		}
	}

	public void removerSelo(SeloEstoque selo) {
		if (this.selos.stream().noneMatch(selo::equals)) {
			throw new WMSSeloNaoExistenteException();
		} else {
			this.selos.remove(selo);
			this.registerEvent(EstoqueSeloRemovidoEvent.from(this, selo));
		}
	}

	public boolean isSkuNaoFracionado() {
		return isNull(this.fracionadoId);
	}

	private EstoqueReservaDefinitiva getReserva(ReservaDefinitivaEstoqueId reservaDefinitivaEstoqueId) {
		return this.reservasDefinitivas.stream()
									   .filter(reserva -> reserva.getReservaDefinitivaEstoqueId()
																 .equals(reservaDefinitivaEstoqueId))
									   .findAny()
									   .orElseThrow(WMSEstoqueReservaNaoEncontradaException::new);
	}

	public List<EstoqueAtributoSaldo> getAtributosReserva(ReservaDefinitivaEstoqueId reservaDefinitivaEstoqueId) {
		return this.getReserva(reservaDefinitivaEstoqueId).getAtributosSaldo();
	}

	private BigDecimal getQuantidadeBloqueada(EstoqueAtributoSaldo atributoSaldo) {
		return bloqueiosMovimentacaoEstoque.stream()
										   .map(bloqueioMovimentacao -> bloqueioMovimentacao.getQuantidadeBloqueadaAtributo(atributoSaldo))
										   .reduce(BigDecimal.ZERO, BigDecimal::add);
	}

	private void validarDisponibilidadeAtributosSeriais(List<EstoqueAtributoSaldo> atributosSaldo) {
		var atributosSerial = atributosSaldo.stream()
											.flatMap(atributoSaldo -> atributoSaldo.getAtributos().stream())
											.filter(atributo -> atributo.getControleQuantidade().isSerial())
											.toList();

		List<String> valoresComRestricao = new ArrayList<>();

		this.reservasDefinitivas.forEach(reserva -> atributosSerial.forEach(atributo -> atributo.getValores()
																								.forEach(valor -> {
																									if (reserva.existeAtributoSerial(atributo.getId(),
																																	 valor))
																										valoresComRestricao.add(valor.toString());
																								})));

		if (!valoresComRestricao.isEmpty())
			throw new WMSEstoqueValorAtributoSerialJaPossuiReservaException(valoresComRestricao);

		this.bloqueiosMovimentacaoEstoque.forEach(bloqueio -> atributosSerial.forEach(atributo -> atributo.getValores()
																										  .forEach(valor -> {
																											  if (bloqueio.existeAtributoSerial(atributo.getId(),
																																				valor))
																												  valoresComRestricao.add(valor.toString());
																										  })));

		if (!valoresComRestricao.isEmpty())
			throw new WMSEstoqueValorAtributoSerialJaPossuiBloqueioMovimentacaoException(valoresComRestricao);

	}

	private void validarSaldoSuficienteBloqueioAtributos(List<EstoqueAtributoSaldo> atributosSaldoValidar) {

		if (!CollectionUtils.isEmpty(this.atributosSaldo) && !CollectionUtils.isEmpty(atributosSaldoValidar)) {

			atributosSaldoValidar.forEach(atributoSaldoValidar -> { // NOSONAR

				this.atributosSaldo.stream()
								   .filter(atributo -> atributo.equals(atributoSaldoValidar))
								   .findAny()
								   .ifPresentOrElse(atributoSaldo -> {

									   var quantidadeBloqueadaAtributo = this.getQuantidadeBloqueada(atributoSaldoValidar);

									   var quantidadeDisponivel = atributoSaldo.getSaldo()
																			   .subtract(quantidadeBloqueadaAtributo);

									   if (CompareUtils.greatherThan(atributoSaldoValidar.getSaldo(),
																	 quantidadeDisponivel))
										   throw new WMSEstoqueQuantidadeSaldoAtributoInsuficienteException(atributoSaldoValidar.toString(),
																											atributoSaldoValidar.getSaldo(),
																											atributoSaldo.getSaldo(),
																											quantidadeBloqueadaAtributo,
																											quantidadeDisponivel);

									   this.validarExistenciaAtributosSeriais(atributoSaldo, atributoSaldoValidar);

								   }, () -> {
									   throw new WMSEstoqueAtributoSaldoNaoPertenceAoEstoqueException(atributoSaldoValidar.toString());
								   });

			});
		}
	}

	public void associarAtributosBloqueioMovimentacao(BloqueioMovimentacaoEstoqueId bloqueioMovimentacaoEstoqueId,
													  Produto produto,
													  List<EstoqueAtributoSaldo> atributosSaldo) {

		var bloqueioMovimentacaoEstoque = this.bloqueiosMovimentacaoEstoque.stream()
																		   .filter(bloqueio -> bloqueio.getBloqueioMovimentacaoEstoqueId()
																									   .equals(bloqueioMovimentacaoEstoqueId))
																		   .findFirst()
																		   .orElseThrow(WMSEstoqueBloqueioMovimentacaoEstoqueNaoEncontradoException::new);

		this.validarAtributosBloqueioMovimentacao(atributosSaldo);
		bloqueioMovimentacaoEstoque.associarAtributos(produto, atributosSaldo);

		this.registerEvent(EstoqueBloqueioMovimentacaoAssociacaoAtributosEfetuadaEvent.of(this.id,
																						  bloqueioMovimentacaoEstoqueId,
																						  bloqueioMovimentacaoEstoque.getAtributosSaldo()));
	}

	private void validarAtributosBloqueioMovimentacao(List<EstoqueAtributoSaldo> atributosSaldo) {
		if (!CollectionUtils.isEmpty(atributosSaldo)) {
			this.validarAtributos(atributosSaldo);
			this.validarSaldoSuficienteBloqueioAtributos(atributosSaldo);
			this.validarDisponibilidadeAtributosSeriais(atributosSaldo);
		}
	}

	private List<EstoqueAtributoSaldo> determinarAtributosSaldo(BigDecimal quantidade) {

		var estoqueAtributoSaldoList = new ArrayList<EstoqueAtributoSaldo>();
		for (EstoqueAtributoSaldo estoqueAtributoSaldo : this.atributosSaldo) {
			if (estoqueAtributoSaldo.getSaldo().compareTo(quantidade) <= 0) {

				estoqueAtributoSaldoList.add(estoqueAtributoSaldo);
				quantidade = quantidade.subtract(estoqueAtributoSaldo.getSaldo());

			} else {

				var estoqueAtributoSaldoResult = estoqueAtributoSaldo.dividindoQuantidade(quantidade);
				estoqueAtributoSaldoList.add(estoqueAtributoSaldoResult);
				quantidade = quantidade.subtract(estoqueAtributoSaldoResult.getSaldo());

			}

			if (quantidade.compareTo(BigDecimal.ZERO) <= 0)
				break;
		}

		if (quantidade.compareTo(BigDecimal.ZERO) != 0)
			throw new WMSEstoqueSaldoInformadoParaProcessamentoMaiorOuMenorQueOSuficienteException();

		return estoqueAtributoSaldoList;
	}

}
