package com.totvs.sl.wms.estoque.caracteristicavalor.amqp.cmd;

import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import org.springframework.util.CollectionUtils;

import com.totvs.sl.wms.estoque.caracteristicaconfiguracao.domain.model.CaracteristicaConfiguracaoId;
import com.totvs.sl.wms.estoque.caracteristicaconfiguracao.domain.model.FormatoCaracteristicaValor;
import com.totvs.sl.wms.estoque.caracteristicavalor.domain.model.CaracteristicaValor;
import com.totvs.sl.wms.estoque.caracteristicavalor.domain.model.CaracteristicaValorTexto;

import lombok.Data;

@Data(staticConstructor = "of")
public final class CaracteristicaValorCmd {

	@NotNull(message = "{CaracteristicaValorCmd.caracteristicaConfiguracaoId.NotNull}")
	private final CaracteristicaConfiguracaoId caracteristicaConfiguracaoId;

	@NotBlank(message = "{CaracteristicaValorCmd.valor.NotBlank}")
	private final String valor;

	private final FormatoCaracteristicaValor formato;

	public static List<CaracteristicaValor<?>> from(List<CaracteristicaValorCmd> caracteristicas) { // NOSONAR

		if (CollectionUtils.isEmpty(caracteristicas))
			return Collections.emptyList();

		// TODO retirar esse if quando for eliminado o método fromOld
		if (caracteristicas.stream().anyMatch(caracteristica -> Objects.isNull(caracteristica.getFormato())))
			return Collections.emptyList();

		return caracteristicas.stream()
							  .map(caracteristica -> caracteristica.getFormato()
																   .getInstance(caracteristica.getCaracteristicaConfiguracaoId(),
																				caracteristica.getValor()))
							  .collect(Collectors.toList());
	}

	@Deprecated(forRemoval = true)
	public static List<CaracteristicaValorTexto> fromOld(List<CaracteristicaValorCmd> caracteristicas) {

		if (CollectionUtils.isEmpty(caracteristicas))
			return Collections.emptyList();

		if (caracteristicas.stream().anyMatch(caracteristica -> Objects.isNull(caracteristica.getFormato())))
			return caracteristicas.stream()
								  .filter(caracteristica -> caracteristica.getFormato() == null)
								  .map(caracteristica -> CaracteristicaValorTexto.builder()
																				 .caracteristicaConfiguracaoId(caracteristica.getCaracteristicaConfiguracaoId())
																				 .valor(caracteristica.getValor())
																				 .build())
								  .toList();
		else
			return Collections.emptyList();
	}
}
