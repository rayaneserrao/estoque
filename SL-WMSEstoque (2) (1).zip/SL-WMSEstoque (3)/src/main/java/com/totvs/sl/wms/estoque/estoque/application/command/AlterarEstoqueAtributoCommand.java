package com.totvs.sl.wms.estoque.estoque.application.command;

import com.totvs.sl.wms.estoque.atributoestoque.domain.model.AtributoEstoqueId;
import com.totvs.sl.wms.estoque.estoque.domain.model.EstoqueAtributoSaldoId;
import com.totvs.sl.wms.estoque.estoque.domain.model.EstoqueId;

import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;

@Getter
@Builder
@EqualsAndHashCode
public final class AlterarEstoqueAtributoCommand {
	private final EstoqueId id;
	private final EstoqueAtributoSaldoId estoqueAtributoSaldoId;
	private final AtributoEstoqueId atributoEstoqueId;
	private final String valorAtual;
	private final String novoValor;
}
