package com.totvs.sl.wms.estoque.atributoestoquevalor.domain.model;

import java.util.TreeSet;

import com.totvs.sl.wms.estoque.atributoestoque.domain.model.AtributoEstoqueId;
import com.totvs.sl.wms.estoque.atributoestoque.domain.model.ControleQuantidadeAtributoEstoqueValor;
import com.totvs.sl.wms.estoque.atributoestoque.domain.model.FormatoAtributoEstoqueValor;

public interface AtributoEstoqueValor<T> extends Comparable<AtributoEstoqueValor<T>> {

	AtributoEstoqueId getId();

	TreeSet<T> getValores();

	FormatoAtributoEstoqueValor getFormato();

	ControleQuantidadeAtributoEstoqueValor getControleQuantidade();

	default void adicionarValorSerial(Object valor) {
	}

	default void removerValorSerial(Object valor) {
	}

	default void atualizarValorVariavel(Object valor) {
	}

	default String withValoresToString() {

		var sb = new StringBuilder();
		sb.append(this.getId().toString() + ": ");
		sb.append("[");

		var primeiro = true;

		for (var valor : this.getValores()) {

			if (!primeiro)
				sb.append(",");

			sb.append(valor.toString());

			primeiro = false;
		}

		sb.append("]");

		return sb.toString();

	}
}