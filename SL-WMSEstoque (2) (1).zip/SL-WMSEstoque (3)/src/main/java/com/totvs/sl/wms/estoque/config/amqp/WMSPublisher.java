package com.totvs.sl.wms.estoque.config.amqp;

import java.util.Collection;
import java.util.Objects;
import java.util.Optional;

import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.stream.annotation.EnableBinding;
import org.springframework.messaging.Message;
import org.springframework.messaging.support.MessageHeaderAccessor;

import com.totvs.sl.wms.estoque.config.amqp.WMSChannel.WMSEstoqueOutput;
import com.totvs.sl.wms.estoque.config.amqp.WMSChannel.WMSExchangeOutput;
import com.totvs.sl.wms.estoque.util.Constants;
import com.totvs.sl.wms.estoque.util.amqp.MessageType;
import com.totvs.sl.wms.estoque.util.amqp.QueryResult;
import com.totvs.sl.wms.estoque.util.amqp.RejectedEvent;
import com.totvs.sl.wms.estoque.util.amqp.SubjectDomainEvent;
import com.totvs.sl.wms.estoque.util.amqp.SubjectMessage;
import com.totvs.sl.wms.estoque.util.amqp.TransactionalCmd;
import com.totvs.sl.wms.estoque.util.amqp.TransactionalEvent;
import com.totvs.sl.wms.estoque.util.amqp.WMSIntegrationMessage;
import com.totvs.tjf.core.common.domain.DomainEvent;
import com.totvs.tjf.core.security.context.SecurityDetails;
import com.totvs.tjf.messaging.TransactionContext;
import com.totvs.tjf.messaging.context.CloudEventsInfo;
import com.totvs.tjf.messaging.context.TOTVSMessage;
import com.totvs.tjf.messaging.context.TOTVSMessageBuilder;
import com.totvs.tjf.messaging.context.TransactionInfo;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@EnableBinding({ WMSChannel.WMSExchangeOutput.class, WMSChannel.WMSEstoqueOutput.class })
public class WMSPublisher {

	private static final String WMS_ARMAZENAGEM = "wms-armazenagem";
	private static final String WMS_ESTOQUE = "wms-estoque";
	private static final String WMS_EXPEDICAO = "wms-expedicao";
	private static final String WMS_INVENTARIO = "wms-inventario";
	private static final String WMS_MANUFATURA = "wms-manufatura";
	private static final String WMS_PICKING = "wms-picking";
	private static final String WMS_SEPARACAO = "wms-separacao";
	private static final String WMS_SETUP = "wms-setup";

	@Autowired
	private WMSExchangeOutput wmsExchangeOutput;

	@Autowired
	private WMSEstoqueOutput wmsEstoqueOutput;

	@Autowired
	private TransactionContext transactionContext;

	@Value("${spring.application.name}")
	private String appName;

	public void dispatch(RejectedEvent event) {
		this.dispatch(event,
					  transactionContext.getTransactionInfo(),
					  buildHeaderEvent(event, transactionContext.getTransactionInfo()));
	}

	public void dispatch(Collection<? extends DomainEvent> events) {
		events.forEach(this::dispatch);
	}

	public void dispatch(DomainEvent event) {
		if (event instanceof WMSIntegrationMessage) {
			log.info("Event used for integration, publishing to the old channel:");
			this.dispatchOld(event, transactionContext.getTransactionInfo());
		}

		if (event instanceof SubjectDomainEvent subjectDomainEvent) {
			dispatch(subjectDomainEvent);
		} else if (event instanceof TransactionalEvent transactionalEvent) {
			this.dispatch(transactionalEvent);
		} else {
			log.info("public void dispatch(DomainEvent event)");
			this.dispatchOld(event, transactionContext.getTransactionInfo());
		}
	}

	private void dispatch(final SubjectDomainEvent message) {
		var transactionInfo = transactionContext.getTransactionInfo();
		this.dispatch(message, transactionInfo, buildHeaderEvent(message, transactionInfo));
	}

	private void dispatch(final TransactionalEvent message) {

		var transactionInfoOrigem = transactionContext.getTransactionInfo();
		var transactionInfo = new TransactionInfo(message.getTransactionId(),
												  message.getGeneratedBy(),
												  transactionInfoOrigem.getActivityId(),
												  transactionInfoOrigem.getTaskId(),
												  transactionInfoOrigem.getRoles(),
												  transactionInfoOrigem.getPlanItemId());
		this.dispatch(message, transactionInfo, buildHeaderEvent(message, transactionInfo));
	}

	public void dispatch(final TransactionalCmd message) {

		var transactionInfoOrigem = transactionContext.getTransactionInfo();
		var transactionInfo = new TransactionInfo(message.getTransactionId(),
												  buildGeneratedByWithApplicationName(message.getGeneratedBy()),
												  transactionInfoOrigem.getActivityId(),
												  transactionInfoOrigem.getTaskId(),
												  transactionInfoOrigem.getRoles(),
												  transactionInfoOrigem.getPlanItemId());
		this.dispatch(message, transactionInfo, buildHeaderCmd(message));
	}

	public void dispatch(final QueryResult result) {
		this.dispatchOld(result, transactionContext.getTransactionInfo());
	}

	public <T> void dispatchCommandEventUtil(T message, TransactionInfo transactionInfo) {
		this.dispatch(message, transactionInfo, buildHeaderEvent(message, transactionInfo));
	}

	private String buildGeneratedByWithApplicationName(String generatedBy) {
		return generatedBy == null ? null : appName.concat(".").concat(generatedBy);
	}

	private <T> void dispatchOld(T contentToBeDispatched, TransactionInfo transactionInfo) {

		var totvsMessage = TOTVSMessageBuilder.<T>withDefaultType()
											  .setContent(contentToBeDispatched)
											  .setTransactionInfo(transactionInfo)
											  .asTOTVSLegacyEvent()
											  .build();

		wmsExchangeOutput.output().send(totvsMessage);

		if (Objects.isNull(transactionInfo))
			log.info("Publishing OLD content: {} | TenantId: {}",
					 contentToBeDispatched.toString(),
					 SecurityDetails.getTenant());
		else
			log.info("Publishing OLD content: {} | TenantId: {} | GeneratedBy: {} | TransactionId: {}",
					 contentToBeDispatched.toString(),
					 SecurityDetails.getTenant(),
					 transactionInfo.getGeneratedBy(),
					 transactionInfo.getTransactionId());
	}

	private <T> void dispatch(T message, TransactionInfo transactionInfo, MessageHeaderAccessor headers) {

		var cloudEventsInfoOrigem = transactionContext.getCloudEventsInfo();
		var cloudEventsInfo = new CloudEventsInfo();
		cloudEventsInfo.setDataContentType(CloudEventsInfo.APPLICATION_JSON);

		if (cloudEventsInfoOrigem != null) {
			cloudEventsInfo.setSubject(cloudEventsInfoOrigem.getSubject());
			cloudEventsInfo.setDataSchema(cloudEventsInfoOrigem.getDataSchema());
			cloudEventsInfo.setCorrelationId(cloudEventsInfoOrigem.getCorrelationId());
		}

		if (MDC.get(Constants.CORRELATIONID_HEADER_PARAM) != null)
			cloudEventsInfo.setCorrelationId(MDC.get(Constants.CORRELATIONID_HEADER_PARAM));

		var totvsMessage = TOTVSMessageBuilder.<T>withDefaultType()
											  .setTransactionInfo(transactionInfo)
											  .setCloudEventsInfo(cloudEventsInfo)
											  .setContent(message)
											  .asCloudEvent()
											  .setHeaders(headers)
											  .build();

		this.send(totvsMessage);

		this.log(message, transactionInfo);
	}

	private <T> void send(Message<TOTVSMessage<T>> message) {

		wmsEstoqueOutput.output().send(message);
	}

	private <T> void log(T event, TransactionInfo transactionInfo) {

		var subject = event instanceof SubjectMessage subjectMessage ? subjectMessage.getSubject() : null;

		if (Objects.isNull(transactionInfo)) {
			log.info("Publishing content: {} | Subject: {} | TenantId: {}",
					 event.toString(),
					 subject,
					 SecurityDetails.getTenant());
		} else {
			log.info("Publishing content: {} | Subject: {} | TenantId: {} | GeneratedBy: {} | TransactionId: {}",
					 event.toString(),
					 subject,
					 SecurityDetails.getTenant(),
					 transactionInfo.getGeneratedBy(),
					 transactionInfo.getTransactionId());
		}
	}

	private <T> MessageHeaderAccessor buildHeaderDefault(T message) {

		var accessor = new MessageHeaderAccessor();

		if (message instanceof SubjectMessage subjectMessage)
			accessor.setHeader("subject", subjectMessage.getSubject());

		if (message instanceof MessageType messageType)
			accessor.setHeader("sl-message-type", messageType.getMessageType());

		if (message instanceof ConsumeMessage messageType)
			accessor.setHeader("sl-for-own-consumption", "true");

		return accessor;
	}

	private <T> MessageHeaderAccessor buildHeaderCmd(T message) {
		return buildHeaderDefault(message);
	}

	private <T> MessageHeaderAccessor buildHeaderEvent(T message, final TransactionInfo transactionInfo) {

		var accessor = buildHeaderDefault(message);

		getRequestingService(transactionInfo).ifPresent(requestingService -> accessor.setHeader("sl-generated-to",
																								requestingService));
		return accessor;
	}

	private Optional<String> getRequestingService(TransactionInfo transactionInfo) {

		var generatedBy = transactionInfo == null ? null : transactionInfo.getGeneratedBy();
		var serviceName = generatedBy != null && generatedBy.contains(".") ? generatedBy.split("\\.")[0] : null;

		return Optional.ofNullable(getRequesterServiceLegacyAdapter(serviceName, generatedBy));
	}

	private String getRequesterServiceLegacyAdapter(String serviceName, String generatedBy) {

		if (serviceName != null)
			return serviceName;

		if (generatedBy == null)
			return null;

		if (generatedBy.equals(appName))
			return generatedBy;

		if (generatedBy.equals("TransferenciaEnderecoEstoqueManual"))
			return null;

		switch (generatedBy) {

		case "SEPARACAO_ESTOQUE_TRANSFERENCIA":
			return WMS_SEPARACAO;

		case "SEPARACAO_ESTOQUE_BLOQUEIO":
			return WMS_SEPARACAO;

		case "EXCLUSAO_SEPARACAO":
			return WMS_SEPARACAO;

		case "REQUISICAO_MATERIA_PRIMA":
			return WMS_MANUFATURA;

		case "RESERVA_PICKING":
			return WMS_PICKING;

		case "ESTOQUE_REABASTECIMENTO_PICKING":
			return WMS_PICKING;

		case "INVENTARIO":
			return WMS_INVENTARIO;

		case "TRANSFERENCIA_PICKING":
			return WMS_PICKING;

		case "PICKING":
			return WMS_PICKING;

		case "MOVIMENTO_ARMAZENAGEM":
			return WMS_ARMAZENAGEM;

		case "SETUP_WMS":
			return WMS_SETUP;

		case "MOVIMENTO_VERTICAL":
			return WMS_ESTOQUE;

		case "PROCESSO_EXPEDICAO":
			return WMS_EXPEDICAO;

		default:
			return null;
		}
	}
}