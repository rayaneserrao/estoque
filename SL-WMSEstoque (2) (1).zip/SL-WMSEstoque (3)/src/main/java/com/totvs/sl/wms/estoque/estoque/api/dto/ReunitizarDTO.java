package com.totvs.sl.wms.estoque.estoque.api.dto;

import static com.totvs.sl.wms.estoque.util.Constants.QUANTIDADE_MAXIMA_DECIMAIS;
import static com.totvs.sl.wms.estoque.util.Constants.QUANTIDADE_MAXIMA_INTEIROS;

import java.math.BigDecimal;
import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.Digits;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Positive;

import org.springframework.util.CollectionUtils;

import com.totvs.sl.wms.estoque.atributoestoquevalor.api.dto.AtributoEstoqueValorDTO;
import com.totvs.sl.wms.estoque.endereco.domain.model.EnderecoId;
import com.totvs.sl.wms.estoque.estoque.domain.model.EstoqueId;
import com.totvs.sl.wms.estoque.estoque.exception.WMSReunitizacaoEstoqueIdNaoInformadoException;
import com.totvs.sl.wms.estoque.estoque.exception.WMSReunitizacaoNaoPermiteMaisDeUmaOcorrenciaDeEstoqueIdException;
import com.totvs.sl.wms.estoque.sku.domain.model.SKUId;
import com.totvs.sl.wms.estoque.tipoestoque.domain.model.TipoEstoqueId;
import com.totvs.sl.wms.estoque.unidade.domain.model.UnidadeId;
import com.totvs.sl.wms.estoque.unitizador.domain.model.UnitizadorId;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Builder
@AllArgsConstructor(access = AccessLevel.PRIVATE)
@NoArgsConstructor(force = true)
@Getter
@Schema(description = "Informações para reunitização de estoque")
public final class ReunitizarDTO {

	@NotNull(message = "{ReunitizarDTO.unidadeId.NotNull}")
	@Schema(description = "Identificador da unidade")
	private final UnidadeId unidadeId;

	@Deprecated(since = "DWMSSAAS-1673")
	@Schema(description = "Lista de identificadores de estoque")
	private final List<EstoqueId> estoquesId;

	@Valid
	@NotNull(message = "{ReunitizarDTO.destino.NotNull}")
	@Schema(description = "Dados do destino da reuntização")
	private final DestinoDTO destino;

	private final EstoqueId estoqueId;

	@Valid
	private final List<AtributoEstoqueValorDTO> atributos;

	@Data
	@Builder
	@NoArgsConstructor(access = AccessLevel.PRIVATE, force = true)
	@AllArgsConstructor(access = AccessLevel.PRIVATE)
	@Schema(description = "Informações dos dados destino da reunitização")
	public static final class DestinoDTO {

		@NotNull(message = "{ReunitizarDTO.DestinoDTO.skuId.NotNull}")
		@Schema(description = "Identificador do SKU")
		private final SKUId skuId;

		@NotNull(message = "{ReunitizarDTO.DestinoDTO.enderecoId.NotNull}")
		@Schema(description = "Identificador do endereço")
		private final EnderecoId enderecoId;

		@NotNull(message = "{ReunitizarDTO.DestinoDTO.unitizadorId.NotNull}")
		@Schema(description = "Identificador do unitizador")
		private final UnitizadorId unitizadorId;

		@NotNull(message = "{ReunitizarDTO.DestinoDTO.tipoEstoqueId.NotNull}")
		@Schema(description = "Identificador do tipo de estoque")
		private final TipoEstoqueId tipoEstoqueId;

		@NotNull(message = "{ReunitizarDTO.DestinoDTO.avariado.NotNull}")
		@Schema(description = "Identificador de avaria")
		private final Boolean avariado;

		@NotNull(message = "{ReunitizarDTO.DestinoDTO.quantidadeSku.NotNull}")
		@Positive(message = "{ReunitizarDTO.DestinoDTO.quantidadeSku.Positive}")
		@Digits(fraction = QUANTIDADE_MAXIMA_DECIMAIS, integer = QUANTIDADE_MAXIMA_INTEIROS, message = "{ReunitizarDTO.DestinoDTO.quantidadeSku.Digits}")
		@Schema(description = "Quantidade de SKU que serão reunitizadas")
		private final BigDecimal quantidadeSku;

	}

	public EstoqueId obterEstoqueId() {
		if (estoqueId != null)
			return estoqueId;
		if (CollectionUtils.isEmpty(estoquesId))
			throw new WMSReunitizacaoEstoqueIdNaoInformadoException();
		if (estoquesId.size() > 1)
			throw new WMSReunitizacaoNaoPermiteMaisDeUmaOcorrenciaDeEstoqueIdException();
		return estoquesId.get(0);
	}

}
