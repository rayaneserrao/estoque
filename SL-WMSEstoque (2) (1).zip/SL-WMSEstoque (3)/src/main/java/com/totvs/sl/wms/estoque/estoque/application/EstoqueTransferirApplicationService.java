package com.totvs.sl.wms.estoque.estoque.application;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import com.totvs.sl.wms.estoque.bloqueiomovimentacaoestoque.domain.model.BloqueioMovimentacaoEstoqueDomainRepository;
import com.totvs.sl.wms.estoque.bloqueiomovimentacaoestoque.domain.model.BloqueioMovimentacaoEstoqueId;
import com.totvs.sl.wms.estoque.bloqueiomovimentacaounitizador.domain.model.BloqueioMovimentacaoUnitizadorDomainRepository;
import com.totvs.sl.wms.estoque.bloqueiomovimentacaounitizador.domain.model.BloqueioMovimentacaoUnitizadorId;
import com.totvs.sl.wms.estoque.config.amqp.WMSPublisher;
import com.totvs.sl.wms.estoque.endereco.domain.model.Endereco;
import com.totvs.sl.wms.estoque.endereco.domain.model.EnderecoDomainRepository;
import com.totvs.sl.wms.estoque.endereco.domain.model.EnderecoId;
import com.totvs.sl.wms.estoque.endereco.domain.model.FuncaoEndereco;
import com.totvs.sl.wms.estoque.endereco.domain.service.AtualizarOcupacaoPrevistaEnderecoDomainService;
import com.totvs.sl.wms.estoque.estoque.application.command.EfetuarTransferenciaEnderecoEstoqueCommand;
import com.totvs.sl.wms.estoque.estoque.application.command.EfetuarTransferenciaEnderecoReservaEstoqueCommand;
import com.totvs.sl.wms.estoque.estoque.application.command.EfetuarTransferenciaEnderecoUnitizadorEstoqueCommand;
import com.totvs.sl.wms.estoque.estoque.domain.event.EstoqueTransferenciaEnderecoEfetuadaEvent;
import com.totvs.sl.wms.estoque.estoque.domain.event.EstoqueTransferenciaEnderecoUnitizadorEfetuadaEvent;
import com.totvs.sl.wms.estoque.estoque.domain.model.Estoque;
import com.totvs.sl.wms.estoque.estoque.domain.model.EstoqueAtributoSaldo;
import com.totvs.sl.wms.estoque.estoque.domain.model.EstoqueDomainRepository;
import com.totvs.sl.wms.estoque.estoque.domain.model.EstoqueHash;
import com.totvs.sl.wms.estoque.estoque.domain.model.EstoqueId;
import com.totvs.sl.wms.estoque.estoque.domain.model.FracionadoId;
import com.totvs.sl.wms.estoque.estoque.domain.service.AtualizaSaldoEstoqueEntradaDomainService;
import com.totvs.sl.wms.estoque.estoque.domain.service.AtualizaSaldoEstoqueSaidaDomainService;
import com.totvs.sl.wms.estoque.estoque.domain.service.ConfiguraEstoqueParaEntradaDomainService;
import com.totvs.sl.wms.estoque.estoque.domain.service.ValidaInformacoesBasicasEstoqueDomainService;
import com.totvs.sl.wms.estoque.estoque.domain.service.ValidaUnitizadorEstoqueDomainService;
import com.totvs.sl.wms.estoque.estoque.exception.WMSEnderecoOrigemEDestinoIguaisException;
import com.totvs.sl.wms.estoque.estoque.exception.WMSEstoqueJaExistenteParaEnderecoIdEUnitizadorIdException;
import com.totvs.sl.wms.estoque.movimentoestoque.domain.model.MovimentoEstoque;
import com.totvs.sl.wms.estoque.movimentoestoque.domain.model.MovimentoEstoqueDomainRepository;
import com.totvs.sl.wms.estoque.movimentoestoque.domain.model.MovimentoEstoqueId;
import com.totvs.sl.wms.estoque.origem.domain.model.Origem;
import com.totvs.sl.wms.estoque.produto.domain.model.ProdutoDomainRepository;
import com.totvs.sl.wms.estoque.reservadefinitivaestoque.domain.model.ReservaDefinitivaEstoque;
import com.totvs.sl.wms.estoque.reservadefinitivaestoque.domain.model.ReservaDefinitivaEstoqueDomainRepository;
import com.totvs.sl.wms.estoque.sku.domain.model.SKUDomainRepository;
import com.totvs.sl.wms.estoque.unidade.domain.model.UnidadeId;
import com.totvs.sl.wms.estoque.unitizador.domain.model.UnitizadorDomainRepository;
import com.totvs.sl.wms.estoque.unitizador.domain.model.UnitizadorId;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;

@Service
@Transactional
@AllArgsConstructor
public class EstoqueTransferirApplicationService {

	private final MovimentoEstoqueDomainRepository movimentoEstoqueRepository;
	private final EstoqueDomainRepository estoqueRepository;
	private final ReservaDefinitivaEstoqueDomainRepository reservaDefinitivaEstoqueRepository;
	private final ProdutoDomainRepository produtoRepository;
	private final SKUDomainRepository skuRepository;
	private final EnderecoDomainRepository enderecoRepository;
	private final UnitizadorDomainRepository unitizadorRepository;
	private final BloqueioMovimentacaoUnitizadorDomainRepository bloqueioMovimentacaoUnitizadorRepository;
	private final BloqueioMovimentacaoEstoqueDomainRepository bloqueioMovimentacaoEstoqueRepository;
	private final ValidaInformacoesBasicasEstoqueDomainService validaInformacoesBasicasService;
	private final ValidaUnitizadorEstoqueDomainService validaEstoqueUnitizadorService;
	private final ConfiguraEstoqueParaEntradaDomainService configuraEstoqueEntradaService;
	private final AtualizaSaldoEstoqueEntradaDomainService atualizaSaldoEntradaService;
	private final AtualizaSaldoEstoqueSaidaDomainService atualizaSaldoSaidaService;
	private final AtualizarOcupacaoPrevistaEnderecoDomainService atualizarOcupacaoPrevistaEnderecoService;
	private final WMSPublisher publisher;

	@Getter
	@Builder
	public static final class TransferenciaEnderecoEfetuadaEventEstoquesMovimentos {
		private EstoqueTransferenciaEnderecoEfetuadaEvent evento;
		private EstoqueSaidaEntrada estoques;
		private MovimentoEstoque movimentoSaida;
		private MovimentoEstoque movimentoEntrada;
	}

	public EstoqueId handle(final EfetuarTransferenciaEnderecoEstoqueCommand cmd) {

		validaInformacoesBasicasService.existeEnderecoParaUnidade(cmd.getUnidadeId(), cmd.getEnderecoId());

		validaEstoqueUnitizadorService.existeEmOutroEstoqueEOutroEndereco(cmd.getEstoqueId(),
																		  cmd.getUnidadeId(),
																		  cmd.getUnitizadorId().orElse(null),
																		  cmd.getEnderecoId());

		var estoqueSaida = estoqueRepository.findWithLockByIdAndUnidadeIdOrThrowNotFound(cmd.getEstoqueId(),
																						 cmd.getUnidadeId());

		this.validarSeEnderecoOrigemEDestinoSaoIguais(estoqueSaida.getEnderecoId(), cmd.getEnderecoId());

		validaEstoqueUnitizadorService.idDiferenteBloqueioMovimentacaoUnitizador(cmd.getBloqueioMovimentacaoUnitizadorId()
																					.orElse(null),
																				 estoqueSaida.getUnitizadorId());

		var reservasIds = cmd.getReservasDefinitivas(estoqueSaida);
		var reservasDefinitivas = reservasIds.stream()
											 .map(reservaDefinitivaEstoqueRepository::findWithLockByIdOrThrowNotFound)
											 .toList();

		Endereco endereco = null;

		if (cmd.getBloqueioMovimentacaoEstoqueId().isPresent()) {

			var sku = skuRepository.findByIdOrThrowNotFound(estoqueSaida.getSkuId());

			var bloqueio = bloqueioMovimentacaoEstoqueRepository.findWithLockByIdOrThrowNotFound(cmd.getBloqueioMovimentacaoEstoqueId()
																									.orElseThrow());

			if (bloqueio.getEnderecoIdDestino().isPresent())
				endereco = atualizarOcupacaoPrevistaEnderecoService.diminuir(bloqueio.getEnderecoIdDestino()
																					 .orElseThrow(),
																			 sku,
																			 cmd.getQuantidade(estoqueSaida));

		}

		var eventoMovimentos = this.efetuarTransferenciaEstoque(estoqueSaida,
																cmd.getOrigem(),
																cmd.getEnderecoId(),
																cmd.getQuantidade(estoqueSaida),
																cmd.getBloqueioMovimentacaoEstoqueId().orElse(null),
																reservasDefinitivas,
																cmd.getBloqueioMovimentacaoUnitizadorId().orElse(null),
																cmd.getUnitizadorId().orElse(null),
																cmd.getChaveAcesso().orElse(null),
																cmd.getAtributosSaldo(estoqueSaida),
																false);

		eventoMovimentos.getMovimentoSaida().getEvents().forEach(publisher::dispatch);
		eventoMovimentos.getMovimentoEntrada().getEvents().forEach(publisher::dispatch);

		publisher.dispatch(eventoMovimentos.getEvento());

		if (endereco != null)
			publisher.dispatch(endereco.getEvents());

		return eventoMovimentos.getMovimentoEntrada().getEstoqueId();

	}

	public EstoqueId handle(final EfetuarTransferenciaEnderecoReservaEstoqueCommand cmd) {

		validaInformacoesBasicasService.existeEnderecoParaUnidade(cmd.getUnidadeId(), cmd.getEnderecoId());

		var reservaSaida = reservaDefinitivaEstoqueRepository.findWithLockByIdOrThrowNotFound(cmd.getReservaDefinitivaEstoqueId());

		var estoqueSaida = estoqueRepository.findWithLockByIdAndUnidadeIdOrThrowNotFound(reservaSaida.getEstoqueId(),
																						 cmd.getUnidadeId());

		cmd.getUnitizadorId()
		   .ifPresent(unitizadorId -> validaEstoqueUnitizadorService.existeEmOutroEndereco(cmd.getUnidadeId(),
																						   unitizadorId,
																						   estoqueSaida.getEnderecoId(),
																						   cmd.getEnderecoId()));

		this.validarSeEnderecoOrigemEDestinoSaoIguais(estoqueSaida.getEnderecoId(), cmd.getEnderecoId());

		Endereco endereco = null;

		if (cmd.getBloqueioMovimentacaoEstoqueId().isPresent()) {

			var sku = skuRepository.findByIdOrThrowNotFound(estoqueSaida.getSkuId());

			var bloqueio = bloqueioMovimentacaoEstoqueRepository.findWithLockByIdOrThrowNotFound(cmd.getBloqueioMovimentacaoEstoqueId()
																									.orElseThrow());

			if (bloqueio.getEnderecoIdDestino().isPresent())
				endereco = atualizarOcupacaoPrevistaEnderecoService.diminuir(bloqueio.getEnderecoIdDestino()
																					 .orElseThrow(),
																			 sku,
																			 reservaSaida.getQuantidade());
		}

		var eventoMovimentos = this.efetuarTransferenciaEstoque(estoqueSaida,
																cmd.getOrigem(),
																cmd.getEnderecoId(),
																reservaSaida.getQuantidade(),
																cmd.getBloqueioMovimentacaoEstoqueId().orElse(null),
																List.of(reservaSaida),
																null,
																cmd.getUnitizadorId().orElse(null),
																cmd.getAtributosSaldo(estoqueSaida, reservaSaida),
																true);

		eventoMovimentos.getMovimentoSaida().getEvents().forEach(publisher::dispatch);
		eventoMovimentos.getMovimentoEntrada().getEvents().forEach(publisher::dispatch);

		publisher.dispatch(eventoMovimentos.getEvento());

		if (endereco != null)
			publisher.dispatch(endereco.getEvents());

		return eventoMovimentos.getMovimentoEntrada().getEstoqueId();

	}

	public List<EstoqueSaidaEntrada> handle(final EfetuarTransferenciaEnderecoUnitizadorEstoqueCommand cmd) {

		var enderecoDestino = enderecoRepository.findByIdAndUnidadeIdOrThrowNotFound(cmd.getEnderecoId(),
																					 cmd.getUnidadeId());

		unitizadorRepository.findWithLockByIdAndUnidadeIdOrThrowNotFound(cmd.getUnitizadorId(), cmd.getUnidadeId());

		this.validarSeEnderecoIdUnitizadorIdUnidadeIdJaExiste(cmd.getUnidadeId(),
															  cmd.getEnderecoId(),
															  cmd.getUnitizadorId());

		validaEstoqueUnitizadorService.idDiferenteBloqueioMovimentacaoUnitizador(cmd.getBloqueioMovimentacaoUnitizadorId()
																					.orElse(null),
																				 cmd.getUnitizadorId());

		var listaEstoquesOrigem = estoqueRepository.findWithLockByUnitizadorIdAndUnidadeId(cmd.getUnitizadorId(),
																						   cmd.getUnidadeId());

		validaEstoqueUnitizadorService.existeNaListaEstoques(listaEstoquesOrigem);

		validaEstoqueUnitizadorService.existeEmOutroEndereco(cmd.getUnidadeId(),
															 cmd.getUnitizadorId(),
															 listaEstoquesOrigem.stream()
																				.iterator()
																				.next()
																				.getEnderecoId(),
															 cmd.getEnderecoId());

		var unitizadorId = enderecoDestino.getFuncao() == FuncaoEndereco.PICKING ? null : cmd.getUnitizadorId();
		var listaTransferencias = new ArrayList<TransferenciaEnderecoEfetuadaEventEstoquesMovimentos>();

		Endereco endereco = null;

		if (cmd.getBloqueioMovimentacaoUnitizadorId().isPresent()) {

			var bloqueio = bloqueioMovimentacaoUnitizadorRepository.findWithLockByIdOrThrowNotFound(cmd.getBloqueioMovimentacaoUnitizadorId()
																									   .orElseThrow());

			if (bloqueio.getEnderecoIdDestino().isPresent())
				endereco = atualizarOcupacaoPrevistaEnderecoService.diminuir(bloqueio.getEnderecoIdDestino()
																					 .orElseThrow(),
																			 listaEstoquesOrigem);
		}

		for (var estoqueSaida : listaEstoquesOrigem) {

			var evento = this.efetuarTransferenciaEstoque(estoqueSaida,
														  cmd.getOrigem(),
														  cmd.getEnderecoId(),
														  estoqueSaida.getSaldo(),
														  null,
														  List.of(),
														  cmd.getBloqueioMovimentacaoUnitizadorId().orElse(null),
														  unitizadorId,
														  cmd.getChaveAcesso(),
														  estoqueSaida.getAtributosSaldo(),
														  false);

			listaTransferencias.add(evento);

		}

		var movimentosSaida = listaTransferencias.stream()
												 .map(eventoMovimentos -> eventoMovimentos.getMovimentoSaida())
												 .collect(Collectors.toList());

		var movimentosEntrada = listaTransferencias.stream()
												   .map(eventoMovimentos -> eventoMovimentos.getMovimentoEntrada())
												   .collect(Collectors.toList());

		var estoquesTransferencia = listaTransferencias.stream()
													   .map(eventoMovimentos -> eventoMovimentos.getEstoques())
													   .collect(Collectors.toList());

		movimentosSaida.forEach(movimento -> movimento.getEvents().forEach(publisher::dispatch));
		movimentosEntrada.forEach(movimento -> movimento.getEvents().forEach(publisher::dispatch));

		if (endereco != null)
			publisher.dispatch(endereco.getEvents());

		publisher.dispatch(EstoqueTransferenciaEnderecoUnitizadorEfetuadaEvent.from(cmd.getUnidadeId(),
																					enderecoDestino,
																					estoquesTransferencia,
																					cmd.getBloqueioMovimentacaoUnitizadorId()
																					   .orElse(null)));

		return estoquesTransferencia;

	}

	private TransferenciaEnderecoEfetuadaEventEstoquesMovimentos efetuarTransferenciaEstoque(Estoque estoqueSaida, // NOSONAR
																							 Origem origem,
																							 EnderecoId enderecoId,
																							 BigDecimal quantidade,
																							 BloqueioMovimentacaoEstoqueId bloqueioMovimentacaoEstoqueId,
																							 List<ReservaDefinitivaEstoque> reservasDefinitivas,
																							 BloqueioMovimentacaoUnitizadorId bloqueioMovimentacaoUnitizadorId,
																							 UnitizadorId unitizadorId,
																							 List<EstoqueAtributoSaldo> atributosSaldo,
																							 boolean manterAtributosReserva) {
		return this.efetuarTransferenciaEstoque(estoqueSaida,
												origem,
												enderecoId,
												quantidade,
												bloqueioMovimentacaoEstoqueId,
												reservasDefinitivas,
												bloqueioMovimentacaoUnitizadorId,
												unitizadorId,
												null,
												atributosSaldo,
												manterAtributosReserva);
	}

	private TransferenciaEnderecoEfetuadaEventEstoquesMovimentos efetuarTransferenciaEstoque(Estoque estoqueSaida, // NOSONAR
																							 Origem origem,
																							 EnderecoId enderecoId,
																							 BigDecimal quantidade,
																							 BloqueioMovimentacaoEstoqueId bloqueioMovimentacaoEstoqueId,
																							 List<ReservaDefinitivaEstoque> reservasDefinitivas,
																							 BloqueioMovimentacaoUnitizadorId bloqueioMovimentacaoUnitizadorId,
																							 UnitizadorId unitizadorId,
																							 String chaveAcesso,
																							 List<EstoqueAtributoSaldo> atributosSaldo,
																							 boolean manterAtributosReserva) {

		var produto = produtoRepository.findByIdOrThrowNotFound(estoqueSaida.getProdutoId());

		var sku = skuRepository.findByIdAndProdutoIdThrowNotFound(estoqueSaida.getSkuId(), estoqueSaida.getProdutoId());

		var enderecoDestino = enderecoRepository.findByIdOrThrowNotFound(enderecoId);

		var rastreioId = configuraEstoqueEntradaService.definirRastreio(quantidade, estoqueSaida);

		var movimentoEstoqueIdSaida = MovimentoEstoqueId.generate();
		var movimentoEstoqueIdEntrada = MovimentoEstoqueId.generate();

		var estoqueHash = EstoqueHash.builder()
									 .unidadeId(estoqueSaida.getUnidadeId())
									 .produtoId(estoqueSaida.getProdutoId())
									 .skuId(estoqueSaida.getSkuId())
									 .tipoEstoqueId(estoqueSaida.getTipoEstoqueId())
									 .avariado(estoqueSaida.getAvariado())
									 .caracteristicas(estoqueSaida.getCaracteristicas())
									 .situacoes(estoqueSaida.getSituacoes())
									 .enderecoId(enderecoDestino.getId())
									 .fracionadoId(sku.isFracionado() ? FracionadoId.generate() : null)
									 .unitizadorId(unitizadorId)
									 .build();

		var estoqueEntrada = configuraEstoqueEntradaService.configurar(produto,
																	   sku,
																	   estoqueSaida.getSituacoes().iterator().next(),
																	   estoqueHash,
																	   rastreioId,
																	   estoqueSaida.getSelos(),
																	   estoqueSaida.getDataHoraEntrada());

		var enderecoSaida = enderecoRepository.findByIdOrThrowNotFound(estoqueSaida.getEnderecoId());

		var atributosSaldoSaida = CollectionUtils.isEmpty(atributosSaldo) ? null
				: new ArrayList<EstoqueAtributoSaldo>(atributosSaldo);

		var atributosSaldoEntrada = CollectionUtils.isEmpty(atributosSaldo) ? null
				: new ArrayList<EstoqueAtributoSaldo>(atributosSaldo);

		var movimentoEstoqueSaida = estoqueSaida.efetuarSaidaTransferencia(produto,
																		   sku,
																		   origem,
																		   quantidade,
																		   bloqueioMovimentacaoEstoqueId,
																		   bloqueioMovimentacaoUnitizadorId,
																		   reservasDefinitivas,
																		   movimentoEstoqueIdSaida,
																		   movimentoEstoqueIdEntrada,
																		   estoqueEntrada.getRastreioId(),
																		   enderecoSaida,
																		   this.determinarAlteraOcupacaoEndereco(enderecoSaida),
																		   chaveAcesso,
																		   atributosSaldoSaida);

		atualizaSaldoSaidaService.atualizar(estoqueSaida);

		movimentoEstoqueRepository.insert(movimentoEstoqueSaida);

		validaEstoqueUnitizadorService.ocupacaoUnitizadorEndereco(unitizadorId, enderecoDestino);

		var movimentoEstoqueEntrada = estoqueEntrada.efetuarEntradaTransferencia(origem,
																				 enderecoDestino,
																				 quantidade,
																				 reservasDefinitivas,
																				 movimentoEstoqueIdEntrada,
																				 movimentoEstoqueIdSaida,
																				 estoqueSaida.getRastreioId(),
																				 this.determinarAlteraOcupacaoEndereco(enderecoDestino),
																				 produto,
																				 sku,
																				 atributosSaldoEntrada,
																				 manterAtributosReserva);

		atualizaSaldoEntradaService.atualizar(estoqueEntrada);

		if (!CollectionUtils.isEmpty(reservasDefinitivas))
			reservasDefinitivas.forEach(reservaDefinitiva -> reservaDefinitivaEstoqueRepository.update(reservaDefinitiva));

		movimentoEstoqueRepository.insert(movimentoEstoqueEntrada);

		if (bloqueioMovimentacaoEstoqueId != null)
			bloqueioMovimentacaoEstoqueRepository.delete(bloqueioMovimentacaoEstoqueId);

		if (bloqueioMovimentacaoUnitizadorId != null
				&& !estoqueRepository.existsByBloqueioMovimentacaoUnitizadorId(bloqueioMovimentacaoUnitizadorId))
			bloqueioMovimentacaoUnitizadorRepository.delete(bloqueioMovimentacaoUnitizadorId);

		var unitizadorPossuiSaldoRestante = false;
		if (estoqueSaida.getUnitizadorId() != null) {
			unitizadorPossuiSaldoRestante = estoqueRepository.existsByUnitizadorIdAndEnderecoId(estoqueSaida.getUnitizadorId(),
																								estoqueSaida.getEnderecoId());
		}

		estoqueSaida.removeEvents();
		estoqueEntrada.removeEvents();

		return TransferenciaEnderecoEfetuadaEventEstoquesMovimentos.builder()
																   .evento(EstoqueTransferenciaEnderecoEfetuadaEvent.from(estoqueSaida,
																														  estoqueEntrada,
																														  reservasDefinitivas,
																														  bloqueioMovimentacaoEstoqueId,
																														  unitizadorPossuiSaldoRestante,
																														  origem))
																   .estoques(EstoqueSaidaEntrada.of(estoqueSaida.getUnidadeId(),
																									EstoqueSaida.from(estoqueSaida),
																									estoqueEntrada))
																   .movimentoEntrada(movimentoEstoqueEntrada)
																   .movimentoSaida(movimentoEstoqueSaida)
																   .build();
	}

	private void validarSeEnderecoOrigemEDestinoSaoIguais(EnderecoId enderecoIdOrigem, EnderecoId enderecoIdDestino) {
		if (enderecoIdOrigem.equals(enderecoIdDestino))
			throw new WMSEnderecoOrigemEDestinoIguaisException();
	}

	private void validarSeEnderecoIdUnitizadorIdUnidadeIdJaExiste(UnidadeId unidadeId,
																  EnderecoId enderecoId,
																  UnitizadorId unitizadorId) {
		if (estoqueRepository.existeEstoqueComUnitizadorIdAndEnderecoIdAndUnidadeId(unidadeId,
																					enderecoId,
																					unitizadorId))
			throw new WMSEstoqueJaExistenteParaEnderecoIdEUnitizadorIdException();
	}

	private boolean determinarAlteraOcupacaoEndereco(Endereco endereco) {
		return !endereco.isDoca() && !endereco.isStage();
	}
}
