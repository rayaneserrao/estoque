package com.totvs.sl.wms.estoque.atributoestoque.application;

import javax.transaction.Transactional;

import org.springframework.stereotype.Service;

import com.totvs.sl.wms.estoque.atributoestoque.application.command.ExcluirAtributoEstoqueCommand;
import com.totvs.sl.wms.estoque.atributoestoque.application.metric.EstoqueAtributosMetricService;
import com.totvs.sl.wms.estoque.atributoestoque.domain.model.AtributoEstoqueDomainRepository;
import com.totvs.sl.wms.estoque.config.amqp.WMSPublisher;

import lombok.AllArgsConstructor;

@Service
@Transactional
@AllArgsConstructor
public class AtributoEstoqueExcluirApplicationService {

	private AtributoEstoqueDomainRepository repository;
	private WMSPublisher publisher;
	private final EstoqueAtributosMetricService totalAtributosMetricService;

	public void handle(ExcluirAtributoEstoqueCommand cmd) {

		var atributoEstoque = repository.findByIdOrThrowNotFound(cmd.getId());

		atributoEstoque.excluir();

		repository.delete(cmd.getId());

		atributoEstoque.getEvents().forEach(publisher::dispatch);

		totalAtributosMetricService.atributoExcluido();
	}

}
