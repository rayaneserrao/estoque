package com.totvs.sl.wms.estoque.estoque.domain.model;

import static com.totvs.tjf.autoconfigure.ValidationUtils.validateIntegrity;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.TreeSet;

import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.Digits;
import javax.validation.constraints.NotNull;

import org.springframework.util.CollectionUtils;

import com.totvs.sl.wms.estoque.atributoestoque.domain.model.AtributoEstoqueId;
import com.totvs.sl.wms.estoque.atributoestoque.domain.model.ControleQuantidadeAtributoEstoqueValor;
import com.totvs.sl.wms.estoque.atributoestoquevalor.domain.model.AtributoEstoqueValor;
import com.totvs.sl.wms.estoque.estoque.exception.WMSEstoqueAtributoQuantidadeExcluirReservaSuperiorAoReservadoException;
import com.totvs.sl.wms.estoque.estoque.exception.WMSEstoqueAtributosRestantesReservaDivergemQuantidadeReservadaException;
import com.totvs.sl.wms.estoque.estoque.exception.WMSEstoqueReservaDefinitivaConstraintException;
import com.totvs.sl.wms.estoque.reservadefinitivaestoque.domain.model.ReservaDefinitivaEstoqueId;
import com.totvs.sl.wms.estoque.util.CompareUtils;
import com.totvs.tjf.core.stereotype.Aggregate;

import lombok.AccessLevel;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.EqualsAndHashCode.Include;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Getter
@Aggregate
@NoArgsConstructor(access = AccessLevel.PRIVATE)
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
public final class EstoqueReservaDefinitiva {

	@Include
	@NotNull(message = "{EstoqueReservaDefinitiva.reservaDefinitivaEstoqueId.NotNull}")
	private ReservaDefinitivaEstoqueId reservaDefinitivaEstoqueId;

	@NotNull(message = "{EstoqueReservaDefinitiva.quantidade.NotNull}")
	@DecimalMin(value = "0.0001", message = "{EstoqueReservaDefinitiva.quantidade.DecimalMin}")
	@Digits(fraction = 4, integer = 11, message = "{EstoqueReservaDefinitiva.quantidade.Digits}")
	private BigDecimal quantidade;

	private List<EstoqueAtributoSaldo> atributosSaldo = new ArrayList<>();

	@Builder
	private EstoqueReservaDefinitiva(ReservaDefinitivaEstoqueId reservaDefinitivaEstoqueId,
									 BigDecimal quantidade,
									 List<EstoqueAtributoSaldo> atributos) {
		this.reservaDefinitivaEstoqueId = reservaDefinitivaEstoqueId;
		this.quantidade = quantidade;

		if (Objects.nonNull(atributos))
			this.atributosSaldo.addAll(atributos);

		validateIntegrity(this).ifPresent(violations -> {
			throw new WMSEstoqueReservaDefinitivaConstraintException(violations);
		});
	}

	public BigDecimal getQuantidadeReservadaAtributo(EstoqueAtributoSaldo estoqueAtributo) {
		var atributoOpt = this.atributosSaldo.stream().filter(atributo -> atributo.equals(estoqueAtributo)).findAny();
		if (atributoOpt.isPresent())
			return atributoOpt.orElseThrow().getSaldo();
		else
			return BigDecimal.ZERO;
	}

	public List<EstoqueAtributoSaldo> atualizarAtributos(BigDecimal quantidadeReservadaRestante,
														 List<EstoqueAtributoSaldo> estoqueAtributosExcluir) {

		if (CollectionUtils.isEmpty(this.getAtributosSaldo()) && CollectionUtils.isEmpty(estoqueAtributosExcluir))
			return Collections.emptyList();

		List<EstoqueAtributoSaldo> atributosRestantes = new ArrayList<>();

		atributosRestantes.addAll(this.getAtributosSaldo()
									  .stream()
									  .filter(atributo -> !estoqueAtributosExcluir.contains(atributo))
									  .toList());

		estoqueAtributosExcluir.forEach(atributoExcluir -> {

			var estoqueAtributoExcluido = this.getAtributosSaldo()
											  .stream()
											  .filter(atributo -> atributo.equals(atributoExcluir))
											  .findAny()
											  .orElseThrow();

			if (CompareUtils.greatherThan(estoqueAtributoExcluido.getSaldo(), atributoExcluir.getSaldo())) {

				List<AtributoEstoqueValor<?>> atributoValorAtualizado = new ArrayList<>();

				estoqueAtributoExcluido.getAtributos().forEach(atributoValorExcluido -> {

					TreeSet<Object> valorAtributoEstoqueAtualizar = new TreeSet<>();

					if (atributoValorExcluido.getControleQuantidade()
											 .equals(ControleQuantidadeAtributoEstoqueValor.SERIAL)) {

						var atributoValorExcluir = atributoExcluir.getAtributos()
																  .stream()
																  .filter(valorExcluir -> valorExcluir.getId()
																									  .equals(atributoValorExcluido.getId()))
																  .findAny()
																  .orElseThrow();

						atributoValorExcluido.getValores().forEach(valorExcluido -> {

							if (!atributoValorExcluir.getValores().contains(valorExcluido))
								valorAtributoEstoqueAtualizar.add(valorExcluido);
						});
					} else {
						valorAtributoEstoqueAtualizar.addAll(atributoValorExcluido.getValores());
					}

					atributoValorAtualizado.add(atributoValorExcluido.getFormato()
																	 .getInstance(atributoValorExcluido.getId(),
																				  valorAtributoEstoqueAtualizar,
																				  atributoValorExcluido.getControleQuantidade()));

				});

				atributosRestantes.add(EstoqueAtributoSaldo.of(atributoValorAtualizado,
															   estoqueAtributoExcluido.getSaldo()
																					  .subtract(atributoExcluir.getSaldo())));

			} else if (CompareUtils.lessThan(estoqueAtributoExcluido.getSaldo(), atributoExcluir.getSaldo())) {
				throw new WMSEstoqueAtributoQuantidadeExcluirReservaSuperiorAoReservadoException(atributoExcluir.toString(),
																								 estoqueAtributoExcluido.getSaldo(),
																								 atributoExcluir.getSaldo());
			}

		});

		var quantidadeAtributosRestantes = atributosRestantes.stream()
															 .map(EstoqueAtributoSaldo::getSaldo)
															 .reduce(BigDecimal.ZERO, BigDecimal::add);

		if (!CompareUtils.equalTo(quantidadeAtributosRestantes, quantidadeReservadaRestante))
			throw new WMSEstoqueAtributosRestantesReservaDivergemQuantidadeReservadaException(quantidadeReservadaRestante,
																							  quantidadeAtributosRestantes);

		return atributosRestantes;
	}

	public boolean existeAtributoSerial(AtributoEstoqueId atributoEstoqueId, Object valor) {

		return this.atributosSaldo.stream()
								  .flatMap(atributoSaldo -> atributoSaldo.getAtributos().stream())
								  .anyMatch(atributo -> atributo.getId().equals(atributoEstoqueId)
										  && atributo.getValores()
													 .stream()
													 .map(Object::toString)
													 .anyMatch(v -> v.equals(valor.toString())));
	}
}
