package com.totvs.sl.wms.estoque.estoque.amqp.cmd;

import java.math.BigDecimal;
import java.util.List;
import java.util.Set;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import com.totvs.sl.wms.estoque.atributoestoquevalor.amqp.cmd.AtributoEstoqueValorCmd;
import com.totvs.sl.wms.estoque.atributoestoquevalor.domain.model.AtributoEstoqueValor;
import com.totvs.sl.wms.estoque.bloqueiomovimentacaoestoque.domain.model.BloqueioMovimentacaoEstoqueId;
import com.totvs.sl.wms.estoque.bloqueiomovimentacaounitizador.domain.model.BloqueioMovimentacaoUnitizadorId;
import com.totvs.sl.wms.estoque.endereco.domain.model.EnderecoId;
import com.totvs.sl.wms.estoque.estoque.amqp.cmd.validator.ValidarAtributosOpcionaisTransferenciaEstoque;
import com.totvs.sl.wms.estoque.estoque.domain.model.EstoqueId;
import com.totvs.sl.wms.estoque.reservadefinitivaestoque.domain.model.ReservaDefinitivaEstoqueId;
import com.totvs.sl.wms.estoque.unidade.domain.model.UnidadeId;
import com.totvs.sl.wms.estoque.unitizador.domain.model.UnitizadorId;
import com.totvs.tjf.core.common.CollectionUtils;

import lombok.Builder;
import lombok.Data;
import lombok.Singular;

@Data
@Builder
@ValidarAtributosOpcionaisTransferenciaEstoque
public final class EfetuarTransferenciaEnderecoEstoqueCmd {

	public static final String NAME = "EfetuarTransferenciaEnderecoEstoqueCmd";

	public static final String CONDITIONAL_EXPRESSION = "headers['type']=='" + NAME + "'";

	@NotNull(message = "{EfetuarTransferenciaEnderecoEstoqueCmd.unidadeId.NotNull}")
	private final UnidadeId unidadeId;

	@NotNull(message = "{EfetuarTransferenciaEnderecoEstoqueCmd.estoqueId.NotNull}")
	private final EstoqueId estoqueId;

	@NotNull(message = "{EfetuarTransferenciaEnderecoEstoqueCmd.enderecoId.NotNull}")
	private final EnderecoId enderecoId;

	private final BigDecimal quantidade;

	private final BloqueioMovimentacaoEstoqueId bloqueioMovimentacaoEstoqueId;

	private final BloqueioMovimentacaoUnitizadorId bloqueioMovimentacaoUnitizadorId;

	@Singular("reservaDefinitiva")
	private final Set<ReservaDefinitivaEstoqueId> reservasDefinitivas;

	private final UnitizadorId unitizadorId;

	private final String chaveAcesso;

	@Valid
	private final List<AtributoEstoqueValorCmd> atributos;

	public Set<ReservaDefinitivaEstoqueId> getReservasDefinitivas() {
		return CollectionUtils.unmodifiable(this.reservasDefinitivas);
	}

	public final List<AtributoEstoqueValor<?>> getAtributos() { // NOSONAR
		return AtributoEstoqueValorCmd.toAtributoEstoqueValor(this.atributos);
	}
}
