package com.totvs.sl.wms.estoque.estoque.application;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.totvs.sl.wms.estoque.caracteristicaconfiguracao.domain.model.CaracteristicaConfiguracaoDomainRepository;
import com.totvs.sl.wms.estoque.caracteristicaconfiguracao.domain.model.CaracteristicaConfiguracaoId;
import com.totvs.sl.wms.estoque.caracteristicavalor.domain.model.CaracteristicaValor;
import com.totvs.sl.wms.estoque.config.amqp.WMSPublisher;
import com.totvs.sl.wms.estoque.estoque.application.command.AdicionarCaracteristicaEstoqueCommand;
import com.totvs.sl.wms.estoque.estoque.application.command.RemoverCaracteristicaEstoqueCommand;
import com.totvs.sl.wms.estoque.estoque.domain.event.EstoqueSaldoAtualizadoEvent;
import com.totvs.sl.wms.estoque.estoque.domain.model.Estoque;
import com.totvs.sl.wms.estoque.estoque.domain.model.EstoqueDomainRepository;
import com.totvs.sl.wms.estoque.estoque.domain.model.EstoqueHash;
import com.totvs.sl.wms.estoque.estoque.domain.model.FracionadoId;
import com.totvs.sl.wms.estoque.estoque.domain.model.SituacaoEstoqueBloqueado;
import com.totvs.sl.wms.estoque.estoque.domain.service.AtualizaSaldoEstoqueEntradaDomainService;
import com.totvs.sl.wms.estoque.estoque.domain.service.AtualizaSaldoEstoqueSaidaDomainService;
import com.totvs.sl.wms.estoque.estoque.domain.service.ConfiguraEstoqueParaEntradaDomainService;
import com.totvs.sl.wms.estoque.estoque.domain.service.ValidaInformacoesBasicasEstoqueDomainService;
import com.totvs.sl.wms.estoque.estoque.exception.WMSEstoqueBloqueadoComChaveAcessoNaoPodeTerCaracteristicaAdicionadaException;
import com.totvs.sl.wms.estoque.estoque.exception.WMSEstoqueBloqueadoComChaveAcessoNaoPodeTerCaracteristicaRemovidaException;
import com.totvs.sl.wms.estoque.movimentoestoque.domain.model.MovimentoEstoque;
import com.totvs.sl.wms.estoque.movimentoestoque.domain.model.MovimentoEstoqueDomainRepository;
import com.totvs.sl.wms.estoque.movimentoestoque.domain.model.MovimentoEstoqueId;
import com.totvs.sl.wms.estoque.origem.domain.model.Origem;
import com.totvs.sl.wms.estoque.origem.domain.model.OrigemId;
import com.totvs.sl.wms.estoque.produto.domain.model.ProdutoDomainRepository;
import com.totvs.sl.wms.estoque.produto.domain.model.ProdutoId;
import com.totvs.sl.wms.estoque.sku.domain.model.SKUDomainRepository;

import lombok.AllArgsConstructor;

@Service
@Transactional
@AllArgsConstructor
public class EstoqueAdicionarRemoverCaracteristicaApplicationService {

	private final MovimentoEstoqueDomainRepository movimentoEstoqueRepository;
	private final EstoqueDomainRepository estoqueRepository;
	private final ProdutoDomainRepository produtoRepository;
	private final SKUDomainRepository skuRepository;
	private final CaracteristicaConfiguracaoDomainRepository configuracaoRepository;
	private final ValidaInformacoesBasicasEstoqueDomainService validaInformacoesBasicasService;
	private final ConfiguraEstoqueParaEntradaDomainService configuraEstoqueEntradaService;
	private final AtualizaSaldoEstoqueEntradaDomainService atualizaSaldoEntradaService;
	private final AtualizaSaldoEstoqueSaidaDomainService atualizaSaldoSaidaService;
	private final WMSPublisher publisher;

	public EstoquesSaidaEntradaMovimentoLista handle(final AdicionarCaracteristicaEstoqueCommand cmd) {

		validaInformacoesBasicasService.existeProdutoAtivo(cmd.getProdutoId());
		validaInformacoesBasicasService.existeCaracteristicaConfiguracao(cmd.getCaracteristicaConfiguracaoId());

		var listaEstoquesOrigem = estoqueRepository.findWithLockByProdutoId(cmd.getProdutoId());

		List<EstoqueSaida> estoquesSaida = new ArrayList<>();
		List<Estoque> estoquesEntrada = new ArrayList<>();
		List<MovimentoEstoque> movimentosSaida = new ArrayList<>();
		List<MovimentoEstoque> movimentosEntrada = new ArrayList<>();

		for (var estoqueSaida : listaEstoquesOrigem) {

			if (this.verificarEstoqueBloqueadoComChaveAcessoESemNovaCaracteristica(estoqueSaida,
																				   cmd.getCaracteristicaConfiguracaoId())) {
				throw new WMSEstoqueBloqueadoComChaveAcessoNaoPodeTerCaracteristicaAdicionadaException();
			}

			if (this.verificarEstoqueContemCaracteristica(estoqueSaida, cmd.getCaracteristicaConfiguracaoId()))
				continue;

			var origem = Origem.of(OrigemId.from(UUID.randomUUID().toString()),
								   "AdicionarCaracteristicaEstoqueCommand");

			var estoquesMovimentos = this.adicionarCaracteristicaEstoque(estoqueSaida,
																		 cmd.getCaracteristicaConfiguracaoId(),
																		 cmd.getValorPadrao(),
																		 origem);

			movimentosSaida.add(estoquesMovimentos.getMovimentoSaida());
			movimentosEntrada.add(estoquesMovimentos.getMovimentoEntrada());
			estoquesSaida.add(estoquesMovimentos.getEstoques().getEstoqueSaida());
			estoquesMovimentos.removerEstoqueComSaldoDesatualizado(estoquesEntrada);
			estoquesEntrada.add(estoquesMovimentos.getEstoques().getEstoqueEntrada());

		}

		this.publicarEventosAtualizacaoCaracteristicas(cmd.getProdutoId(),
													   estoquesSaida,
													   estoquesEntrada,
													   movimentosSaida,
													   movimentosEntrada);

		return new EstoquesSaidaEntradaMovimentoLista(estoquesSaida,
													  estoquesEntrada,
													  movimentosSaida,
													  movimentosEntrada);

	}

	public EstoquesSaidaEntradaMovimentoLista handle(final RemoverCaracteristicaEstoqueCommand cmd) {

		validaInformacoesBasicasService.existeProdutoAtivo(cmd.getProdutoId());
		validaInformacoesBasicasService.existeCaracteristicaConfiguracao(cmd.getCaracteristicaConfiguracaoId());

		var listaEstoquesOrigem = estoqueRepository.findWithLockByProdutoId(cmd.getProdutoId());

		List<EstoqueSaida> estoquesSaida = new ArrayList<>();
		List<Estoque> estoquesEntrada = new ArrayList<>();
		List<MovimentoEstoque> movimentosSaida = new ArrayList<>();
		List<MovimentoEstoque> movimentosEntrada = new ArrayList<>();

		for (var estoqueSaida : listaEstoquesOrigem) {

			if (this.verificarEstoqueBloqueadoComChaveAcessoEComCaracteristicaRemovida(estoqueSaida,
																					   cmd.getCaracteristicaConfiguracaoId())) {
				throw new WMSEstoqueBloqueadoComChaveAcessoNaoPodeTerCaracteristicaRemovidaException();
			}

			if (!this.verificarEstoqueContemCaracteristica(estoqueSaida, cmd.getCaracteristicaConfiguracaoId()))
				continue;

			var origem = Origem.of(OrigemId.from(UUID.randomUUID().toString()), "RemoverCaracteristicaEstoqueCommand");

			var estoquesMovimentos = this.removerCaracteristicaEstoque(estoqueSaida,
																	   cmd.getCaracteristicaConfiguracaoId(),
																	   origem);

			movimentosSaida.add(estoquesMovimentos.getMovimentoSaida());
			movimentosEntrada.add(estoquesMovimentos.getMovimentoEntrada());
			estoquesSaida.add(estoquesMovimentos.getEstoques().getEstoqueSaida());
			estoquesMovimentos.removerEstoqueComSaldoDesatualizado(estoquesEntrada);
			estoquesEntrada.add(estoquesMovimentos.getEstoques().getEstoqueEntrada());

		}

		this.publicarEventosAtualizacaoCaracteristicas(cmd.getProdutoId(),
													   estoquesSaida,
													   estoquesEntrada,
													   movimentosSaida,
													   movimentosEntrada);

		return new EstoquesSaidaEntradaMovimentoLista(estoquesSaida,
													  estoquesEntrada,
													  movimentosSaida,
													  movimentosEntrada);
	}

	private EstoquesSaidaEntradaMovimentos adicionarCaracteristicaEstoque(Estoque estoqueSaida,
																		  CaracteristicaConfiguracaoId caracteristicaConfiguracaoId,
																		  String valorPadrao,
																		  Origem origem) {

		var saldoAMovimentar = estoqueSaida.getSaldo();

		var produto = produtoRepository.findByIdOrThrowNotFound(estoqueSaida.getProdutoId());

		var sku = skuRepository.findByIdAndProdutoIdThrowNotFound(estoqueSaida.getSkuId(), estoqueSaida.getProdutoId());

		var movimentoEstoqueIdSaida = MovimentoEstoqueId.generate();
		var movimentoEstoqueIdEntrada = MovimentoEstoqueId.generate();

		var caracteristicaConfiguracao = configuracaoRepository.findByIdOrThrowNotFound(caracteristicaConfiguracaoId);

		List<CaracteristicaValor<?>> caracteristicasEntrada = new ArrayList<>();
		estoqueSaida.getCaracteristicas().forEach(caracteristicasEntrada::add);

		caracteristicasEntrada.add(caracteristicaConfiguracao.getFormato()
															 .getInstance(caracteristicaConfiguracaoId, valorPadrao));

		var estoqueHash = EstoqueHash.builder()
									 .unidadeId(estoqueSaida.getUnidadeId())
									 .produtoId(estoqueSaida.getProdutoId())
									 .skuId(estoqueSaida.getSkuId())
									 .unitizadorId(estoqueSaida.getUnitizadorId())
									 .tipoEstoqueId(estoqueSaida.getTipoEstoqueId())
									 .enderecoId(estoqueSaida.getEnderecoId())
									 .fracionadoId(sku.isFracionado() ? FracionadoId.generate() : null)
									 .situacoes(estoqueSaida.getSituacoes())
									 .avariado(estoqueSaida.getAvariado())
									 .caracteristicas(caracteristicasEntrada)
									 .build();

		var estoqueEntrada = configuraEstoqueEntradaService.configurar(produto,
																	   sku,
																	   estoqueSaida.getSituacoes().iterator().next(),
																	   estoqueHash,
																	   estoqueSaida.getBloqueioMovimentacaoUnitizadorId()
																				   .orElse(null),
																	   estoqueSaida.getRastreioId(),
																	   estoqueSaida.getSelos(),
																	   estoqueSaida.getDataHoraEntrada());

		var atributosEstoqueEntrada = new ArrayList<>(estoqueSaida.getAtributosSaldo());

		var movimentoEstoqueSaida = estoqueSaida.efetuarSaidaSaldoTotal(origem,
																		movimentoEstoqueIdSaida,
																		movimentoEstoqueIdEntrada,
																		estoqueEntrada.getRastreioId(),
																		false);

		atualizaSaldoSaidaService.atualizar(estoqueSaida);

		var movimentoEstoqueEntrada = estoqueEntrada.efetuarEntradaAdicaoCaracteristica(produto,
																						sku,
																						saldoAMovimentar,
																						origem,
																						movimentoEstoqueIdEntrada,
																						movimentoEstoqueIdSaida,
																						estoqueSaida.getRastreioId(),
																						false,
																						atributosEstoqueEntrada);
		atualizaSaldoEntradaService.atualizar(estoqueEntrada);

		movimentoEstoqueRepository.insert(movimentoEstoqueSaida);
		movimentoEstoqueRepository.insert(movimentoEstoqueEntrada);

		estoqueSaida.removeEvents();
		estoqueEntrada.removeEvents();

		return EstoquesSaidaEntradaMovimentos.of(EstoqueSaidaEntrada.of(estoqueSaida.getUnidadeId(),
																		EstoqueSaida.from(estoqueSaida),
																		estoqueEntrada),
												 movimentoEstoqueSaida,
												 movimentoEstoqueEntrada);
	}

	private EstoquesSaidaEntradaMovimentos removerCaracteristicaEstoque(Estoque estoqueSaida,
																		CaracteristicaConfiguracaoId caracteristicaConfiguracaoId,
																		Origem origem) {

		var saldoAMovimentar = estoqueSaida.getSaldo();

		var produto = produtoRepository.findByIdOrThrowNotFound(estoqueSaida.getProdutoId());

		var sku = skuRepository.findByIdAndProdutoIdThrowNotFound(estoqueSaida.getSkuId(), estoqueSaida.getProdutoId());

		var movimentoEstoqueIdSaida = MovimentoEstoqueId.generate();
		var movimentoEstoqueIdEntrada = MovimentoEstoqueId.generate();

		List<CaracteristicaValor<?>> caracteristicasEntrada = new ArrayList<>();
		estoqueSaida.getCaracteristicas().forEach(caracteristica -> {
			if (!caracteristica.getCaracteristicaConfiguracaoId().equals(caracteristicaConfiguracaoId)) {
				caracteristicasEntrada.add(caracteristica);
			}
		});

		var estoqueHash = EstoqueHash.builder()
									 .unidadeId(estoqueSaida.getUnidadeId())
									 .produtoId(estoqueSaida.getProdutoId())
									 .skuId(estoqueSaida.getSkuId())
									 .unitizadorId(estoqueSaida.getUnitizadorId())
									 .tipoEstoqueId(estoqueSaida.getTipoEstoqueId())
									 .enderecoId(estoqueSaida.getEnderecoId())
									 .fracionadoId(sku.isFracionado() ? FracionadoId.generate() : null)
									 .situacoes(estoqueSaida.getSituacoes())
									 .avariado(estoqueSaida.getAvariado())
									 .caracteristicas(caracteristicasEntrada)
									 .build();

		var estoqueEntrada = configuraEstoqueEntradaService.configurar(produto,
																	   sku,
																	   estoqueSaida.getSituacoes().iterator().next(),
																	   estoqueHash,
																	   estoqueSaida.getBloqueioMovimentacaoUnitizadorId()
																				   .orElse(null),
																	   estoqueSaida.getRastreioId(),
																	   estoqueSaida.getSelos(),
																	   estoqueSaida.getDataHoraEntrada());

		var atributosEstoqueEntrada = new ArrayList<>(estoqueSaida.getAtributosSaldo());

		var movimentoEstoqueSaida = estoqueSaida.efetuarSaidaSaldoTotal(origem,
																		movimentoEstoqueIdSaida,
																		movimentoEstoqueIdEntrada,
																		estoqueEntrada.getRastreioId(),
																		false);

		atualizaSaldoSaidaService.atualizar(estoqueSaida);

		movimentoEstoqueRepository.insert(movimentoEstoqueSaida);

		var movimentoEstoqueEntrada = estoqueEntrada.efetuarEntradaRemocaoCaracteristica(produto,
																						 sku,
																						 saldoAMovimentar,
																						 origem,
																						 movimentoEstoqueIdEntrada,
																						 movimentoEstoqueIdSaida,
																						 estoqueSaida.getRastreioId(),
																						 false,
																						 atributosEstoqueEntrada);

		atualizaSaldoEntradaService.atualizar(estoqueEntrada);

		movimentoEstoqueRepository.insert(movimentoEstoqueEntrada);

		estoqueSaida.removeEvents();
		estoqueEntrada.removeEvents();

		return EstoquesSaidaEntradaMovimentos.of(EstoqueSaidaEntrada.of(estoqueSaida.getUnidadeId(),
																		EstoqueSaida.from(estoqueSaida),
																		estoqueEntrada),
												 movimentoEstoqueSaida,
												 movimentoEstoqueEntrada);
	}

	private boolean verificarEstoqueBloqueadoComChaveAcessoESemNovaCaracteristica(Estoque estoque,
																				  CaracteristicaConfiguracaoId caracteristicaConfiguracaoId) {
		if (estoque.isBloqueado()) {
			var situacao = (SituacaoEstoqueBloqueado) estoque.getSituacoes().iterator().next();
			return (situacao.getChaveAcesso() != null
					&& !this.verificarEstoqueContemCaracteristica(estoque, caracteristicaConfiguracaoId));
		} else {
			return false;
		}
	}

	private boolean verificarEstoqueBloqueadoComChaveAcessoEComCaracteristicaRemovida(Estoque estoque,
																					  CaracteristicaConfiguracaoId caracteristicaConfiguracaoId) {
		if (estoque.isBloqueado()) {
			var situacao = (SituacaoEstoqueBloqueado) estoque.getSituacoes().iterator().next();
			return (situacao.getChaveAcesso() != null
					&& this.verificarEstoqueContemCaracteristica(estoque, caracteristicaConfiguracaoId));
		} else {
			return false;
		}
	}

	private boolean verificarEstoqueContemCaracteristica(Estoque estoque,
														 CaracteristicaConfiguracaoId caracteristicaConfiguracaoId) {
		return estoque.getCaracteristicas()
					  .stream()
					  .anyMatch(caracteristica -> caracteristica.getCaracteristicaConfiguracaoId()
																.equals(caracteristicaConfiguracaoId));
	}

	private void publicarEventosAtualizacaoCaracteristicas(ProdutoId produtoId,
														   List<EstoqueSaida> estoquesSaida,
														   List<Estoque> estoquesEntrada,
														   List<MovimentoEstoque> movimentosSaida,
														   List<MovimentoEstoque> movimentosEntrada) {

		movimentosSaida.forEach(movimento -> movimento.getEvents().forEach(publisher::dispatch));
		movimentosEntrada.forEach(movimento -> movimento.getEvents().forEach(publisher::dispatch));

		publisher.dispatch(EstoqueSaldoAtualizadoEvent.from(produtoId, estoquesEntrada, estoquesSaida));
	}
}
