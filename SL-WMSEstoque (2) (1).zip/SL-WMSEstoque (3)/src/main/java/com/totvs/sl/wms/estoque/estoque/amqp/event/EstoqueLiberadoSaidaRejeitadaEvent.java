package com.totvs.sl.wms.estoque.estoque.amqp.event;

import com.totvs.sl.wms.estoque.estoque.domain.event.SubjectSaidaEstoque;
import com.totvs.sl.wms.estoque.unidade.domain.model.UnidadeId;
import com.totvs.sl.wms.estoque.util.amqp.RejectedEvent;
import com.totvs.tjf.api.context.response.ApiErrorResponse;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data(staticConstructor = "of")
@EqualsAndHashCode(callSuper = false)
public final class EstoqueLiberadoSaidaRejeitadaEvent extends RejectedEvent implements SubjectSaidaEstoque {

	private final UnidadeId unidadeId;
	private final ApiErrorResponse inconsistencia;
}
