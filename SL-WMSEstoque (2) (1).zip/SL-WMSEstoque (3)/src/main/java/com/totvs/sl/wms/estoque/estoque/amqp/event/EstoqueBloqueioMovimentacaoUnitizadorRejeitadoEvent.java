package com.totvs.sl.wms.estoque.estoque.amqp.event;

import java.util.List;

import com.totvs.sl.wms.estoque.estoque.domain.event.SubjectBloqueioEstoque;
import com.totvs.sl.wms.estoque.unidade.domain.model.UnidadeId;
import com.totvs.sl.wms.estoque.util.amqp.RejectedEvent;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.ToString;

@ToString
@Getter
@AllArgsConstructor(staticName = "of")
public final class EstoqueBloqueioMovimentacaoUnitizadorRejeitadoEvent extends RejectedEvent
		implements SubjectBloqueioEstoque {

	private final UnidadeId unidadeId;
	private final List<Inconsistencia> inconsistencias;

	@Data(staticConstructor = "of")
	public static final class Inconsistencia {
		private final String id;
		private final String mensagem;
		private final String detalhe;
	}
}
