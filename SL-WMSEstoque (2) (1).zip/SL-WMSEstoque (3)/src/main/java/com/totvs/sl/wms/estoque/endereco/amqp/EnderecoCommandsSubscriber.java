package com.totvs.sl.wms.estoque.endereco.amqp;

import org.springframework.cloud.stream.annotation.EnableBinding;
import org.springframework.cloud.stream.annotation.StreamListener;

import com.totvs.sl.wms.estoque.config.amqp.WMSChannel;
import com.totvs.sl.wms.estoque.config.amqp.WMSPublisher;
import com.totvs.sl.wms.estoque.endereco.amqp.cmd.AlterarCapacidadeEnderecoCmd;
import com.totvs.sl.wms.estoque.endereco.amqp.cmd.CriarEnderecoEstoqueCmd;
import com.totvs.sl.wms.estoque.endereco.amqp.event.AlteracaoCapacidadeEnderecoRejeitadaEvent;
import com.totvs.sl.wms.estoque.endereco.amqp.event.AlteracaoCapacidadeEnderecoRejeitadaEvent.Inconsistencia;
import com.totvs.sl.wms.estoque.endereco.application.EnderecoApplicationService;
import com.totvs.sl.wms.estoque.endereco.application.command.AlterarCapacidadeEnderecoCommand;
import com.totvs.sl.wms.estoque.endereco.application.command.CriarEnderecoCommand;
import com.totvs.sl.wms.estoque.endereco.domain.model.CapacidadeEndereco;
import com.totvs.sl.wms.estoque.endereco.domain.model.DimensaoEndereco;
import com.totvs.sl.wms.estoque.endereco.domain.model.FuncaoEndereco;
import com.totvs.sl.wms.estoque.endereco.exception.WMSAlterarCapacidadeEnderecoConstraintException;
import com.totvs.sl.wms.estoque.endereco.exception.WMSCriarEnderecoEstoqueConstraintException;
import com.totvs.sl.wms.estoque.util.amqp.AMQPUtil;
import com.totvs.tjf.api.response.error.converter.ErrorExceptionConverter;
import com.totvs.tjf.core.i18n.I18nService;
import com.totvs.tjf.core.validation.ValidatorService;
import com.totvs.tjf.messaging.context.TOTVSMessage;

import lombok.AllArgsConstructor;

@AllArgsConstructor
@EnableBinding(WMSChannel.WMSEstoqueEnderecoCommandsInput.class)
public class EnderecoCommandsSubscriber {

	private EnderecoApplicationService service;

	private ValidatorService validator;

	private WMSPublisher wmsPublisher;

	private I18nService i18nService;

	@StreamListener(target = WMSChannel.WMS_ESTOQUE_ENDERECO_COMMANDS_IN, condition = CriarEnderecoEstoqueCmd.CONDITIONAL_EXPRESSION)
	public void criarEnderecoEstoque(final TOTVSMessage<CriarEnderecoEstoqueCmd> message) {

		AMQPUtil.gerarLog(this.getClass(), message, CriarEnderecoEstoqueCmd.CONDITIONAL_EXPRESSION);

		var cmd = message.getContent();

		validator.validate(cmd).ifPresent(violations -> {
			throw new WMSCriarEnderecoEstoqueConstraintException(violations);
		});

		var command = CriarEnderecoCommand.builder()
										  .id(cmd.getId())
										  .funcao(FuncaoEndereco.valueOf(cmd.getFuncao()))
										  .unidadeId(cmd.getUnidadeId());

		if (cmd.getCapacidade() != null) {

			DimensaoEndereco dimensao = null;

			if (cmd.getCapacidade().getDimensao() != null)
				dimensao = DimensaoEndereco.of(cmd.getCapacidade().getDimensao().getAltura(),
											   cmd.getCapacidade().getDimensao().getLargura(),
											   cmd.getCapacidade().getDimensao().getComprimento());

			command.capacidade(CapacidadeEndereco.of(cmd.getCapacidade().getUnitizador(),
													 cmd.getCapacidade().getPeso(),
													 dimensao));
		}

		service.handle(command.build());

	}

	@StreamListener(target = WMSChannel.WMS_ESTOQUE_ENDERECO_COMMANDS_IN, condition = AlterarCapacidadeEnderecoCmd.CONDITIONAL_EXPRESSION)
	public void alterarCapacidade(final TOTVSMessage<AlterarCapacidadeEnderecoCmd> message) {

		AMQPUtil.gerarLog(this.getClass(), message, AlterarCapacidadeEnderecoCmd.CONDITIONAL_EXPRESSION);

		var cmd = message.getContent();

		validator.validate(cmd).ifPresent(violations -> {
			throw new WMSAlterarCapacidadeEnderecoConstraintException(violations);
		});

		DimensaoEndereco dimensao = null;

		if (cmd.getDimensao() != null)
			dimensao = DimensaoEndereco.of(cmd.getDimensao().getAltura(),
										   cmd.getDimensao().getLargura(),
										   cmd.getDimensao().getComprimento());

		var command = AlterarCapacidadeEnderecoCommand.of(cmd.getId(),
														  CapacidadeEndereco.of(cmd.getUnitizador(),
																				cmd.getPeso(),
																				dimensao));

		try {
			service.handle(command);
		} catch (RuntimeException e) {
			rejeitarAlterarCapacidadeEnderecoCmd(cmd, e);
		}

	}

	private void rejeitarAlterarCapacidadeEnderecoCmd(AlterarCapacidadeEnderecoCmd cmd, RuntimeException excecao) {

		var id = excecao.getClass().getSimpleName();

		if (!id.startsWith("WMS")) {
			throw excecao;
		}

		var erroConverter = new ErrorExceptionConverter(i18nService);
		var erro = erroConverter.convert(excecao).getError();

		var eventoRejeicao = AlteracaoCapacidadeEnderecoRejeitadaEvent.of(cmd.getId(),
																		  Inconsistencia.of(id,
																							erro.getMessage(),
																							erro.getDetailedMessage()));

		wmsPublisher.dispatch(eventoRejeicao);
	}
}
