package com.totvs.sl.wms.estoque.estoque.amqp;

import java.util.ArrayList;
import org.springframework.cloud.stream.annotation.EnableBinding;
import org.springframework.cloud.stream.annotation.StreamListener;
import com.totvs.sl.wms.estoque.config.amqp.WMSChannel;
import com.totvs.sl.wms.estoque.config.amqp.WMSPublisher;
import com.totvs.sl.wms.estoque.estoque.amqp.cmd.EfetuarTransferenciaEnderecoEstoqueCmd;
import com.totvs.sl.wms.estoque.estoque.amqp.cmd.EfetuarTransferenciaEnderecoEstoquePorReservaDefinitivaEstoqueCmd;
import com.totvs.sl.wms.estoque.estoque.amqp.cmd.EfetuarTransferenciaEnderecoUnitizadorEstoqueCmd;
import com.totvs.sl.wms.estoque.estoque.amqp.event.EstoqueTransferenciaEnderecoRejeitadaEvent;
import com.totvs.sl.wms.estoque.estoque.amqp.event.EstoqueTransferenciaEnderecoReservaRejeitadaEvent;
import com.totvs.sl.wms.estoque.estoque.amqp.event.EstoqueTransferenciaEnderecoUnitizadorRejeitadaEvent;
import com.totvs.sl.wms.estoque.estoque.amqp.event.EstoqueTransferenciaEnderecoUnitizadorRejeitadaEvent.TransferenciaUnitizadorInconsistencia;
import com.totvs.sl.wms.estoque.estoque.application.EstoqueTransferirApplicationService;
import com.totvs.sl.wms.estoque.estoque.application.command.EfetuarTransferenciaEnderecoEstoqueCommand;
import com.totvs.sl.wms.estoque.estoque.application.command.EfetuarTransferenciaEnderecoReservaEstoqueCommand;
import com.totvs.sl.wms.estoque.estoque.application.command.EfetuarTransferenciaEnderecoUnitizadorEstoqueCommand;
import com.totvs.sl.wms.estoque.estoque.exception.WMSEfetuarTransferenciaEnderecoConstraintException;
import com.totvs.sl.wms.estoque.estoque.exception.WMSEfetuarTransferenciaEnderecoEstoqueReservadoConstraintException;
import com.totvs.sl.wms.estoque.estoque.exception.WMSExisteEstoqueComMesmoHashException;
import com.totvs.sl.wms.estoque.estoque.exception.WMSTransferirEnderecoUnitizadorException;
import com.totvs.sl.wms.estoque.origem.domain.model.Origem;
import com.totvs.sl.wms.estoque.origem.domain.model.OrigemId;
import com.totvs.sl.wms.estoque.util.amqp.AMQPUtil;
import com.totvs.tjf.api.response.error.converter.ErrorExceptionConverter;
import com.totvs.tjf.core.i18n.I18nService;
import com.totvs.tjf.core.validation.ValidatorService;
import com.totvs.tjf.messaging.context.TOTVSMessage;
import lombok.AllArgsConstructor;

@AllArgsConstructor
@EnableBinding(WMSChannel.WMSMovimentacaoEstoqueCommandsInput.class)
public class EstoqueTransferenciaCommandsSubscriber {

	private EstoqueTransferirApplicationService service;
	private ValidatorService validator;
	private WMSPublisher wmsPublisher;
	private I18nService i18nService;

	@StreamListener(target = WMSChannel.WMS_MOVIMENTACAO_ESTOQUE_COMMANDS_IN, condition = EfetuarTransferenciaEnderecoEstoqueCmd.CONDITIONAL_EXPRESSION)
	public void efetuarTransferenciaEnderecoEstoque(final TOTVSMessage<EfetuarTransferenciaEnderecoEstoqueCmd> message) {

		AMQPUtil.gerarLog(this.getClass(), message, EfetuarTransferenciaEnderecoEstoqueCmd.CONDITIONAL_EXPRESSION);

		var cmd = message.getContent();

		validator.validate(cmd).ifPresent(violations -> {
			throw new WMSEfetuarTransferenciaEnderecoConstraintException(violations);
		});

		var transactionInfo = message.getHeader().getTransactionInfo();

		var origem = Origem.of(OrigemId.from(transactionInfo.getTransactionId()), transactionInfo.getGeneratedBy());

		var command = EfetuarTransferenciaEnderecoEstoqueCommand.builder()
																.unidadeId(cmd.getUnidadeId())
																.origem(origem)
																.estoqueId(cmd.getEstoqueId())
																.enderecoId(cmd.getEnderecoId())
																.bloqueioMovimentacaoEstoqueId(cmd.getBloqueioMovimentacaoEstoqueId())
																.bloqueioMovimentacaoUnitizadorId(cmd.getBloqueioMovimentacaoUnitizadorId())
																.quantidade(cmd.getQuantidade())
																.reservasDefinitivas(cmd.getReservasDefinitivas())
																.unitizadorId(cmd.getUnitizadorId())
																.chaveAcesso(cmd.getChaveAcesso())
																.atributos(cmd.getAtributos())
																.build();

		try {
			service.handle(command);
		} catch (WMSExisteEstoqueComMesmoHashException excecao) {
			throw excecao;
		} catch (RuntimeException excecao) {
			rejeitarTransferenciaEnderecoEstoqueCmd(cmd, excecao);
		}
	}

	private void rejeitarTransferenciaEnderecoEstoqueCmd(EfetuarTransferenciaEnderecoEstoqueCmd cmd,
														 RuntimeException excecao) {

		var id = excecao.getClass().getSimpleName();

		if (!id.startsWith("WMS"))
			throw excecao;

		var erroConverter = new ErrorExceptionConverter(i18nService);
		var erro = erroConverter.convert(excecao).getError();

		var eventoRejeicao = EstoqueTransferenciaEnderecoRejeitadaEvent.builder()
																	   .unidadeId(cmd.getUnidadeId())
																	   .estoqueId(cmd.getEstoqueId())
																	   .inconsistencia(erro)
																	   .mensagemCodigo(erro.getCode())
																	   .mensagemDetalhe(erro.getDetailedMessage())
																	   .build();
		wmsPublisher.dispatch(eventoRejeicao);
	}

	@StreamListener(target = WMSChannel.WMS_MOVIMENTACAO_ESTOQUE_COMMANDS_IN, condition = EfetuarTransferenciaEnderecoEstoquePorReservaDefinitivaEstoqueCmd.CONDITIONAL_EXPRESSION)
	public void efetuarTransferenciaEnderecoEstoquePorReservaDefinitivaEstoque(final TOTVSMessage<EfetuarTransferenciaEnderecoEstoquePorReservaDefinitivaEstoqueCmd> message) {

		AMQPUtil.gerarLog(this.getClass(),
						  message,
						  EfetuarTransferenciaEnderecoEstoquePorReservaDefinitivaEstoqueCmd.CONDITIONAL_EXPRESSION);

		var cmd = message.getContent();

		validator.validate(cmd).ifPresent(violations -> {
			throw new WMSEfetuarTransferenciaEnderecoEstoqueReservadoConstraintException(violations);
		});

		var transactionInfo = message.getHeader().getTransactionInfo();

		var origem = Origem.of(OrigemId.from(transactionInfo.getTransactionId()), transactionInfo.getGeneratedBy());

		var command = EfetuarTransferenciaEnderecoReservaEstoqueCommand.builder()
																	   .unidadeId(cmd.getUnidadeId())
																	   .enderecoId(cmd.getEnderecoId())
																	   .reservaDefinitivaEstoqueId(cmd.getReservaDefinitivaEstoqueId())
																	   .origem(origem)
																	   .bloqueioMovimentacaoEstoqueId(cmd.getBloqueioMovimentacaoEstoqueId())
																	   .unitizadorId(cmd.getUnitizadorId())
																	   .atributos(cmd.getAtributos())
																	   .build();
		try {
			service.handle(command);
		} catch (WMSExisteEstoqueComMesmoHashException excecao) {
			throw excecao;
		} catch (RuntimeException excecao) {
			rejeitarTransferenciaEnderecoReservaEstoqueCmd(cmd, excecao);
		}
	}

	private void rejeitarTransferenciaEnderecoReservaEstoqueCmd(EfetuarTransferenciaEnderecoEstoquePorReservaDefinitivaEstoqueCmd cmd,
																RuntimeException excecao) {
		var id = excecao.getClass().getSimpleName();

		if (!id.startsWith("WMS"))
			throw excecao;

		var erroConverter = new ErrorExceptionConverter(i18nService);
		var erro = erroConverter.convert(excecao).getError();

		var eventoRejeicao = EstoqueTransferenciaEnderecoReservaRejeitadaEvent.of(cmd.getReservaDefinitivaEstoqueId(),
																				  erro);
		wmsPublisher.dispatch(eventoRejeicao);
	}

	@StreamListener(target = WMSChannel.WMS_MOVIMENTACAO_ESTOQUE_COMMANDS_IN, condition = EfetuarTransferenciaEnderecoUnitizadorEstoqueCmd.CONDITIONAL_EXPRESSION)
	public void efetuarTransferenciaEnderecoUnitizador(final TOTVSMessage<EfetuarTransferenciaEnderecoUnitizadorEstoqueCmd> message) {

		AMQPUtil.gerarLog(this.getClass(),
						  message,
						  EfetuarTransferenciaEnderecoUnitizadorEstoqueCmd.CONDITIONAL_EXPRESSION);

		var cmd = message.getContent();

		validator.validate(cmd).ifPresent(violations -> {
			throw new WMSTransferirEnderecoUnitizadorException(violations);
		});

		var transactionInfo = message.getHeader().getTransactionInfo();

		var origem = Origem.of(OrigemId.from(transactionInfo.getTransactionId()), transactionInfo.getGeneratedBy());

		var command = EfetuarTransferenciaEnderecoUnitizadorEstoqueCommand.builder()
																		  .unidadeId(cmd.getUnidadeId())
																		  .unitizadorId(cmd.getUnitizadorId())
																		  .enderecoId(cmd.getEnderecoId())
																		  .bloqueioMovimentacaoUnitizadorId(cmd.getBloqueioMovimentacaoUnitizadorId())
																		  .origem(origem)
																		  .chaveAcesso(cmd.getChaveAcesso())
																		  .build();

		try {
			service.handle(command);
		} catch (WMSExisteEstoqueComMesmoHashException excecao) {
			throw excecao;
		} catch (RuntimeException excecao) {
			rejeitarEfetuarTransferenciaEnderecoUnitizadorEstoqueCmd(excecao);
		}
	}

	private void rejeitarEfetuarTransferenciaEnderecoUnitizadorEstoqueCmd(RuntimeException excecao) {

		var id = excecao.getClass().getSimpleName();
		var mensagem = "";
		var detalhe = "";

		if (!id.startsWith("WMS"))
			throw excecao;

		var erroConverter = new ErrorExceptionConverter(i18nService);
		var erro = erroConverter.convert(excecao).getError();

		mensagem = erro.getMessage();
		detalhe = erro.getDetailedMessage();

		var eventoRejeicao = EstoqueTransferenciaEnderecoUnitizadorRejeitadaEvent.of(TransferenciaUnitizadorInconsistencia.of(id,
																															  mensagem,
																															  detalhe));
		wmsPublisher.dispatch(eventoRejeicao);
	}

}
