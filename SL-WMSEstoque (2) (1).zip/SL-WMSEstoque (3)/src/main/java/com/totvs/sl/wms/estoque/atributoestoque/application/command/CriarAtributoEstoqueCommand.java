package com.totvs.sl.wms.estoque.atributoestoque.application.command;

import com.totvs.sl.wms.estoque.atributoestoque.domain.model.ControleQuantidadeAtributoEstoqueValor;
import com.totvs.sl.wms.estoque.atributoestoque.domain.model.FormatoAtributoEstoqueValor;

import lombok.Data;

@Data(staticConstructor = "of")
public final class CriarAtributoEstoqueCommand {

	private final String descricao;
	private final FormatoAtributoEstoqueValor formato;
	private final ControleQuantidadeAtributoEstoqueValor controleQuantidade;
}
