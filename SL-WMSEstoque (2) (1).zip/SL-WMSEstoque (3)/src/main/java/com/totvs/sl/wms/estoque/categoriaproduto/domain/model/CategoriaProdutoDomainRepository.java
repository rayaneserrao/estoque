package com.totvs.sl.wms.estoque.categoriaproduto.domain.model;

import java.util.Optional;

import com.totvs.tjf.repository.aggregate.AggregateRepository;

public interface CategoriaProdutoDomainRepository extends AggregateRepository<CategoriaProduto, CategoriaProdutoId> {

	Optional<CategoriaProduto> findById(CategoriaProdutoId id);

	CategoriaProduto findByIdOrThrowNotFound(CategoriaProdutoId id);
	
	boolean existeCategoriaMesmaDescricao(String descricao);

	boolean existeCategoriaMesmaDescricao(CategoriaProdutoId id, String descricao);

}