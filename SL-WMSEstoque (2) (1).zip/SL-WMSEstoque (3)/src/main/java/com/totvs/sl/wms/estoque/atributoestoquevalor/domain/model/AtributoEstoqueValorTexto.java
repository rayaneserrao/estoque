package com.totvs.sl.wms.estoque.atributoestoquevalor.domain.model;

import static com.totvs.tjf.autoconfigure.ValidationUtils.validateIntegrity;

import java.util.Comparator;
import java.util.Set;
import java.util.TreeSet;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.totvs.sl.wms.estoque.atributoestoque.domain.model.AtributoEstoqueId;
import com.totvs.sl.wms.estoque.atributoestoque.domain.model.ControleQuantidadeAtributoEstoqueValor;
import com.totvs.sl.wms.estoque.atributoestoque.domain.model.FormatoAtributoEstoqueValor;
import com.totvs.sl.wms.estoque.atributoestoquevalor.exception.WMSAtributoEstoqueValorTextoConstraintException;
import com.totvs.sl.wms.estoque.atributoestoquevalor.exception.WMSAtributoEstoqueValorTextoNaoSerialDeveTerSomenteUmaOcorrenciaException;

import lombok.AccessLevel;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Getter
@ToString
@EqualsAndHashCode
@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class AtributoEstoqueValorTexto implements AtributoEstoqueValor<String> {

	@NotNull(message = "{AtributoEstoqueValorTexto.id.NotNull}")
	private AtributoEstoqueId id;

	@NotNull(message = "{AtributoEstoqueValorTexto.valor.NotNull}")
	@Size(min = 1, message = "{AtributoEstoqueValorTexto.valor.Size}")
	private TreeSet<String> valores;

	@NotNull(message = "{AtributoEstoqueValorTexto.controleQuantidade.NotNull}")
	private ControleQuantidadeAtributoEstoqueValor controleQuantidade;

	@Builder
	private AtributoEstoqueValorTexto(AtributoEstoqueId id,
									  TreeSet<String> valores,
									  ControleQuantidadeAtributoEstoqueValor controleQuantidade) {

		this.id = id;
		this.valores = valores;
		this.controleQuantidade = controleQuantidade;

		validateIntegrity(this).ifPresent(violations -> {
			throw new WMSAtributoEstoqueValorTextoConstraintException(violations);
		});

		this.validarControleQuantidadeSerial();

	}

	@Override
	public FormatoAtributoEstoqueValor getFormato() {
		return FormatoAtributoEstoqueValor.TEXTO;
	}

	@Override
	public void adicionarValorSerial(Object valor) {
		if (this.controleQuantidade.isSerial()) {
			this.valores.add(String.valueOf(valor));
			this.validarControleQuantidadeSerial();
		}
	}

	@Override
	public void removerValorSerial(Object valor) {
		if (this.controleQuantidade.isSerial()) {
			this.valores.remove(String.valueOf(valor));
			this.validarControleQuantidadeSerial();
		}
	}

	@Override
	public void atualizarValorVariavel(Object valor) {
		this.valores = new TreeSet<>(Set.of(String.valueOf(valor)));
	}

	private void validarControleQuantidadeSerial() {
		if (!this.controleQuantidade.equals(ControleQuantidadeAtributoEstoqueValor.SERIAL) && this.valores.size() > 1)
			throw new WMSAtributoEstoqueValorTextoNaoSerialDeveTerSomenteUmaOcorrenciaException();
	}

	@Override
	public int compareTo(AtributoEstoqueValor<String> atributo) {

		return atributo instanceof AtributoEstoqueValorTexto atributoTexto

				? Comparator.comparing(AtributoEstoqueValorTexto::getId)
							.thenComparing(AtributoEstoqueValorTexto::getValores,
										   (a, b) -> new AtributoEstoqueValorComparator<String>().compare(a, b))
							.compare(this, atributoTexto)

				: this.getId().compareTo(atributo.getId());
	}
}
