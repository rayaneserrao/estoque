package com.totvs.sl.wms.estoque.estoque.amqp.event;

import java.util.List;

import com.totvs.sl.wms.estoque.estoque.domain.event.SubjectEntradaEstoque;
import com.totvs.sl.wms.estoque.unidade.domain.model.UnidadeId;
import com.totvs.sl.wms.estoque.util.amqp.RejectedEvent;

import lombok.Builder;
import lombok.Data;
import lombok.Getter;
import lombok.ToString;

@Getter
@ToString
public final class EstoqueLiberadoEntradaRejeitadaEvent extends RejectedEvent implements SubjectEntradaEstoque {

	private final UnidadeId unidadeId;
	private final List<Inconsistencia> inconsistencias;

	@Data(staticConstructor = "of")
	public static final class Inconsistencia {
		private final String id;
		private final String mensagem;
		private final String detalhe;
	}

	@Builder
	private EstoqueLiberadoEntradaRejeitadaEvent(UnidadeId unidadeId, List<Inconsistencia> inconsistencias) {
		this.unidadeId = unidadeId;
		this.inconsistencias = inconsistencias;
	}
}
