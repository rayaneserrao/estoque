package com.totvs.sl.wms.estoque.estoque.domain.model;

import static com.totvs.tjf.autoconfigure.ValidationUtils.validateIntegrity;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.apache.commons.codec.digest.DigestUtils;
import org.springframework.util.CollectionUtils;

import com.totvs.sl.wms.estoque.caracteristicavalor.domain.model.CaracteristicaValor;
import com.totvs.sl.wms.estoque.caracteristicavalor.validator.UniqueListCaracteristicaValor;
import com.totvs.sl.wms.estoque.endereco.domain.model.EnderecoId;
import com.totvs.sl.wms.estoque.estoque.exception.WMSEstoqueHashConstraintException;
import com.totvs.sl.wms.estoque.produto.domain.model.ProdutoId;
import com.totvs.sl.wms.estoque.sku.domain.model.SKUId;
import com.totvs.sl.wms.estoque.tipoestoque.domain.model.TipoEstoqueId;
import com.totvs.sl.wms.estoque.unidade.domain.model.UnidadeId;
import com.totvs.sl.wms.estoque.unitizador.domain.model.UnitizadorId;

import lombok.AccessLevel;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Getter
@NoArgsConstructor(access = AccessLevel.PROTECTED)
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
public class EstoqueHash {

	@NotNull(message = "{EstoqueHash.unidadeId.NotNull}")
	private UnidadeId unidadeId;

	@NotNull(message = "{EstoqueHash.produtoId.NotNull}")
	private ProdutoId produtoId;

	@NotNull(message = "{EstoqueHash.skuId.NotNull}")
	private SKUId skuId;

	private UnitizadorId unitizadorId;

	@NotNull(message = "{EstoqueHash.tipoEstoqueId.NotNull}")
	private TipoEstoqueId tipoEstoqueId;

	@NotNull(message = "{EstoqueHash.enderecoId.NotNull}")
	private EnderecoId enderecoId;

	@NotNull(message = "{EstoqueHash.situacoes.NotNull}")
	@Size(min = 1, message = "{EstoqueHash.situacoes.Size}")
	private Set<SituacaoEstoque> situacoes;

	@NotNull(message = "{EstoqueHash.avariado.NotNull}")
	private Boolean avariado;

	private FracionadoId fracionadoId;

	@Valid
	@UniqueListCaracteristicaValor(message = "{EstoqueHash.caracteristicas.UniqueListCaracteristicaValor}")
	private List<CaracteristicaValor<?>> caracteristicas = new ArrayList<>();

	@Builder
	private EstoqueHash(UnidadeId unidadeId, // NOSONAR
						ProdutoId produtoId,
						SKUId skuId,
						UnitizadorId unitizadorId,
						TipoEstoqueId tipoEstoqueId,
						EnderecoId enderecoId,
						Set<SituacaoEstoque> situacoes,
						Boolean avariado,
						FracionadoId fracionadoId,
						List<CaracteristicaValor<?>> caracteristicas) {
		this.unidadeId = unidadeId;
		this.produtoId = produtoId;
		this.skuId = skuId;
		this.unitizadorId = unitizadorId;
		this.tipoEstoqueId = tipoEstoqueId;
		this.enderecoId = enderecoId;
		this.situacoes = situacoes;
		this.avariado = avariado;
		this.fracionadoId = fracionadoId;

		if (caracteristicas != null) {
			this.caracteristicas.addAll(caracteristicas);
			this.caracteristicas.sort(null);
		}

		validateIntegrity(this).ifPresent(violations -> {
			throw new WMSEstoqueHashConstraintException(violations);
		});
	}

	public String getHash() {

		var unitizadorIdString = this.unitizadorId != null ? this.unitizadorId.toString() : "";
		var fracionadoIdString = this.fracionadoId != null ? this.fracionadoId.toString() : "";

		var chaveSb = new StringBuilder();
		chaveSb.append(this.unidadeId.toString());
		chaveSb.append(this.produtoId.toString());
		chaveSb.append(this.skuId.toString());
		chaveSb.append(unitizadorIdString);
		chaveSb.append(this.tipoEstoqueId.toString());
		chaveSb.append(this.enderecoId.toString());
		chaveSb.append(this.situacoes.iterator().next().toString());
		chaveSb.append(this.avariado.toString());
		chaveSb.append(fracionadoIdString);
		configurarHashComCaracteristicas(chaveSb);

		var generatedHash = new BigInteger(1, new DigestUtils("MD5").digest(chaveSb.toString().getBytes()));
		return generatedHash.toString(16);

	}

	private void configurarHashComCaracteristicas(StringBuilder chaveSb) {
		if (!CollectionUtils.isEmpty(this.caracteristicas)) {
			this.caracteristicas.forEach(caracteristica -> {
				chaveSb.append(caracteristica.getCaracteristicaConfiguracaoId().toString());
				chaveSb.append(caracteristica.getValor().toString());
			});
		}
	}
}