package com.totvs.sl.wms.estoque.estoque.exception;

import com.totvs.tjf.api.context.stereotype.error.ApiBadRequest;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
@ApiBadRequest
public class WMSCaracteristicaValorDiferenteProdutoCaracteristicaConfiguracaoException extends RuntimeException {

	private static final long serialVersionUID = -4329647570240478130L;

}