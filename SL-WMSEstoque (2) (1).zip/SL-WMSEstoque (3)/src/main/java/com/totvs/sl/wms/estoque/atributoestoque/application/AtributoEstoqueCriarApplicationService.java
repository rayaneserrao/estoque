package com.totvs.sl.wms.estoque.atributoestoque.application;

import static java.util.Objects.nonNull;

import javax.transaction.Transactional;

import org.springframework.stereotype.Service;

import com.totvs.sl.wms.estoque.atributoestoque.application.command.CriarAtributoEstoqueCommand;
import com.totvs.sl.wms.estoque.atributoestoque.application.metric.EstoqueAtributosMetricService;
import com.totvs.sl.wms.estoque.atributoestoque.domain.model.AtributoEstoque;
import com.totvs.sl.wms.estoque.atributoestoque.domain.model.AtributoEstoqueDomainRepository;
import com.totvs.sl.wms.estoque.atributoestoque.domain.model.AtributoEstoqueId;
import com.totvs.sl.wms.estoque.atributoestoque.exception.WMSAtributoEstoqueDuplicadoException;
import com.totvs.sl.wms.estoque.config.amqp.WMSPublisher;

import lombok.AllArgsConstructor;

@Service
@Transactional
@AllArgsConstructor
public class AtributoEstoqueCriarApplicationService {

	private static final String ATRIBUTO_ESTOQUE_DESCRICAO_IDX = "atributo_estoque_descricao_idx";

	private final AtributoEstoqueDomainRepository repository;
	private final WMSPublisher publisher;
	private final EstoqueAtributosMetricService totalAtributosMetricService;

	public AtributoEstoqueId handle(CriarAtributoEstoqueCommand cmd) {
		var atributo = AtributoEstoque.builder()
									  .id(AtributoEstoqueId.generate())
									  .descricao(cmd.getDescricao().trim())
									  .formato(cmd.getFormato())
									  .controleQuantidade(cmd.getControleQuantidade())
									  .build();

		try {
			this.repository.insert(atributo);
		} catch (Exception excecao) {
			var rootCause = excecao.getCause();
			var erro = nonNull(rootCause) ? rootCause.getMessage() : "";
			if (erro.contains(ATRIBUTO_ESTOQUE_DESCRICAO_IDX))
				throw new WMSAtributoEstoqueDuplicadoException(cmd.getDescricao());
			throw excecao;
		}

		atributo.getEvents().forEach(publisher::dispatch);

		totalAtributosMetricService.atributoCriado();

		return atributo.getId();
	}
}
