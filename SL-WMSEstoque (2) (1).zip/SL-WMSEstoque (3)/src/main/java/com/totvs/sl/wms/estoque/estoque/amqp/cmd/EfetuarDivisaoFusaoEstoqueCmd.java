package com.totvs.sl.wms.estoque.estoque.amqp.cmd;

import com.totvs.sl.wms.estoque.atributoestoquevalor.amqp.cmd.AtributoEstoqueValorCmd;
import com.totvs.sl.wms.estoque.atributoestoquevalor.domain.model.AtributoEstoqueValor;
import com.totvs.sl.wms.estoque.endereco.domain.model.EnderecoId;
import com.totvs.sl.wms.estoque.estoque.domain.model.EstoqueId;
import com.totvs.sl.wms.estoque.tipoestoque.domain.model.TipoEstoqueId;
import com.totvs.sl.wms.estoque.unitizador.domain.model.UnitizadorId;
import lombok.Data;
import lombok.Builder;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Positive;
import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

@Data
@Builder
public final class EfetuarDivisaoFusaoEstoqueCmd {

	public static final String NAME = "EfetuarDivisaoFusaoEstoqueCmd";

	public static final String CONDITIONAL_EXPRESSION = "headers['type']=='" + NAME + "'";

	@NotNull(message = "{EfetuarDivisaoFusaoEstoqueCmd.estoqueId.NotNull}")
	private final EstoqueId estoqueId;

	@NotNull(message = "{EfetuarDivisaoFusaoEstoqueCmd.quantidade.NotNull}")
	@Positive(message = "{EfetuarDivisaoFusaoEstoqueCmd.quantidade.Positive}")
	private final BigDecimal quantidade;

	@NotNull(message = "{EfetuarDivisaoFusaoEstoqueCmd.unitizadorIdDestino.NotNull}")
	private final UnitizadorId unitizadorIdDestino;

	@NotNull(message = "{EfetuarDivisaoFusaoEstoqueCmd.enderecoIdDestino.NotNull}")
	private final EnderecoId enderecoIdDestino;
	private final TipoEstoqueId novoTipoEstoqueId;

	@Valid
	private final List<AtributoEstoqueValorCmd> atributos;

	public final List<AtributoEstoqueValor<?>> getAtributos() {
		return AtributoEstoqueValorCmd.toAtributoEstoqueValor(this.atributos);
	}

	public Optional<TipoEstoqueId> getNovoTipoEstoqueId() {
		return Optional.ofNullable(this.novoTipoEstoqueId);
	}
}
