package com.totvs.sl.wms.estoque.estoque.amqp.cmd;

import javax.validation.constraints.NotNull;

import com.totvs.sl.wms.estoque.caracteristicaconfiguracao.domain.model.CaracteristicaConfiguracaoId;
import com.totvs.sl.wms.estoque.produto.domain.model.ProdutoId;
import com.totvs.sl.wms.estoque.util.amqp.EstoqueOutput;
import com.totvs.sl.wms.estoque.util.amqp.SubjectConfiguracao;
import com.totvs.sl.wms.estoque.util.amqp.TransactionalCmd;

import lombok.Getter;
import lombok.ToString;

@Getter
@ToString
public final class RemoverCaracteristicaConfiguracaoEstoqueCmd extends TransactionalCmd
		implements SubjectConfiguracao, EstoqueOutput {

	public static final String NAME = "RemoverCaracteristicaConfiguracaoEstoqueCmd";

	public static final String CONDITIONAL_EXPRESSION = "headers['type']=='" + NAME + "'";

	@NotNull(message = "{RemoverCaracteristicaConfiguracaoEstoqueCmd.produtoId.NotNull}")
	private final ProdutoId produtoId;

	@NotNull(message = "{RemoverCaracteristicaConfiguracaoEstoqueCmd.caracteristicaConfiguracaoId.NotNull}")
	private final CaracteristicaConfiguracaoId caracteristicaConfiguracaoId;

	private RemoverCaracteristicaConfiguracaoEstoqueCmd(ProdutoId produtoId,
														CaracteristicaConfiguracaoId caracteristicaConfiguracaoId) {
		super(null, null);
		this.produtoId = produtoId;
		this.caracteristicaConfiguracaoId = caracteristicaConfiguracaoId;
	}

	public static RemoverCaracteristicaConfiguracaoEstoqueCmd of(ProdutoId produtoId,
																 CaracteristicaConfiguracaoId caracteristicaConfiguracaoId) {
		return new RemoverCaracteristicaConfiguracaoEstoqueCmd(produtoId, caracteristicaConfiguracaoId);
	}
}
