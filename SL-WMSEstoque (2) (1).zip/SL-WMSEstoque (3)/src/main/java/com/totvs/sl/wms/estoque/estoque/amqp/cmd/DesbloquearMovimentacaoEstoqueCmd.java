package com.totvs.sl.wms.estoque.estoque.amqp.cmd;

import javax.validation.constraints.NotNull;

import com.totvs.sl.wms.estoque.bloqueiomovimentacaoestoque.domain.model.BloqueioMovimentacaoEstoqueId;
import com.totvs.sl.wms.estoque.estoque.domain.model.EstoqueId;

import lombok.Data;

@Data(staticConstructor = "of")
public final class DesbloquearMovimentacaoEstoqueCmd {

	public static final String NAME = "DesbloquearMovimentacaoEstoqueCmd";

	public static final String CONDITIONAL_EXPRESSION = "headers['type']=='" + NAME + "'";

	@NotNull(message = "{DesbloquearMovimentacaoEstoqueCmd.estoqueId.NotNull}")
	private final EstoqueId estoqueId;

	@NotNull(message = "{DesbloquearMovimentacaoEstoqueCmd.bloqueioMovimentacaoEstoqueId.NotNull}")
	private final BloqueioMovimentacaoEstoqueId bloqueioMovimentacaoEstoqueId;

}
