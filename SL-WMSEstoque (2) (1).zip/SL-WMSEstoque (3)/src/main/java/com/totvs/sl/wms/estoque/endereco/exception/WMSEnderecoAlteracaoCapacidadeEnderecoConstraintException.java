package com.totvs.sl.wms.estoque.endereco.exception;

import java.util.Set;

import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;

import com.totvs.tjf.api.context.stereotype.error.ApiBadRequest;

@ApiBadRequest
public class WMSEnderecoAlteracaoCapacidadeEnderecoConstraintException extends ConstraintViolationException {

	private static final long serialVersionUID = -6081623897012546844L;

	public WMSEnderecoAlteracaoCapacidadeEnderecoConstraintException(Set<? extends ConstraintViolation<?>> constraintViolations) {
		super(constraintViolations);
	}
}
