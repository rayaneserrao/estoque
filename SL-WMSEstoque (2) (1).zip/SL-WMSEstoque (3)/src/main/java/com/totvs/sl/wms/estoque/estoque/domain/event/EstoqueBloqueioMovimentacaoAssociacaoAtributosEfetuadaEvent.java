package com.totvs.sl.wms.estoque.estoque.domain.event;

import com.totvs.sl.wms.estoque.bloqueiomovimentacaoestoque.domain.model.BloqueioMovimentacaoEstoqueId;
import com.totvs.sl.wms.estoque.estoque.domain.model.EstoqueAtributoSaldo;
import com.totvs.sl.wms.estoque.estoque.domain.model.EstoqueId;
import com.totvs.sl.wms.estoque.util.amqp.SubjectDomainEvent;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.ToString;

import java.util.List;

@ToString
@Getter
@AllArgsConstructor(access = AccessLevel.PRIVATE)
public final class EstoqueBloqueioMovimentacaoAssociacaoAtributosEfetuadaEvent extends SubjectDomainEvent
		implements SubjectBloqueioEstoque {

	private final EstoqueId estoqueId;
	private final BloqueioMovimentacaoEstoqueId bloqueioMovimentacaoEstoqueId;
	private final List<EstoqueAtributoSaldoEvent> atributosSaldo;

	public static EstoqueBloqueioMovimentacaoAssociacaoAtributosEfetuadaEvent of(EstoqueId estoqueId,
																				 BloqueioMovimentacaoEstoqueId bloqueioMovimentacaoEstoqueId,
																				 List<EstoqueAtributoSaldo> atributosSaldo) {

		return new EstoqueBloqueioMovimentacaoAssociacaoAtributosEfetuadaEvent(estoqueId,
																			   bloqueioMovimentacaoEstoqueId,
																			   EstoqueAtributoSaldoEvent.from(atributosSaldo));
	}

}
