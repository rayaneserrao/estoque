package com.totvs.sl.wms.estoque.estoque.application;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import com.totvs.sl.wms.estoque.atributoestoquevalor.domain.model.AtributoEstoqueValor;
import com.totvs.sl.wms.estoque.bloqueiomovimentacaounitizador.domain.model.BloqueioMovimentacaoUnitizadorDomainRepository;
import com.totvs.sl.wms.estoque.caracteristicaconfiguracao.domain.model.CaracteristicaConfiguracaoDomainRepository;
import com.totvs.sl.wms.estoque.caracteristicavalor.domain.model.CaracteristicaValor;
import com.totvs.sl.wms.estoque.caracteristicavalor.domain.model.CaracteristicaValorTexto;
import com.totvs.sl.wms.estoque.config.amqp.WMSPublisher;
import com.totvs.sl.wms.estoque.endereco.domain.model.Endereco;
import com.totvs.sl.wms.estoque.endereco.domain.model.EnderecoDomainRepository;
import com.totvs.sl.wms.estoque.endereco.domain.model.EnderecoId;
import com.totvs.sl.wms.estoque.estoque.application.command.EfetuarEntradaEstoqueBloqueadoCommand;
import com.totvs.sl.wms.estoque.estoque.application.command.EfetuarEntradaEstoqueCommand;
import com.totvs.sl.wms.estoque.estoque.application.command.EfetuarEntradaEstoqueLiberadoCommand;
import com.totvs.sl.wms.estoque.estoque.domain.model.Estoque;
import com.totvs.sl.wms.estoque.estoque.domain.model.EstoqueAtributoSaldo;
import com.totvs.sl.wms.estoque.estoque.domain.model.EstoqueDomainRepository;
import com.totvs.sl.wms.estoque.estoque.domain.model.EstoqueHash;
import com.totvs.sl.wms.estoque.estoque.domain.model.EstoqueId;
import com.totvs.sl.wms.estoque.estoque.domain.model.FracionadoId;
import com.totvs.sl.wms.estoque.estoque.domain.model.SeloEstoque;
import com.totvs.sl.wms.estoque.estoque.domain.model.SituacaoEstoque;
import com.totvs.sl.wms.estoque.estoque.domain.model.SituacaoEstoqueBloqueado;
import com.totvs.sl.wms.estoque.estoque.domain.model.SituacaoEstoqueLiberado;
import com.totvs.sl.wms.estoque.estoque.domain.service.AtualizaSaldoEstoqueEntradaDomainService;
import com.totvs.sl.wms.estoque.estoque.domain.service.ConfiguraEstoqueParaEntradaDomainService;
import com.totvs.sl.wms.estoque.estoque.domain.service.ValidaInformacoesBasicasEstoqueDomainService;
import com.totvs.sl.wms.estoque.estoque.domain.service.ValidaUnitizadorEstoqueDomainService;
import com.totvs.sl.wms.estoque.estoque.exception.WMSEstoqueEntradaValorJaInformadoParaAtributoSerialException;
import com.totvs.sl.wms.estoque.estoque.exception.WMSUnitizadorBloqueadoParaMovimentacaoException;
import com.totvs.sl.wms.estoque.movimentoestoque.domain.model.MovimentoEstoque;
import com.totvs.sl.wms.estoque.movimentoestoque.domain.model.MovimentoEstoqueDomainRepository;
import com.totvs.sl.wms.estoque.origem.domain.model.Origem;
import com.totvs.sl.wms.estoque.produto.domain.model.ProdutoDomainRepository;
import com.totvs.sl.wms.estoque.produto.domain.model.ProdutoId;
import com.totvs.sl.wms.estoque.sku.domain.model.SKU;
import com.totvs.sl.wms.estoque.sku.domain.model.SKUDomainRepository;
import com.totvs.sl.wms.estoque.sku.domain.model.SKUId;
import com.totvs.sl.wms.estoque.tipoestoque.domain.model.TipoEstoqueId;
import com.totvs.sl.wms.estoque.unidade.domain.model.UnidadeId;
import com.totvs.sl.wms.estoque.unitizador.domain.model.UnitizadorId;
import com.totvs.sl.wms.estoque.util.DateTimeUtils;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Service
@Transactional
@AllArgsConstructor
public class EstoqueEfetuarEntradaApplicationService {

	private final MovimentoEstoqueDomainRepository movimentoEstoqueRepository;
	private final ProdutoDomainRepository produtoRepository;
	private final SKUDomainRepository skuRepository;
	private final EnderecoDomainRepository enderecoRepository;
	private final CaracteristicaConfiguracaoDomainRepository configuracaoRepository;
	private final BloqueioMovimentacaoUnitizadorDomainRepository bloqueioMovimentacaoUnitizadorRepository;
	private final ValidaInformacoesBasicasEstoqueDomainService validaInformacoesBasicasService;
	private final ValidaUnitizadorEstoqueDomainService validaEstoqueUnitizadorService;
	private final ConfiguraEstoqueParaEntradaDomainService configuraEstoqueEntradaService;
	private final AtualizaSaldoEstoqueEntradaDomainService atualizaSaldoEntradaService;
	private final WMSPublisher publisher;
	private final EstoqueDomainRepository estoqueDomainRepository;

	@Getter
	@AllArgsConstructor(staticName = "of")
	public static final class EstoqueEntradaMovimento {
		private Estoque estoque;
		private MovimentoEstoque movimento;
	}

	public EstoqueId handle(final EfetuarEntradaEstoqueLiberadoCommand cmd) {
		return this.processarComandoEntrada(cmd,
											SituacaoEstoqueLiberado.of(),
											determinarEstoqueAtributoSaldo(cmd.getAtributos(), cmd.getQuantidade()));
	}

	public EstoqueId handle(final EfetuarEntradaEstoqueBloqueadoCommand cmd) {
		return this.processarComandoEntrada(cmd,
											SituacaoEstoqueBloqueado.of(cmd.getChaveAcesso(), cmd.getMotivo()),
											determinarEstoqueAtributoSaldo(cmd.getAtributos(), cmd.getQuantidade()));
	}

	private EstoqueId processarComandoEntrada(EfetuarEntradaEstoqueCommand cmd,
											  SituacaoEstoque situacaoEstoque,
											  List<EstoqueAtributoSaldo> atributosSaldo) {

		validaInformacoesBasicasService.existeUnidade(cmd.getUnidadeId());
		validaInformacoesBasicasService.existeEnderecoParaUnidade(cmd.getUnidadeId(), cmd.getEnderecoId());
		validaInformacoesBasicasService.existeProdutoAtivoParaUnidade(cmd.getUnidadeId(), cmd.getProdutoId());
		validaInformacoesBasicasService.existeTipoEstoqueAtivoParaUnidade(cmd.getUnidadeId(), cmd.getTipoEstoqueId());
		validaInformacoesBasicasService.existeSkuAtivo(cmd.getSkuId(), cmd.getProdutoId());

		validaEstoqueUnitizadorService.existeParaUnidade(cmd.getUnidadeId(), cmd.getUnitizadorId());
		validaEstoqueUnitizadorService.existeEmOutroEndereco(cmd.getUnidadeId(),
															 cmd.getUnitizadorId(),
															 cmd.getEnderecoId());

		this.validarSeExisteBloqueioMovimentacaoUnitizador(cmd.getUnitizadorId());
		this.validarAtributosControleQuantidadeSerial(cmd.getProdutoId(), atributosSaldo);

		var caracteristicas = !CollectionUtils.isEmpty(cmd.getCaracteristicas()) ? cmd.getCaracteristicas()
				: this.carregarValoresDasCaracteristicasParaEntradaEstoque(cmd.getCaracteristicasOld());

		var estoqueMovimento = this.efetuarEntradaEstoque(cmd.getUnidadeId(),
														  cmd.getProdutoId(),
														  cmd.getSkuId(),
														  cmd.getUnitizadorId(),
														  cmd.getTipoEstoqueId(),
														  cmd.getEnderecoId(),
														  situacaoEstoque,
														  cmd.getAvariado(),
														  caracteristicas,
														  cmd.getQuantidade(),
														  cmd.getOrigem(),
														  cmd.getSelos(),
														  cmd.getFracionadoId(),
														  atributosSaldo);

		estoqueMovimento.getMovimento().getEvents().forEach(publisher::dispatch);
		estoqueMovimento.getEstoque().getEvents().forEach(publisher::dispatch);

		return estoqueMovimento.getEstoque().getId();
	}

	private EstoqueEntradaMovimento efetuarEntradaEstoque(UnidadeId unidadeId, // NOSONAR
														  ProdutoId produtoId,
														  SKUId skuId,
														  UnitizadorId unitizadorId,
														  TipoEstoqueId tipoEstoqueId,
														  EnderecoId enderecoId,
														  SituacaoEstoque situacao,
														  Boolean avariado,
														  List<CaracteristicaValor<?>> caracteristicas,
														  BigDecimal quantidade,
														  Origem origem,
														  List<SeloEstoque> selos,
														  FracionadoId fracionadoId,
														  List<EstoqueAtributoSaldo> atributosSaldo) {

		var produto = produtoRepository.findByIdOrThrowNotFound(produtoId);

		var sku = skuRepository.findByIdAndProdutoIdAndAtivoOrThrowNotFound(skuId, produtoId);

		var endereco = enderecoRepository.findByIdOrThrowNotFound(enderecoId);

		var fracionado = fracionadoId != null ? fracionadoId : this.gerarFracionadoId(sku);

		var estoqueHash = EstoqueHash.builder()
									 .unidadeId(unidadeId)
									 .produtoId(produtoId)
									 .skuId(skuId)
									 .unitizadorId(unitizadorId)
									 .tipoEstoqueId(tipoEstoqueId)
									 .enderecoId(enderecoId)
									 .fracionadoId(fracionado)
									 .situacoes(Set.of(situacao))
									 .avariado(avariado)
									 .caracteristicas(caracteristicas)
									 .build();

		var estoque = configuraEstoqueEntradaService.configurar(produto,
																sku,
																situacao,
																estoqueHash,
																null,
																selos,
																DateTimeUtils.getNow());

		validaEstoqueUnitizadorService.ocupacaoUnitizadorEndereco(unitizadorId, endereco);

		var movimentoEstoque = estoque.efetuarEntradaEstoque(endereco,
															 produto,
															 sku,
															 quantidade,
															 origem,
															 this.determinarAlteraOcupacaoEndereco(endereco),
															 atributosSaldo);

		atualizaSaldoEntradaService.atualizar(estoque);

		movimentoEstoqueRepository.insert(movimentoEstoque);

		return EstoqueEntradaMovimento.of(estoque, movimentoEstoque);

	}

	private FracionadoId gerarFracionadoId(SKU sku) {
		return sku.isFracionado() ? FracionadoId.generate() : null;
	}

	private List<CaracteristicaValor<?>> carregarValoresDasCaracteristicasParaEntradaEstoque(List<CaracteristicaValorTexto> caracteristicas) {

		if (CollectionUtils.isEmpty(caracteristicas)) {
			return new ArrayList<>();
		}

		List<CaracteristicaValor<?>> caracteristicaValores = new ArrayList<>();

		caracteristicas.forEach(caracteristicaTexto -> {
			var caracteristicaConfiguracao = configuracaoRepository.findByIdOrThrowNotFound(caracteristicaTexto.getCaracteristicaConfiguracaoId());

			caracteristicaValores.add(caracteristicaConfiguracao.getFormato()
																.getInstance(caracteristicaTexto.getCaracteristicaConfiguracaoId(),
																			 caracteristicaTexto.getValor()));
		});

		return caracteristicaValores;
	}

	private void validarSeExisteBloqueioMovimentacaoUnitizador(UnitizadorId unitizadorId) {
		if (bloqueioMovimentacaoUnitizadorRepository.existsByUnitizadorId(unitizadorId))
			throw new WMSUnitizadorBloqueadoParaMovimentacaoException();
	}

	private void validarAtributosControleQuantidadeSerial(ProdutoId produtoId,
														  List<EstoqueAtributoSaldo> atributosSaldo) {

		if (!CollectionUtils.isEmpty(atributosSaldo)) {

			var atributosSerial = atributosSaldo.stream()
												.flatMap(atributoSaldo -> atributoSaldo.getAtributos()
																					   .stream()
																					   .filter(a -> a.getControleQuantidade()
																									 .isSerial()))
												.toList();

			atributosSerial.forEach(atributoSerial -> {

				var valoresDuplicados = new ArrayList<String>();
				atributoSerial.getValores().forEach(valorAtributo -> {

					if (estoqueDomainRepository.existsAtributoSerialRepetidoByProdutoIdAndAtributoIdAndValor(produtoId,
																											 atributoSerial.getId(),
																											 String.valueOf(valorAtributo))) {
						valoresDuplicados.add(String.valueOf(valorAtributo));
					}
				});

				if (!valoresDuplicados.isEmpty())
					throw new WMSEstoqueEntradaValorJaInformadoParaAtributoSerialException(valoresDuplicados);

			});

		}
	}

	private List<EstoqueAtributoSaldo> determinarEstoqueAtributoSaldo(List<AtributoEstoqueValor<?>> atributos,
																	  BigDecimal quantidade) {
		return CollectionUtils.isEmpty(atributos) ? null : List.of(EstoqueAtributoSaldo.of(atributos, quantidade));
	}

	private boolean determinarAlteraOcupacaoEndereco(Endereco endereco) {
		return !endereco.isDoca() && !endereco.isStage();
	}
}
