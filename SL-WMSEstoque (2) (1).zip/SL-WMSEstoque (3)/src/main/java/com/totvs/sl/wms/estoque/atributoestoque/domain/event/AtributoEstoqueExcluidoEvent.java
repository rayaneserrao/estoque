package com.totvs.sl.wms.estoque.atributoestoque.domain.event;

import com.totvs.sl.wms.estoque.atributoestoque.domain.model.AtributoEstoque;
import com.totvs.sl.wms.estoque.atributoestoque.domain.model.AtributoEstoqueId;
import com.totvs.sl.wms.estoque.util.amqp.SubjectConfiguracao;
import com.totvs.sl.wms.estoque.util.amqp.SubjectDomainEvent;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
public final class AtributoEstoqueExcluidoEvent extends SubjectDomainEvent implements SubjectConfiguracao {

	private final AtributoEstoqueId id;

	public static AtributoEstoqueExcluidoEvent from(AtributoEstoque atributoEstoque) {
		return new AtributoEstoqueExcluidoEvent(atributoEstoque.getId());
	}
}
