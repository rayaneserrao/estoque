package com.totvs.sl.wms.estoque.estoque.domain.event;

import java.math.BigDecimal;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.util.CollectionUtils;

import com.totvs.sl.wms.estoque.caracteristicaconfiguracao.domain.model.CaracteristicaConfiguracaoId;
import com.totvs.sl.wms.estoque.caracteristicaconfiguracao.domain.model.FormatoCaracteristicaValor;
import com.totvs.sl.wms.estoque.endereco.domain.model.EnderecoId;
import com.totvs.sl.wms.estoque.estoque.domain.model.Estoque;
import com.totvs.sl.wms.estoque.estoque.domain.model.EstoqueId;
import com.totvs.sl.wms.estoque.estoque.domain.model.SituacaoEstoque;
import com.totvs.sl.wms.estoque.estoque.domain.model.SituacaoEstoqueBloqueado;
import com.totvs.sl.wms.estoque.movimentoestoque.domain.model.MovimentoEstoque;
import com.totvs.sl.wms.estoque.produto.domain.model.ProdutoId;
import com.totvs.sl.wms.estoque.rastreio.domain.model.RastreioId;
import com.totvs.sl.wms.estoque.sku.domain.model.SKUId;
import com.totvs.sl.wms.estoque.tipoestoque.domain.model.TipoEstoqueId;
import com.totvs.sl.wms.estoque.unidade.domain.model.UnidadeId;
import com.totvs.sl.wms.estoque.unitizador.domain.model.UnitizadorId;
import com.totvs.sl.wms.estoque.util.amqp.TransactionalEvent;

import lombok.Builder;
import lombok.Data;
import lombok.Getter;
import lombok.ToString;

@Getter
@ToString
public final class EstoqueBloqueadoEntradaEfetuadaEvent extends TransactionalEvent implements SubjectEntradaEstoque {

	private final UnidadeId unidadeId;

	private final EstoqueEntrada estoque;

	@Data
	@Builder
	public static final class EstoqueEntrada {
		private final EstoqueId id;
		private final ProdutoId produtoId;
		private final SKUId skuId;
		private final UnitizadorId unitizadorId;
		private final TipoEstoqueId tipoEstoqueId;
		private final EnderecoId enderecoId;
		private final List<SituacaoEstoqueEntrada> situacoes;
		private final Boolean avariado;
		private final List<CaracteristicaEstoqueEntrada> caracteristicas;
		private final List<EstoqueAtributoSaldoEvent> atributosSaldo;
		private final RastreioId rastreioId;
		private final BigDecimal quantidadeEntrada;
		private final BigDecimal saldo;
		private final BigDecimal saldoReservado;
		private final BigDecimal saldoDisponivel;
		private final BigDecimal quantidadeBloqueadaMovimentacaoNaoReservada;
		private final BigDecimal quantidadeBloqueadaMovimentacaoReservada;
		private final BigDecimal quantidadeBloqueadaMovimentacaoTotal;
		private final List<SeloEstoqueEvent> selos;
		private final ZonedDateTime dataHoraEntrada;
	}

	@Data(staticConstructor = "of")
	public static final class SituacaoEstoqueEntrada {
		private final ZonedDateTime quando;
		private final String chaveAcesso;
		private final String motivo;
	}

	@Data(staticConstructor = "of")
	public static final class CaracteristicaEstoqueEntrada {
		private final CaracteristicaConfiguracaoId caracteristicaConfiguracaoId;
		private final FormatoCaracteristicaValor formato;
		private final String valor;
	}

	@Data(staticConstructor = "of")
	public static final class SeloEstoqueEvent {
		private final String chave;
		private final String valor;
	}

	@Builder
	private EstoqueBloqueadoEntradaEfetuadaEvent(String generatedBy,
												 String transactionId,
												 UnidadeId unidadeId,
												 EstoqueEntrada estoque) {
		super(generatedBy, transactionId);
		this.unidadeId = unidadeId;
		this.estoque = estoque;
	}

	public static EstoqueBloqueadoEntradaEfetuadaEvent from(Estoque estoque, MovimentoEstoque movimentoEstoque) {

		return EstoqueBloqueadoEntradaEfetuadaEvent.builder()
												   .unidadeId(estoque.getUnidadeId())
												   .transactionId(movimentoEstoque.getOrigem().getId().toString())
												   .generatedBy(movimentoEstoque.getOrigem().getOrigem())
												   .estoque(EstoqueBloqueadoEntradaEfetuadaEvent.EstoqueEntrada.builder()
																											   .id(estoque.getId())
																											   .produtoId(estoque.getProdutoId())
																											   .skuId(estoque.getSkuId())
																											   .unitizadorId(estoque.getUnitizadorId())
																											   .tipoEstoqueId(estoque.getTipoEstoqueId())
																											   .enderecoId(estoque.getEnderecoId())
																											   .situacoes(montarSituacoesEstoque(estoque))
																											   .avariado(estoque.getAvariado())
																											   .caracteristicas(montarCaracteristicas(estoque))
																											   .atributosSaldo(EstoqueAtributoSaldoEvent.from(estoque.getAtributosSaldo()))
																											   .quantidadeEntrada(movimentoEstoque.getQuantidade())
																											   .rastreioId(estoque.getRastreioId())
																											   .saldo(estoque.getSaldo())
																											   .saldoReservado(estoque.getQuantidadeReservada())
																											   .saldoDisponivel(estoque.getSaldoDisponivel())
																											   .quantidadeBloqueadaMovimentacaoNaoReservada(estoque.getQuantidadeBloqueadaParaMovimentacaoEstoqueNaoReservada())
																											   .quantidadeBloqueadaMovimentacaoReservada(estoque.getQuantidadeBloqueadaParaMovimentacaoEstoqueReservada())
																											   .quantidadeBloqueadaMovimentacaoTotal(estoque.getQuantidadeBloqueadaParaMovimentacaoEstoqueTotal())
																											   .selos(estoque.getSelos()
																															 .stream()
																															 .map(selo -> SeloEstoqueEvent.of(selo.getChave(),
																																							  selo.getValor()))
																															 .collect(Collectors.toList()))
																											   .dataHoraEntrada(estoque.getDataHoraEntrada())
																											   .build())
												   .build();
	}

	private static List<SituacaoEstoqueEntrada> montarSituacoesEstoque(Estoque estoque) {
		return estoque.getSituacoes()
					  .stream()
					  .map(EstoqueBloqueadoEntradaEfetuadaEvent::criarSituacaoEstoqueEntrada)
					  .toList();
	}

	private static SituacaoEstoqueEntrada criarSituacaoEstoqueEntrada(SituacaoEstoque situacao) {
		var situacaoEstoque = (SituacaoEstoqueBloqueado) situacao;
		return SituacaoEstoqueEntrada.of(situacaoEstoque.getQuando(),
										 situacaoEstoque.getChaveAcesso(),
										 situacaoEstoque.getMotivo());
	}

	private static List<CaracteristicaEstoqueEntrada> montarCaracteristicas(Estoque estoque) {
		if (CollectionUtils.isEmpty(estoque.getCaracteristicas())) {
			return new ArrayList<>();
		}
		return estoque.getCaracteristicas()
					  .stream()
					  .map(caracteristica -> CaracteristicaEstoqueEntrada.of(caracteristica.getCaracteristicaConfiguracaoId(),
																			 caracteristica.getFormato(),
																			 caracteristica.getValor().toString()))
					  .collect(Collectors.toList());
	}
}
