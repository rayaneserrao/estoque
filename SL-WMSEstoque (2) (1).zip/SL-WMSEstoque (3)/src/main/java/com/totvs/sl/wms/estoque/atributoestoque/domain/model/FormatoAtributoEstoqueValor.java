package com.totvs.sl.wms.estoque.atributoestoque.domain.model;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.SortedSet;

import com.totvs.sl.wms.estoque.atributoestoquevalor.domain.model.AtributoEstoqueValor;
import com.totvs.sl.wms.estoque.atributoestoquevalor.domain.model.AtributoEstoqueValorData;
import com.totvs.sl.wms.estoque.atributoestoquevalor.domain.model.AtributoEstoqueValorNumero;
import com.totvs.sl.wms.estoque.atributoestoquevalor.domain.model.AtributoEstoqueValorTexto;
import com.totvs.sl.wms.estoque.util.ConversionUtils;

public enum FormatoAtributoEstoqueValor {

	TEXTO {
		@Override
		public AtributoEstoqueValor<String> getInstance(AtributoEstoqueId id,
														SortedSet<?> valor,
														ControleQuantidadeAtributoEstoqueValor controleQuantidade) {
			return AtributoEstoqueValorTexto.builder()
											.id(id)
											.valores(ConversionUtils.toString(valor))
											.controleQuantidade(controleQuantidade)
											.build();
		}
	},

	NUMERO {
		@Override
		public AtributoEstoqueValor<BigDecimal> getInstance(AtributoEstoqueId id,
															SortedSet<?> valor,
															ControleQuantidadeAtributoEstoqueValor controleQuantidade) {
			return AtributoEstoqueValorNumero.builder()
											 .id(id)
											 .valores(ConversionUtils.toBigDecimal(valor))
											 .controleQuantidade(controleQuantidade)
											 .build();

		}
	},

	DATA {
		@Override
		public AtributoEstoqueValor<LocalDate> getInstance(AtributoEstoqueId id,
														   SortedSet<?> valor,
														   ControleQuantidadeAtributoEstoqueValor controleQuantidade) {
			return AtributoEstoqueValorData.builder()
										   .id(id)
										   .valor(ConversionUtils.toLocalDate(valor.iterator().next()))
										   .controleQuantidade(controleQuantidade)
										   .build();
		}

	};

	public abstract AtributoEstoqueValor<?> getInstance(AtributoEstoqueId id, // NOSONAR
														SortedSet<?> valor,
														ControleQuantidadeAtributoEstoqueValor controleQuantidade); // NOSONAR

	public boolean isTexto() {
		return this.equals(TEXTO);
	}

	public boolean isNumero() {
		return this.equals(NUMERO);
	}

	public boolean isData() {
		return this.equals(DATA);
	}
}
