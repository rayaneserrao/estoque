package com.totvs.sl.wms.estoque.endereco.domain.model;

import static com.totvs.tjf.autoconfigure.ValidationUtils.validateIntegrity;

import java.math.BigDecimal;
import java.util.Collection;
import java.util.Optional;
import java.util.Set;

import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import com.totvs.sl.wms.estoque.bloqueiomovimentacaoestoque.domain.model.BloqueioMovimentacaoEstoque;
import com.totvs.sl.wms.estoque.bloqueiomovimentacaounitizador.domain.model.BloqueioMovimentacaoUnitizador;
import com.totvs.sl.wms.estoque.endereco.domain.event.EnderecoBloqueadoEntradaEstoqueEvent;
import com.totvs.sl.wms.estoque.endereco.domain.event.EnderecoBloqueadoEntradaSaidaEstoqueEvent;
import com.totvs.sl.wms.estoque.endereco.domain.event.EnderecoBloqueadoSaidaEstoqueEvent;
import com.totvs.sl.wms.estoque.endereco.domain.event.EnderecoDesbloqueadoEntradaEstoqueEvent;
import com.totvs.sl.wms.estoque.endereco.domain.event.EnderecoDesbloqueadoEntradaSaidaEstoqueEvent;
import com.totvs.sl.wms.estoque.endereco.domain.event.EnderecoDesbloqueadoSaidaEstoqueEvent;
import com.totvs.sl.wms.estoque.endereco.domain.event.EnderecoEstoqueAlteradoEvent;
import com.totvs.sl.wms.estoque.endereco.domain.event.EnderecoEstoqueCriadoEvent;
import com.totvs.sl.wms.estoque.endereco.domain.event.EnderecoOcupacaoAtualizadaEvent;
import com.totvs.sl.wms.estoque.endereco.domain.event.EnderecoOcupacaoPrevistaAtualizadaEvent;
import com.totvs.sl.wms.estoque.endereco.exception.WMSBloqueioEnderecoChaveAcessoDiferenteEstoqueBloqueadoChaveAcessoException;
import com.totvs.sl.wms.estoque.endereco.exception.WMSBloqueioEnderecoChaveAcessoInvalidaException;
import com.totvs.sl.wms.estoque.endereco.exception.WMSCalculoCapacidadeCubagemUltrapassouOnzeDigitosInteirosException;
import com.totvs.sl.wms.estoque.endereco.exception.WMSEnderecoCapacidadeCubagemNaoPodeSerInferiorOcupacaoException;
import com.totvs.sl.wms.estoque.endereco.exception.WMSEnderecoCapacidadePesoNaoPodeSerInferiorOcupacaoException;
import com.totvs.sl.wms.estoque.endereco.exception.WMSEnderecoCapacidadeUnitizadorNaoPodeSerInferiorOcupacaoException;
import com.totvs.sl.wms.estoque.endereco.exception.WMSEnderecoConstraintException;
import com.totvs.sl.wms.estoque.endereco.exception.WMSEnderecoOcupacaoCubagemNaoPodeSerSuperiorCapacidadeException;
import com.totvs.sl.wms.estoque.endereco.exception.WMSEnderecoOcupacaoPesoNaoPodeSerSuperiorCapacidadeException;
import com.totvs.sl.wms.estoque.endereco.exception.WMSEnderecoOcupacaoPrevistaDeCubagemNaoPodeSerNegativaException;
import com.totvs.sl.wms.estoque.endereco.exception.WMSEnderecoOcupacaoPrevistaDePesoNaoPodeSerNegativaException;
import com.totvs.sl.wms.estoque.endereco.exception.WMSEnderecoOcupacaoPrevistaDeUnitizadorNaoPodeSerNegativaException;
import com.totvs.sl.wms.estoque.endereco.exception.WMSEnderecoOcupacaoUnitizadorNaoPodeSerSuperiorCapacidadeException;
import com.totvs.sl.wms.estoque.endereco.exception.WMSEnderecoPossuiEstoqueBloqueadoParaMovimentacaoEstoqueException;
import com.totvs.sl.wms.estoque.endereco.exception.WMSEnderecoPossuiEstoqueBloqueadoParaMovimentacaoUnitizadorException;
import com.totvs.sl.wms.estoque.endereco.exception.WMSEnderecoPossuiEstoqueComReservaDefinitivaException;
import com.totvs.sl.wms.estoque.endereco.exception.WMSEnderecoPossuiMovimentacoesPrevistasEstoqueException;
import com.totvs.sl.wms.estoque.endereco.exception.WMSEnderecoPossuiMovimentacoesPrevistasUnitizadorException;
import com.totvs.sl.wms.estoque.estoque.domain.model.Estoque;
import com.totvs.sl.wms.estoque.estoque.domain.model.SituacaoEstoqueBloqueado;
import com.totvs.sl.wms.estoque.origem.domain.model.Origem;
import com.totvs.sl.wms.estoque.sku.domain.model.SKU;
import com.totvs.sl.wms.estoque.unidade.domain.model.UnidadeId;
import com.totvs.sl.wms.estoque.unitizador.domain.model.Unitizador;
import com.totvs.tjf.core.stereotype.Aggregate;
import com.totvs.tjf.repository.aggregate.metadata.AggregateDomainMetadataInfo;

import lombok.AccessLevel;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;

@ToString
@Getter
@Aggregate
@Table(name = "endereco")
@EqualsAndHashCode(callSuper = true)
@NoArgsConstructor(access = AccessLevel.PROTECTED, force = true)
public class Endereco extends AggregateDomainMetadataInfo<EnderecoId> {

	@NotNull(message = "{Endereco.unidadeId.NotNull}")
	private UnidadeId unidadeId;

	@NotNull(message = "{Endereco.funcao.NotNull}")
	private FuncaoEndereco funcao;

	private BloqueioEndereco bloqueio;

	private CapacidadeEndereco capacidade;

	@NotNull(message = "{Endereco.ocupacao.NotNull}")
	private OcupacaoEndereco ocupacao;

	@NotNull(message = "{Endereco.ocupacaoPrevista.NotNull}")
	private OcupacaoEndereco ocupacaoPrevista;

	@Builder
	private Endereco(EnderecoId id, UnidadeId unidadeId, FuncaoEndereco funcao, CapacidadeEndereco capacidade) {

		super(id);

		this.unidadeId = unidadeId;
		this.funcao = funcao;
		this.capacidade = capacidade;
		this.ocupacao = OcupacaoEndereco.of(0, BigDecimal.ZERO, BigDecimal.ZERO);
		this.ocupacaoPrevista = OcupacaoEndereco.of(0, BigDecimal.ZERO, BigDecimal.ZERO);

		validateIntegrity(this).ifPresent(violations -> {
			throw new WMSEnderecoConstraintException(violations);
		});

		this.registerEvent(EnderecoEstoqueCriadoEvent.from(this));

	}

	public Optional<BloqueioEndereco> getBloqueio() {
		return Optional.ofNullable(this.bloqueio);
	}

	public Optional<CapacidadeEndereco> getCapacidade() {
		return Optional.ofNullable(this.capacidade);
	}

	public void alterarFuncao(FuncaoEndereco funcao) {
		this.funcao = funcao;
		validateIntegrity(this).ifPresent(violations -> {
			throw new WMSEnderecoConstraintException(violations);
		});
	}

	public void alterarCapacidade(CapacidadeEndereco capacidade) {

		if (capacidade != null)
			this.validarAlteracaoCapacidade(capacidade);

		this.capacidade = capacidade;

		this.registerEvent(EnderecoEstoqueAlteradoEvent.from(this));
	}

	public void atualizarOcupacao(OcupacaoEndereco ocupacao) {

		this.ocupacao = ocupacao;

		validateIntegrity(this).ifPresent(violations -> {
			throw new WMSEnderecoConstraintException(violations);
		});

		this.registerEvent(EnderecoOcupacaoAtualizadaEvent.from(this));
	}

	public void atualizarOcupacaoPrevista(OcupacaoEndereco ocupacaoPrevista) {

		this.validarAlteracaoOcupacao(this.ocupacao, ocupacaoPrevista);

		this.ocupacaoPrevista = ocupacaoPrevista;

		validateIntegrity(this).ifPresent(violations -> {
			throw new WMSEnderecoConstraintException(violations);
		});

		this.registerEvent(EnderecoOcupacaoPrevistaAtualizadaEvent.from(this));
	}

	public void validarSePermiteAumentarOcupacaoUnitizador() {
		validarSePermiteAumentarOcupacao(1, BigDecimal.ZERO, BigDecimal.ZERO);
	}

	public void validarSePermiteAumentarOcupacao(BigDecimal peso, BigDecimal cubagem) {
		validarSePermiteAumentarOcupacao(0, peso, cubagem);
	}

	public void validarSePermiteAumentarOcupacao(Integer unitizador, BigDecimal peso, BigDecimal cubagem) {

		var novaOcupacaoPrevista = OcupacaoEndereco.of(unitizador + this.getOcupacaoPrevista().getUnitizador(),
													   peso.add(this.getOcupacaoPrevista().getPeso()),
													   cubagem.add(this.getOcupacaoPrevista().getCubagem()));

		this.validarAlteracaoOcupacao(ocupacao, novaOcupacaoPrevista);
	}

	public void aumentarOcupacaoPrevista(Integer unitizador, BigDecimal peso, BigDecimal cubagem) {

		var novaOcupacaoPrevista = OcupacaoEndereco.of(unitizador + this.getOcupacaoPrevista().getUnitizador(),
													   peso.add(this.getOcupacaoPrevista().getPeso()),
													   cubagem.add(this.getOcupacaoPrevista().getCubagem()));

		this.validarAlteracaoOcupacao(ocupacao, novaOcupacaoPrevista);

		this.ocupacaoPrevista = novaOcupacaoPrevista;

		this.registerEvent(EnderecoOcupacaoPrevistaAtualizadaEvent.from(this));

	}

	public void diminuirOcupacaoPrevista(Integer unitizador, BigDecimal peso, BigDecimal cubagem) {

		var unitizadorPrevisto = ocupacaoPrevista.getUnitizador() - unitizador;
		var pesoPrevisto = ocupacaoPrevista.getPeso().subtract(peso);
		var cubagemPrevista = ocupacaoPrevista.getCubagem().subtract(cubagem);

		validarDiminuicaoOcupacaoPrevista(unitizadorPrevisto, pesoPrevisto, cubagemPrevista);

		this.ocupacaoPrevista = OcupacaoEndereco.of(unitizadorPrevisto, pesoPrevisto, cubagemPrevista);

		this.registerEvent(EnderecoOcupacaoPrevistaAtualizadaEvent.from(this));
	}

	public void bloquearEntradaEstoque(Origem origem,
									   String chaveAcesso,
									   Collection<BloqueioMovimentacaoEstoque> movimentacoesPrevistasEstoque,
									   Collection<BloqueioMovimentacaoUnitizador> movimentacoesPrevistasUnitizador,
									   Collection<Estoque> estoquesEndereco) {

		this.validarMovimentacoesPrevistasEstoque(movimentacoesPrevistasEstoque);

		this.validarMovimentacoesPrevistasUnitizador(movimentacoesPrevistasUnitizador);

		this.validarChaveAcessoBloqueioEndereco(chaveAcesso);

		this.validarChaveAcessoBloqueioEstoque(chaveAcesso, estoquesEndereco);

		if (this.isNaoBloqueado() || this.isBloqueadoEntrada()) {
			this.bloqueio = BloqueioEndereco.novoBloqueioEntradaEstoque(origem, chaveAcesso);
			this.registerEvent(EnderecoBloqueadoEntradaEstoqueEvent.from(this));
			return;
		}

		this.bloqueio = BloqueioEndereco.novoBloqueioEntradaSaidaEstoque(origem, chaveAcesso);
		this.registerEvent(EnderecoBloqueadoEntradaEstoqueEvent.from(this));
	}

	public void bloquearSaidaEstoque(Origem origem, String chaveAcesso, Collection<Estoque> estoquesEndereco) {

		this.validarEstoquesEndereco(estoquesEndereco);

		this.validarBloqueioMovimentacaoEstoqueEstoquesEnderecos(estoquesEndereco);

		this.validarBloqueioMovimentacaoUnitizadorEstoquesEnderecos(estoquesEndereco);

		this.validarReservasDefinitivasEstoquesEnderecos(estoquesEndereco);

		this.validarChaveAcessoBloqueioEndereco(chaveAcesso);

		this.validarChaveAcessoBloqueioEstoque(chaveAcesso, estoquesEndereco);

		if (this.isNaoBloqueado() || this.isBloqueadoSaida()) {
			this.bloqueio = BloqueioEndereco.novoBloqueioSaidaEstoque(origem, chaveAcesso);
			this.registerEvent(EnderecoBloqueadoSaidaEstoqueEvent.from(this));
			return;
		}

		this.bloqueio = BloqueioEndereco.novoBloqueioEntradaSaidaEstoque(origem, chaveAcesso);
		this.registerEvent(EnderecoBloqueadoSaidaEstoqueEvent.from(this));
	}

	public void bloquearEntradaSaidaEstoque(Origem origem,
											String chaveAcesso,
											Collection<BloqueioMovimentacaoEstoque> movimentacoesPrevistasEstoque,
											Collection<BloqueioMovimentacaoUnitizador> movimentacoesPrevistasUnitizador,
											Collection<Estoque> estoquesEndereco,
											Set<SKU> skus,
											Set<Unitizador> unitizadores) {

		this.validarMovimentacoesPrevistasEstoque(movimentacoesPrevistasEstoque);

		this.validarMovimentacoesPrevistasUnitizador(movimentacoesPrevistasUnitizador);

		this.validarEstoquesEndereco(estoquesEndereco);

		this.validarBloqueioMovimentacaoEstoqueEstoquesEnderecos(estoquesEndereco);

		this.validarBloqueioMovimentacaoUnitizadorEstoquesEnderecos(estoquesEndereco);

		this.validarReservasDefinitivasEstoquesEnderecos(estoquesEndereco);

		this.validarChaveAcessoBloqueioEndereco(chaveAcesso);

		this.validarChaveAcessoBloqueioEstoque(chaveAcesso, estoquesEndereco);

		this.bloqueio = BloqueioEndereco.novoBloqueioEntradaSaidaEstoque(origem, chaveAcesso);

		this.registerEvent(EnderecoBloqueadoEntradaSaidaEstoqueEvent.from(this, estoquesEndereco, skus, unitizadores));

	}

	public void desbloquearEntradaEstoque(String chaveAcesso) {

		this.validarChaveAcessoBloqueioEndereco(chaveAcesso);

		if (this.isBloqueadoEntradaSaida() || this.isBloqueadoSaida()) {
			this.bloqueio = BloqueioEndereco.novoBloqueioSaidaEstoque(this.bloqueio.getOrigem(), chaveAcesso);
			this.registerEvent(EnderecoDesbloqueadoEntradaEstoqueEvent.from(this));
			return;
		}

		this.bloqueio = null;
		this.registerEvent(EnderecoDesbloqueadoEntradaEstoqueEvent.from(this));
	}

	public void desbloquearSaidaEstoque(String chaveAcesso) {

		this.validarChaveAcessoBloqueioEndereco(chaveAcesso);

		if (this.isBloqueadoEntradaSaida() || this.isBloqueadoEntrada()) {
			this.bloqueio = BloqueioEndereco.novoBloqueioEntradaEstoque(this.bloqueio.getOrigem(), chaveAcesso);
			this.registerEvent(EnderecoDesbloqueadoSaidaEstoqueEvent.from(this));
			return;
		}

		this.bloqueio = null;
		this.registerEvent(EnderecoDesbloqueadoSaidaEstoqueEvent.from(this));

	}

	public void desbloquearEntradaSaidaEstoque(String chaveAcesso, int estoquesDesbloqueados) {

		this.validarChaveAcessoBloqueioEndereco(chaveAcesso);

		this.bloqueio = null;
		this.registerEvent(EnderecoDesbloqueadoEntradaSaidaEstoqueEvent.from(this, estoquesDesbloqueados));
	}

	private void validarMovimentacoesPrevistasEstoque(Collection<BloqueioMovimentacaoEstoque> movimentacoesPrevistasEstoque) {

		if (movimentacoesPrevistasEstoque.isEmpty())
			return;

		if (movimentacoesPrevistasEstoque.stream()
										 .anyMatch(movimentacao -> !movimentacao.getEnderecoIdDestino()
																				.get()
																				.equals(this.id))) {
			throw new IllegalArgumentException();
		}

		throw new WMSEnderecoPossuiMovimentacoesPrevistasEstoqueException();
	}

	private void validarMovimentacoesPrevistasUnitizador(Collection<BloqueioMovimentacaoUnitizador> movimentacoesPrevistasUnitizador) {

		if (movimentacoesPrevistasUnitizador.isEmpty())
			return;

		if (movimentacoesPrevistasUnitizador.stream()
											.anyMatch(movimentacao -> !movimentacao.getEnderecoIdDestino()
																				   .get()
																				   .equals(this.id))) {
			throw new IllegalArgumentException();
		}

		throw new WMSEnderecoPossuiMovimentacoesPrevistasUnitizadorException();
	}

	private void validarBloqueioMovimentacaoEstoqueEstoquesEnderecos(Collection<Estoque> estoquesEndereco) {

		if (!estoquesEndereco.isEmpty()
				&& estoquesEndereco.stream()
								   .anyMatch(estoque -> !estoque.getBloqueiosMovimentacaoEstoque().isEmpty())) {

			throw new WMSEnderecoPossuiEstoqueBloqueadoParaMovimentacaoEstoqueException();
		}
	}

	private void validarBloqueioMovimentacaoUnitizadorEstoquesEnderecos(Collection<Estoque> estoquesEndereco) {

		if (!estoquesEndereco.isEmpty()
				&& estoquesEndereco.stream()
								   .anyMatch(estoque -> estoque.getBloqueioMovimentacaoUnitizadorId().isPresent())) {

			throw new WMSEnderecoPossuiEstoqueBloqueadoParaMovimentacaoUnitizadorException();
		}

	}

	private void validarReservasDefinitivasEstoquesEnderecos(Collection<Estoque> estoquesEndereco) {

		if (!estoquesEndereco.isEmpty()
				&& estoquesEndereco.stream().anyMatch(estoque -> !estoque.getReservasDefinitivas().isEmpty())) {

			throw new WMSEnderecoPossuiEstoqueComReservaDefinitivaException();
		}
	}

	private void validarEstoquesEndereco(Collection<Estoque> estoquesEndereco) {
		if (!estoquesEndereco.isEmpty()
				&& estoquesEndereco.stream().anyMatch(estoque -> !estoque.getEnderecoId().equals(this.id))) {

			throw new IllegalArgumentException();
		}
	}

	private void validarChaveAcessoBloqueioEndereco(String chaveAcesso) {
		if (this.bloqueio != null && !chaveAcesso.equals(this.bloqueio.getChaveAcesso())) {
			throw new WMSBloqueioEnderecoChaveAcessoInvalidaException();
		}
	}

	private void validarChaveAcessoBloqueioEstoque(String chaveAcesso, Collection<Estoque> estoquesEndereco) {

		if (estoquesEndereco.isEmpty())
			return;

		for (Estoque estoque : estoquesEndereco) {
			if (estoque.isBloqueado()) {
				var situacao = (SituacaoEstoqueBloqueado) estoque.getSituacoes().iterator().next();
				if (!situacao.getChaveAcesso().equals(chaveAcesso))
					throw new WMSBloqueioEnderecoChaveAcessoDiferenteEstoqueBloqueadoChaveAcessoException();
			}
		}

	}

	private void validarAlteracaoCapacidade(CapacidadeEndereco capacidade) {

		capacidade.getUnitizador().ifPresent(unitizador -> {
			if (unitizador < this.getOcupacaoTotalUnitizador())
				throw new WMSEnderecoCapacidadeUnitizadorNaoPodeSerInferiorOcupacaoException(unitizador,
																							 this.getOcupacaoTotalUnitizador());
		});

		capacidade.getPeso().ifPresent(peso -> {
			if (peso.compareTo(this.getOcupacaoTotalPeso()) < 0)
				throw new WMSEnderecoCapacidadePesoNaoPodeSerInferiorOcupacaoException(peso,
																					   this.getOcupacaoTotalPeso());
		});

		capacidade.getDimensao().ifPresent(dimensao -> {
			if (dimensao.getCubagem().compareTo(this.getOcupacaoTotalCubagem()) < 0)
				throw new WMSEnderecoCapacidadeCubagemNaoPodeSerInferiorOcupacaoException(dimensao.getCubagem(),
																						  this.getOcupacaoTotalCubagem());
		});

		validaCapacidadeCubagemTotal(capacidade);
	}

	private void validarDiminuicaoOcupacaoPrevista(int unitizador, BigDecimal peso, BigDecimal cubagem) {

		if (unitizador < 0)
			throw new WMSEnderecoOcupacaoPrevistaDeUnitizadorNaoPodeSerNegativaException(ocupacaoPrevista.getUnitizador(),
																						 unitizador);
		if (peso.compareTo(BigDecimal.ZERO) < 0)
			throw new WMSEnderecoOcupacaoPrevistaDePesoNaoPodeSerNegativaException(ocupacaoPrevista.getPeso(), peso);

		if (cubagem.compareTo(BigDecimal.ZERO) < 0)
			throw new WMSEnderecoOcupacaoPrevistaDeCubagemNaoPodeSerNegativaException(ocupacaoPrevista.getCubagem(),
																					  cubagem);
	}

	private void validarAlteracaoOcupacao(OcupacaoEndereco ocupacao, OcupacaoEndereco ocupacaoPrevista) {

		if (this.deveAlterarOcupacaoEndereco() && this.getCapacidade().isPresent()) {

			var ocupacaoUnitizador = ocupacao != null ? ocupacao.getUnitizador() : 0;
			var ocupacaoPrevistaUnitizador = ocupacaoPrevista != null ? ocupacaoPrevista.getUnitizador() : 0;

			this.validarAlteracaoOcupacaoUnitizador(ocupacaoUnitizador + ocupacaoPrevistaUnitizador);

			var ocupacaoPeso = ocupacao != null ? ocupacao.getPeso() : BigDecimal.ZERO;
			var ocupacaoPrevistaPeso = ocupacaoPrevista != null ? ocupacaoPrevista.getPeso() : BigDecimal.ZERO;

			this.validarAlteracaoOcupacaoPeso(ocupacaoPeso.add(ocupacaoPrevistaPeso));

			var ocupacaoCubagem = ocupacao != null ? ocupacao.getCubagem() : BigDecimal.ZERO;
			var ocupacaoPrevistaCubagem = ocupacaoPrevista != null ? ocupacaoPrevista.getCubagem() : BigDecimal.ZERO;

			this.validarAlteracaoOcupacaoCubagem(ocupacaoCubagem.add(ocupacaoPrevistaCubagem));
		}
	}

	private void validarAlteracaoOcupacaoUnitizador(Integer ocupacaoUnitizadorTotal) {
		this.getCapacidade()
			.ifPresent(capacidadeEndereco -> capacidadeEndereco.getUnitizador().ifPresent(capacidadeUnitizador -> {
				if (ocupacaoUnitizadorTotal > this.getOcupacaoTotalUnitizador()
						&& ocupacaoUnitizadorTotal > capacidadeUnitizador)
					throw new WMSEnderecoOcupacaoUnitizadorNaoPodeSerSuperiorCapacidadeException(capacidadeUnitizador,
																								 ocupacaoUnitizadorTotal);
			}));
	}

	private void validarAlteracaoOcupacaoPeso(BigDecimal ocupacaoPesoTotal) {
		this.getCapacidade().ifPresent(capacidadeEndereco -> capacidadeEndereco.getPeso().ifPresent(capacidadePeso -> {
			if (ocupacaoPesoTotal.compareTo(this.getOcupacaoTotalPeso()) > 0
					&& ocupacaoPesoTotal.compareTo(capacidadePeso) > 0)
				throw new WMSEnderecoOcupacaoPesoNaoPodeSerSuperiorCapacidadeException(capacidadePeso,
																					   ocupacaoPesoTotal);
		}));
	}

	private void validarAlteracaoOcupacaoCubagem(BigDecimal ocupacaoCubagemTotal) {
		this.getCapacidade().ifPresent(capacidadeEndereco -> capacidadeEndereco.getDimensao().ifPresent(dimensao -> {
			var capacidadeCubagem = dimensao.getCubagem();
			if (ocupacaoCubagemTotal.compareTo(this.getOcupacaoTotalCubagem()) > 0
					&& ocupacaoCubagemTotal.compareTo(capacidadeCubagem) > 0)
				throw new WMSEnderecoOcupacaoCubagemNaoPodeSerSuperiorCapacidadeException(capacidadeCubagem,
																						  ocupacaoCubagemTotal);
		}));
	}

	private void validaCapacidadeCubagemTotal(CapacidadeEndereco capacidade) {
		capacidade.getDimensao().ifPresent(dimensao -> {
			if (String.valueOf(dimensao.getCubagem().longValue()).length() > 11)
				throw new WMSCalculoCapacidadeCubagemUltrapassouOnzeDigitosInteirosException();
		});

	}

	public Integer getOcupacaoTotalUnitizador() {
		return this.ocupacao.getUnitizador() + this.ocupacaoPrevista.getUnitizador();
	}

	public BigDecimal getOcupacaoTotalPeso() {
		return this.ocupacao.getPeso().add(this.ocupacaoPrevista.getPeso());
	}

	public BigDecimal getOcupacaoTotalCubagem() {
		return this.ocupacao.getCubagem().add(this.ocupacaoPrevista.getCubagem());
	}

	public boolean isNaoBloqueado() {
		return this.bloqueio == null;
	}

	public boolean isBloqueadoEntrada() {
		return this.bloqueio != null && (this.bloqueio.getTipo().equals(TipoBloqueioEndereco.ENTRADA));
	}

	public boolean isBloqueadoSaida() {
		return this.bloqueio != null && (this.bloqueio.getTipo().equals(TipoBloqueioEndereco.SAIDA));
	}

	public boolean isBloqueadoEntradaSaida() {
		return this.bloqueio != null && (this.bloqueio.getTipo().equals(TipoBloqueioEndereco.ENTRADA_SAIDA));
	}

	public boolean isDoca() {
		return this.funcao.isDoca();
	}

	public boolean isStage() {
		return this.funcao.isStage();
	}

	private boolean deveAlterarOcupacaoEndereco() {
		return !this.isDoca() && !this.isStage();
	}
}