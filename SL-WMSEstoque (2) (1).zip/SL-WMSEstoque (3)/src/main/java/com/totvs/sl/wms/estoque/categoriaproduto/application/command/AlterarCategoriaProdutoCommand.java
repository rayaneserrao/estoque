package com.totvs.sl.wms.estoque.categoriaproduto.application.command;

import com.totvs.sl.wms.estoque.categoriaproduto.domain.model.CategoriaProdutoId;

import lombok.Data;

@Data(staticConstructor = "of")
public final class AlterarCategoriaProdutoCommand {

	private final CategoriaProdutoId id;

	private final String descricao;

}
