package com.totvs.sl.wms.estoque.caracteristicaconfiguracao.exception;

import java.util.Set;

import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;

import com.totvs.tjf.api.context.stereotype.error.ApiBadRequest;

@ApiBadRequest("WMSCaracteristicaConfiguracaoConstraintException")
public class WMSCaracteristicaConfiguracaoConstraintException extends ConstraintViolationException {

	private static final long serialVersionUID = 2294989725054273992L;

	public WMSCaracteristicaConfiguracaoConstraintException(Set<? extends ConstraintViolation<?>> constraintViolations) {
		super(constraintViolations);
	}

}
