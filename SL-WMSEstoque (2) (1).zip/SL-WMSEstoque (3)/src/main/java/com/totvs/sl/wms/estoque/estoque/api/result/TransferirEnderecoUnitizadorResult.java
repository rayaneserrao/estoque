package com.totvs.sl.wms.estoque.estoque.api.result;

import java.util.List;

import com.totvs.sl.wms.estoque.endereco.domain.model.EnderecoId;
import com.totvs.sl.wms.estoque.estoque.application.EstoqueSaidaEntrada;
import com.totvs.sl.wms.estoque.estoque.domain.model.Estoque;
import com.totvs.sl.wms.estoque.estoque.domain.model.EstoqueId;
import com.totvs.sl.wms.estoque.produto.domain.model.ProdutoId;
import com.totvs.sl.wms.estoque.sku.domain.model.SKUId;
import com.totvs.sl.wms.estoque.tipoestoque.domain.model.TipoEstoqueId;

import lombok.AccessLevel;
import lombok.Builder;
import lombok.Data;

@Data
@Builder(access = AccessLevel.PRIVATE)
public final class TransferirEnderecoUnitizadorResult {

	private final EstoqueId estoqueId;
	private final ProdutoId produtoId;
	private final SKUId skuId;
	private final TipoEstoqueId tipoEstoqueId;
	private final EnderecoId enderecoId;

	public static List<TransferirEnderecoUnitizadorResult> from(List<EstoqueSaidaEntrada> estoquesSaidaEntrada) {
		return estoquesSaidaEntrada.stream()
								   .map(estoqueSaidaEntrada -> TransferirEnderecoUnitizadorResult.from(estoqueSaidaEntrada.getEstoqueEntrada()))
								   .toList();

	}

	private static TransferirEnderecoUnitizadorResult from(Estoque estoque) {
		return TransferirEnderecoUnitizadorResult.builder()
												 .estoqueId(estoque.getId())
												 .produtoId(estoque.getProdutoId())
												 .skuId(estoque.getSkuId())
												 .tipoEstoqueId(estoque.getTipoEstoqueId())
												 .enderecoId(estoque.getEnderecoId())
												 .build();
	}
}
