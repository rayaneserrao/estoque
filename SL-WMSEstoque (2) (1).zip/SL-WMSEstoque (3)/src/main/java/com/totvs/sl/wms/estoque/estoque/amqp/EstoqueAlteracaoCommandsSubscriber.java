package com.totvs.sl.wms.estoque.estoque.amqp;

import java.util.ArrayList;

import org.springframework.cloud.stream.annotation.EnableBinding;
import org.springframework.cloud.stream.annotation.StreamListener;

import com.totvs.sl.wms.estoque.config.amqp.WMSChannel;
import com.totvs.sl.wms.estoque.config.amqp.WMSPublisher;
import com.totvs.sl.wms.estoque.estoque.amqp.cmd.AlterarEstoqueSKUCmd;
import com.totvs.sl.wms.estoque.estoque.amqp.event.AlterarEstoqueSKURejeitadoEvent;
import com.totvs.sl.wms.estoque.estoque.application.EstoqueAlterarApplicationService;
import com.totvs.sl.wms.estoque.estoque.application.command.AlterarEstoqueSKUCommand;
import com.totvs.sl.wms.estoque.estoque.exception.WMSAlterarEstoqueSKUException;
import com.totvs.sl.wms.estoque.estoque.exception.WMSExisteEstoqueComMesmoHashException;
import com.totvs.sl.wms.estoque.util.amqp.AMQPUtil;
import com.totvs.tjf.api.response.error.converter.ErrorExceptionConverter;
import com.totvs.tjf.core.i18n.I18nService;
import com.totvs.tjf.core.validation.ValidatorService;
import com.totvs.tjf.messaging.context.TOTVSMessage;

import lombok.AllArgsConstructor;

@AllArgsConstructor
@EnableBinding(WMSChannel.WMSAlteracaoEstoqueCommandsInput.class)
public class EstoqueAlteracaoCommandsSubscriber {

	private EstoqueAlterarApplicationService service;
	private ValidatorService validator;
	private WMSPublisher wmsPublisher;
	private I18nService i18nService;

	@StreamListener(target = WMSChannel.WMS_ALTERACAO_ESTOQUE_COMMANDS_IN, condition = AlterarEstoqueSKUCmd.CONDITIONAL_EXPRESSION)
	public void alterarEstoqueSKU(final TOTVSMessage<AlterarEstoqueSKUCmd> message) {

		AMQPUtil.gerarLog(this.getClass(), message, AlterarEstoqueSKUCmd.CONDITIONAL_EXPRESSION);

		var cmd = message.getContent();

		validator.validate(cmd).ifPresent(violations -> {
			throw new WMSAlterarEstoqueSKUException(violations);
		});

		var command = AlterarEstoqueSKUCommand.builder()
											  .id(cmd.getId())
											  .skuId(cmd.getSkuId())
											  .quantidadeSKU(cmd.getQuantidadeSKU())
											  .aceitarParcialConvertendoSaldoDisponivel(cmd.isAceitarParcialConvertendoSaldoDisponivel())
											  .reservasDefinitivasId(cmd.getReservasDefinitivas()
																		.stream()
																		.map(reservaDefinitiva -> reservaDefinitiva.getId())
																		.toList())
											  .atributos(cmd.getAtributos())
											  .manterAtributosReserva(cmd.isManterAtributosReserva())
											  .build();

		try {
			service.handle(command);
		} catch (WMSExisteEstoqueComMesmoHashException excecao) {
			throw excecao;
		} catch (RuntimeException e) {
			rejeitarAlterarEstoqueSKUCmd(cmd, e);
		}
	}

	private void rejeitarAlterarEstoqueSKUCmd(AlterarEstoqueSKUCmd cmd, RuntimeException excecao) {

		var id = excecao.getClass().getSimpleName();

		if (!id.startsWith("WMS"))
			throw excecao;

		var erroConverter = new ErrorExceptionConverter(i18nService);
		var erro = erroConverter.convert(excecao).getError();

		var inconsistencias = new ArrayList<AlterarEstoqueSKURejeitadoEvent.Inconsistencia>();

		inconsistencias.add(AlterarEstoqueSKURejeitadoEvent.Inconsistencia.of(id,
																			  erro.getMessage(),
																			  erro.getDetailedMessage()));

		var eventoRejeicao = AlterarEstoqueSKURejeitadoEvent.of(cmd.getId(), cmd.getSkuId(), inconsistencias);
		wmsPublisher.dispatch(eventoRejeicao);

	}

}
