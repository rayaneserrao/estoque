package com.totvs.sl.wms.estoque.estoque.amqp.cmd;

import java.math.BigDecimal;
import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.Digits;
import javax.validation.constraints.NotNull;

import com.totvs.sl.wms.estoque.atributoestoquevalor.amqp.cmd.AtributoEstoqueValorCmd;
import com.totvs.sl.wms.estoque.atributoestoquevalor.domain.model.AtributoEstoqueValor;
import com.totvs.sl.wms.estoque.estoque.domain.model.EstoqueId;
import com.totvs.sl.wms.estoque.unidade.domain.model.UnidadeId;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public final class EfetuarSaidaEstoqueBloqueadoCmd {

	public static final String NAME = "EfetuarSaidaEstoqueBloqueadoCmd";
	public static final String CONDITIONAL_EXPRESSION = "headers['type']=='" + NAME + "'";

	@NotNull(message = "{EfetuarSaidaEstoqueBloqueadoCmd.unidadeId.NotNull}")
	private final UnidadeId unidadeId;

	@NotNull(message = "{EfetuarSaidaEstoqueBloqueadoCmd.estoqueId.NotNull}")
	private final EstoqueId estoqueId;

	@NotNull(message = "{EfetuarSaidaEstoqueBloqueadoCmd.quantidade.NotNull}")
	@DecimalMin(value = "0.0001", message = "{EfetuarSaidaEstoqueBloqueadoCmd.quantidade.DecimalMin}")
	@Digits(fraction = 4, integer = 11, message = "{EfetuarSaidaEstoqueBloqueadoCmd.quantidade.Digits}")
	private final BigDecimal quantidade;

	private final String chaveAcesso;

	@Valid
	private final List<AtributoEstoqueValorCmd> atributos;

	public final List<AtributoEstoqueValor<?>> getAtributos() {
		return AtributoEstoqueValorCmd.toAtributoEstoqueValor(this.atributos);
	}
}
