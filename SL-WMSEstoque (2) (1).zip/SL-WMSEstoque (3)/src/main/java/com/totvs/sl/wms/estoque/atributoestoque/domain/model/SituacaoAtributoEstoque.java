package com.totvs.sl.wms.estoque.atributoestoque.domain.model;

import java.time.ZonedDateTime;

import com.totvs.sl.wms.estoque.util.DateTimeUtils;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor(access = AccessLevel.PRIVATE)
@AllArgsConstructor(access = AccessLevel.PRIVATE)
public final class SituacaoAtributoEstoque {

	private SituacaoAtributoEstoqueValor valor;

	private ZonedDateTime quando;

	public static SituacaoAtributoEstoque ofAtivo() {
		return new SituacaoAtributoEstoque(SituacaoAtributoEstoqueValor.ATIVO, DateTimeUtils.getNow());
	}

	public static SituacaoAtributoEstoque ofInativo() {
		return new SituacaoAtributoEstoque(SituacaoAtributoEstoqueValor.INATIVO, DateTimeUtils.getNow());
	}

	public boolean isAtivo() {
		return this.valor.equals(SituacaoAtributoEstoqueValor.ATIVO);
	}

	public boolean isInativo() {
		return this.valor.equals(SituacaoAtributoEstoqueValor.INATIVO);
	}

}
