package com.totvs.sl.wms.estoque.categoriaproduto.domain.model;

public enum SituacaoCategoriaProdutoValor {
	ATIVO, INATIVO
}
