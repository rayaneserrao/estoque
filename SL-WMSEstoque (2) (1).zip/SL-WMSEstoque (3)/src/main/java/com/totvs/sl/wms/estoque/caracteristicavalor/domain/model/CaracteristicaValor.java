package com.totvs.sl.wms.estoque.caracteristicavalor.domain.model;

import com.totvs.sl.wms.estoque.caracteristicaconfiguracao.domain.model.CaracteristicaConfiguracaoId;
import com.totvs.sl.wms.estoque.caracteristicaconfiguracao.domain.model.FormatoCaracteristicaValor;

public interface CaracteristicaValor<T> extends Comparable<CaracteristicaValor<T>> {

	CaracteristicaConfiguracaoId getCaracteristicaConfiguracaoId();

	T getValor();

	FormatoCaracteristicaValor getFormato();

}