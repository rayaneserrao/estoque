package com.totvs.sl.wms.estoque.config.amqp;

public interface ConsumeMessage {

}
