package com.totvs.sl.wms.estoque.estoque.application.command;

import com.totvs.sl.wms.estoque.estoque.domain.model.EstoqueId;
import com.totvs.sl.wms.estoque.tipoestoque.domain.model.TipoEstoqueId;

import lombok.Data;

@Data(staticConstructor = "of")
public final class AlterarEstoqueTipoEstoqueCommand {
	private final EstoqueId id;
	private final TipoEstoqueId tipoEstoqueId;
}
