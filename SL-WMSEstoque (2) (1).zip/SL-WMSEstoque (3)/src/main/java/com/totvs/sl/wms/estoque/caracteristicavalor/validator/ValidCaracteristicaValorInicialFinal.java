package com.totvs.sl.wms.estoque.caracteristicavalor.validator;

import static java.lang.annotation.ElementType.TYPE;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.Target;

import javax.validation.Constraint;
import javax.validation.Payload;

@Documented
@Target(TYPE)
@Retention(RUNTIME)
@Constraint(validatedBy = { CaracteristicaValorInicialFinalValidator.class })
public @interface ValidCaracteristicaValorInicialFinal {

	String message() default "{com.totvs.sl.wms.expedicao.caracteristicavalorfaixa.validators.ValidCaracteristicaValorInicialFinal}";

	Class<?>[] groups() default {};

	Class<? extends Payload>[] payload() default {};
}