package com.totvs.sl.wms.estoque.estoque.application.command;

import com.totvs.sl.wms.estoque.estoque.domain.model.EstoqueAtributoSaldo;
import com.totvs.sl.wms.estoque.origem.domain.model.Origem;
import com.totvs.sl.wms.estoque.reservadefinitivaestoque.domain.model.ReservaDefinitivaEstoqueId;

import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;

import java.util.List;

@Getter
@Builder
@EqualsAndHashCode
public final class BloquearMovimentacaoEstoqueReservaCommand {

	private final ReservaDefinitivaEstoqueId reservaDefinitivaEstoqueId;
	private final Origem origem;
	private final List<EstoqueAtributoSaldo> atributosSaldo;
}
