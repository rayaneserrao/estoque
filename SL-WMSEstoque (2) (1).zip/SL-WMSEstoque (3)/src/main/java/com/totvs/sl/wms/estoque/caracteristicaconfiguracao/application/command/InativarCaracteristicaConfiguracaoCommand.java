package com.totvs.sl.wms.estoque.caracteristicaconfiguracao.application.command;

import com.totvs.sl.wms.estoque.caracteristicaconfiguracao.domain.model.CaracteristicaConfiguracaoId;

import lombok.Data;
import lombok.Getter;

@Getter
@Data(staticConstructor = "of")
public final class InativarCaracteristicaConfiguracaoCommand {

	private final CaracteristicaConfiguracaoId id;
}
