package com.totvs.sl.wms.estoque.atributoestoque.amqp.cmd;

import javax.validation.constraints.NotNull;

import com.totvs.sl.wms.estoque.atributoestoque.domain.model.AtributoEstoqueId;
import com.totvs.sl.wms.estoque.util.amqp.EstoqueOutput;
import com.totvs.sl.wms.estoque.util.amqp.SubjectConfiguracao;
import com.totvs.sl.wms.estoque.util.amqp.TransactionalCmd;

import lombok.Getter;
import lombok.ToString;

@Getter
@ToString
public final class DesmarcarUtilizacaoAtributoEstoqueCmd extends TransactionalCmd
		implements SubjectConfiguracao, EstoqueOutput {

	public static final String NAME = "DesmarcarUtilizacaoAtributoEstoqueCmd";
	public static final String CONDITIONAL_EXPRESSION = "headers['type']=='" + NAME + "'";

	@NotNull(message = "{DesmarcarUtilizacaoAtributoEstoqueCmd.id.NotNull}")
	private final AtributoEstoqueId id;

	private DesmarcarUtilizacaoAtributoEstoqueCmd(String generatedBy, String transactionId, AtributoEstoqueId id) {
		super(generatedBy, transactionId);
		this.id = id;
	}

	public static DesmarcarUtilizacaoAtributoEstoqueCmd of(String generatedBy,
														   String transactionId,
														   AtributoEstoqueId id) {
		return new DesmarcarUtilizacaoAtributoEstoqueCmd(generatedBy, transactionId, id);
	}

}
