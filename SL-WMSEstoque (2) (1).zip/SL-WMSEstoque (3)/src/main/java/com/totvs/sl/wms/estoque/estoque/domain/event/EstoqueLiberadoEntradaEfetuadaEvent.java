package com.totvs.sl.wms.estoque.estoque.domain.event;

import java.math.BigDecimal;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.util.CollectionUtils;

import com.totvs.sl.wms.estoque.caracteristicaconfiguracao.domain.model.CaracteristicaConfiguracaoId;
import com.totvs.sl.wms.estoque.caracteristicaconfiguracao.domain.model.FormatoCaracteristicaValor;
import com.totvs.sl.wms.estoque.endereco.domain.model.EnderecoId;
import com.totvs.sl.wms.estoque.estoque.domain.model.Estoque;
import com.totvs.sl.wms.estoque.estoque.domain.model.EstoqueId;
import com.totvs.sl.wms.estoque.estoque.domain.model.SituacaoEstoque;
import com.totvs.sl.wms.estoque.estoque.domain.model.SituacaoEstoqueLiberado;
import com.totvs.sl.wms.estoque.movimentoestoque.domain.model.MovimentoEstoque;
import com.totvs.sl.wms.estoque.produto.domain.model.ProdutoId;
import com.totvs.sl.wms.estoque.rastreio.domain.model.RastreioId;
import com.totvs.sl.wms.estoque.sku.domain.model.SKUId;
import com.totvs.sl.wms.estoque.tipoestoque.domain.model.TipoEstoqueId;
import com.totvs.sl.wms.estoque.unidade.domain.model.UnidadeId;
import com.totvs.sl.wms.estoque.unitizador.domain.model.UnitizadorId;
import com.totvs.sl.wms.estoque.util.amqp.SubjectDomainEvent;

import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
@Builder
public final class EstoqueLiberadoEntradaEfetuadaEvent extends SubjectDomainEvent implements SubjectEntradaEstoque {

	private final UnidadeId unidadeId;
	private final EstoqueOrigem origem;
	private final EstoqueEntrada estoque;

	@Data(staticConstructor = "of")
	public static final class EstoqueOrigem {
		private final String id;
		private final String origem;
	}

	@Data
	@Builder
	public static final class EstoqueEntrada {
		private final EstoqueId id;
		private final ProdutoId produtoId;
		private final SKUId skuId;
		private final UnitizadorId unitizadorId;
		private final TipoEstoqueId tipoEstoqueId;
		private final EnderecoId enderecoId;
		private final List<SituacaoEstoqueEntrada> situacoes;
		private final Boolean avariado;
		private final BigDecimal quantidadeEntrada;
		private final List<CaracteristicaEstoqueEntrada> caracteristicas;
		private final List<EstoqueAtributoSaldoEvent> atributosSaldo;
		private final RastreioId rastreioId;
		private final BigDecimal saldo;
		private final BigDecimal saldoReservado;
		private final BigDecimal saldoDisponivel;
		private final BigDecimal quantidadeBloqueadaMovimentacaoNaoReservada;
		private final BigDecimal quantidadeBloqueadaMovimentacaoReservada;
		private final BigDecimal quantidadeBloqueadaMovimentacaoTotal;
		private final List<SeloEstoqueEvent> selos;
		private final ZonedDateTime dataHoraEntrada;
	}

	@Data(staticConstructor = "of")
	public static final class SituacaoEstoqueEntrada {
		private final ZonedDateTime quando;
	}

	@Data(staticConstructor = "of")
	public static final class CaracteristicaEstoqueEntrada {
		private final CaracteristicaConfiguracaoId caracteristicaConfiguracaoId;
		private final FormatoCaracteristicaValor formato;
		private final String valor;
	}

	@Data(staticConstructor = "of")
	public static final class SeloEstoqueEvent {
		private final String chave;
		private final String valor;
	}

	public static EstoqueLiberadoEntradaEfetuadaEvent from(Estoque estoque, MovimentoEstoque movimentoEstoque) {

		return EstoqueLiberadoEntradaEfetuadaEvent.builder()
												  .unidadeId(estoque.getUnidadeId())
												  .origem(EstoqueLiberadoEntradaEfetuadaEvent.EstoqueOrigem.of(movimentoEstoque.getOrigem()
																															   .getId()
																															   .toString(),
																											   movimentoEstoque.getOrigem()
																															   .getOrigem()))
												  .estoque(EstoqueLiberadoEntradaEfetuadaEvent.EstoqueEntrada.builder()
																											 .id(estoque.getId())
																											 .produtoId(estoque.getProdutoId())
																											 .skuId(estoque.getSkuId())
																											 .unitizadorId(estoque.getUnitizadorId())
																											 .tipoEstoqueId(estoque.getTipoEstoqueId())
																											 .enderecoId(estoque.getEnderecoId())
																											 .situacoes(montarSituacoesEstoque(estoque))
																											 .avariado(estoque.getAvariado())
																											 .quantidadeEntrada(movimentoEstoque.getQuantidade())
																											 .caracteristicas(montarCaracteristicas(estoque))
																											 .atributosSaldo(EstoqueAtributoSaldoEvent.from(estoque.getAtributosSaldo()))
																											 .rastreioId(estoque.getRastreioId())
																											 .saldo(estoque.getSaldo())
																											 .saldoReservado(estoque.getQuantidadeReservada())
																											 .saldoDisponivel(estoque.getSaldoDisponivel())
																											 .quantidadeBloqueadaMovimentacaoNaoReservada(estoque.getQuantidadeBloqueadaParaMovimentacaoEstoqueNaoReservada())
																											 .quantidadeBloqueadaMovimentacaoReservada(estoque.getQuantidadeBloqueadaParaMovimentacaoEstoqueReservada())
																											 .quantidadeBloqueadaMovimentacaoTotal(estoque.getQuantidadeBloqueadaParaMovimentacaoEstoqueTotal())
																											 .selos(estoque.getSelos()
																														   .stream()
																														   .map(selo -> SeloEstoqueEvent.of(selo.getChave(),
																																							selo.getValor()))
																														   .collect(Collectors.toList()))
																											 .dataHoraEntrada(estoque.getDataHoraEntrada())
																											 .build())
												  .build();
	}

	private static List<SituacaoEstoqueEntrada> montarSituacoesEstoque(Estoque estoque) {
		return estoque.getSituacoes()
					  .stream()
					  .map(EstoqueLiberadoEntradaEfetuadaEvent::criarSituacaoEstoqueEntrada)
					  .toList();
	}

	private static SituacaoEstoqueEntrada criarSituacaoEstoqueEntrada(SituacaoEstoque situacao) {
		var situacaoEstoque = (SituacaoEstoqueLiberado) situacao;
		return SituacaoEstoqueEntrada.of(situacaoEstoque.getQuando());
	}

	private static List<CaracteristicaEstoqueEntrada> montarCaracteristicas(Estoque estoque) {
		if (CollectionUtils.isEmpty(estoque.getCaracteristicas())) {
			return new ArrayList<>();
		}
		return estoque.getCaracteristicas()
					  .stream()
					  .map(caracteristica -> CaracteristicaEstoqueEntrada.of(caracteristica.getCaracteristicaConfiguracaoId(),
																			 caracteristica.getFormato(),
																			 caracteristica.getValor().toString()))
					  .collect(Collectors.toList());
	}
}
