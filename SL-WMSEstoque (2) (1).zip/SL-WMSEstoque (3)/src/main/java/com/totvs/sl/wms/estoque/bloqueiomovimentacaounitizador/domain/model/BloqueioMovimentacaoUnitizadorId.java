package com.totvs.sl.wms.estoque.bloqueiomovimentacaounitizador.domain.model;

import java.util.UUID;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.totvs.tjf.core.common.domain.DomainObjectId;

public final class BloqueioMovimentacaoUnitizadorId extends DomainObjectId<UUID> {

	private static final long serialVersionUID = 1703968550460870904L;

	protected BloqueioMovimentacaoUnitizadorId(UUID id) {
		super(id);
	}

	public static BloqueioMovimentacaoUnitizadorId generate() {
		return new BloqueioMovimentacaoUnitizadorId(UUID.randomUUID());
	}
	
	@JsonCreator
	public static BloqueioMovimentacaoUnitizadorId from(String uuid) {
		return uuid == null ? null : new BloqueioMovimentacaoUnitizadorId(UUID.fromString(uuid));
	}
}