package com.totvs.sl.wms.estoque.endereco.api;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.totvs.sl.wms.estoque.endereco.api.dto.AlterarEnderecoCapacidadeDTO;
import com.totvs.sl.wms.estoque.endereco.application.EnderecoApplicationService;
import com.totvs.sl.wms.estoque.endereco.application.command.AlterarCapacidadeEnderecoCommand;
import com.totvs.sl.wms.estoque.endereco.application.command.AtualizarOcupacoesEnderecoCommand;
import com.totvs.sl.wms.estoque.endereco.domain.model.CapacidadeEndereco;
import com.totvs.sl.wms.estoque.endereco.domain.model.DimensaoEndereco;
import com.totvs.sl.wms.estoque.endereco.domain.model.EnderecoId;
import com.totvs.sl.wms.estoque.endereco.exception.WMSEnderecoAlteracaoCapacidadeEnderecoConstraintException;
import com.totvs.tjf.api.context.stereotype.ApiGuideline;
import com.totvs.tjf.core.validation.ValidatorService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import lombok.AllArgsConstructor;

@RestController
@RequestMapping(path = EnderecoController.PATH, produces = APPLICATION_JSON_VALUE, consumes = APPLICATION_JSON_VALUE)
@AllArgsConstructor
@ApiGuideline(ApiGuideline.ApiGuidelineVersion.V2)
public class EnderecoController {

	public static final String PATH = "/api/v1/estoques/enderecos";

	private ValidatorService validatorService;
	private EnderecoApplicationService enderecoApplicationService;

	@Operation(description = "Realizar alteração da capacidade no endereço", method = "POST")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "204", description = "Alteração da capacidade do endereço realizada com sucesso."),
			@ApiResponse(responseCode = "400", description = "A alteração da capacidade do endereço não pôde ser realizada."),
			@ApiResponse(responseCode = "404", description = "Endereço não encontrado.") })
	@PostMapping(path = "/{id}/alterarCapacidade")
	public ResponseEntity<Void> alterarCapacidade(@PathVariable String id,
												  @RequestBody AlterarEnderecoCapacidadeDTO dto) {

		validatorService.validate(dto).ifPresent(violations -> {
			throw new WMSEnderecoAlteracaoCapacidadeEnderecoConstraintException(violations);
		});

		DimensaoEndereco dimensao = null;

		if (dto.getCapacidadeAltura() != null || dto.getCapacidadeLargura() != null
				|| dto.getCapacidadeComprimento() != null)
			dimensao = DimensaoEndereco.of(dto.getCapacidadeAltura(),
										   dto.getCapacidadeLargura(),
										   dto.getCapacidadeComprimento());

		var cmd = AlterarCapacidadeEnderecoCommand.of(EnderecoId.from(id),
													  CapacidadeEndereco.of(dto.getCapacidadeUnitizador(),
																			dto.getCapacidadePeso(),
																			dimensao));

		enderecoApplicationService.handle(cmd);

		return ResponseEntity.noContent().build();
	}

	@Operation(description = "Atualizar ocupação e ocupação prevista", method = "POST", hidden = true)
	@ApiResponses(value = {
			@ApiResponse(responseCode = "204", description = "Alteração da capacidade do endereço realizada com sucesso."),
			@ApiResponse(responseCode = "400", description = "A alteração da capacidade do endereço não pôde ser realizada."),
			@ApiResponse(responseCode = "404", description = "Endereço não encontrado.") })
	@PostMapping(path = "/{id}/atualizarOcupacao")
	public ResponseEntity<Void> atualizarOcupacao(@PathVariable String id) {

		enderecoApplicationService.handle(AtualizarOcupacoesEnderecoCommand.of(EnderecoId.from(id)));

		return ResponseEntity.noContent().build();
	}
}
