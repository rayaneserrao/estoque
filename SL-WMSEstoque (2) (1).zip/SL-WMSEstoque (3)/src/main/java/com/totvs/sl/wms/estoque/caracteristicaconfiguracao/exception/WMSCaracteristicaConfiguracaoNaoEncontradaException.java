package com.totvs.sl.wms.estoque.caracteristicaconfiguracao.exception;

import com.totvs.tjf.api.context.stereotype.error.ApiNotFound;

@ApiNotFound
public class WMSCaracteristicaConfiguracaoNaoEncontradaException extends RuntimeException {

	private static final long serialVersionUID = 8784344116300190672L;

}
