package com.totvs.sl.wms.estoque.caracteristicaconfiguracao.domain.model;

import java.time.ZonedDateTime;

import com.totvs.sl.wms.estoque.util.DateTimeUtils;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor(access = AccessLevel.PRIVATE)
@AllArgsConstructor(access = AccessLevel.PRIVATE)
public final class SituacaoCaracteristica {

	private SituacaoCaracteristicaValor valor;

	private ZonedDateTime quando;

	public static SituacaoCaracteristica ofAtivo() {
		return new SituacaoCaracteristica(SituacaoCaracteristicaValor.ATIVO, DateTimeUtils.getNow());
	}

	public static SituacaoCaracteristica ofInativo() {
		return new SituacaoCaracteristica(SituacaoCaracteristicaValor.INATIVO, DateTimeUtils.getNow());
	}

	public boolean isAtivo() {
		return this.valor.equals(SituacaoCaracteristicaValor.ATIVO);
	}

	public boolean isInativo() {
		return this.valor.equals(SituacaoCaracteristicaValor.INATIVO);
	}
}
