package com.totvs.sl.wms.estoque.estoque.domain.event;

import java.math.BigDecimal;
import java.util.List;
import java.util.stream.Collectors;

import com.totvs.sl.wms.estoque.estoque.application.EstoqueEfetuarSaidaApplicationService.EstoquesSaidaMovimentoLista;
import com.totvs.sl.wms.estoque.estoque.domain.model.EstoqueId;
import com.totvs.sl.wms.estoque.produto.domain.model.ProdutoId;
import com.totvs.sl.wms.estoque.unidade.domain.model.UnidadeId;
import com.totvs.sl.wms.estoque.util.amqp.TransactionalEvent;

import lombok.Builder;
import lombok.Data;
import lombok.Getter;
import lombok.ToString;

@Getter
@ToString
public final class EstoqueBloqueadoSaidaLoteEfetuadaEvent extends TransactionalEvent
		implements SubjectSaidaEstoqueLoteEvent {

	public static final String NAME = "EstoqueBloqueadoSaidaLoteEfetuadaEvent";

	public static final String CONDITIONAL_EXPRESSION = "headers['type']=='" + NAME + "'";

	private final UnidadeId unidadeId;

	private final List<EstoqueSaida> estoques;

	@Data
	@Builder
	public static final class EstoqueSaida {
		private final EstoqueId id;
		private final BigDecimal saldo;
		private final BigDecimal saldoReservado;
		private final BigDecimal saldoDisponivel;
		private final BigDecimal quantidadeBloqueadaMovimentacaoNaoReservada;
		private final BigDecimal quantidadeBloqueadaMovimentacaoReservada;
		private final BigDecimal quantidadeBloqueadaMovimentacaoTotal;
		private final List<EstoqueAtributoSaldoEvent> atributosSaldo;
		private final ProdutoId produtoId;
	}

	@Builder
	private EstoqueBloqueadoSaidaLoteEfetuadaEvent(String transactionId,
												   String generatedBy,
												   UnidadeId unidadeId,
												   List<EstoqueSaida> estoques) {
		super(generatedBy, transactionId);
		this.unidadeId = unidadeId;
		this.estoques = estoques;
	}

	public static EstoqueBloqueadoSaidaLoteEfetuadaEvent from(EstoquesSaidaMovimentoLista listaEstoqueMovimento) {

		var estoquesSaida = listaEstoqueMovimento.getEstoquesSaida().stream().map(estoqueSaida -> {

			var produtoId = listaEstoqueMovimento.getMovimentosSaida()
			                                     .stream()
			                                     .filter(movimentoEstoque -> movimentoEstoque.getEstoqueId()
			                                                                                 .equals(estoqueSaida.getEstoqueId()))
			                                     .findFirst()
			                                     .orElseThrow()
			                                     .getProdutoId();

			return EstoqueSaida.builder()
			                   .id(estoqueSaida.getEstoqueId())
			                   .saldo(estoqueSaida.getSaldo())
			                   .saldoReservado(estoqueSaida.getSaldoReservado())
			                   .saldoDisponivel(estoqueSaida.getSaldoDisponivel())
			                   .quantidadeBloqueadaMovimentacaoNaoReservada(estoqueSaida.getQuantidadeBloqueadaMovimentacaoNaoReservada())
			                   .quantidadeBloqueadaMovimentacaoReservada(estoqueSaida.getQuantidadeBloqueadaMovimentacaoReservada())
			                   .quantidadeBloqueadaMovimentacaoTotal(estoqueSaida.getQuantidadeBloqueadaMovimentacaoTotal())
			                   .atributosSaldo(EstoqueAtributoSaldoEvent.from(estoqueSaida.getAtributosSaldo()))
			                   .produtoId(produtoId)
			                   .build();
		}).collect(Collectors.toList());

		return EstoqueBloqueadoSaidaLoteEfetuadaEvent.builder()
													 .unidadeId(listaEstoqueMovimento.getMovimentosSaida()
																					 .get(0)
																					 .getUnidadeId())
													 .estoques(estoquesSaida)
													 .generatedBy(listaEstoqueMovimento.getMovimentosSaida()
																					   .get(0)
																					   .getOrigem()
																					   .getOrigem())
													 .transactionId(listaEstoqueMovimento.getMovimentosSaida()
																						 .get(0)
																						 .getOrigem()
																						 .getId()
																						 .toString())
													 .build();

	}
}
