package com.totvs.sl.wms.estoque.caracteristicavalor.domain.model;

import static com.totvs.tjf.autoconfigure.ValidationUtils.validateIntegrity;

import java.time.LocalDate;
import java.util.Comparator;

import javax.validation.constraints.NotNull;

import com.totvs.sl.wms.estoque.caracteristicaconfiguracao.domain.model.CaracteristicaConfiguracaoId;
import com.totvs.sl.wms.estoque.caracteristicaconfiguracao.domain.model.FormatoCaracteristicaValor;
import com.totvs.sl.wms.estoque.caracteristicavalor.exception.WMSCaracteristicaValorFaixaDataConstraintException;
import com.totvs.sl.wms.estoque.caracteristicavalor.exception.WMSCaracteristicaValorFaixaInicialMaiorQueFinalException;
import com.totvs.sl.wms.estoque.caracteristicavalor.validator.ValidCaracteristicaValorInicialFinal;

import lombok.AccessLevel;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Getter
@EqualsAndHashCode
@NoArgsConstructor(access = AccessLevel.PRIVATE)
@ValidCaracteristicaValorInicialFinal(message = "{CaracteristicaValorFaixaData.valorInicialOuValorFinal.NotNull}")
public class CaracteristicaValorFaixaData implements CaracteristicaValorFaixa<LocalDate> {

	@NotNull(message = "{CaracteristicaValorFaixaData.caracteristicaConfiguracaoId.NotNull}")
	private CaracteristicaConfiguracaoId caracteristicaConfiguracaoId;

	private LocalDate valorInicial;
	private LocalDate valorFinal;

	@Builder
	private CaracteristicaValorFaixaData(CaracteristicaConfiguracaoId caracteristicaConfiguracaoId,
										 LocalDate valorInicial,
										 LocalDate valorFinal) {

		this.caracteristicaConfiguracaoId = caracteristicaConfiguracaoId;
		this.valorInicial = valorInicial;
		this.valorFinal = valorFinal;

		validarValorInicialMaiorQueValorFinal();

		validateIntegrity(this).ifPresent(violations -> {
			throw new WMSCaracteristicaValorFaixaDataConstraintException(violations);
		});
	}

	private void validarValorInicialMaiorQueValorFinal() {

		if (this.valorInicial == null || this.valorFinal == null)
			return;

		if (this.valorInicial.compareTo(this.valorFinal) > 0)
			throw new WMSCaracteristicaValorFaixaInicialMaiorQueFinalException();
	}

	@Override
	public FormatoCaracteristicaValor getFormato() {
		return FormatoCaracteristicaValor.DATA;
	}

	@Override
	public int compareTo(CaracteristicaValorFaixa<LocalDate> caracteristica) {
		return caracteristica instanceof CaracteristicaValorFaixaData caracteristicaValorFaixaData
				? Comparator.comparing(CaracteristicaValorFaixaData::getCaracteristicaConfiguracaoId)
							.thenComparing(CaracteristicaValorFaixaData::getValorInicial,
										   Comparator.nullsFirst(LocalDate::compareTo))
							.thenComparing(CaracteristicaValorFaixaData::getValorFinal,
										   Comparator.nullsFirst(LocalDate::compareTo))
							.compare(this, caracteristicaValorFaixaData)
				: this.getCaracteristicaConfiguracaoId().compareTo(caracteristica.getCaracteristicaConfiguracaoId());
	}
}
