package com.totvs.sl.wms.estoque.estoque.domain.model;

import java.time.ZonedDateTime;

public interface SituacaoEstoque {

	SituacaoEstoqueValor getSituacaoEstoque();

	ZonedDateTime getQuando();
}
