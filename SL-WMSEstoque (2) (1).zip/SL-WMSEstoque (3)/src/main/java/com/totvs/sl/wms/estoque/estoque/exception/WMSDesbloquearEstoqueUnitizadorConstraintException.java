package com.totvs.sl.wms.estoque.estoque.exception;

import com.totvs.tjf.api.context.stereotype.error.ApiBadRequest;

import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;
import java.util.Set;

@ApiBadRequest
public class WMSDesbloquearEstoqueUnitizadorConstraintException extends ConstraintViolationException {

	private static final long serialVersionUID = 8098961976113492059L;

	public WMSDesbloquearEstoqueUnitizadorConstraintException(Set<? extends ConstraintViolation<?>> constraintViolations) {
		super(constraintViolations);
	}
}
