package com.totvs.sl.wms.estoque.estoque.application;

import java.math.BigDecimal;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import com.totvs.sl.wms.estoque.atributoestoquevalor.domain.model.AtributoEstoqueValor;
import com.totvs.sl.wms.estoque.config.amqp.WMSPublisher;
import com.totvs.sl.wms.estoque.endereco.domain.model.Endereco;
import com.totvs.sl.wms.estoque.endereco.domain.model.EnderecoDomainRepository;
import com.totvs.sl.wms.estoque.endereco.domain.model.EnderecoId;
import com.totvs.sl.wms.estoque.estoque.application.command.EfetuarDivisaoFusaoEstoqueCommand;
import com.totvs.sl.wms.estoque.estoque.domain.event.EstoqueDivisaoFusaoEfetuadaEvent;
import com.totvs.sl.wms.estoque.estoque.domain.model.Estoque;
import com.totvs.sl.wms.estoque.estoque.domain.model.EstoqueAtributoSaldo;
import com.totvs.sl.wms.estoque.estoque.domain.model.EstoqueDomainRepository;
import com.totvs.sl.wms.estoque.estoque.domain.model.EstoqueHash;
import com.totvs.sl.wms.estoque.estoque.domain.model.FracionadoId;
import com.totvs.sl.wms.estoque.estoque.domain.service.AtualizaSaldoEstoqueEntradaDomainService;
import com.totvs.sl.wms.estoque.estoque.domain.service.AtualizaSaldoEstoqueSaidaDomainService;
import com.totvs.sl.wms.estoque.estoque.domain.service.ConfiguraEstoqueParaEntradaDomainService;
import com.totvs.sl.wms.estoque.estoque.exception.WMSEstoqueDivisaoFusaoJaSeEncontraNoUnitizadorETipoDeEstoqueDestinoException;
import com.totvs.sl.wms.estoque.estoque.exception.WMSEstoqueDivisaoFusaoUnitizadorOrigemEDestinoIguaisException;
import com.totvs.sl.wms.estoque.estoque.exception.WMSUnitizadorPossuiSaldoEnderecoDiferenteIndicadoFusaoEstoqueException;
import com.totvs.sl.wms.estoque.movimentoestoque.domain.model.MovimentoEstoqueDomainRepository;
import com.totvs.sl.wms.estoque.movimentoestoque.domain.model.MovimentoEstoqueId;
import com.totvs.sl.wms.estoque.origem.domain.model.Origem;
import com.totvs.sl.wms.estoque.origem.domain.model.OrigemId;
import com.totvs.sl.wms.estoque.produto.domain.model.ProdutoDomainRepository;
import com.totvs.sl.wms.estoque.sku.domain.model.SKU;
import com.totvs.sl.wms.estoque.sku.domain.model.SKUDomainRepository;
import com.totvs.sl.wms.estoque.tipoestoque.domain.model.TipoEstoqueId;
import com.totvs.sl.wms.estoque.unitizador.domain.model.Unitizador;
import com.totvs.sl.wms.estoque.unitizador.domain.model.UnitizadorDomainRepository;
import com.totvs.sl.wms.estoque.unitizador.domain.model.UnitizadorId;

import lombok.AllArgsConstructor;

@Service
@Transactional
@AllArgsConstructor
public class EstoqueDividirFundirApplicationService {

	private final MovimentoEstoqueDomainRepository movimentoEstoqueRepository;
	private final EstoqueDomainRepository estoqueRepository;
	private final ProdutoDomainRepository produtoRepository;
	private final SKUDomainRepository skuRepository;
	private final EnderecoDomainRepository enderecoRepository;
	private final UnitizadorDomainRepository unitizadorRepository;
	private final ConfiguraEstoqueParaEntradaDomainService configuraEstoqueEntradaService;
	private final AtualizaSaldoEstoqueEntradaDomainService atualizaSaldoEntradaService;
	private final AtualizaSaldoEstoqueSaidaDomainService atualizaSaldoSaidaService;
	private final WMSPublisher publisher;

	public EstoquesSaidaEntradaMovimentoLista handle(final EfetuarDivisaoFusaoEstoqueCommand cmd) {

		var estoqueSaida = estoqueRepository.findWithLockByIdOrThrowNotFound(cmd.getEstoqueId());

		var unitizador = unitizadorRepository.findWithLockByIdAndUnidadeIdOrThrowNotFound(cmd.getUnitizadorIdDestino(),
																						  estoqueSaida.getUnidadeId());

		var sku = skuRepository.findByIdAndProdutoIdThrowNotFound(estoqueSaida.getSkuId(), estoqueSaida.getProdutoId());

		var atributos = this.obterListaEstoqueAtributoSaldo(cmd.getAtributos(), cmd.getQuantidade());

		EstoquesSaidaEntradaMovimentos eventoMovimentos = realizarDivisaoFusao(sku,
																			   estoqueSaida,
																			   cmd.getQuantidade(),
																			   unitizador,
																			   cmd.getEnderecoIdDestino(),
																			   atributos,
																			   cmd.getNovoTipoEstoqueId());

		eventoMovimentos.getMovimentoSaida().getEvents().forEach(publisher::dispatch);
		eventoMovimentos.getMovimentoEntrada().getEvents().forEach(publisher::dispatch);

		publisher.dispatch(EstoqueDivisaoFusaoEfetuadaEvent.from(estoqueSaida,
																 eventoMovimentos.getEstoques().getEstoqueEntrada()));

		return new EstoquesSaidaEntradaMovimentoLista(List.of(eventoMovimentos.getEstoques().getEstoqueSaida()),
													  List.of(eventoMovimentos.getEstoques().getEstoqueEntrada()),
													  List.of(eventoMovimentos.getMovimentoSaida()),
													  List.of(eventoMovimentos.getMovimentoEntrada()));
	}

	private List<EstoqueAtributoSaldo> obterListaEstoqueAtributoSaldo(List<AtributoEstoqueValor<?>> atributos,
																	  BigDecimal quantidade) {
		return CollectionUtils.isEmpty(atributos) ? null : List.of(EstoqueAtributoSaldo.of(atributos, quantidade));
	}

	private EstoquesSaidaEntradaMovimentos realizarDivisaoFusao(SKU sku,
																Estoque estoqueSaida,
																BigDecimal quantidade,
																Unitizador unitizador,
																EnderecoId enderecoId,
																List<EstoqueAtributoSaldo> atributosSaldo,
																Optional<TipoEstoqueId> novoTipoEstoqueId) {

		var origem = Origem.of(OrigemId.from(UUID.randomUUID().toString()), "DivisaoFusaoEstoque");

		var rastreioId = configuraEstoqueEntradaService.definirRastreio(quantidade, estoqueSaida);

		var movimentoEstoqueIdSaida = MovimentoEstoqueId.generate();
		var movimentoEstoqueIdEntrada = MovimentoEstoqueId.generate();

		var estoquesSaldos = estoqueRepository.findWithLockByUnitizadorIdAndUnidadeId(unitizador.getId(),
																					  unitizador.getUnidadeId());

		var tipoEstoqueId = estoqueSaida.getTipoEstoqueId();

		if (novoTipoEstoqueId.isPresent()) {
			tipoEstoqueId = novoTipoEstoqueId.get();
			if (estoqueSaida.getTipoEstoqueId().equals(tipoEstoqueId)
					&& this.unitizadoresIguais(estoqueSaida.getUnitizadorId(), unitizador.getId())) {
				throw new WMSEstoqueDivisaoFusaoJaSeEncontraNoUnitizadorETipoDeEstoqueDestinoException();
			}
		} else {
			if (this.unitizadoresIguais(estoqueSaida.getUnitizadorId(), unitizador.getId()))
				throw new WMSEstoqueDivisaoFusaoUnitizadorOrigemEDestinoIguaisException();
		}

		if (enderecoId != null && !CollectionUtils.isEmpty(estoquesSaldos)
				&& estoquesSaldos.stream().anyMatch(estoque -> !estoque.getEnderecoId().equals(enderecoId)))
			throw new WMSUnitizadorPossuiSaldoEnderecoDiferenteIndicadoFusaoEstoqueException();

		EnderecoId enderecoIdDestino = enderecoId != null ? enderecoId : null;

		if (CollectionUtils.isEmpty(estoquesSaldos)) {
			if (enderecoIdDestino == null) {
				enderecoIdDestino = estoqueSaida.getEnderecoId();
			}
		} else {
			enderecoIdDestino = estoquesSaldos.iterator().next().getEnderecoId();
		}

		var enderecoDestino = enderecoRepository.findByIdOrThrowNotFound(enderecoIdDestino);

		var estoqueHash = EstoqueHash.builder()
									 .unidadeId(estoqueSaida.getUnidadeId())
									 .produtoId(estoqueSaida.getProdutoId())
									 .skuId(sku.getId())
									 .unitizadorId(unitizador.getId())
									 .tipoEstoqueId(tipoEstoqueId)
									 .enderecoId(enderecoDestino.getId())
									 .fracionadoId(sku.isFracionado() ? FracionadoId.generate() : null)
									 .situacoes(estoqueSaida.getSituacoes())
									 .avariado(estoqueSaida.getAvariado())
									 .caracteristicas(estoqueSaida.getCaracteristicas())
									 .build();

		var produto = produtoRepository.findByIdOrThrowNotFound(estoqueSaida.getProdutoId());

		var estoqueEntrada = configuraEstoqueEntradaService.configurar(produto,
																	   sku,
																	   estoqueSaida.getSituacoes().iterator().next(),
																	   estoqueHash,
																	   estoqueSaida.getBloqueioMovimentacaoUnitizadorId()
																				   .orElse(null),
																	   rastreioId,
																	   estoqueSaida.getSelos(),
																	   estoqueSaida.getDataHoraEntrada());

		var enderecosDiferentes = !estoqueSaida.getEnderecoId().equals(enderecoIdDestino);

		var alteraOcupacaoEnderecoOrigem = enderecosDiferentes
				&& this.determinarAlteraOcupacaoEndereco(enderecoRepository.findByIdOrThrowNotFound(estoqueSaida.getEnderecoId()));

		var alteraOcupacaoEnderecoDestino = enderecosDiferentes
				&& this.determinarAlteraOcupacaoEndereco(enderecoDestino);

		var movimentoEstoqueSaida = estoqueSaida.efetuarSaidaSaldoParcial(produto,
																		  sku,
																		  quantidade,
																		  origem,
																		  movimentoEstoqueIdSaida,
																		  movimentoEstoqueIdEntrada,
																		  estoqueEntrada.getRastreioId(),
																		  alteraOcupacaoEnderecoOrigem,
																		  atributosSaldo);
		atualizaSaldoSaidaService.atualizar(estoqueSaida);

		movimentoEstoqueRepository.insert(movimentoEstoqueSaida);

		var movimentoEstoqueEntrada = estoqueEntrada.efetuarEntradaDivisaoFusao(enderecoDestino,
																				produto,
																				sku,
																				quantidade,
																				origem,
																				movimentoEstoqueIdEntrada,
																				movimentoEstoqueIdSaida,
																				estoqueSaida.getRastreioId(),
																				alteraOcupacaoEnderecoDestino,
																				atributosSaldo);
		atualizaSaldoEntradaService.atualizar(estoqueEntrada);

		movimentoEstoqueRepository.insert(movimentoEstoqueEntrada);

		estoqueSaida.removeEvents();
		estoqueEntrada.removeEvents();

		return EstoquesSaidaEntradaMovimentos.of(EstoqueSaidaEntrada.of(estoqueSaida.getUnidadeId(),
																		EstoqueSaida.from(estoqueSaida),
																		estoqueEntrada),
												 movimentoEstoqueSaida,
												 movimentoEstoqueEntrada);
	}

	private boolean determinarAlteraOcupacaoEndereco(Endereco endereco) {
		return !endereco.isDoca() && !endereco.isStage();
	}

	private boolean unitizadoresIguais(UnitizadorId unitizadorIdOrigem, UnitizadorId unitizadorIdDestino) {

		if (Objects.isNull(unitizadorIdOrigem))
			return false;

		return unitizadorIdOrigem.equals(unitizadorIdDestino);
	}
}
