package com.totvs.sl.wms.estoque.estoque.domain.event;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.springframework.util.CollectionUtils;

import com.totvs.sl.wms.estoque.atributoestoquevalor.domain.event.AtributoEstoqueValorEvent;
import com.totvs.sl.wms.estoque.estoque.domain.model.EstoqueAtributoSaldo;
import com.totvs.sl.wms.estoque.estoque.domain.model.EstoqueAtributoSaldoId;

import lombok.Data;

@Data(staticConstructor = "of")
public final class EstoqueAtributoSaldoEvent {

	private final EstoqueAtributoSaldoId id;
	private final BigDecimal saldo;
	private final List<AtributoEstoqueValorEvent> atributos;

	public static List<EstoqueAtributoSaldoEvent> from(List<EstoqueAtributoSaldo> atributosSaldo) {
		if (CollectionUtils.isEmpty(atributosSaldo)) {
			return new ArrayList<>();
		}
		return atributosSaldo.stream()
							 .map(atributoSaldo -> EstoqueAtributoSaldoEvent.of(atributoSaldo.getId(),
																				atributoSaldo.getSaldo(),
																				AtributoEstoqueValorEvent.from(atributoSaldo)))
							 .toList();
	}
}
