package com.totvs.sl.wms.estoque.estoque.api.dto;

import java.math.BigDecimal;
import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import com.totvs.sl.wms.estoque.atributoestoquevalor.api.dto.AtributoEstoqueValorDTO;
import com.totvs.sl.wms.estoque.endereco.domain.model.EnderecoId;
import com.totvs.sl.wms.estoque.estoque.domain.model.EstoqueId;
import com.totvs.sl.wms.estoque.unidade.domain.model.UnidadeId;
import com.totvs.sl.wms.estoque.unitizador.domain.model.UnitizadorId;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor(force = true)
@AllArgsConstructor(staticName = "of")
public final class TransferirEnderecoEstoqueDTO {

	@NotNull(message = "{TransferirEnderecoEstoqueDTO.unidadeId.NotNull}")
	private final UnidadeId unidadeId;

	@NotNull(message = "{TransferirEnderecoEstoqueDTO.estoqueIdOrigem.NotNull}")
	private final EstoqueId estoqueIdOrigem;

	private final UnitizadorId unitizadorIdDestino;

	@NotNull(message = "{TransferirEnderecoEstoqueDTO.enderecoIdDestino.NotNull}")
	private final EnderecoId enderecoIdDestino;

	private final BigDecimal quantidade;

	private final String origem;

	@Valid
	private final List<AtributoEstoqueValorDTO> atributos;
}
