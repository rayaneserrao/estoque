package com.totvs.sl.wms.estoque.caracteristicavalor.exception;

import java.util.Set;

import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;

import com.totvs.tjf.api.context.stereotype.error.ApiBadRequest;

@ApiBadRequest("WMSGenericConstraintViolationException")
public class WMSCaracteristicaValorDataConstraintException extends ConstraintViolationException {

	private static final long serialVersionUID = 1L;

	public WMSCaracteristicaValorDataConstraintException(Set<? extends ConstraintViolation<?>> constraintViolations) {
		super(constraintViolations);
	}

}
