package com.totvs.sl.wms.estoque.estoque.amqp.cmd;

import javax.validation.constraints.NotNull;

import com.totvs.sl.wms.estoque.endereco.domain.model.EnderecoId;
import com.totvs.sl.wms.estoque.unidade.domain.model.UnidadeId;
import com.totvs.sl.wms.estoque.unitizador.domain.model.UnitizadorId;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public final class BloquearMovimentacaoUnitizadorEstoqueCmd {

	public static final String NAME = "BloquearMovimentacaoUnitizadorEstoqueCmd";
	public static final String CONDITIONAL_EXPRESSION = "headers['type']=='" + NAME + "'";

	@NotNull(message = "{BloquearMovimentacaoUnitizadorEstoqueCmd.unidadeId.NotNull}")
	private final UnidadeId unidadeId;

	@NotNull(message = "{BloquearMovimentacaoUnitizadorEstoqueCmd.unitizadorId.NotNull}")
	private final UnitizadorId unitizadorId;

	private final EnderecoId enderecoIdOrigem;

	private final EnderecoId enderecoIdDestino;

	private final String chaveAcesso;
}
