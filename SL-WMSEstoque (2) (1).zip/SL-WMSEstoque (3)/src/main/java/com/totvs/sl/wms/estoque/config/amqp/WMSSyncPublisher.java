package com.totvs.sl.wms.estoque.config.amqp;

import org.slf4j.MDC;
import org.springframework.cloud.stream.annotation.EnableBinding;
import org.springframework.messaging.support.MessageHeaderAccessor;

import com.totvs.sl.wms.estoque.config.amqp.WMSSyncChannel.WMSExchangeSyncOutput;
import com.totvs.sl.wms.estoque.util.Constants;
import com.totvs.sl.wms.estoque.util.exportdata.IExportDataCmd;
import com.totvs.sl.wms.estoque.util.exportdata.IExportDataResult;
import com.totvs.tjf.messaging.context.TOTVSMessageBuilder;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@EnableBinding(WMSSyncChannel.WMSExchangeSyncOutput.class)
@AllArgsConstructor
public class WMSSyncPublisher {

	private WMSExchangeSyncOutput wmsExchangeSyncOutput;

	public void dispatch(final IExportDataResult message) {
		this.dispatch(message, buildHeader(message));
	}

	public void dispatch(final IExportDataCmd message) {
		this.dispatch(message, buildHeader(message));
	}

	private <T> void dispatch(T content, MessageHeaderAccessor headers) {

		var totvsMessage = TOTVSMessageBuilder.<T>withDefaultType()
											  .setContent(content)
											  .asCloudEvent()
											  .setHeaders(headers)
											  .build();

		wmsExchangeSyncOutput.output().send(totvsMessage);

		log.info("Publishing... sl-destination {} content: {}", headers.getHeader("sl-destination"), content);
	}

	private MessageHeaderAccessor buildHeader(final IExportDataResult message) {

		var accessor = new MessageHeaderAccessor();

		accessor.setHeader("sl-destination", MDC.get(Constants.EXPORT_DATA_DESTINATION));

		return accessor;
	}

	private MessageHeaderAccessor buildHeader(final IExportDataCmd message) {

		var accessor = new MessageHeaderAccessor();

		accessor.setHeader("sl-message-type", message.getMessageType());

		return accessor;
	}
}