package com.totvs.sl.wms.estoque.estoque.api.dto;

import javax.validation.constraints.NotNull;

import com.totvs.sl.wms.estoque.endereco.domain.model.EnderecoId;
import com.totvs.sl.wms.estoque.unidade.domain.model.UnidadeId;
import com.totvs.sl.wms.estoque.unitizador.domain.model.UnitizadorId;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor(force = true)
@AllArgsConstructor(staticName = "of")
public final class TransferirEnderecoUnitizadorDTO {

	@NotNull(message = "{TransferirEnderecoUnitizadorDTO.unidadeId.NotNull}")
	private final UnidadeId unidadeId;

	@NotNull(message = "{TransferirEnderecoUnitizadorDTO.unitizadorId.NotNull}")
	private final UnitizadorId unitizadorId;

	@NotNull(message = "{TransferirEnderecoUnitizadorDTO.enderecoIdDestino.NotNull}")
	private final EnderecoId enderecoIdDestino;

}
