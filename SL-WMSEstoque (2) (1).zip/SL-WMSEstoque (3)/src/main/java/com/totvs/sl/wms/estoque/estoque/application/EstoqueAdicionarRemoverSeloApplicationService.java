package com.totvs.sl.wms.estoque.estoque.application;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.totvs.sl.wms.estoque.config.amqp.WMSPublisher;
import com.totvs.sl.wms.estoque.estoque.application.command.AdicionarSeloEstoqueCommand;
import com.totvs.sl.wms.estoque.estoque.application.command.RemoverSeloEstoqueCommand;
import com.totvs.sl.wms.estoque.estoque.domain.model.EstoqueDomainRepository;

import lombok.AllArgsConstructor;

@Service
@Transactional
@AllArgsConstructor
public class EstoqueAdicionarRemoverSeloApplicationService {

	private final EstoqueDomainRepository estoqueRepository;
	private final WMSPublisher publisher;

	public void handle(AdicionarSeloEstoqueCommand cmd) {

		var estoque = estoqueRepository.findWithLockByIdOrThrowNotFound(cmd.getId());

		estoque.adicionarSelo(cmd.getSelo());

		estoqueRepository.update(estoque);

		publisher.dispatch(estoque.getEvents());
	}

	public void handle(RemoverSeloEstoqueCommand cmd) {

		var estoque = estoqueRepository.findWithLockByIdOrThrowNotFound(cmd.getId());

		estoque.removerSelo(cmd.getSelo());

		estoqueRepository.update(estoque);

		publisher.dispatch(estoque.getEvents());
	}

}
