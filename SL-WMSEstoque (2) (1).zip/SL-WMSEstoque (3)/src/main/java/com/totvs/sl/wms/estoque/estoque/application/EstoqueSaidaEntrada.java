package com.totvs.sl.wms.estoque.estoque.application;

import com.totvs.sl.wms.estoque.estoque.domain.model.Estoque;
import com.totvs.sl.wms.estoque.unidade.domain.model.UnidadeId;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor(staticName = "of")
public final class EstoqueSaidaEntrada {
	private UnidadeId unidadeId;
	private EstoqueSaida estoqueSaida;
	private Estoque estoqueEntrada;
}
