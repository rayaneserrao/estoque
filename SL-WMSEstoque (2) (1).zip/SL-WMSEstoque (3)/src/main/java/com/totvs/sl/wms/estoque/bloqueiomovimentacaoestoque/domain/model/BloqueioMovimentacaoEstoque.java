package com.totvs.sl.wms.estoque.bloqueiomovimentacaoestoque.domain.model;

import static com.totvs.tjf.autoconfigure.ValidationUtils.validateIntegrity;

import java.math.BigDecimal;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import javax.persistence.Table;
import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.NotNull;

import org.springframework.util.CollectionUtils;

import com.totvs.sl.wms.estoque.bloqueiomovimentacaoestoque.exception.WMSBloqueioMovimentacaoEstoqueComReservaNaoRealizadoQuantidadeNaoDeveSerSuperiorSaldoDisponivelParaAssociarReservaException;
import com.totvs.sl.wms.estoque.bloqueiomovimentacaoestoque.exception.WMSBloqueioMovimentacaoEstoqueConstraintException;
import com.totvs.sl.wms.estoque.endereco.domain.model.EnderecoId;
import com.totvs.sl.wms.estoque.estoque.domain.model.Estoque;
import com.totvs.sl.wms.estoque.estoque.domain.model.EstoqueAtributoSaldo;
import com.totvs.sl.wms.estoque.estoque.domain.model.EstoqueId;
import com.totvs.sl.wms.estoque.estoque.domain.model.EstoqueReservaDefinitiva;
import com.totvs.sl.wms.estoque.estoque.exception.WMSBloqueioMovimentacaoEstoqueReservaDefinitivaNaoPertenceAoEstoqueException;
import com.totvs.sl.wms.estoque.origem.domain.model.Origem;
import com.totvs.sl.wms.estoque.produto.domain.model.Produto;
import com.totvs.sl.wms.estoque.reservadefinitivaestoque.domain.model.ReservaDefinitivaEstoque;
import com.totvs.sl.wms.estoque.reservadefinitivaestoque.domain.model.ReservaDefinitivaEstoqueId;
import com.totvs.sl.wms.estoque.unitizador.domain.model.UnitizadorId;
import com.totvs.tjf.core.stereotype.Aggregate;
import com.totvs.tjf.repository.aggregate.metadata.AggregateDomainMetadataInfo;

import lombok.AccessLevel;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Singular;
import lombok.ToString;

@ToString
@Getter
@Aggregate
@Table(name = "bloqueio_movimentacao_estoque")
@EqualsAndHashCode(callSuper = true)
@NoArgsConstructor(access = AccessLevel.PROTECTED, force = true)
public class BloqueioMovimentacaoEstoque extends AggregateDomainMetadataInfo<@NotNull BloqueioMovimentacaoEstoqueId> {

	@NotNull(message = "{BloqueioMovimentacaoEstoque.estoqueId.NotNull}")
	private EstoqueId estoqueId;

	@NotNull(message = "{BloqueioMovimentacaoEstoque.origem.NotNull}")
	private Origem origem;

	@NotNull(message = "{BloqueioMovimentacaoEstoque.quantidade.NotNull}")
	@DecimalMin(value = "0.0001", message = "{BloqueioMovimentacaoEstoque.quantidade.DecimalMin}")
	private BigDecimal quantidade;

	private Set<EstoqueReservaDefinitiva> reservasDefinitivas = new HashSet<>();
	private EnderecoId enderecoIdDestino;
	private UnitizadorId unitizadorIdDestino;

	@Builder
	public BloqueioMovimentacaoEstoque(BloqueioMovimentacaoEstoqueId id, // NOSONAR
									   Estoque estoque,
									   Origem origem,
									   BigDecimal quantidade,
									   @Singular("reservaDefinitiva") Collection<EstoqueReservaDefinitiva> reservasDefinitivas,
									   EnderecoId enderecoIdDestino,
									   UnitizadorId unitizadorIdDestino,
									   Produto produto) {
		super(id);
		this.estoqueId = estoque != null ? estoque.getId() : null;
		this.origem = origem;
		this.quantidade = quantidade;
		this.enderecoIdDestino = enderecoIdDestino;
		this.unitizadorIdDestino = unitizadorIdDestino;

		if (!CollectionUtils.isEmpty(reservasDefinitivas))
			this.reservasDefinitivas.addAll(reservasDefinitivas);

		validateIntegrity(this).ifPresent(violations -> {
			throw new WMSBloqueioMovimentacaoEstoqueConstraintException(violations);
		});

	}

	public Optional<EnderecoId> getEnderecoIdDestino() {
		return Optional.ofNullable(this.enderecoIdDestino);
	}

	public Optional<UnitizadorId> getUnitizadorIdDestino() {
		return Optional.ofNullable(this.unitizadorIdDestino);
	}

	public void adicionarReservaDefinitivaEstoque(ReservaDefinitivaEstoque reservaDefinitivaEstoque,
												  List<EstoqueAtributoSaldo> estoqueAtributos) {
		adicionarReservaDefinitivaEstoque(reservaDefinitivaEstoque, true, estoqueAtributos);
	}

	private void adicionarReservaDefinitivaEstoque(ReservaDefinitivaEstoque reservaDefinitivaEstoque,
												   boolean validarEstoqueReservaDiferente,
												   List<EstoqueAtributoSaldo> estoqueAtributos) {

		if (validarEstoqueReservaDiferente && !this.estoqueId.equals(reservaDefinitivaEstoque.getEstoqueId()))
			throw new WMSBloqueioMovimentacaoEstoqueReservaDefinitivaNaoPertenceAoEstoqueException();

		if (this.getQuantidadeNaoReservada().compareTo(reservaDefinitivaEstoque.getQuantidade()) < 0)
			throw new WMSBloqueioMovimentacaoEstoqueComReservaNaoRealizadoQuantidadeNaoDeveSerSuperiorSaldoDisponivelParaAssociarReservaException(this.getQuantidadeNaoReservada()
																																					  .toString());

		var estoqueReservaDefinitiva = EstoqueReservaDefinitiva.builder()
															   .reservaDefinitivaEstoqueId(reservaDefinitivaEstoque.getId())
															   .quantidade(reservaDefinitivaEstoque.getQuantidade())
															   .atributos(estoqueAtributos)
															   .build();

		this.reservasDefinitivas.add(estoqueReservaDefinitiva);
	}

	public void removerReservaDefinitivaEstoque(ReservaDefinitivaEstoque reservaDefinitivaEstoque) {
		removerReservaDefinitivaEstoque(reservaDefinitivaEstoque, true);
	}

	private void removerReservaDefinitivaEstoque(ReservaDefinitivaEstoque reservaDefinitivaEstoque,
												 boolean validarEstoqueReservaDiferente) {

		if (validarEstoqueReservaDiferente && !this.estoqueId.equals(reservaDefinitivaEstoque.getEstoqueId()))
			throw new WMSBloqueioMovimentacaoEstoqueReservaDefinitivaNaoPertenceAoEstoqueException();

		this.reservasDefinitivas.removeIf(reserva -> reserva.getReservaDefinitivaEstoqueId()
															.equals(reservaDefinitivaEstoque.getId()));
	}

	public void atualizar(EstoqueId estoqueId,
						  BigDecimal quantidade,
						  ReservaDefinitivaEstoque reservaDefinitivaEstoque,
						  List<EstoqueAtributoSaldo> estoqueAtributos) {

		if (!estoqueId.equals(reservaDefinitivaEstoque.getEstoqueId()))
			throw new WMSBloqueioMovimentacaoEstoqueReservaDefinitivaNaoPertenceAoEstoqueException();

		this.estoqueId = estoqueId;
		this.quantidade = quantidade;

		removerReservaDefinitivaEstoque(reservaDefinitivaEstoque, false);
		adicionarReservaDefinitivaEstoque(reservaDefinitivaEstoque, false, estoqueAtributos);
	}

	public boolean possuiReservaDefinitivaEstoque(ReservaDefinitivaEstoqueId reservaDefinitivaEstoqueId) {
		return this.reservasDefinitivas.stream()
									   .anyMatch(reserva -> reserva.getReservaDefinitivaEstoqueId()
																   .equals(reservaDefinitivaEstoqueId));
	}

	public BigDecimal getQuantidadeReservada() {
		return this.reservasDefinitivas.stream()
									   .map(EstoqueReservaDefinitiva::getQuantidade)
									   .reduce(BigDecimal.ZERO, BigDecimal::add);
	}

	public BigDecimal getQuantidadeNaoReservada() {
		return this.quantidade.subtract(this.getQuantidadeReservada());
	}

	public void aumentarQuantidadeBloqueada(BigDecimal quantidadeNecessaria) {
		this.quantidade = this.quantidade.add(quantidadeNecessaria);
	}
}
