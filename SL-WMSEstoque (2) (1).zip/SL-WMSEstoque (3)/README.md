# SL :: WMS Estoque

[![Build Status](https://dev.azure.com/totvstfs/SuiteLogistica/_apis/build/status/SL-WMS/SL-WMSEstoque?branchName=master)](https://dev.azure.com/totvstfs/SuiteLogistica/_build/latest?definitionId=668&branchName=master)


[![TOTVS SonarQube Project](https://img.shields.io/badge/TOTVS%20SonarQube-%20Project-blue)](https://sonarqube.totvs.io/dashboard?id=com.totvs.sl%3Awms-estoque)

## Desenvolvimento

- Clone o projeto:
    ```bash
    git clone https://totvstfs@dev.azure.com/totvstfs/SuiteLogistica/_git/SL-WMSEstoque
    ```
    ou utilizando `SSH`
    ```bash
    git clone git@ssh.dev.azure.com:v3/totvstfs/SuiteLogistica/SL-WMSEstoque
    ```

- É necessário estar conectado a `VPN TOTVS` para efetuar o download das dependências internas;
- É necessário configurar o feed maven supply-engenharia conforme documentação https://tdn.totvs.com/display/public/EN/Configurando+o+feed+maven+supply-engenharia;

- Importe o projeto em um Editor de código (ex. `Eclipse`);

- Quando `Eclipse`, importe o profile de formatação de código que está em `devops/dev/suitelog-profile-eclipse.xml`;
- Utilize o arquivo `devops/dev/docker-compose.yml` para iniciar os containers necessários para execução do serviço (`Postgresql` e `RabbitMQ`) ou utilize os serviços localmente (se já possuir);

- Execute o serviço com o `profile dev` e o mesmo estará disponível na porta `8281`;

- Diagrama de classe disponível em https://tdn.totvs.com/pages/viewpage.action?pageId=506987418
